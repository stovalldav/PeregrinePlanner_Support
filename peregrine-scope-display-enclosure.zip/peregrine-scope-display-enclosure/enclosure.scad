// First-fit prototype. All units mm. See README.txt before printing.
// part: front, rear, sensor_tab, speaker_bracket, test, layout
part="layout";
$fn=48;
W=100.33; H=116.84; D=38; wall=2.4;
board_w=61.214; board_h=112.014;
glass_w=60.706; glass_h=94.234;
hole_x=51.816; hole_y=102.616; hole_d=3.048;
display_depth=9.652;
// Mic offsets from PCB edges, viewed from screen side.
mic_right=13.462; mic_top=5.588; mic_d=2.032;
strap_spacing=92.71; strap_slot_length=26; strap_slot_gap=3.5;
// Left edge of USB port measured 25.908 from left PCB edge.
usb_x=-board_w/2+25.908+8.89/2;
usb_z=10; // UNKNOWN: adjust after test fitting display with standoffs.
// Reuse existing display brass standoffs: height must be checked physically.
module rounded(w,h,r,z){linear_extrude(z) offset(r=r) square([w-2*r,h-2*r],center=true);}
module corners(){for(x=[-W/2+7,W/2-7])for(y=[-H/2+7,H/2-7])translate([x,y,0])children();}
module sensor_fasteners(){for(x=[-1,33])for(y=[-12,32])translate([x,y,0])children();}
module speaker_fasteners(){for(x=[-24,24])translate([x,-39,0])children();}
module battery_anchor(){difference(){cube([4,14,6],center=false);
 translate([-1,2,2])cube([6,10,2.5]);}}
module sensor_tab(){difference(){linear_extrude(2.4) hull(){translate([0,0])circle(r=3.5);translate([5,0])circle(r=3);}
 translate([0,0,-1])cylinder(h=5,d=3.4);}}
module speaker_bracket(){difference(){union(){difference(){rounded(43.64,31.194,2,2.4);
 translate([0,0,-1])cube([38.64,26.194,8],center=true);}
 for(x=[-24,24])translate([x,0,0])cylinder(h=2.4,d=10);
 // Connect screw ears to perimeter ring.
 for(x=[-22,22])translate([x,0,1.2])cube([8,8,2.4],center=true);}
 for(x=[-24,24])translate([x,0,-1])cylinder(h=5,d=3.4);}}
module front(){difference(){rounded(W,H,5,wall);
 translate([0,0,wall/2])cube([glass_w+.6,glass_h+.6,wall+2],center=true);
 for(x=[-hole_x/2,hole_x/2])for(y=[-hole_y/2,hole_y/2])translate([x,y,-1])cylinder(h=wall+2,d=3.3);
 corners()translate([0,0,-1])cylinder(h=wall+2,d=3.4);
 translate([board_w/2-mic_right,board_h/2-mic_top,-1])cylinder(h=wall+2,d=mic_d);
}}
module rear(){difference(){union(){difference(){rounded(W,H,5,D-wall);
 translate([0,0,wall])rounded(W-2*wall,H-2*wall,3,D);
 }
 // Cover screw posts, M3 through bolts and nuts; verify hardware length.
 corners()cylinder(h=D-wall,d=9);
 // Component locating fences, open tops; retain with removable straps/adhesive.
 // Rear interior is z=wall; front bezel mates at z=D-wall.
 translate([-23,14,wall])difference(){cube([38.3,69.5,3],center=true);cube([36.3,67.5,9],center=true);}
 translate([16,14,wall])difference(){cube([32.7,72.9,3],center=true);cube([30.7,70.9,9],center=true);}
 // Speaker 40.64 x 28.194 x 10.16; grille faces rear.
 translate([0,-39,wall])difference(){cube([43.64,31.194,3],center=true);cube([41.64,29.194,9],center=true);}
 // Battery strap anchors for a separate 8-10 mm wide hook-and-loop strap.
 for(x=[-46.3,-4.5])translate([x,7,wall-.1])battery_anchor();
 // PCB rests on 2 mm high edge supports; check solder clearance.
 for(x=[1.2,29.3])translate([x,-19.5,wall-.1])cube([1.5,67,2.1]);
 sensor_fasteners()translate([0,0,wall-.1])cylinder(h=2.1,d=5);
 speaker_fasteners()translate([0,0,wall-.1])cylinder(h=10.26,d=7);
 }
 corners()translate([0,0,-1])cylinder(h=D+2,d=3.4);
 sensor_fasteners()translate([0,0,-1])cylinder(h=D+2,d=3.4);
 speaker_fasteners()translate([0,0,-1])cylinder(h=D+2,d=3.4);
 // USB notch through bottom wall, generous cable plug clearance.
 translate([usb_x,-H/2, D-wall-usb_z])cube([12.9,wall*4,10.35],center=true);
 // Left-wall strap slots. Long axis follows case depth, centers along height.
 for(y=[-strap_spacing/2,strap_spacing/2])translate([-W/2,y,(D-wall)/2])cube([wall*2+.8,strap_slot_gap,strap_slot_length],center=true);
 // Sound slots remain inside speaker footprint.
 for(x=[-15,-10,-5,0,5,10,15])translate([x,-39,wall/2])cube([2,18,wall+2],center=true);
}}
module test(){front();}
if(part=="front") front();
else if(part=="rear") rear();
else if(part=="sensor_tab") sensor_tab();
else if(part=="speaker_bracket") speaker_bracket();
else if(part=="test") test();
else {translate([-W/2-5,0,0])front();translate([W/2+5,0,0])rear();}
