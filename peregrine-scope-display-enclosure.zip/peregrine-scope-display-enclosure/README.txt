SPOTTING SCOPE DISPLAY ENCLOSURE — FIRST-FIT PROTOTYPE

Measurements interpreted as inches and converted to millimeters.
Outside: 100.33 wide x 116.84 tall x 38 deep mm.
Two pieces: front bezel and deep rear tray, four corner through bolts.

IMPORTANT FIT LIMITS
This is a prototype, not a verified production enclosure.
Print front.stl first to check screen opening and display mounting holes.
Mounting holes assumed symmetric about the PCB center. Glass assumed centered
on the PCB. Confirm both before printing the rear.
The front opening clears the entire black glass; it does not overlap or clamp it.
Use the existing display mounting hardware; the correct standoff height must
place glass at the bezel without pressing on it. Do not clamp the glass.
Display depth measured 9.652 mm. Sensor assembly depth 18.542 mm.
38 mm exterior depth allows 33.2 mm interior depth: approximately 5 mm extra
for the combined component depths. Standoffs/connectors/wires may require more.
Check physical stack height before assembling.

USB is assumed centered approximately 0.254 mm left of PCB center, calculated
from 25.908 mm from PCB left edge to USB left edge and 8.89 mm port/plug width.
Reported equal left and right distances do not exactly reconcile with PCB width.
USB notch is 12.9 wide x 10.35 high; its depth coordinate is provisional.
Adjust usb_x and usb_z in enclosure.scad after the front fit test.
Reset/boot and microSD require opening the rear in this first version.

Battery pocket: upper left, 36.3 x 67.5 mm clear interior, low locating fences.
Sensor pocket: upper right, 30.7 x 70.9 mm clear interior, low locating fences.
Install BNO055 end toward enclosure top; keep sensor orientation fixed.
Speaker: bottom rear, measured 40.64 x 28.194 x 10.16 mm. Pocket is
41.64 x 29.194 mm clear, with seven sound slots in rear wall.
Speaker is assumed rectangular with its sound face against the rear grille.
Its mounting ears, connector projection and diaphragm clearance are unknown.
Use removable retention around the speaker frame, not over its diaphragm.
Speaker magnet may distort BNO055 heading. Verify compass while speaker is
installed, powered off and playing. If heading shifts or accuracy degrades,
move speaker or sensor outside the case. Calibration alone may not suffice.
RETENTION PARTS ADDED
Battery: two integrated strap anchors at sides of battery pocket. Thread a
separate 8-10 mm wide hook-and-loop strap through both 10 x 2.5 mm passages
and over battery. Tighten gently; do not compress pouch. Strap not supplied.
BNO055 PCB: 2 mm high edge supports plus four M3 through-bolt positions.
Print sensor_tab.stl FOUR times. Tabs pivot inward to overlap PCB edges.
Use washers/spacers as needed so tabs press only bare PCB edges, never sensor,
solder, traces or wires. Right-side tabs rotate 180 degrees toward PCB.
PCB thickness and solder protrusion were not individually measured: verify
2 mm underside clearance. Adjust support height in source if insufficient.
M3 screw heads sit outside rear. Nuts/washers secure tabs inside. Use suitable
spacers under tabs to keep them level and avoid bending PCB. Tighten gently.
Sensor support adds 2 mm to component stack; check display/wire clearance.
Speaker: print speaker_bracket.stl ONCE. Ring overlaps speaker outer perimeter
by 1 mm per edge, and mounts to two posts using M3 bolts through rear floor.
Speaker posts are 10.16 mm above rear interior. Add thin compliant frame pads
if needed, and adjust post height if frame geometry differs from measured depth.
Ring must contact rigid speaker frame, never diaphragm. Check fit before use.
Hardware: four M3 bolts/nuts/washers for PCB tabs, two for speaker bracket,
plus original four cover bolts and display mounting hardware. Select bolt
length after measuring actual assembled stack; ends must clear display.
The retainers are prototypes and need a physical fit check.
Mic hole: 2.032 mm diameter in front bezel; center 13.462 mm from display
PCB right edge and 5.588 mm from PCB top edge, viewed from screen side.
Assumes PCB centered and mic acoustic inlet faces front. Confirm inlet direction
and that mounting hardware does not obstruct the acoustic path.
Left-wall strap slots: 26 mm long along case depth x 3.5 mm along case height,
for 24.384 mm strap. Centers spaced 92.71 mm along height (3.65 inches).
Slot centers are 12.065 mm from top and bottom outside enclosure edges.
These are two openings into the case; route/retain strap internally without
pressing on battery, wires or components. No external strap bridges provided.
Corner screws: 3.4 mm clearance holes. Use suitable M3 bolts and external nuts.
Choose length after fitting; protruding screw ends must not touch components.
Recalibrate/check BNO055 compass in final assembly with the scope and hardware.
No weather seal or waterproof rating is provided.

EDITING / EXPORT
Open enclosure.scad in OpenSCAD. Change part to front or rear, render (F6),
then export STL. The included STL files are exported from this source.
Keep all dimensions in millimeters. A physical test fit is required.
