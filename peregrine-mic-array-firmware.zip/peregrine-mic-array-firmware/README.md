# Peregrine Planner — DIY Directional Mic Array Firmware

Arduino sketches for the optional hardware accessories that add sound
direction-finding (and, on a camera node, photo/video capture) to
Peregrine Planner's Bird Sounds Detection. This is a hobbyist build, not
a product.

## What's in here

| Folder | Board | Purpose |
| --- | --- | --- |
| `PeregrineMicArray/` | ESP32-S3 (e.g. XIAO ESP32-S3 or a dev board) + 2–4 INMP441 I2S mics, optional ATGM336H GPS + PPS | The stationary front array. Streams audio + direction-of-arrival to the app over Wi-Fi UDP; advertises itself over BLE. |
| `PeregrineMicArrayCam/` | ESP32-S3 **with PSRAM** + OV3660 camera + 2–4 INMP441 mics, optional GPS | A camera node: everything the mic array does, plus still capture, video recording, and a rough live preview. `HOME_ASSISTANT.md` covers using one as a standalone feeder cam. |

Each folder has its own `README.md` with the full **wiring** (pin
tables), **parts list**, **Arduino IDE / arduino-cli setup**, and
**first-time setup / calibration** steps. Start there.

## Before you flash

Open `Config.h` in the folder you're building and set your own network:

- `kWiFiSSID` / `kWiFiPassword` — the network the node joins. The shipped
  default is the array's own hosted AP (`PeregrineMicArray` / `birding123`);
  change it to your home Wi-Fi or phone hotspot if you'd rather the node
  join an existing network.
- `kWiFiCandidates[]` — optional ordered list of fallback networks.
- GPS / camera / mic-count toggles as documented inline.

`Config.h` is heavily commented — every option explains what it does and
what the trade-offs are. You can keep your edits in a `Config.local.h`
next to it (git-ignored in the source repo) if you prefer, but a plain
edit to `Config.h` is fine for a single build.

## Requirements

- Arduino IDE 2.x (or arduino-cli) with the **esp32 by Espressif** board
  package.
- Board: ESP32-S3. The camera node needs a variant with PSRAM
  (`PartitionScheme = huge_app`, `PSRAM = OPI` — see its README).
- Libraries: TinyGPSPlus (only if you wire the optional GPS).

## Pairing with the app

1. Flash the node and power it on.
2. In Peregrine Planner, turn on **Settings ▸ Mic Array ▸ Enable Mic
   Array Integration**. A **Mic Array** tab appears.
3. If the node joined its own AP, join that Wi-Fi on your phone
   (`PeregrineMicArray` / `birding123` by default). If it joined your
   home network / hotspot, just make sure the phone is on the same one.
4. The app auto-discovers the node over BLE and Wi-Fi. Use the clap
   self-test on the Mic Array screen to confirm direction readings before
   heading out.
