# Peregrine Planner — Mic Array & Camera Node Firmware

Firmware for the optional, separately-built hardware accessories that extend Peregrine Planner's
Bird Sounds Detection screen. These are DIY hobbyist builds (ESP32-S3 + INMP441 MEMS microphones,
Arduino IDE) — not commercial products, and not required for anything else in the app.

## What's in this download

- **`PeregrineMicArray/`** — the main unit. A 4-microphone array that measures left-right
  direction (azimuth) for bird calls the app detects. Start here; this is the only unit you need
  to get direction-finding working. See its `README.md` for wiring, parts, and setup.
- **`PeregrineMicArrayCam/`** — a camera-equipped node. Adds an OV2640 camera (and, optionally, a
  GPS module) to a mic node, so it can photograph or record video of a bird when its own
  audio/motion detection fires, and report its position for the app's Mic Array Map. It can run
  alongside a `PeregrineMicArray/` unit as part of a small fleet, or host its own network as the
  primary node. See its `README.md` for the camera/GPS wiring table and the 2-mic vs 4-mic variants.

Each folder is a self-contained Arduino sketch. They intentionally duplicate a few shared files
(`NetworkProtocol.h`, `DOAEstimator.*`, etc.) byte-for-byte, since Arduino sketches can't share
headers across folders — don't try to merge them.

## Configuration

Each sketch's `Config.h` ships with safe defaults:

- Wi-Fi network it hosts (or joins): SSID `PeregrineMicArray`, password `birding123`. Change these
  in `Config.h` before flashing if you want a different network.
- To add fallback networks (a phone hotspot, home Wi-Fi) for a node that joins as a client rather
  than hosting, fill in the `kWiFiCandidates[]` list near the top of `Config.h` — it ships with
  commented-out examples showing the format. Put your real credentials there locally; don't commit
  them.
- Camera node only: pick the 2-mic + GPS or 4-mic variant with `kMicCount`, and set `kNodeType` /
  network role as described in its `README.md`.

## Setup overview

1. Build and flash `PeregrineMicArray/` first (Arduino IDE — see that folder's README for the
   full parts list, wiring diagram, and calibration steps).
2. In the Peregrine Planner app, go to More → Settings → Mic Array, join the array's Wi-Fi
   network in your device's Wi-Fi settings, and enable the feature.
3. Optional: build and flash `PeregrineMicArrayCam/`, join it to the same network, and add it
   from More → Settings → Mic Array → Additional Mic Array Nodes (or let Auto-Discover find it).

Each folder's own README has the real detail — hardware you'll need, exact wiring, known issues,
and troubleshooting notes from real-device testing. This is a from-scratch electronics build, so
expect to spend some time on it even with the instructions.
