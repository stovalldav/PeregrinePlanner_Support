# Peregrine Planner — DIY Directional Mic Array Firmware

Arduino sketches for the optional hardware accessories that add sound
direction-finding (and, on a camera node, photo/video capture, and on
the security variant, presence detection + a speaker) to Peregrine
Planner. This is a hobbyist build, not a product.

## What's in here

| Folder | Board | Purpose |
| --- | --- | --- |
| `PeregrineMicArray/` | ESP32-S3 (e.g. XIAO ESP32-S3 or a dev board) + 2–4 INMP441 I2S mics, optional ATGM336H GPS + PPS | The stationary front array. Streams audio + direction-of-arrival to the app over Wi-Fi UDP; advertises itself over BLE. |
| `PeregrineMicArrayCam/` | ESP32-S3 **with PSRAM** + OV3660 camera + 2–4 INMP441 mics, optional GPS | A camera node: everything the mic array does, plus still capture, video recording, and a rough live preview. On a 2-mic build, an optional DFRobot C4002 mmWave presence sensor (replaced the old optional PIR) adds presence alerts and presence-triggered photos. `HOME_ASSISTANT.md` covers using one as a standalone feeder cam and the C4002 wiring. |
| `PeregrineMicArrayCampingSecurity/` | ESP32-S3-CAM (GOOUUU V1.5) + OV5640 camera + 2 INMP441 mics + a DFRobot mmWave presence sensor (**C4001** or **C4002** — auto-detected) + NS4168 speaker, optional BNO055 compass | A camera node that also doubles as an unattended camping or home security camera — presence-triggered capture and alerts, a siren, live "speak through the node" voice playback, and a real Home Assistant MQTT integration. C4001, C4002, and the optional compass all confirmed on real hardware. The sensor's detection range and hold time are set from the app and saved on the node, and the app shows a live distance / speed / approaching-or-away readout. See its own `README.md` for wiring (the C4002 needs 5V on VCC; the compass uses GPIO48, which also drives the onboard LED) and camera orientation. |

**`Peregrine-Node-Wiring.pdf`** (in this folder) is a one-page printable pin sheet for all four
builds, including the optional compass and radar.
`PeregrineMicArrayCampingSecurity/Security-Node-Drill-Template.pdf` is a 1:1 drill template for
that node's enclosure (print at 100%).

Each folder has its own `README.md` with the full **wiring** (pin
tables), **parts list**, **Arduino IDE / arduino-cli setup**, and
**first-time setup / calibration** steps. Start there.

## Before you flash

Open `Config.h` in the folder you're building and set your own network:

- `kWiFiSSID` / `kWiFiPassword` — the network the node joins. The shipped
  default is the array's own hosted AP (`PeregrineMicArray` / `birding123`);
  change it to your home Wi-Fi or phone hotspot if you'd rather the node
  join an existing network.
- `kWiFiCandidates[]` — optional ordered list of fallback networks, each
  with its own enabled/disabled flag you can also flip later from the
  app's Wi-Fi & Role screen without reflashing.
- GPS / camera / mic-count / compass / presence-sensor toggles as documented inline. Nodes with a
  BNO055 now also report full 3-D orientation (tilt / vertical detection) to the app.

`Config.h` is heavily commented — every option explains what it does and
what the trade-offs are. You can keep your edits in a `Config.local.h`
next to it (git-ignored in the source repo) if you prefer, but a plain
edit to `Config.h` is fine for a single build.

Once a node is on the network, most of the above — Wi-Fi networks and
role, access-point password, direction sensitivity, heading source — can
also be changed later from the app itself (Mic Array tab ▸ Fleet, tap the
node's row) without reflashing. A change that leaves a node unable to
reach any of its enabled networks automatically reverts to its last
working settings after about 3 minutes, so a bad remote change can't
permanently lock you out of a node.

## Requirements

- Arduino IDE 2.x (or arduino-cli) with the **esp32 by Espressif** board
  package.
- Board: ESP32-S3. The camera nodes need a variant with PSRAM
  (`PartitionScheme = huge_app`, `PSRAM = OPI` — see their READMEs).
- Libraries: TinyGPSPlus (only if you wire the optional GPS on
  `PeregrineMicArray`/`PeregrineMicArrayCam`); `PubSubClient` (only if
  you use `PeregrineMicArrayCampingSecurity`'s Home Assistant
  integration).

## Pairing with the app

1. Flash the node and power it on.
2. In Peregrine Planner, turn on **Settings ▸ Mic Array ▸ Enable Mic
   Array Integration**. A **Mic Array** tab appears (Fleet / Map / Camera).
3. If the node joined its own AP, join that Wi-Fi on your phone
   (`PeregrineMicArray` / `birding123` by default, or a per-chip default
   password shown in the app if you've turned that on). If it joined your
   home network / hotspot, just make sure the phone is on the same one.
4. The app auto-discovers the node over BLE and Wi-Fi on the Fleet
   screen. Tap the node's row for its clap self-test to confirm direction
   readings before heading out, along with its GPS status, heading
   source, and Wi-Fi & Role settings.
5. On a `PeregrineMicArrayCampingSecurity` build, the Camera tab opens the
   **Camera Console**: arm the security nodes (Off / Camping / Home), see
   each camera's latest picture with live presence badges, and get
   presence alerts on your phone. Tap a node for Hold to talk, Siren,
   Snapshot, Record, and its settings; the gear opens Camera Setup, where
   Home Security mode's Home Assistant (MQTT broker) settings live.
