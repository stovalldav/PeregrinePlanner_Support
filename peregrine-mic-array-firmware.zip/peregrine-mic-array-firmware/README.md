# Peregrine Planner — Directional Mic Array Firmware

Firmware for the optional, separately-built hardware accessory that adds direction-finding to
Peregrine Planner's Bird Sounds Detection screen. This is a DIY hobbyist build (ESP32-S3 +
INMP441 MEMS microphones, Arduino IDE) — not a commercial product, and not required for anything
else in the app.

## What's in this download

- **`PeregrineMicArray/`** — the main unit. Required. A 4-microphone array that measures left-right
  direction (azimuth) for bird calls the app detects. Start here; this is the only unit you need
  to get direction-finding working. See its `README.md` for wiring, parts, and setup.
- **`PeregrineMicArrayRearSensor/`** — optional companion unit. Only build this if you want to
  resolve the main array's front/back blind spot (it can tell left from right, but not whether a
  sound is in front of it or behind it). Requires the main array to already be built and running.
  See its `README.md`.

## Setup overview

1. Build and flash `PeregrineMicArray/` first (Arduino IDE — see that folder's README for the
   full parts list, wiring diagram, and calibration steps).
2. In the Peregrine Planner app, go to More → Settings → Mic Array, join the array's
   `PeregrineMicArray` Wi-Fi network when prompted, and enable the feature.
3. Optional: build and flash `PeregrineMicArrayRearSensor/` and enable it from the same Settings
   screen once it's powered on and connected to the main array.

Each folder's own README has the real detail — hardware you'll need, exact wiring, known issues,
and troubleshooting from real-device testing. This is a from-scratch electronics build, so expect
to spend some time on it even with the instructions.
