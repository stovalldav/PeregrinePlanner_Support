// Config.h — pins, WiFi credentials, and tunable constants for the Peregrine Mic Array Rear
// Sensor accessory.
//
// This is a single-INMP441 companion to the main 4-mic PeregrineMicArray unit (see
// ../PeregrineMicArray/), rigidly mounted to the same enclosure/structure, facing the OPPOSITE
// direction from that array's "FRONT" mark -- i.e., this mic's capsule points toward what the
// front array calls "behind." The whole point of this unit depends on that mount being fixed and
// rigid: a lone mic has no pair to cross-correlate against, so it CANNOT compute a bearing on its
// own, and there's no per-placement calibration step here (no compass, no position entry) the way
// a genuinely independent, movable sensor would need. See MIC_ARRAY_MULTI_UNIT_PLAN.md (repo
// root) for the actual design this feeds: the phone compares this unit's loudness against the
// front array's own onset level for roughly-contemporaneous events, to flag/correct the front
// array's known front-back blind spot (it "never indicates behind" on its own -- see that unit's
// DOAEstimator.h/Config.h) and give a coarse proximity cue -- not to independently triangulate a
// position.
//
// GPIO choices below avoid ESP32-S3 strapping pins (0, 3, 45, 46) and the native-USB pins.
#pragma once

#include <cstdint>

namespace Config {

// ---- I2S pin (matches the actual build) ----
constexpr int kDIN  = 4; // INMP441 SD
constexpr int kBCLK = 5;
constexpr int kWS   = 6;

// ---- Audio ----
constexpr uint32_t kSampleRateHz = 44100;
// INMP441 outputs 24-bit samples left-justified in a 32-bit I2S slot.
constexpr int kI2SBitsPerSample = 32;

// ---- WiFi ----
// Joins the front array's own SoftAP as a station -- NOT its own access point. Must match that
// unit's Config.h exactly (../PeregrineMicArray/Config.h's kWiFiSSID/kWiFiPassword).
constexpr const char *kWiFiSSID = "PeregrineMicArray";
constexpr const char *kWiFiPassword = "birding123";
// Static IP, deliberately outside the front array's SoftAP DHCP lease pool (which starts at
// 192.168.4.2) so this unit's self-assigned address can never collide with the one handed out to
// the phone. No mDNS/discovery needed as a result -- the phone can hardcode this address the same
// way it already hardcodes the front array's own fixed 192.168.4.1.
constexpr uint8_t kStaticIP[4] = {192, 168, 4, 20};
constexpr uint8_t kGateway[4]  = {192, 168, 4, 1}; // the front array's own AP gateway address
constexpr uint8_t kSubnet[4]   = {255, 255, 255, 0};
constexpr uint32_t kWiFiConnectTimeoutMs = 15000;

// ---- UDP ----
constexpr uint16_t kUDPPort = 3333; // same port as the front array -- different device, no conflict
constexpr uint32_t kStreamingInactivityTimeoutMs = 10000;

// ---- Level telemetry ----
// See NetworkProtocol.h's RearSensorTelemetryPacket comment for why this streams continuously
// rather than being gated on this unit's own onset trigger.
constexpr uint32_t kTelemetryIntervalMs = 100; // 10Hz

// ---- Onset gate (envelope smoothing/outlier-rejection tuning) ----
// Same defaults as the front array's Config.h -- re-tune independently if this unit's ambient
// noise floor or mic sensitivity differs once real hardware data is in.
constexpr float kOnsetFastEnvelopeAlpha = 0.6f;
constexpr float kOnsetFloorDownAlpha = 0.01f;
constexpr float kOnsetFloorUpAlpha = 0.0001f;
constexpr float kOnsetTriggerRatio = 4.0f;
constexpr uint32_t kOnsetMinHoldMs = 5;
constexpr uint32_t kOnsetMinIntervalMs = 175;
constexpr float kOutlierRejectRatio = 6.0f;

} // namespace Config
