// PeregrineMicArrayRearSensor — ESP32-S3 + single INMP441, companion accessory to
// PeregrineMicArray (see ../PeregrineMicArray/).
//
// Rigidly mounted to the same enclosure/structure as the front 4-mic array, facing the OPPOSITE
// direction from that unit's "FRONT" mark. A lone mic has no pair to cross-correlate against, so
// this firmware makes no attempt at a bearing -- it only tracks and streams a smoothed loudness
// figure. See ../../MIC_ARRAY_MULTI_UNIT_PLAN.md (repo root) for what the phone app does with it:
// compares this unit's level against the front array's own onset level for roughly-contemporaneous
// events, to flag/correct that unit's known front-back blind spot (see its DOAEstimator.h) and
// give a coarse proximity cue -- not to independently triangulate a position. This only works
// because the mount is fixed and rigid relative to the front array; there's no per-placement
// calibration here (no compass, no position entry) the way a genuinely independent sensor would need.
//
// Joins the front array's own SoftAP as a WiFi station (see Config.h) -- it does not run its own
// access point.
//
// Uses Serial0 (UART), not Serial (native USB CDC) -- matches the front array's firmware; see its
// PeregrineMicArray.ino header comment for why (native-USB Serial silently stops working after
// re-initialization on this board).

#include <WiFi.h>
#include "Config.h"
#include "NetworkProtocol.h"
#include "I2SCapture.h"
#include "OnsetDetector.h"
#include "UDPStreamer.h"

// Matches the front array's own read-block size (see that unit's PeregrineMicArray.ino) --
// small enough to keep the envelope follower responsive, large enough to not thrash the I2S DMA.
static const int kReadBlockFrames = 256;

I2SBus bus;
UDPStreamer network;
OnsetDetector onset;

uint32_t telemetrySeq = 0;

// Read success/failure counters, surfaced periodically in loop() -- same pattern as the front
// array's own topReadOk/topReadFail (see that unit's PeregrineMicArray.ino).
volatile uint32_t readOk = 0;
volatile uint32_t readFail = 0;

// Raw sample min/max from the single most recent block, both channels -- bring-up diagnostic so
// a real hardware fault (dead mic, no clock reaching it, no power) can be told apart from "the
// mic is fine but too quiet/gated out," directly from the wire rather than through the onset
// detector's derived envelope. Real silence still produces small nonzero values (room noise,
// self-noise); a true [0,0] here on both channels means the ESP32 isn't receiving real PDM/PCM
// data from the mic at all.
volatile int16_t lastBlockLeftMin = 0;
volatile int16_t lastBlockLeftMax = 0;
volatile int16_t lastBlockRightMin = 0;
volatile int16_t lastBlockRightMax = 0;

void captureTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!bus.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            readFail++;
            continue;
        }
        readOk++;

        int16_t leftMin = blockLeft[0], leftMax = blockLeft[0];
        int16_t rightMin = blockRight[0], rightMax = blockRight[0];
        for (int i = 1; i < kReadBlockFrames; i++) {
            leftMin = min(leftMin, blockLeft[i]);
            leftMax = max(leftMax, blockLeft[i]);
            rightMin = min(rightMin, blockRight[i]);
            rightMax = max(rightMax, blockRight[i]);
        }
        lastBlockLeftMin = leftMin;
        lastBlockLeftMax = leftMax;
        lastBlockRightMin = rightMin;
        lastBlockRightMax = rightMax;

        // The single INMP441 must have its L/R pin tied to GND (left-select) per the README's
        // wiring note -- only blockLeft carries real audio. If it's wired to VDD instead, swap
        // this to blockRight (and update the README to match).
        onset.processBlock(blockLeft, kReadBlockFrames, millis());
    }
}

void setup() {
    Serial0.begin(115200);
    delay(1500); // let the host's terminal attach before the first print
    Serial0.println("[boot] checkpoint 1: Serial0 ready");

    Serial0.println("[boot] checkpoint 2: starting I2S bus (single mic)");
    if (!bus.begin(I2S_NUM_0, Config::kBCLK, Config::kWS, Config::kDIN, Config::kSampleRateHz)) {
        Serial0.println("[boot] I2S bus init failed");
    } else {
        Serial0.println("[boot] checkpoint 3: I2S bus ready");
    }

    Serial0.println("[boot] checkpoint 4: joining WiFi (station mode, front array's SoftAP)");
    if (!network.begin()) {
        Serial0.println("[boot] WiFi connect failed/timed out -- check the front array is powered on and broadcasting, and that Config.h's SSID/password match it exactly");
    } else {
        Serial0.printf("[boot] checkpoint 5: WiFi connected, IP %s\n", WiFi.localIP().toString().c_str());
    }

    xTaskCreatePinnedToCore(captureTask, "capture", 4096, NULL, 2, NULL, 0);
    Serial0.println("[boot] checkpoint 6: capture task started, entering loop()");
}

void loop() {
    network.poll();

    // Streamed continuously while a session is active -- see NetworkProtocol.h's
    // RearSensorTelemetryPacket comment for why this isn't gated on an onset trigger.
    static uint32_t lastTelemetryMs = 0;
    uint32_t now = millis();
    if (now - lastTelemetryMs >= Config::kTelemetryIntervalMs) {
        lastTelemetryMs = now;
        network.sendRearSensorTelemetry(telemetrySeq++, now, onset.lastRelativeLevel());
    }

    // Periodic status/level summary -- printed directly so this unit can be validated in the
    // Serial Monitor without the phone connected, matching the front array's own
    // calibration-friendly logging (see its PeregrineMicArray.ino).
    static uint32_t lastStatusMs = 0;
    if (now - lastStatusMs >= 2000) {
        lastStatusMs = now;
        Serial0.printf(
            "[status] read: %lu ok / %lu fail   wifi: %s   streaming: %s\n",
            (unsigned long)readOk, (unsigned long)readFail,
            WiFi.status() == WL_CONNECTED ? "connected" : "disconnected",
            network.isStreaming() ? "yes" : "no"
        );
        Serial0.printf(
            "[onset] fast: %.1f  floor: %.1f  threshold: %.1f  outliers_rejected: %lu\n",
            onset.currentFastEnvelope(), onset.currentSlowFloor(), onset.currentThreshold(),
            (unsigned long)onset.outlierRejectedCount()
        );
        Serial0.printf(
            "[raw] left: [%d, %d]  right: [%d, %d]\n",
            lastBlockLeftMin, lastBlockLeftMax, lastBlockRightMin, lastBlockRightMax
        );
    }
}
