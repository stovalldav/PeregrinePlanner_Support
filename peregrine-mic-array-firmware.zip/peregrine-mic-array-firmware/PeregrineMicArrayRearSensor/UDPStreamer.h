// UDPStreamer.h — WiFi station (joins the front array's own SoftAP, see Config.h) + the UDP
// control/telemetry socket for the rear sensor accessory. Reuses the front array's own
// ping/session-start/stop control protocol (NetworkProtocol.h) so the phone-side connection code
// can eventually treat both units' handshake/session lifecycle the same way.
#pragma once

#include <cstdint>
#include <WiFiUdp.h>
#include "NetworkProtocol.h"

class UDPStreamer {
public:
    // Joins the front array's SoftAP as a station with a fixed static IP (Config.h) and opens the
    // local UDP socket. Blocks (with a timeout) until WiFi actually connects -- there's no useful
    // fallback mode without it, so the caller should treat a false return as fatal for this
    // unit's purpose (check the front array is powered on and the SSID/password match).
    bool begin();

    // Call every loop() iteration: processes any incoming control packets (ping/start/stop) and
    // checks the streaming-inactivity timeout.
    void poll();

    bool isStreaming() const { return streaming_; }

    void sendRearSensorTelemetry(uint32_t seq, uint32_t timestampMs, float relativeLevel);

private:
    void handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort);

    WiFiUDP udp_;
    bool streaming_ = false;
    IPAddress clientIP_;
    uint16_t clientPort_ = 0;
    uint32_t lastClientActivityMs_ = 0;
};
