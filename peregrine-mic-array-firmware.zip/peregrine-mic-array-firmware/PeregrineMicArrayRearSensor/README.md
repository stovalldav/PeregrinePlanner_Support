# Peregrine Mic Array — Rear Sensor Firmware

ESP32-S3 + a single INMP441, an optional companion accessory to `../PeregrineMicArray/` (the main
4-mic direction-finding array). See `../../MIC_ARRAY_MULTI_UNIT_PLAN.md` (repo root) for the full
design and the decisions behind it.

## What this is for

The main 4-mic array can only measure left-right azimuth — it has no way to tell whether a sound
came from in front of it or directly behind it (see that firmware's README, "What this can and
can't do"). This unit doesn't fix that by computing its own bearing — a single mic has no pair to
cross-correlate against, so it can't. Instead:

- Mount it **rigidly to the same enclosure/structure as the front array, facing the exact opposite
  direction** from that array's FRONT mark.
- It streams a smoothed loudness figure (`relativeLevel`) continuously, not a direction.
- The phone app compares this unit's level against the front array's own onset level for
  roughly-contemporaneous events: if the rear sensor is significantly louder, the sound is more
  likely coming from behind the array (the front array's own blind spot) than from wherever its
  reported azimuth points. The relative loudness also serves as a coarse proximity cue.

This only works because the mount is fixed and rigid — there's deliberately no per-placement
calibration in this firmware (no compass, no position entry) the way a genuinely independent,
movable sensor would need. If you want that instead, see `MIC_ARRAY_MULTI_UNIT_PLAN.md`'s "Mode
B — fixed placement" for what a real independent unit requires (its own direction-finding
capability, i.e. a second full 4-mic array, plus a compass-calibrated heading and a known position)
— a single mic can't do that on its own.

## Hardware

- ESP32-S3 dev board (Arduino IDE, "ESP32S3 Dev Module" or your board's specific entry).
- 1x INMP441 I2S MEMS microphone breakout board.

### Wiring

| Signal | Pin |
|---|---|
| SD | GPIO4 |
| BCLK | GPIO5 |
| WS | GPIO6 |

`VDD`→3.3V, `GND`→GND. **`L/R` pin: tie to GND (left-select).** The firmware reads the left
channel only (`I2SCapture`'s `readFrames` still returns a stereo pair regardless — that's just how
the I2S peripheral works — but only `left` carries real audio here). If you wire `L/R` to VDD
instead, swap `blockLeft` for `blockRight` in `PeregrineMicArrayRearSensor.ino`'s `captureTask`.

If GPIO4/5/6 are unavailable on your board, edit `Config.h` — any 3 free GPIOs work, avoiding the
ESP32-S3 strapping pins (0, 3, 45, 46) and the native-USB pins.

## Arduino IDE setup

1. Install the **esp32 by Espressif Systems** board package (same as the front array).
2. Board: your specific ESP32-S3 dev board entry.
3. Open `PeregrineMicArrayRearSensor.ino` — the other files in this folder show as additional
   tabs; that's normal.
4. **Flash the front array first (or make sure it's already powered on and broadcasting)** —
   this unit joins the front array's own WiFi network as a station; it has nothing to connect to
   otherwise.
5. Flash this unit. Open the Serial Monitor at 115200 baud — you should see boot checkpoint lines
   ending with `WiFi connected, IP 192.168.4.20`, then periodic `[status] read: N ok / N fail
   wifi: connected streaming: no` lines. `streaming: no` is expected until the phone app actually
   connects and starts a session — this firmware doesn't print live level readings to Serial
   outside of the periodic `[onset]` summary line, since (unlike the front array's DOA events)
   there's no discrete "event" to print, just a continuous level.

If WiFi never connects: double check `Config.h`'s `kWiFiSSID`/`kWiFiPassword` match
`../PeregrineMicArray/Config.h` exactly, and that the front array is actually powered on (it's the
one running the access point — this unit has nothing to join if it's off).

## Network protocol

See `NetworkProtocol.h` (kept in sync with `../PeregrineMicArray/NetworkProtocol.h` and the app's
`MicArrayProtocol.swift`). Same ping/session-start/session-stop control flow as the front array,
on the same UDP port (3333) — just a different device, at a fixed static IP (`192.168.4.20`)
instead of the front array's own gateway address (`192.168.4.1`). Sends `RearSensorTelemetryPacket`
(`0x07`) continuously (every ~100ms) while a session is active, not gated on an onset trigger — see
that struct's comment in `NetworkProtocol.h` for why.

## Status

Integrated into the phone app: enable it from Settings → Mic Array → "Rear Sensor (Optional
Companion Unit)" once this unit is flashed and powered on alongside the main array. You can also
validate this unit standalone via its Serial output (`[status]`/`[onset]` lines) without the app
running: confirm `read: N ok / 0 fail` climbs and `[onset] fast:` rises when you make noise near
the mic.
