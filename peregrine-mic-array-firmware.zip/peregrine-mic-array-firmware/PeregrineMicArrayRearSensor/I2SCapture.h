// I2SCapture.h — duplicated verbatim from ../PeregrineMicArray/I2SCapture.h (Arduino sketches
// can't share code across folders). Wraps one ESP32-S3 I2S peripheral in standard stereo RX mode.
// This unit only has one physical INMP441, tied to the L-select (GND) pin per the README's wiring
// note -- readFrames() still returns a full stereo pair since that's how the I2S peripheral/driver
// works regardless, but only `left` carries real audio; `right` is whatever the unconnected R slot
// returns and is ignored by the caller.
#pragma once

#include <cstdint>
#include "driver/i2s_std.h"

class I2SBus {
public:
    // `port` is I2S_NUM_0 or I2S_NUM_1. `bclk`/`ws` are this bus's own dedicated clock GPIOs
    // (each bus generates its own, independent of the other). `din` is this bus's data GPIO.
    bool begin(i2s_port_t port, int bclk, int ws, int din, uint32_t sampleRateHz);

    // Blocking read of `frameCount` stereo frames (frameCount samples per channel), bounded to
    // `timeoutMs` -- not portMAX_DELAY, so a stalled bus reports failure and lets the caller's
    // task loop retry rather than blocking forever. Decodes each INMP441's 24-bit-in-32-bit I2S
    // word down to int16 (right-shift by 16: 8 bits to strip the padding, 8 more to reduce
    // 24-bit range to 16-bit — acceptable precision loss for wireless streaming and
    // cross-correlation, both of which only need relative timing/amplitude, not full 24-bit
    // dynamic range). `left`/`right` must each have room for `frameCount` samples.
    bool readFrames(int16_t *left, int16_t *right, int frameCount, uint32_t timeoutMs = 1000);

private:
    i2s_chan_handle_t rxHandle_ = nullptr;
    int32_t *rawBuffer_ = nullptr;
    int rawBufferCapacityFrames_ = 0;
};
