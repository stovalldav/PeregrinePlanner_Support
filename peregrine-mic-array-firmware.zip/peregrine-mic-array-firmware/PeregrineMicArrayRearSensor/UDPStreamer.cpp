#include "UDPStreamer.h"
#include <WiFi.h>
#include "Config.h"

bool UDPStreamer::begin() {
    IPAddress staticIP(Config::kStaticIP[0], Config::kStaticIP[1], Config::kStaticIP[2], Config::kStaticIP[3]);
    IPAddress gateway(Config::kGateway[0], Config::kGateway[1], Config::kGateway[2], Config::kGateway[3]);
    IPAddress subnet(Config::kSubnet[0], Config::kSubnet[1], Config::kSubnet[2], Config::kSubnet[3]);

    WiFi.mode(WIFI_STA);
    // Static config, not DHCP -- this unit's address is fixed and known in advance (see Config.h's
    // comment on why), so the phone can hardcode it the same way it already hardcodes the front
    // array's own 192.168.4.1.
    WiFi.config(staticIP, gateway, subnet);
    WiFi.begin(Config::kWiFiSSID, Config::kWiFiPassword);

    uint32_t startMs = millis();
    while (WiFi.status() != WL_CONNECTED) {
        if (millis() - startMs > Config::kWiFiConnectTimeoutMs) {
            return false;
        }
        delay(250);
    }

    udp_.begin(Config::kUDPPort);
    return true;
}

void UDPStreamer::poll() {
    int packetSize = udp_.parsePacket();
    if (packetSize > 0) {
        uint8_t buf[16];
        int len = udp_.read(buf, sizeof(buf));
        if (len > 0) {
            handlePacket(buf, len, udp_.remoteIP(), udp_.remotePort());
        }
    }

    if (streaming_ && (millis() - lastClientActivityMs_) > Config::kStreamingInactivityTimeoutMs) {
        streaming_ = false;
    }
}

void UDPStreamer::handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort) {
    if (len < 2) return;
    uint8_t type = data[1];

    switch (type) {
        case Protocol::kHandshakePing: {
            Protocol::HandshakePongPacket pong;
            pong.version = Protocol::kVersion;
            pong.type = Protocol::kHandshakePong;
            pong.magic0 = Protocol::kPongMagic0;
            pong.magic1 = Protocol::kPongMagic1;
            udp_.beginPacket(remoteIP, remotePort);
            udp_.write((const uint8_t *)&pong, sizeof(pong));
            udp_.endPacket();
            break;
        }
        case Protocol::kSessionStart: {
            clientIP_ = remoteIP;
            clientPort_ = remotePort;
            streaming_ = true;
            lastClientActivityMs_ = millis();
            break;
        }
        case Protocol::kSessionStop: {
            if (remoteIP == clientIP_ && remotePort == clientPort_) {
                streaming_ = false;
            }
            break;
        }
        default:
            break;
    }
}

void UDPStreamer::sendRearSensorTelemetry(uint32_t seq, uint32_t timestampMs, float relativeLevel) {
    if (!streaming_) return;

    Protocol::RearSensorTelemetryPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kRearSensorTelemetry;
    packet.seq = seq;
    packet.timestampMs = timestampMs;
    packet.relativeLevel = relativeLevel;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}
