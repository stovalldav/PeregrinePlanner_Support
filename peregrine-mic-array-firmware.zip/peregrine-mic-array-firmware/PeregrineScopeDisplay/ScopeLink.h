// ScopeLink.h -- the display's side of the fleet protocol (SCOPE_DISPLAY_PLAN.md §2, §5).
//
// Behaves like any other node toward the app: answers kHandshakePing, records the app as its client
// on kSessionStart, sends kNodeIdentity (nodeType 3). On top of that it parses the app's relayed
// scope packets (ScopeProtocol.h) into gState, and sends card requests / commands back.
//
// It NEVER sends kSessionStart to another node: a node streams to exactly one client, and taking
// that over would silently cut the phone off (plan §5). Talk audio goes to nodes directly from the
// TalkAudio task on its own socket; snapshots are plain HTTP (SnapshotFetcher).
#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include "ScopeState.h"

struct CardResult {
    uint16_t requestId = 0;
    String text;
    uint8_t *jpeg = nullptr; // PSRAM, owned by ScopeLink until the next card request
    size_t jpegLen = 0;
};

class ScopeLink {
public:
    void begin();
    // Loads the outbox from NVS (call once at boot).
    void beginOutbox() { loadOutbox(); }
    // Wi-Fi upkeep, UDP receive/dispatch, periodic identity. Call every loop().
    void poll(uint32_t nowMs);

    // Asks the app for a bird card. Any earlier pending card is discarded. `prefetch` = a download
    // for the SD card (ScopeStorage), not one you tapped -- it's handed to takePrefetchCard instead.
    uint16_t requestCard(const String &common, const String &scientific, bool prefetch = false);
    // True once, when a card you tapped has fully arrived. Also stores it on the SD card.
    bool takeCard(CardResult &out);
    // True once, when a prefetch card has fully arrived: its name and raw payload (valid until the
    // next request).
    bool takePrefetchCard(String &common, const uint8_t *&payload, size_t &len);
    // A card request still worth waiting for. Expires after 30 s, so one that never completes
    // (a lost reply, the app closed) can't block everything behind it -- it used to, forever:
    // "Downloading 0 of 331" with the queue never moving (2026-10-05).
    bool cardPending() const { return cardRequestId_ != 0 && !cardComplete_ && millis() - cardRequestMs_ < 30000; }
    // The pending request is a download for the SD card (not a card you tapped).
    bool prefetchInFlight() const { return cardPending() && cardIsPrefetch_; }
    // Forget the pending request (it timed out); a late reply to it is ignored.
    void cancelCard() { cardRequestId_ = 0; cardComplete_ = false; }
    // Chunks of the pending card received so far / expected (0 = no chunk yet) -- diagnostics.
    void cardProgress(uint16_t &received, uint16_t &expected) const { received = cardChunksReceived_; expected = cardChunkCount_; }

    void sendCommand(uint8_t command, const IPAddress &ip = IPAddress(0, 0, 0, 0));
    // Mark / Saw it / Undo: sent with a seq and resent until the app acks it (it acts on the first
    // copy only), for up to kButtonTimeoutMs. Not queued -- a late Mark would have the wrong place.
    // A new press replaces one still waiting.
    void sendButton(uint8_t command);
    enum class ButtonState : uint8_t { Idle, Waiting, Acked, NoReply };
    // Acked / NoReply are reported once, then it goes back to Idle.
    ButtonState takeButtonState();
    // A target bird checked / unchecked, or "new location", on the display. Applied to the local
    // list right away and queued in the outbox (NVS, survives power-off): sent in order whenever the
    // phone is linked, each one until the app acks it (kScopeAck). Works with the phone out of reach.
    void sendTargetToggle(const String &name, bool seen);
    // Long-press on a target: add `delta` to its count (kScopeCountAdd). Not queued -- the app
    // answers by voice, so a press with the phone away just does nothing.
    void sendCountAdd(const String &name, int8_t delta);
    void sendNewLocation();
    // From the Map view's picker, through the same outbox: start a trip / "I'm at this stop" (which
    // starts its trip if it hasn't been). Shown locally right away.
    void sendStartTrip(const char *tripId);
    void sendArriveAt(const char *stopId);
    // A trip's stop maps on / off (only trips with maps on are made and downloaded).
    void sendTripMaps(const char *tripId, bool on);

    // Stop maps (kScopeMapRequest / kScopeMapData) -- one at a time, separate from cards, so a
    // map download never cancels a card and the other way round. `prefetch` = for the SD card.
    uint16_t requestMap(const char *stopId, uint8_t style, uint8_t level, uint8_t col, uint8_t row, bool prefetch);
    // The tile the pending / last request is for.
    bool mapRequestIs(const char *stopId, uint8_t style, uint8_t level, uint8_t col, uint8_t row) const {
        return mapStyle_ == style && mapLevel_ == level && mapCol_ == col && mapRow_ == row && mapStopId_.equals(stopId);
    }
    bool mapPending() const { return mapRequestId_ != 0 && !mapComplete_ && millis() - mapRequestMs_ < 30000; }
    bool mapPrefetchInFlight() const { return mapPending() && mapIsPrefetch_; }
    void cancelMap() { mapRequestId_ = 0; mapComplete_ = false; }
    void mapProgress(uint16_t &received, uint16_t &expected) const { received = mapChunksReceived_; expected = mapChunkCount_; }
    // True once, when a requested map has fully arrived: which one, and its payload (valid until
    // the next request).
    bool takeMap(String &stopId, uint8_t &style, bool &prefetch, const uint8_t *&payload, size_t &len); // tile ids are in the payload

    bool hasApp() const { return appPort_ != 0; }
    IPAddress appIP() const { return appIP_; }
    uint16_t appPort() const { return appPort_; }
    // Re-send identity now (micCount follows the mic-stream switch).
    void announce() { sendIdentity(); }

    // Mic audio to the app, from THIS socket (port kUDPPort). The app's connection to the display
    // is a connected UDP flow to that port, so iOS drops anything sent from another local port --
    // the talk task's own socket (random port) never reached the classifier. Safe from any task.
    bool sendToApp(const uint8_t *data, size_t len);

private:
    void connectWiFi(uint32_t nowMs);
    void handlePacket(const uint8_t *data, int len, const IPAddress &from, uint16_t fromPort);
    void sendIdentity();
    void sendTo(const uint8_t *data, size_t len, const IPAddress &ip, uint16_t port);

    void onDetection(const uint8_t *d, int len);
    void onCardChunk(const uint8_t *d, int len);
    void onTargets(const uint8_t *d, int len);
    void onFleetStatus(const uint8_t *d, int len);
    void onNodeLive(const uint8_t *d, int len);
    void onSession(const uint8_t *d, int len);
    void onPresence(const uint8_t *d, int len);
    void onTargetList(const uint8_t *d, int len);
    void onAck(const uint8_t *d, int len);
    void onPrefetchList(const uint8_t *d, int len);
    void onTripHistory(const uint8_t *d, int len);
    void onTripPlans(const uint8_t *d, int len);
    void onMapChunk(const uint8_t *d, int len);
    void onPhonePosition(const uint8_t *d, int len);
    void onSpeech(const uint8_t *d, int len);
    void sendMapRequestPacket();
    void pollMapResend(); // asks again for the chunks of the pending map that never came
    void applyOutboxToPlans(); // shows starts / arrivals still waiting for the phone
    static void applyTripCommandLocally(uint8_t kind, const char *id);
    void sendCardStatus();
    void sendHeading();

    // Outbox (see sendTargetToggle)
    // kind 0 toggle, 1 new location, 2 start trip (name = trip id), 3 I'm at this stop (name = stop
    // id), 4 / 5 a trip's maps on / off (name = trip id)
    struct OutboxEntry { uint16_t seq; uint8_t kind; uint8_t seen; char name[49]; };
    static constexpr int kOutboxMax = 48;
    OutboxEntry outbox_[kOutboxMax];
    int outboxCount_ = 0;
    uint16_t nextSeq_ = 1;
    uint32_t lastOutboxSendMs_ = 0;
    uint32_t lastCardStatusMs_ = 0;
    uint32_t lastHeadingMs_ = 0;
    void loadOutbox();
    void saveOutbox();
    void enqueue(uint8_t kind, const String &name, bool seen);
    void pollOutbox(uint32_t nowMs);
    void pollButton(uint32_t nowMs);
    void sendButtonPacket();
    static constexpr uint32_t kButtonResendMs = 400;
    static constexpr uint32_t kButtonTimeoutMs = 6000;
    uint16_t buttonSeq_ = 0;       // own counter, random start each boot (see sendButton)
    uint8_t buttonCommand_ = 0;
    uint32_t buttonStartMs_ = 0;
    uint32_t buttonLastSendMs_ = 0;
    ButtonState buttonState_ = ButtonState::Idle;
    void sendOutboxHead();
    void applyOutboxToList(); // re-applies what's still queued on top of a list from the app
    static void applyNewLocationLocally(TripTargetList &list);

    // Trip-history reassembly
    TripHistory historyStaging_;
    uint16_t historyStagingSeq_ = 0;
    uint8_t historyStagingChunks_ = 0;
    uint32_t historyStagingSeen_ = 0;
    uint16_t historyCommittedSeq_ = 0;
    bool historyHaveCommitted_ = false;

    WiFiUDP udp_;
    // udp_ is used by the main loop and the talk task (sendToApp); WiFiUDP keeps the packet's
    // remote address in the object, so every begin/parse..end/read must hold this.
    SemaphoreHandle_t udpLock_ = xSemaphoreCreateRecursiveMutex();
    bool udpStarted_ = false;
    IPAddress appIP_;
    uint16_t appPort_ = 0;
    uint32_t lastIdentityMs_ = 0;

    int wifiCandidate_ = -1;
    uint32_t wifiAttemptStartMs_ = 0;
    bool wifiWasConnected_ = false;

    // Card reassembly (PSRAM)
    uint16_t nextRequestId_ = 1;
    uint16_t cardRequestId_ = 0;
    uint16_t cardChunkCount_ = 0;
    uint16_t cardChunksReceived_ = 0;
    uint8_t *cardBuffer_ = nullptr;
    uint8_t *cardChunkSeen_ = nullptr;
    bool cardComplete_ = false;
    bool cardTaken_ = false;
    bool cardIsPrefetch_ = false;
    uint32_t cardRequestMs_ = 0;
    String cardCommon_;
    String cardScientific_;

    // Link diagnostics
    uint32_t rxPackets_ = 0, rxPings_ = 0, rxFromApp_ = 0;
    uint32_t lastStatMs_ = 0, maxAppGapMs_ = 0, lastAppSeenMs_ = 0;
    bool wasLinked_ = false;
    void logLinkStats(uint32_t nowMs);

    // Trip-plans reassembly (PSRAM)
    TripPlans planStaging_;
    uint16_t planStagingSeq_ = 0;
    uint8_t planStagingChunks_ = 0;
    uint32_t planStagingSeen_ = 0;
    uint16_t planCommittedSeq_ = 0;
    bool planHaveCommitted_ = false;

    // Map reassembly (PSRAM)
    uint16_t mapRequestId_ = 0;
    uint16_t mapChunkCount_ = 0;
    uint16_t mapChunksReceived_ = 0;
    uint8_t *mapBuffer_ = nullptr;
    uint8_t *mapChunkSeen_ = nullptr;
    bool mapComplete_ = false;
    bool mapTaken_ = false;
    bool mapIsPrefetch_ = false;
    uint32_t mapRequestMs_ = 0;
    uint32_t lastMapChunkMs_ = 0;
    uint32_t lastMapResendMs_ = 0;
    uint32_t mapResendGapMs_ = 300;     // doubles (to 3 s) while asking brings nothing new
    uint16_t chunksAtLastResend_ = 0;
    String mapStopId_;
    uint8_t mapStyle_ = 0, mapLevel_ = 0, mapCol_ = 0, mapRow_ = 0;

    // Target-list reassembly
    TripTargetList targetStaging_;
    uint16_t targetStagingSeq_ = 0;
    uint8_t targetStagingChunks_ = 0;
    uint32_t targetStagingSeen_ = 0; // chunk bitmask (<= 32 chunks)
    uint16_t targetCommittedSeq_ = 0;
    bool targetHaveCommitted_ = false;
};

extern ScopeLink gLink;
