// ScopeLink.h -- the display's side of the fleet protocol (SCOPE_DISPLAY_PLAN.md §2, §5).
//
// Behaves like any other node toward the app: answers kHandshakePing, records the app as its client
// on kSessionStart, sends kNodeIdentity (nodeType 3). On top of that it parses the app's relayed
// scope packets (ScopeProtocol.h) into gState, and sends card requests / commands back.
//
// It NEVER sends kSessionStart to another node: a node streams to exactly one client, and taking
// that over would silently cut the phone off (plan §5). Talk audio goes to nodes directly from the
// TalkAudio task on its own socket; snapshots are plain HTTP (SnapshotFetcher).
#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include "ScopeState.h"

struct CardResult {
    uint16_t requestId = 0;
    String text;
    uint8_t *jpeg = nullptr; // PSRAM, owned by ScopeLink until the next card request
    size_t jpegLen = 0;
};

class ScopeLink {
public:
    void begin();
    // Loads the outbox from NVS (call once at boot).
    void beginOutbox() { loadOutbox(); }
    // Wi-Fi upkeep, UDP receive/dispatch, periodic identity. Call every loop().
    void poll(uint32_t nowMs);

    // Asks the app for a bird card. Any earlier pending card is discarded. `prefetch` = a download
    // for the SD card (ScopeStorage), not one you tapped -- it's handed to takePrefetchCard instead.
    uint16_t requestCard(const String &common, const String &scientific, bool prefetch = false);
    // True once, when a card you tapped has fully arrived. Also stores it on the SD card.
    bool takeCard(CardResult &out);
    // True once, when a prefetch card has fully arrived: its name and raw payload (valid until the
    // next request).
    bool takePrefetchCard(String &common, const uint8_t *&payload, size_t &len);
    // A card request still worth waiting for. Expires after 30 s, so one that never completes
    // (a lost reply, the app closed) can't block everything behind it -- it used to, forever:
    // "Downloading 0 of 331" with the queue never moving (2026-10-05).
    bool cardPending() const { return cardRequestId_ != 0 && !cardComplete_ && millis() - cardRequestMs_ < 30000; }
    // The pending request is a download for the SD card (not a card you tapped).
    bool prefetchInFlight() const { return cardPending() && cardIsPrefetch_; }
    // Forget the pending request (it timed out); a late reply to it is ignored.
    void cancelCard() { cardRequestId_ = 0; cardComplete_ = false; }
    // Chunks of the pending card received so far / expected (0 = no chunk yet) -- diagnostics.
    void cardProgress(uint16_t &received, uint16_t &expected) const { received = cardChunksReceived_; expected = cardChunkCount_; }

    void sendCommand(uint8_t command, const IPAddress &ip = IPAddress(0, 0, 0, 0));
    // A target bird checked / unchecked, or "new location", on the display. Applied to the local
    // list right away and queued in the outbox (NVS, survives power-off): sent in order whenever the
    // phone is linked, each one until the app acks it (kScopeAck). Works with the phone out of reach.
    void sendTargetToggle(const String &name, bool seen);
    void sendNewLocation();

    bool hasApp() const { return appPort_ != 0; }
    IPAddress appIP() const { return appIP_; }
    uint16_t appPort() const { return appPort_; }
    // Re-send identity now (micCount follows the mic-stream switch).
    void announce() { sendIdentity(); }

    // Mic audio to the app, from THIS socket (port kUDPPort). The app's connection to the display
    // is a connected UDP flow to that port, so iOS drops anything sent from another local port --
    // the talk task's own socket (random port) never reached the classifier. Safe from any task.
    bool sendToApp(const uint8_t *data, size_t len);

private:
    void connectWiFi(uint32_t nowMs);
    void handlePacket(const uint8_t *data, int len, const IPAddress &from, uint16_t fromPort);
    void sendIdentity();
    void sendTo(const uint8_t *data, size_t len, const IPAddress &ip, uint16_t port);

    void onDetection(const uint8_t *d, int len);
    void onCardChunk(const uint8_t *d, int len);
    void onTargets(const uint8_t *d, int len);
    void onFleetStatus(const uint8_t *d, int len);
    void onNodeLive(const uint8_t *d, int len);
    void onSession(const uint8_t *d, int len);
    void onPresence(const uint8_t *d, int len);
    void onTargetList(const uint8_t *d, int len);
    void onAck(const uint8_t *d, int len);
    void onPrefetchList(const uint8_t *d, int len);
    void onTripHistory(const uint8_t *d, int len);
    void sendCardStatus();

    // Outbox (see sendTargetToggle)
    struct OutboxEntry { uint16_t seq; uint8_t kind; uint8_t seen; char name[49]; }; // kind 0 toggle, 1 new location
    static constexpr int kOutboxMax = 48;
    OutboxEntry outbox_[kOutboxMax];
    int outboxCount_ = 0;
    uint16_t nextSeq_ = 1;
    uint32_t lastOutboxSendMs_ = 0;
    uint32_t lastCardStatusMs_ = 0;
    void loadOutbox();
    void saveOutbox();
    void enqueue(uint8_t kind, const String &name, bool seen);
    void pollOutbox(uint32_t nowMs);
    void sendOutboxHead();
    void applyOutboxToList(); // re-applies what's still queued on top of a list from the app
    static void applyNewLocationLocally(TripTargetList &list);

    // Trip-history reassembly
    TripHistory historyStaging_;
    uint16_t historyStagingSeq_ = 0;
    uint8_t historyStagingChunks_ = 0;
    uint32_t historyStagingSeen_ = 0;
    uint16_t historyCommittedSeq_ = 0;
    bool historyHaveCommitted_ = false;

    WiFiUDP udp_;
    // udp_ is used by the main loop and the talk task (sendToApp); WiFiUDP keeps the packet's
    // remote address in the object, so every begin/parse..end/read must hold this.
    SemaphoreHandle_t udpLock_ = xSemaphoreCreateRecursiveMutex();
    bool udpStarted_ = false;
    IPAddress appIP_;
    uint16_t appPort_ = 0;
    uint32_t lastIdentityMs_ = 0;

    int wifiCandidate_ = -1;
    uint32_t wifiAttemptStartMs_ = 0;
    bool wifiWasConnected_ = false;

    // Card reassembly (PSRAM)
    uint16_t nextRequestId_ = 1;
    uint16_t cardRequestId_ = 0;
    uint16_t cardChunkCount_ = 0;
    uint16_t cardChunksReceived_ = 0;
    uint8_t *cardBuffer_ = nullptr;
    uint8_t *cardChunkSeen_ = nullptr;
    bool cardComplete_ = false;
    bool cardTaken_ = false;
    bool cardIsPrefetch_ = false;
    uint32_t cardRequestMs_ = 0;
    String cardCommon_;
    String cardScientific_;

    // Link diagnostics
    uint32_t rxPackets_ = 0, rxPings_ = 0, rxFromApp_ = 0;
    uint32_t lastStatMs_ = 0, maxAppGapMs_ = 0, lastAppSeenMs_ = 0;
    bool wasLinked_ = false;
    void logLinkStats(uint32_t nowMs);

    // Target-list reassembly
    TripTargetList targetStaging_;
    uint16_t targetStagingSeq_ = 0;
    uint8_t targetStagingChunks_ = 0;
    uint32_t targetStagingSeen_ = 0; // chunk bitmask (<= 32 chunks)
    uint16_t targetCommittedSeq_ = 0;
    bool targetHaveCommitted_ = false;
};

extern ScopeLink gLink;
