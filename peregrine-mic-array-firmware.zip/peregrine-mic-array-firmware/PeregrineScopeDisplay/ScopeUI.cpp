#include "ScopeUI.h"
#include "Config.h"
#include "JpegImage.h"
#include "ScopeBLE.h"
#include "ScopeCompass.h"
#include "ScopeLink.h"
#include "ScopeProtocol.h"
#include "ScopeState.h"
#include "ScopeStorage.h"
#include "SnapshotFetcher.h"
#include "TalkAudio.h"
#include <Preferences.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <Wire.h>
#include <lvgl.h>

ScopeUI gUI;
void saveMicSetting(bool on); // PeregrineScopeDisplay.ino (NVS)
void saveMicGain(int db);     // PeregrineScopeDisplay.ino (NVS)
void requestPowerOff();       // PeregrineScopeDisplay.ino -- loop() carries it out

// Note: LVGL's built-in Montserrat fonts are ASCII + symbols only -- every string on screen stays
// ASCII ("deg", "*", "..."). The app ASCII-folds bird names and card text before sending them.

namespace {

TFT_eSPI tft(Config::kScreenWidth, Config::kScreenHeight);
lv_disp_draw_buf_t drawBuf;
lv_color_t *buf1 = nullptr;
lv_color_t *buf2 = nullptr;

uint32_t lastTouchMs = 0;
bool dimmed = false;

// ---- Palette (night-friendly dark, one accent) ----
const lv_color_t kBg = lv_color_hex(0x0E1512);
const lv_color_t kSurface = lv_color_hex(0x18231E);
const lv_color_t kBorder = lv_color_hex(0x2C3B34);
const lv_color_t kText = lv_color_hex(0xE6EFE9);
const lv_color_t kMuted = lv_color_hex(0x8FA39A);
const lv_color_t kAccent = lv_color_hex(0x5FBF8F);
const lv_color_t kWarn = lv_color_hex(0xE0A93B);
const lv_color_t kDanger = lv_color_hex(0xE0563B);

// ---- Widgets ----
lv_obj_t *statusWifi, *statusLink, *statusBle, *statusBattery;
lv_obj_t *tabview;
lv_obj_t *tabBirds, *tabRadar, *tabCompass, *tabFleet, *tabCamp, *tabSession;
enum Tab : uint16_t { kTabBirds = 0, kTabRadar, kTabCompass, kTabFleet, kTabCamp, kTabSession };
const uint16_t campTabIndex = kTabCamp;

lv_obj_t *compassRose, *compassHeading, *compassPoint, *compassRef, *compassTilt, *compassStatus;
float smoothedHeading = NAN;
uint32_t lastCompassDrawMs = 0;

lv_obj_t *birdsList, *birdsEmpty, *birdsClearBtn, *birdsClearLabel;
lv_obj_t *handsFreeRow; // Mark / Confirm last / Undo (HANDS_FREE_LOGGING_PLAN.md §3)
lv_obj_t *handsFreePending; // the button waiting for the app's ack, if any
struct HandsFreeButton { const char *text; uint8_t command; lv_color_t color; };

// Shows `text` on a hands-free button for a moment, then its own label again.
void flashHandsFree(lv_obj_t *btn, const char *text) {
    lv_label_set_text(lv_obj_get_child(btn, 0), text);
    lv_timer_t *t = lv_timer_create([](lv_timer_t *t) {
        const HandsFreeButton *s = (const HandsFreeButton *)lv_obj_get_user_data((lv_obj_t *)t->user_data);
        lv_label_set_text(lv_obj_get_child((lv_obj_t *)t->user_data, 0), s->text);
    }, 1500, btn);
    lv_timer_set_repeat_count(t, 1);
}

// "Got it" only once the app has the press -- the old "Sent" showed even when it never arrived.
void updateHandsFree() {
    const ScopeLink::ButtonState s = gLink.takeButtonState();
    if (!handsFreePending || (s != ScopeLink::ButtonState::Acked && s != ScopeLink::ButtonState::NoReply)) return;
    flashHandsFree(handsFreePending, s == ScopeLink::ButtonState::Acked ? LV_SYMBOL_OK " Got it" : "No reply");
    handsFreePending = nullptr;
}
lv_obj_t *birdsHeardBtn, *birdsTargetsBtn, *birdsTargetsBtnLabel;
lv_obj_t *targetsInfo, *targetsList, *targetsEmpty, *targetsNewLocBtn, *targetsNewLocLabel;
uint32_t newLocArmedMs = 0;
// Birds tab views: Heard (detections), Targets (the trip's checklist), Trip (seen at each location),
// Cards (search the bird cards saved on the SD card).
enum BirdsView { kViewHeard = 0, kViewTargets, kViewTrip, kViewCards };
int birdsView = kViewHeard;
lv_obj_t *birdsTripBtn, *tripList, *tripEmpty, *tripMapBtn;
lv_obj_t *birdsCardsBtn, *cardsSearch, *cardsInfo, *cardsList, *cardsKeyboard;
uint32_t shownIndexVersion = 0xFFFFFFFF;
uint32_t cardsEditedMs = 0; // search text or filter changed; rebuild once typing pauses
// Cards filter: size class (0 = any) and colors the bird must all have.
lv_obj_t *cardsFilterBtn, *cardsFilterLabel, *cardsFilterLayer, *cardsSizeMatrix, *cardsColorMatrix;
int cardsSizeClass = 0;
uint16_t cardsColorMask = 0;
// Swatches for the color buttons, in ScopeStorage's color-bit order.
const uint32_t kColorSwatches[ScopeStorage::kColorCount] = {
    0x000000, 0xF2F2F2, 0x8A8F94, 0x7A5230, 0xB5562A, 0xD2B48C, 0xD03030, 0xF08A24, 0xF09AB4,
    0xF2D21B, 0x2E9E48, 0x7A7F2A, 0x2F6FD0};
constexpr int kMaxCardRows = 60;
bool cardFromIndex = false; // the card being opened came from the Cards list (its name may be a stand-in)
uint32_t shownHistoryVersion = 0xFFFFFFFF;
int shownOutboxPending = -1;
uint32_t shownTargetsVersion = 0xFFFFFFFF;
uint32_t lastBirdGestureMs = 0;
uint32_t clearArmedMs = 0;
uint32_t shownDetectionsVersion = 0xFFFFFFFF;
uint32_t lastBirdsRefreshMs = 0;

lv_obj_t *cardLayer, *cardTitle, *cardSub, *cardImg, *cardBody, *cardStatus, *cardSeenBtn, *cardSeenLabel;
String cardCommon, cardScientific;
bool cardRetried = false;
int cardTargetIndex = -1; // opened from the Targets list -> offer "Seen it - check off here"
RGBImage cardImage;
uint32_t cardRequestedMs = 0;

lv_obj_t *radarView, *radarArrow, *radarArrowSub, *radarStatus, *radarTargetsRow, *radarMessage;
lv_obj_t *radarTargetBtns[kMaxTargets];
uint32_t lastRadarDrawMs = 0;
int shownTargetCount = -1;

lv_obj_t *fleetList, *fleetEmpty;
uint32_t shownFleetVersion = 0xFFFFFFFF;
lv_obj_t *liveLayer, *liveTitle, *liveNeedle, *liveText;
IPAddress watchedIP;

lv_obj_t *campGrid, *campEmpty, *campTalkBtn, *campTalkLabel;
lv_obj_t *campTiles[kSnapshotSlots], *campTileImg[kSnapshotSlots], *campTileName[kSnapshotSlots], *campTileState[kSnapshotSlots];
IPAddress campTileIP[kSnapshotSlots];
int campTileCount = 0;
int campSelected = -1;
uint32_t shownCampFleetVersion = 0xFFFFFFFF;
uint32_t shownPresenceVersion = 0xFFFFFFFF;

lv_obj_t *alertLayer, *alertTitle, *alertImg, *alertText;
IPAddress alertIP;
uint32_t lastAlertShownMs = 0;

lv_obj_t *sessionBig, *sessionStats, *sessionRecent, *sessionStorage, *sessionMerlin;
lv_obj_t *forgetBtn, *forgetLabel;
uint32_t forgetArmedMs = 0;
lv_obj_t *micGainLabel, *micMeter, *micMeterLabel;
lv_obj_t *powerBtn, *powerLabel;
uint32_t powerArmedMs = 0;

// ---- Small helpers ----

String ago(uint32_t ms) {
    const uint32_t s = ms / 1000;
    if (s < 60) return String(s) + "s ago";
    if (s < 3600) return String(s / 60) + "m ago";
    return String(s / 3600) + "h ago";
}

float wrap180(float deg) {
    deg = fmodf(deg + 540.0f, 360.0f) - 180.0f;
    return deg;
}

lv_obj_t *makeLabel(lv_obj_t *parent, const lv_font_t *font, lv_color_t color, const char *text = "") {
    lv_obj_t *l = lv_label_create(parent);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, color, 0);
    lv_label_set_text(l, text);
    return l;
}

lv_obj_t *makeButton(lv_obj_t *parent, const char *text, lv_color_t color, lv_event_cb_t cb, void *user = nullptr) {
    lv_obj_t *b = lv_btn_create(parent);
    lv_obj_set_style_bg_color(b, color, 0);
    lv_obj_set_style_radius(b, 10, 0);
    lv_obj_t *l = makeLabel(b, &lv_font_montserrat_16, lv_color_white(), text);
    lv_obj_center(l);
    if (cb) lv_obj_add_event_cb(b, cb, LV_EVENT_CLICKED, user);
    return b;
}

void styleSurface(lv_obj_t *o) {
    lv_obj_set_style_bg_color(o, kSurface, 0);
    lv_obj_set_style_border_color(o, kBorder, 0);
    lv_obj_set_style_border_width(o, 1, 0);
    lv_obj_set_style_radius(o, 12, 0);
    lv_obj_set_style_pad_all(o, 10, 0);
}

lv_obj_t *makeOverlay() {
    lv_obj_t *o = lv_obj_create(lv_layer_top());
    lv_obj_set_size(o, Config::kScreenWidth, Config::kScreenHeight);
    lv_obj_set_style_bg_color(o, kBg, 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(o, 0, 0);
    lv_obj_set_style_radius(o, 0, 0);
    lv_obj_set_style_pad_all(o, 14, 0);
    lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
    return o;
}

String movementText(const PresenceInfo &p) {
    if (p.sensorOffline) return "Sensor offline";
    if (p.targetState == 0) return "Clear";
    if (p.targetState == 4) return "Clearing...";
    String dist;
    if (p.distanceCm > 0) {
        const float ft = p.distanceCm / 30.48f;
        dist = ft < 10 ? String(ft, 1) + " ft" : String((int)roundf(ft)) + " ft";
    }
    String speed;
    if (p.speedCmPerSec != 0xFFFF && p.speedCmPerSec >= 5) speed = String(p.speedCmPerSec * 0.0223694f, 1) + " mph";
    String move;
    switch (p.movement) {
        case 2: move = "Approaching"; break;
        case 3: move = "Moving away"; break;
        case 1: move = p.targetState == 2 ? "Moving across" : "Standing still"; break;
        default: move = speed.length() ? "Moving" : "Present"; break;
    }
    String out = move;
    if (speed.length() && (p.movement == 2 || p.movement == 3 || p.movement == 0)) out += " | " + speed;
    if (dist.length()) out += " | " + dist;
    return out;
}

bool isSecurityNode(const FleetNode &n) {
    return (n.flags & Protocol::kFleetHasPresence) || (n.flags & Protocol::kFleetHasSpeaker);
}

// ---- LVGL drivers ----

void flushCb(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *color) {
    const uint32_t w = area->x2 - area->x1 + 1;
    const uint32_t h = area->y2 - area->y1 + 1;
    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.pushColors((uint16_t *)&color->full, w * h, true);
    tft.endWrite();
    lv_disp_flush_ready(drv);
}

// FT6336U, read directly: one 5-byte burst (TD_STATUS, P1_XH, P1_XL, P1_YH, P1_YL). The vendor
// library sleeps 10 ms per register and retries forever on a failed read -- too slow for a UI.
void touchCb(lv_indev_drv_t *, lv_indev_data_t *data) {
    Wire.beginTransmission(0x38);
    Wire.write(0x02);
    if (Wire.endTransmission(false) != 0 || Wire.requestFrom((uint8_t)0x38, (uint8_t)5) != 5) {
        data->state = LV_INDEV_STATE_REL;
        return;
    }
    uint8_t r[5];
    for (int i = 0; i < 5; i++) r[i] = Wire.read();
    const uint8_t points = r[0] & 0x0F;
    if (points == 0 || points > 2) {
        data->state = LV_INDEV_STATE_REL;
        return;
    }
    const int x = ((r[1] & 0x0F) << 8) | r[2];
    const int y = ((r[3] & 0x0F) << 8) | r[4];
    data->point.x = constrain(x, 0, Config::kScreenWidth - 1);
    data->point.y = constrain(y, 0, Config::kScreenHeight - 1);
    data->state = LV_INDEV_STATE_PR;
    gUI.noteTouch(millis());
}

// ---- Birds tab + card ----

void setTargetSeen(int i, bool seen); // Targets section below

void presentCard(const CardResult &card, const char *source) {
    lv_label_set_text(cardBody, card.text.c_str());
    lv_label_set_text(cardStatus, source);
    if (card.jpeg && card.jpegLen) {
        const uint8_t scale = jpegScaleToFit(card.jpeg, card.jpegLen, Config::kScreenWidth - 28, 240);
        if (decodeJpeg(card.jpeg, card.jpegLen, scale, cardImage)) {
            lv_img_set_src(cardImg, &cardImage.dsc);
            lv_obj_clear_flag(cardImg, LV_OBJ_FLAG_HIDDEN);
        }
    }
}

void updateCardSeenButton() {
    const TripTargetList &list = gState.tripTargets;
    const bool offer = cardTargetIndex >= 0 && cardTargetIndex < list.count && list.items[cardTargetIndex].name.equals(cardCommon) &&
                       !(list.items[cardTargetIndex].flags & Protocol::kTripTargetSeen);
    if (offer) lv_obj_clear_flag(cardSeenBtn, LV_OBJ_FLAG_HIDDEN);
    else lv_obj_add_flag(cardSeenBtn, LV_OBJ_FLAG_HIDDEN);
}

// Opens a bird's card: from the SD card if it's stored there (instant, no phone needed), else from
// the phone (and stored for next time). `targetIndex` >= 0 when opened from the Targets list.
void showCardFor(const String &common, const String &scientific, int targetIndex) {
    cardCommon = common;
    cardScientific = scientific;
    cardRetried = false;
    cardTargetIndex = targetIndex;
    lv_label_set_text(cardTitle, common.c_str());
    lv_label_set_text(cardSub, scientific.c_str());
    lv_label_set_text(cardBody, "");
    lv_obj_add_flag(cardImg, LV_OBJ_FLAG_HIDDEN);
    if (cardsKeyboard) lv_obj_add_flag(cardsKeyboard, LV_OBJ_FLAG_HIDDEN);
    CardResult stored;
    if (gStore.loadCard(common, scientific, stored)) {
        presentCard(stored, "Saved on the display");
        cardRequestedMs = 0;
        // A real name (from a detection or target) fixes an index entry named from its file only.
        if (!cardFromIndex) gStore.noteName(common, scientific);
    } else if (gLink.requestCard(common, scientific)) {
        Serial.printf("[card] not on the SD card: \"%s\" (%s) -- asking the phone\n", common.c_str(), scientific.c_str());
        lv_label_set_text(cardStatus, "Loading card from the phone...");
        cardRequestedMs = millis();
    } else {
        lv_label_set_text(cardStatus, gState.sdPresent ? "Phone not connected, and this card isn't saved on the display yet."
                                                       : "Phone not connected - no card available.");
        cardRequestedMs = 0;
    }
    updateCardSeenButton();
    lv_obj_clear_flag(cardLayer, LV_OBJ_FLAG_HIDDEN);
    lv_obj_scroll_to_y(cardLayer, 0, LV_ANIM_OFF);
}

void showCard(const Detection &d) { showCardFor(d.common, d.scientific, -1); }

void onBirdRow(lv_event_t *e) {
    if (millis() - lastBirdGestureMs < 400) return; // the release that ended a swipe isn't a tap
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i >= 0 && i < gState.detectionCount) showCard(gState.detections[i]);
}

void removeDetection(int i) {
    if (i < 0 || i >= gState.detectionCount) return;
    for (int k = i; k < gState.detectionCount - 1; k++) gState.detections[k] = gState.detections[k + 1];
    gState.detections[gState.detectionCount - 1] = Detection();
    gState.detectionCount--;
    gState.detectionsVersion++;
}

// Swipe left on a row removes it (display only -- the phone's session list is untouched, and the
// bird reappears if it's heard again).
void onBirdGesture(lv_event_t *e) {
    if (lv_indev_get_gesture_dir(lv_indev_get_act()) != LV_DIR_LEFT) return;
    lastBirdGestureMs = millis();
    lv_indev_wait_release(lv_indev_get_act());
    removeDetection((int)(intptr_t)lv_event_get_user_data(e));
}

void onClearBirds(lv_event_t *) {
    const uint32_t now = millis();
    if (clearArmedMs && now - clearArmedMs < 3000) {
        for (int i = 0; i < gState.detectionCount; i++) gState.detections[i] = Detection();
        gState.detectionCount = 0;
        gState.detectionsVersion++;
        clearArmedMs = 0;
        lv_label_set_text(birdsClearLabel, LV_SYMBOL_TRASH " Clear");
        lv_obj_set_style_bg_color(birdsClearBtn, kBorder, 0);
        return;
    }
    clearArmedMs = now;
    lv_label_set_text(birdsClearLabel, "Tap again to clear");
    lv_obj_set_style_bg_color(birdsClearBtn, kDanger, 0);
}

void rebuildBirds(uint32_t now) {
    lv_obj_clean(birdsList);
    for (int i = 0; i < gState.detectionCount; i++) {
        const Detection &d = gState.detections[i];
        lv_obj_t *row = lv_obj_create(birdsList);
        styleSurface(row);
        lv_obj_set_width(row, lv_pct(100));
        lv_obj_set_height(row, LV_SIZE_CONTENT);
        lv_obj_set_flex_flow(row, LV_FLEX_FLOW_COLUMN);
        lv_obj_set_style_pad_row(row, 2, 0);
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(row, onBirdRow, LV_EVENT_CLICKED, (void *)(intptr_t)i);
        lv_obj_add_event_cb(row, onBirdGesture, LV_EVENT_GESTURE, (void *)(intptr_t)i);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_GESTURE_BUBBLE);
        String title = d.common;
        if (d.newLifeBird) title += "  * LIFER";
        lv_obj_t *t = makeLabel(row, &lv_font_montserrat_20, d.newLifeBird ? kWarn : kText, title.c_str());
        lv_label_set_long_mode(t, LV_LABEL_LONG_DOT);
        lv_obj_set_width(t, lv_pct(100));
        // Who heard it: our app (confidence + which node) or Merlin on the iPhone (no score).
        String sub = d.source == 1 ? String("MERLIN") : "PEREGRINE  " + String(d.confidencePct) + "%";
        if (d.hits > 1) sub += "  x" + String(d.hits);
        if (d.source == 0 && d.nodeName.length()) sub += "  " + d.nodeName;
        if (!isnan(d.trueBearingDeg)) sub += "  " + String((int)roundf(d.trueBearingDeg)) + " deg";
        sub += "  " + ago(now - d.receivedMs);
        makeLabel(row, &lv_font_montserrat_12, d.source == 1 ? kWarn : kAccent, sub.c_str());
    }
    if (gState.detectionCount == 0) {
        lv_obj_clear_flag(birdsEmpty, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(birdsClearBtn, LV_OBJ_FLAG_HIDDEN);
    } else if (birdsView == kViewHeard) {
        lv_obj_add_flag(birdsEmpty, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_flag(birdsClearBtn, LV_OBJ_FLAG_HIDDEN);
    }
}

// ---- Targets (the trip's target birds, kScopeTargetList) ----

// Works with the phone out of reach: the change shows at once and waits in the outbox (ScopeLink).
void setTargetSeen(int i, bool seen) {
    TripTargetList &list = gState.tripTargets;
    if (i < 0 || i >= list.count) return;
    TripTarget &t = list.items[i];
    if (t.flags & Protocol::kTripTargetHeading) return;
    const bool was = t.flags & Protocol::kTripTargetSeen;
    if (was == seen) return;
    t.flags = seen ? (t.flags | Protocol::kTripTargetSeen) : (t.flags & ~Protocol::kTripTargetSeen);
    if (seen) list.seen++;
    else if (list.seen) list.seen--;
    gState.tripTargetsVersion++;
    gLink.sendTargetToggle(t.name, seen);
}

void onTargetBox(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i < 0 || i >= gState.tripTargets.count) return;
    setTargetSeen(i, !(gState.tripTargets.items[i].flags & Protocol::kTripTargetSeen));
}

// Long-press the box: one more of this bird (checks it off first). The phone says the new count.
void onTargetBoxLong(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    TripTargetList &list = gState.tripTargets;
    if (i < 0 || i >= list.count || (list.items[i].flags & Protocol::kTripTargetHeading)) return;
    // Check it locally only: the app checks it off itself when it adds the count (a separate toggle
    // could arrive first and make it 2).
    if (!(list.items[i].flags & Protocol::kTripTargetSeen)) {
        list.items[i].flags |= Protocol::kTripTargetSeen;
        list.seen++;
        gState.tripTargetsVersion++;
    }
    gLink.sendCountAdd(list.items[i].name, 1);
}

void onTargetRow(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i >= 0 && i < gState.tripTargets.count) showCardFor(gState.tripTargets.items[i].name, String(), i);
}

void rebuildTargets() {
    const TripTargetList &list = gState.tripTargets;
    lv_obj_clean(targetsList);
    const bool any = list.valid && list.total > 0;
    if (!any) {
        lv_obj_clear_flag(targetsEmpty, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(targetsInfo, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(targetsNewLocBtn, LV_OBJ_FLAG_HIDDEN);
        lv_label_set_text(birdsTargetsBtnLabel, "Targets");
        return;
    }
    lv_obj_add_flag(targetsEmpty, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(targetsInfo, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(targetsNewLocBtn, LV_OBJ_FLAG_HIDDEN);
    lv_label_set_text_fmt(birdsTargetsBtnLabel, "Targets %u/%u", list.seen, list.total);
    String info = list.tripName;
    info += "\nAt: " + (list.stopName.length() ? list.stopName : String("no stop yet - tap I'm here on the phone"));
    info += "\n" + String(list.seen) + " of " + String(list.total) + " seen here";
    if (list.count < list.total) info += " (showing " + String(list.count) + ")";
    if (gState.outboxPending) info += "\n" + String(gState.outboxPending) + " change" + (gState.outboxPending == 1 ? "" : "s") + " waiting for the phone";
    info += "\nTap a box to check it off, a name to see its card.";
    lv_label_set_text(targetsInfo, info.c_str());

    for (int i = 0; i < list.count; i++) {
        const TripTarget &t = list.items[i];
        if (t.flags & Protocol::kTripTargetHeading) { // a location: "You are here: Lake", then each other stop
            const bool current = t.flags & Protocol::kTripTargetCurrentHeading;
            lv_obj_t *h = makeLabel(targetsList, &lv_font_montserrat_16, current ? kAccent : kMuted, t.name.c_str());
            lv_label_set_long_mode(h, LV_LABEL_LONG_WRAP);
            lv_obj_set_width(h, lv_pct(100));
            lv_obj_set_style_pad_top(h, i ? 12 : 0, 0);
            const bool nextIsBird = i + 1 < list.count && !(list.items[i + 1].flags & Protocol::kTripTargetHeading);
            if (current && !nextIsBird) makeLabel(targetsList, &lv_font_montserrat_12, kMuted, "Nothing was planned here - other stops' birds are below.");
            continue;
        }
        const bool seen = t.flags & Protocol::kTripTargetSeen;
        lv_obj_t *row = lv_obj_create(targetsList);
        styleSurface(row);
        lv_obj_set_style_pad_all(row, 8, 0);
        lv_obj_set_width(row, lv_pct(100));
        lv_obj_set_height(row, LV_SIZE_CONTENT);
        lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
        lv_obj_set_flex_align(row, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
        lv_obj_set_style_pad_column(row, 10, 0);
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(row, onTargetRow, LV_EVENT_CLICKED, (void *)(intptr_t)i);

        lv_obj_t *box = lv_obj_create(row);
        lv_obj_set_size(box, 34, 34);
        lv_obj_set_style_radius(box, 6, 0);
        lv_obj_set_style_border_width(box, 2, 0);
        lv_obj_set_style_border_color(box, seen ? kAccent : kMuted, 0);
        lv_obj_set_style_bg_color(box, seen ? kAccent : kSurface, 0);
        lv_obj_set_style_pad_all(box, 0, 0);
        lv_obj_clear_flag(box, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_flag(box, LV_OBJ_FLAG_CLICKABLE); // the box checks; the rest of the row opens the card
        lv_obj_set_ext_click_area(box, 10);
        lv_obj_add_event_cb(box, onTargetBox, LV_EVENT_SHORT_CLICKED, (void *)(intptr_t)i);
        lv_obj_add_event_cb(box, onTargetBoxLong, LV_EVENT_LONG_PRESSED, (void *)(intptr_t)i);
        if (seen) lv_obj_center(makeLabel(box, &lv_font_montserrat_16, kBg, LV_SYMBOL_OK));

        lv_obj_t *col = lv_obj_create(row);
        lv_obj_set_style_bg_opa(col, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(col, 0, 0);
        lv_obj_set_style_pad_all(col, 0, 0);
        lv_obj_set_flex_grow(col, 1);
        lv_obj_set_height(col, LV_SIZE_CONTENT);
        lv_obj_set_flex_flow(col, LV_FLEX_FLOW_COLUMN);
        lv_obj_clear_flag(col, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
        lv_obj_t *name = makeLabel(col, &lv_font_montserrat_16, seen ? kMuted : kText, t.name.c_str());
        lv_label_set_long_mode(name, LV_LABEL_LONG_DOT);
        lv_obj_set_width(name, lv_pct(100));
        if (!seen && (t.flags & Protocol::kTripTargetSeenEarlier)) makeLabel(col, &lv_font_montserrat_12, kMuted, "Seen earlier on this trip");
    }
}

// ---- Trip (what you've seen at each location, kScopeTripHistory) ----

void onTripBird(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    const TripHistory &h = gState.tripHistory;
    if (i >= 0 && i < h.count) showCardFor(h.items[i].name, String(), -1);
}

void rebuildTrip() {
    const TripHistory &h = gState.tripHistory;
    lv_obj_clean(tripList);
    if (!h.valid || h.count == 0) {
        lv_obj_clear_flag(tripEmpty, LV_OBJ_FLAG_HIDDEN);
        return;
    }
    lv_obj_add_flag(tripEmpty, LV_OBJ_FLAG_HIDDEN);
    for (int i = 0; i < h.count; i++) {
        const HistoryEntry &item = h.items[i];
        if (item.kind == 0) {
            const bool here = item.flags & 0x01;
            String title = item.name;
            if (here) title += "  - you are here";
            lv_obj_t *l = makeLabel(tripList, &lv_font_montserrat_16, here ? kAccent : kText, title.c_str());
            lv_label_set_long_mode(l, LV_LABEL_LONG_WRAP);
            lv_obj_set_width(l, lv_pct(100));
            lv_obj_set_style_pad_top(l, i ? 10 : 0, 0);
            continue;
        }
        lv_obj_t *row = lv_obj_create(tripList);
        styleSurface(row);
        lv_obj_set_style_pad_all(row, 8, 0);
        lv_obj_set_width(row, lv_pct(100));
        lv_obj_set_height(row, LV_SIZE_CONTENT);
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(row, onTripBird, LV_EVENT_CLICKED, (void *)(intptr_t)i);
        String how = (item.flags & 0x02) ? "seen" : "";
        if (item.flags & 0x01) how += how.length() ? ", heard" : "heard";
        lv_obj_t *name = makeLabel(row, &lv_font_montserrat_16, kText, item.name.c_str());
        lv_label_set_long_mode(name, LV_LABEL_LONG_DOT);
        lv_obj_set_width(name, lv_pct(70));
        lv_obj_t *sub = makeLabel(row, &lv_font_montserrat_12, kMuted, how.c_str());
        lv_obj_align(sub, LV_ALIGN_RIGHT_MID, 0, 0);
    }
}

// ---- Cards (bird cards saved on the SD card) ----

void onCardsRow(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i < 0 || i >= gStore.cardCount()) return;
    const ScopeStorage::IndexEntry &entry = gStore.cardAt(i);
    cardFromIndex = true;
    showCardFor(entry.common, entry.scientific, -1);
    cardFromIndex = false;
}

// "Small, Red + Black"
String cardsFilterSummary() {
    String out;
    if (cardsSizeClass > 0) out = ScopeStorage::sizeClassName(cardsSizeClass);
    bool first = true;
    for (int bit = 0; bit < ScopeStorage::kColorCount; bit++) {
        if (!(cardsColorMask & (1u << bit))) continue;
        out += first ? (out.length() ? ", " : "") : " + ";
        out += ScopeStorage::colorName(bit);
        first = false;
    }
    return out;
}

void updateCardsFilterButton() {
    int active = (cardsSizeClass > 0) + __builtin_popcount(cardsColorMask);
    if (active) lv_label_set_text_fmt(cardsFilterLabel, LV_SYMBOL_SETTINGS " %d", active);
    else lv_label_set_text(cardsFilterLabel, LV_SYMBOL_SETTINGS " Filter");
    lv_obj_set_style_bg_color(cardsFilterBtn, active ? kAccent : kBorder, 0);
    cardsEditedMs = millis(); // rebuild the list
}

void setCardsFilter(int sizeClass, uint16_t colorMask) {
    cardsSizeClass = sizeClass;
    cardsColorMask = colorMask;
    lv_btnmatrix_clear_btn_ctrl_all(cardsSizeMatrix, LV_BTNMATRIX_CTRL_CHECKED);
    lv_btnmatrix_set_btn_ctrl(cardsSizeMatrix, sizeClass, LV_BTNMATRIX_CTRL_CHECKED);
    for (int bit = 0; bit < ScopeStorage::kColorCount; bit++) {
        if (colorMask & (1u << bit)) lv_btnmatrix_set_btn_ctrl(cardsColorMatrix, bit, LV_BTNMATRIX_CTRL_CHECKED);
        else lv_btnmatrix_clear_btn_ctrl(cardsColorMatrix, bit, LV_BTNMATRIX_CTRL_CHECKED);
    }
    updateCardsFilterButton();
}

lv_obj_t *makeFilterMatrix(lv_obj_t *parent, const char **map, int rows) {
    lv_obj_t *m = lv_btnmatrix_create(parent);
    lv_btnmatrix_set_map(m, map);
    // CLICK_TRIG: VALUE_CHANGED on release, after the button has toggled -- without it LVGL sends it
    // on press, before the toggle, and the handler reads the old checked state.
    lv_btnmatrix_set_btn_ctrl_all(m, (lv_btnmatrix_ctrl_t)(LV_BTNMATRIX_CTRL_CHECKABLE | LV_BTNMATRIX_CTRL_CLICK_TRIG));
    lv_obj_set_size(m, lv_pct(100), rows * 50);
    lv_obj_set_style_bg_opa(m, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(m, 0, 0);
    lv_obj_set_style_pad_all(m, 0, 0);
    lv_obj_set_style_pad_gap(m, 6, 0);
    lv_obj_set_style_text_font(m, &lv_font_montserrat_16, LV_PART_ITEMS);
    lv_obj_set_style_bg_color(m, kSurface, LV_PART_ITEMS);
    lv_obj_set_style_text_color(m, kText, LV_PART_ITEMS);
    lv_obj_set_style_border_color(m, kBorder, LV_PART_ITEMS);
    lv_obj_set_style_border_width(m, 1, LV_PART_ITEMS);
    lv_obj_set_style_radius(m, 10, LV_PART_ITEMS);
    lv_obj_set_style_bg_color(m, kAccent, LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_text_color(m, kBg, LV_PART_ITEMS | LV_STATE_CHECKED);
    return m;
}

// Full-screen panel: size buttons (pick one) and color buttons (pick any; the bird must have all).
void buildCardsFilter() {
    cardsFilterLayer = makeOverlay();
    lv_obj_set_flex_flow(cardsFilterLayer, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_row(cardsFilterLayer, 8, 0);

    lv_obj_t *top = lv_obj_create(cardsFilterLayer);
    lv_obj_set_size(top, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(top, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(top, 0, 0);
    lv_obj_set_style_pad_all(top, 0, 0);
    lv_obj_clear_flag(top, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *title = makeLabel(top, &lv_font_montserrat_24, kText, "Filter cards");
    lv_obj_align(title, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_t *done = makeButton(top, "Done", kAccent, [](lv_event_t *) {
        lv_obj_add_flag(cardsFilterLayer, LV_OBJ_FLAG_HIDDEN);
    });
    lv_obj_set_size(done, 90, 40);
    lv_obj_align(done, LV_ALIGN_RIGHT_MID, 0, 0);

    makeLabel(cardsFilterLayer, &lv_font_montserrat_16, kMuted, "Size");
    static const char *sizeMap[] = {"Any", "Tiny", "Small", "\n", "Medium", "Large", "Huge", ""};
    cardsSizeMatrix = makeFilterMatrix(cardsFilterLayer, sizeMap, 2);
    lv_btnmatrix_set_one_checked(cardsSizeMatrix, true);
    lv_obj_add_event_cb(cardsSizeMatrix, [](lv_event_t *e) {
        lv_obj_t *m = lv_event_get_target(e);
        const uint16_t id = lv_btnmatrix_get_selected_btn(m);
        if (id == LV_BTNMATRIX_BTN_NONE) return;
        // Tapping the checked size again would leave none checked: fall back to Any.
        cardsSizeClass = lv_btnmatrix_has_btn_ctrl(m, id, LV_BTNMATRIX_CTRL_CHECKED) ? id : 0;
        if (!cardsSizeClass) lv_btnmatrix_set_btn_ctrl(m, 0, LV_BTNMATRIX_CTRL_CHECKED);
        updateCardsFilterButton();
    }, LV_EVENT_VALUE_CHANGED, nullptr);
    lv_obj_t *hint = makeLabel(cardsFilterLayer, &lv_font_montserrat_12, kMuted,
        "Tiny: under 5 in (kinglet)   Small: 5-7 in (sparrow)\nMedium: 7-11 in (robin)   Large: 11-20 in (crow)\nHuge: over 20 in (goose)");
    lv_label_set_long_mode(hint, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(hint, lv_pct(100));

    makeLabel(cardsFilterLayer, &lv_font_montserrat_16, kMuted, "Colors - the bird has all of them");
    // Same order as ScopeStorage's color bits, so a button's id is its bit.
    static const char *colorMap[ScopeStorage::kColorCount + 5];
    static const int rowBreaks[] = {3, 6, 9}; // 3 / 3 / 3 / 4 buttons
    int n = 0;
    for (int bit = 0; bit < ScopeStorage::kColorCount; bit++) {
        for (int br : rowBreaks) if (bit == br) colorMap[n++] = "\n";
        colorMap[n++] = ScopeStorage::colorName(bit);
    }
    colorMap[n] = "";
    cardsColorMatrix = makeFilterMatrix(cardsFilterLayer, colorMap, 4);
    lv_obj_add_event_cb(cardsColorMatrix, [](lv_event_t *e) {
        lv_obj_t *m = lv_event_get_target(e);
        const uint16_t id = lv_btnmatrix_get_selected_btn(m);
        if (id == LV_BTNMATRIX_BTN_NONE || id >= ScopeStorage::kColorCount) return;
        if (lv_btnmatrix_has_btn_ctrl(m, id, LV_BTNMATRIX_CTRL_CHECKED)) cardsColorMask |= 1u << id;
        else cardsColorMask &= ~(1u << id);
        updateCardsFilterButton();
    }, LV_EVENT_VALUE_CHANGED, nullptr);
    // Paint each button its color; a checked one gets a thick accent ring instead of the fill change.
    lv_obj_add_event_cb(cardsColorMatrix, [](lv_event_t *e) {
        lv_obj_draw_part_dsc_t *dsc = lv_event_get_draw_part_dsc(e);
        if (dsc->class_p != &lv_btnmatrix_class || dsc->type != LV_BTNMATRIX_DRAW_PART_BTN) return;
        if (dsc->id >= ScopeStorage::kColorCount || !dsc->rect_dsc || !dsc->label_dsc) return;
        const uint32_t hex = kColorSwatches[dsc->id];
        const int luma = ((hex >> 16) * 299 + ((hex >> 8) & 0xFF) * 587 + (hex & 0xFF) * 114) / 1000;
        const bool checked = lv_btnmatrix_has_btn_ctrl(lv_event_get_target(e), dsc->id, LV_BTNMATRIX_CTRL_CHECKED);
        dsc->rect_dsc->bg_color = lv_color_hex(hex);
        dsc->rect_dsc->bg_opa = LV_OPA_COVER;
        dsc->rect_dsc->border_color = checked ? kAccent : kBorder;
        dsc->rect_dsc->border_width = checked ? 5 : 1;
        dsc->label_dsc->color = luma > 140 ? lv_color_black() : lv_color_white();
    }, LV_EVENT_DRAW_PART_BEGIN, nullptr);

    lv_obj_t *note = makeLabel(cardsFilterLayer, &lv_font_montserrat_12, kMuted,
        "Colors come from each card's field marks (body, head, breast, back - not wing bars, eye rings or bill), "
        "either sex. Cards with no field-guide entry only show with the filter off.");
    lv_label_set_long_mode(note, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(note, lv_pct(100));
    lv_obj_t *clear = makeButton(cardsFilterLayer, LV_SYMBOL_CLOSE "  Clear filter", kBorder, [](lv_event_t *) {
        setCardsFilter(0, 0);
    });
    lv_obj_set_size(clear, lv_pct(100), 44);
    setCardsFilter(0, 0);
}

void rebuildCards() {
    lv_obj_clean(cardsList);
    if (!gState.sdPresent) {
        lv_label_set_text(cardsInfo, "No SD card in the display. Put a microSD card in, then load cards from the phone: "
                                     "the display's node in Mic Array > Fleet > Bird cards on the display.");
        return;
    }
    if (gStore.cardCount() == 0) {
        lv_label_set_text(cardsInfo, "No bird cards saved yet. Load them from the phone while it has internet: "
                                     "the display's node in Mic Array > Fleet > Bird cards on the display. Cards you open are saved too.");
        return;
    }
    static int matches[kMaxCardRows];
    const String query = lv_textarea_get_text(cardsSearch);
    const int total = gStore.searchCards(query, cardsSizeClass, cardsColorMask, matches, kMaxCardRows);
    const int shown = min(total, kMaxCardRows);
    const bool filtered = cardsSizeClass > 0 || cardsColorMask;
    String info;
    if (query.length() == 0 && !filtered) info = String(gStore.cardCount()) + " cards saved";
    else if (total == 0) info = query.length() ? "No saved card matches \"" + query + "\"" : String("No saved card matches");
    else info = String(total) + " of " + String(gStore.cardCount()) + " match";
    if (filtered) info += " - " + cardsFilterSummary();
    if (total > shown) info += " - showing the first " + String(shown) + ", type more to narrow it down";
    lv_label_set_text(cardsInfo, info.c_str());
    for (int k = 0; k < shown; k++) {
        const ScopeStorage::IndexEntry &entry = gStore.cardAt(matches[k]);
        lv_obj_t *row = lv_obj_create(cardsList);
        styleSurface(row);
        lv_obj_set_style_pad_all(row, 8, 0);
        lv_obj_set_width(row, lv_pct(100));
        lv_obj_set_height(row, LV_SIZE_CONTENT);
        lv_obj_set_flex_flow(row, LV_FLEX_FLOW_COLUMN);
        lv_obj_set_style_pad_row(row, 2, 0);
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(row, onCardsRow, LV_EVENT_CLICKED, (void *)(intptr_t)matches[k]);
        lv_obj_t *name = makeLabel(row, &lv_font_montserrat_16, kText, entry.common);
        lv_label_set_long_mode(name, LV_LABEL_LONG_DOT);
        lv_obj_set_width(name, lv_pct(100));
        if (entry.scientific[0]) makeLabel(row, &lv_font_montserrat_12, kMuted, entry.scientific);
    }
}

void setBirdsView(int view) {
    birdsView = view;
    lv_obj_set_style_bg_color(birdsHeardBtn, view == kViewHeard ? kAccent : kBorder, 0);
    lv_obj_set_style_bg_color(birdsTargetsBtn, view == kViewTargets ? kAccent : kBorder, 0);
    lv_obj_set_style_bg_color(birdsTripBtn, view == kViewTrip ? kAccent : kBorder, 0);
    lv_obj_set_style_bg_color(birdsCardsBtn, view == kViewCards ? kAccent : kBorder, 0);
    auto show = [](lv_obj_t *o, bool on) { if (on) lv_obj_clear_flag(o, LV_OBJ_FLAG_HIDDEN); else lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN); };
    show(birdsList, view == kViewHeard);
    show(targetsList, view == kViewTargets);
    show(tripList, view == kViewTrip);
    show(tripMapBtn, view == kViewTrip);
    show(lv_obj_get_parent(cardsSearch), view == kViewCards);
    show(cardsInfo, view == kViewCards);
    show(cardsList, view == kViewCards);
    if (view != kViewCards) {
        lv_obj_add_flag(cardsKeyboard, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_state(cardsSearch, LV_STATE_FOCUSED);
    }
    show(handsFreeRow, view == kViewHeard || view == kViewTargets);
    if (view != kViewHeard) { show(birdsEmpty, false); show(birdsClearBtn, false); }
    if (view != kViewTargets) { show(targetsInfo, false); show(targetsEmpty, false); show(targetsNewLocBtn, false); }
    if (view != kViewTrip) show(tripEmpty, false);
    if (view == kViewHeard) shownDetectionsVersion = 0xFFFFFFFF; // rebuild on the next update
    if (view == kViewTargets) shownTargetsVersion = 0xFFFFFFFF;
    if (view == kViewTrip) shownHistoryVersion = 0xFFFFFFFF;
    if (view == kViewCards) shownIndexVersion = 0xFFFFFFFF;
}

lv_obj_t *makeSegment(lv_obj_t *parent, const char *text, lv_obj_t **label, lv_event_cb_t cb) {
    lv_obj_t *b = lv_btn_create(parent);
    lv_obj_set_size(b, LV_SIZE_CONTENT, 34);
    lv_obj_set_style_pad_hor(b, 12, 0);
    lv_obj_set_style_radius(b, 10, 0);
    lv_obj_set_style_bg_color(b, kBorder, 0);
    lv_obj_t *l = makeLabel(b, &lv_font_montserrat_12, lv_color_white(), text);
    lv_obj_center(l);
    if (label) *label = l;
    lv_obj_add_event_cb(b, cb, LV_EVENT_CLICKED, nullptr);
    return b;
}


// ---- Map view: a planned stop's map with where you are (the phone's GPS) ----
//
// Full screen, opened from Birds > Trip. Each stop's map (standard + satellite, 4 x 5 km, north up,
// centred on the stop) is made by the app when the trip is planned, as 320x400 tiles at 4 zoom
// levels (ScopeProtocol.h, kScopeMapRequest), and kept on the SD card. Only the (at most 4) tiles
// on screen are decoded, and the last few are kept decoded, so dragging and zooming stay quick
// however big the map. The picker starts a trip and says which stop you're at, like Start Trip /
// "I'm here" in the app. The phone sends its position while a trip is being logged.

lv_point_t polar(const lv_point_t &c, float screenDeg, float r); // with the radar, below
const char *compassPointName(float deg);                          // with the compass, below

lv_obj_t *mapLayer, *mapTitle, *mapStyleLabel, *mapOverlay, *mapStatus, *mapInfo, *mapStopLabel, *mapPrevBtn, *mapNextBtn;
lv_obj_t *pickerLayer, *pickerList, *pickerMapProgress, *pickerMapLabel;

// "Maps: 1,234 of 6,138 tiles" -- the stop maps on the SD card, like the bird cards.
void updatePickerMapProgress() {
    int stored = 0, total = 0;
    gStore.mapProgress(stored, total);
    if (total == 0) {
        lv_obj_add_flag(pickerMapProgress, LV_OBJ_FLAG_HIDDEN);
        lv_label_set_text(pickerMapLabel, gState.sdPresent ? "" : "No SD card: maps come from the phone as you look at them.");
        return;
    }
    lv_obj_clear_flag(pickerMapProgress, LV_OBJ_FLAG_HIDDEN);
    lv_bar_set_range(pickerMapProgress, 0, total);
    lv_bar_set_value(pickerMapProgress, stored, LV_ANIM_OFF);
    if (stored >= total) lv_label_set_text_fmt(pickerMapLabel, "Maps: all %d tiles on the display", total);
    else lv_label_set_text_fmt(pickerMapLabel, "Maps: %d of %d tiles on the display (%d%%) - downloading while the phone app is open",
                               stored, total, (int)((int64_t)stored * 100 / total));
}
lv_obj_t *mapArea;
constexpr int kMapViewW = Protocol::kMapTileW, kMapViewH = Protocol::kMapTileH;
lv_obj_t *mapTileImg[4]; // the 2 x 2 tiles around the screen's top-left one
char mapStopId[41] = {0};   // the stop being shown ("" = none picked yet)
uint8_t mapStyle = Protocol::kMapSatellite;
// Zoom level: 4 = the whole 4 x 5 km, 3 = 2 km on screen, 2 = 1 km, 1 = 500 m, 0 = 250 m.
int mapLevel = 2;
int mapViewX = 0, mapViewY = 0; // screen's top-left, in pixels of the whole map at mapLevel
bool mapDragged = false;
// The map's bounds (from any of its tiles' headers) -- needed before anything can be placed.
bool mapFrameValid = false;
double mapNorth = 0, mapSouth = 0, mapWest = 0, mapEast = 0;
uint32_t shownMapsVersion = 0xFFFFFFFF, shownPickerPlansVersion = 0xFFFFFFFF;
// A tile asked of the phone for the screen (not a background download) -- asked again after 10 s.
struct { char id[41]; uint8_t style, level, col, row; uint32_t ms; } mapAsked = {};

// Decoded tiles, least recently used goes first. 9 x 256 KB of PSRAM.
struct MapTileCache {
    char id[41];
    uint32_t stamp; // the map's version -- a remade map has new tiles
    uint8_t style, level, col, row;
    bool valid;
    uint32_t used;
    RGBImage img;
};
constexpr int kMapTileCache = 9;
MapTileCache mapTiles[kMapTileCache];

const PlanEntry *planById(const char *id) {
    for (int i = 0; i < gState.plans.count; i++) if (strcmp(gState.plans.items[i].id, id) == 0) return &gState.plans.items[i];
    return nullptr;
}

// The stop you're at on the trip being logged, else the first stop with a map.
const PlanEntry *defaultMapStop() {
    const PlanEntry *first = nullptr;
    bool inActiveTrip = false;
    for (int i = 0; i < gState.plans.count; i++) {
        const PlanEntry &e = gState.plans.items[i];
        if (e.kind == 0) { inActiveTrip = e.flags & Protocol::kPlanTripActive; continue; }
        if (inActiveTrip && (e.flags & Protocol::kPlanStopCurrent)) return &e;
        if (!first && e.hasCoordinate()) first = &e;
    }
    return first;
}

double mercatorY(double latDeg) { return log(tan(M_PI / 4 + latDeg * M_PI / 360)); }

int mapLevelW(int level) { return kMapViewW * Protocol::mapGridSize(level); }
int mapLevelH(int level) { return kMapViewH * Protocol::mapGridSize(level); }

// Lat/lon -> pixel of the whole map at the current level (may be off the map).
void mapProject(double lat, double lon, float &x, float &y) {
    x = (float)((lon - mapWest) / (mapEast - mapWest) * mapLevelW(mapLevel));
    y = (float)((mercatorY(mapNorth) - mercatorY(lat)) / (mercatorY(mapNorth) - mercatorY(mapSouth)) * mapLevelH(mapLevel));
}

float mapMetersPerPixel() {
    const double midLat = (mapNorth + mapSouth) / 2;
    return (float)((mapEast - mapWest) * 111320.0 * cos(midLat * M_PI / 180) / mapLevelW(mapLevel));
}

bool phoneOnMap() {
    float x, y;
    mapProject(gState.phone.lat, gState.phone.lon, x, y);
    return x >= 0 && y >= 0 && x < mapLevelW(mapLevel) && y < mapLevelH(mapLevel);
}

// Distance (m) and initial bearing (deg true) from a to b.
void distanceBearing(double lat1, double lon1, double lat2, double lon2, float &meters, float &bearing) {
    const double p1 = lat1 * M_PI / 180, p2 = lat2 * M_PI / 180, dp = p2 - p1, dl = (lon2 - lon1) * M_PI / 180;
    const double a = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2);
    meters = (float)(6371000.0 * 2 * atan2(sqrt(a), sqrt(1 - a)));
    bearing = (float)fmod(atan2(sin(dl) * cos(p2), cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)) * 180 / M_PI + 360, 360);
}

String distanceText(float m) {
    return m < 1000 ? String((int)roundf(m)) + " m" : String(m / 1000, m < 10000 ? 1 : 0) + " km";
}

// Stale once it's older than the phone's fix interval allows (Settings > Trip GPS Updates).
int32_t phoneStaleAfterMs() { return max(30000, (int)gState.phone.intervalS * 2500); }
bool phoneFresh(uint32_t nowMs) { return gState.phone.valid && (int32_t)(nowMs - gState.phone.updatedMs) < phoneStaleAfterMs(); }

// The trip a plan entry belongs to (its index), and the stops of that trip -- for the map's
// previous / next stop arrows.
int tripOfEntry(int index) {
    for (int i = index; i >= 0; i--) if (gState.plans.items[i].kind == 0) return i;
    return -1;
}

int planIndexById(const char *id) {
    for (int i = 0; i < gState.plans.count; i++) if (strcmp(gState.plans.items[i].id, id) == 0) return i;
    return -1;
}

// ---- Tiles ----

void clampMapView() {
    mapViewX = constrain(mapViewX, 0, max(0, mapLevelW(mapLevel) - kMapViewW));
    mapViewY = constrain(mapViewY, 0, max(0, mapLevelH(mapLevel) - kMapViewH));
}

// The shown stop's map version in the current style (0 = the phone hasn't made it yet).
uint32_t shownMapStamp() {
    const PlanEntry *stop = planById(mapStopId);
    return stop ? stop->stamp[mapStyle] : 0;
}

MapTileCache *cachedTile(uint8_t level, uint8_t col, uint8_t row) {
    const uint32_t stamp = shownMapStamp();
    for (MapTileCache &t : mapTiles) {
        if (t.valid && t.stamp == stamp && t.style == mapStyle && t.level == level && t.col == col && t.row == row &&
            strcmp(t.id, mapStopId) == 0) return &t;
    }
    return nullptr;
}

// The tile shown in slot i (0..3) right now.
void slotTile(int i, int &col, int &row) {
    col = mapViewX / kMapViewW + (i % 2);
    row = mapViewY / kMapViewH + (i / 2);
}

bool tileOnScreen(const MapTileCache &t) {
    if (!t.valid || t.style != mapStyle || t.level != mapLevel || strcmp(t.id, mapStopId) != 0) return false;
    for (int i = 0; i < 4; i++) {
        int col, row;
        slotTile(i, col, row);
        if (t.col == col && t.row == row) return true;
    }
    return false;
}

// Puts the cached tiles where they belong; missing ones are fetched by updateMapView().
void placeMapTiles() {
    bool any = false;
    for (int i = 0; i < 4; i++) {
        int col, row;
        slotTile(i, col, row);
        MapTileCache *t = Protocol::mapHasTile(mapLevel, col, row) ? cachedTile(mapLevel, col, row) : nullptr;
        if (!t) { lv_obj_add_flag(mapTileImg[i], LV_OBJ_FLAG_HIDDEN); continue; }
        t->used = millis();
        if (lv_img_get_src(mapTileImg[i]) != &t->img.dsc) lv_img_set_src(mapTileImg[i], &t->img.dsc);
        lv_obj_set_pos(mapTileImg[i], col * kMapViewW - mapViewX, row * kMapViewH - mapViewY);
        lv_obj_clear_flag(mapTileImg[i], LV_OBJ_FLAG_HIDDEN);
        any = true;
    }
    if (any) lv_obj_add_flag(mapStatus, LV_OBJ_FLAG_HIDDEN);
    lv_obj_invalidate(mapArea);
}

// Decodes a tile into the least recently used cache slot that isn't on screen.
MapTileCache *decodeTile(const ScopeStorage::MapView &v) {
    MapTileCache *slot = nullptr;
    for (MapTileCache &t : mapTiles) {
        if (tileOnScreen(t)) continue;
        if (!slot || !t.valid || (slot->valid && t.used < slot->used)) slot = &t;
        if (!t.valid) break;
    }
    if (!slot) return nullptr;
    slot->valid = false;
    if (!decodeJpeg(v.jpeg, v.jpegLen, 1, slot->img)) return nullptr;
    lv_img_cache_invalidate_src(&slot->img.dsc);
    strlcpy(slot->id, mapStopId, sizeof(slot->id));
    slot->stamp = v.stamp;
    slot->style = mapStyle;
    slot->level = v.level;
    slot->col = v.col;
    slot->row = v.row;
    slot->used = millis();
    slot->valid = true;
    return slot;
}

void setMapFrame(const ScopeStorage::MapView &v) {
    mapNorth = v.north;
    mapSouth = v.south;
    mapWest = v.west;
    mapEast = v.east;
    mapFrameValid = true;
}

// Centres the screen on a point of the whole map, given as fractions (0-1) of its width / height.
void centerMapOnFraction(double fx, double fy) {
    mapViewX = (int)(fx * mapLevelW(mapLevel)) - kMapViewW / 2;
    mapViewY = (int)(fy * mapLevelH(mapLevel)) - kMapViewH / 2;
    clampMapView();
    placeMapTiles();
}

void zoomMap(int direction) { // +1 = closer
    if (!mapFrameValid) return;
    const int next = constrain(mapLevel - direction, 0, Protocol::kMapLevels - 1);
    if (next == mapLevel) return;
    const double fx = (mapViewX + kMapViewW / 2.0) / mapLevelW(mapLevel), fy = (mapViewY + kMapViewH / 2.0) / mapLevelH(mapLevel);
    mapLevel = next;
    centerMapOnFraction(fx, fy);
    lv_obj_invalidate(mapOverlay);
}

// Asks the phone for a tile you're looking at (one at a time; again after 10 s).
void askForTile(uint8_t level, uint8_t col, uint8_t row) {
    if (!gLink.hasApp() || !gState.appLinked(millis(), Config::kAppLinkTimeoutMs)) return;
    const bool same = strcmp(mapAsked.id, mapStopId) == 0 && mapAsked.style == mapStyle && mapAsked.level == level &&
                      mapAsked.col == col && mapAsked.row == row;
    if (same && (int32_t)(millis() - mapAsked.ms) < 10000) return;
    if (gLink.mapPending() && !gLink.mapPrefetchInFlight()) return; // another tile you're looking at is on its way
    gLink.requestMap(mapStopId, mapStyle, level, col, row, false);
    strlcpy(mapAsked.id, mapStopId, sizeof(mapAsked.id));
    mapAsked.style = mapStyle;
    mapAsked.level = level;
    mapAsked.col = col;
    mapAsked.row = row;
    mapAsked.ms = millis();
}

// One step of filling the screen: the map's bounds first (from the overview tile), then each
// missing tile on screen -- from the SD card, or asked of the phone. One decode per call keeps the
// UI responsive while dragging.
void fillMapTiles() {
    const PlanEntry *stop = planById(mapStopId);
    if (!stop || !stop->hasCoordinate()) return;
    const uint32_t stamp = stop->stamp[mapStyle];
    ScopeStorage::MapView v;
    if (!mapFrameValid) {
        if (!stamp) {
            lv_label_set_text(mapStatus, "The phone hasn't made this map yet. It does while the app is open with internet; then it downloads here.");
            lv_obj_clear_flag(mapStatus, LV_OBJ_FLAG_HIDDEN);
            return;
        }
        if (gStore.loadTile(mapStopId, mapStyle, stamp, Protocol::kMapLevels - 1, 0, 0, v)) {
            setMapFrame(v);
            decodeTile(v);
            centerMapOnFraction(0.5, 0.5); // open on the stop
            lv_obj_invalidate(mapOverlay);
        } else {
            askForTile(Protocol::kMapLevels - 1, 0, 0);
            lv_label_set_text(mapStatus, gState.appLinked(millis(), Config::kAppLinkTimeoutMs)
                ? "Getting this map from the phone..."
                : "This map isn't on the display yet. It downloads while the phone is connected (the phone makes it when it has internet).");
            lv_obj_clear_flag(mapStatus, LV_OBJ_FLAG_HIDDEN);
        }
        return;
    }
    for (int i = 0; i < 4; i++) {
        int col, row;
        slotTile(i, col, row);
        if (!Protocol::mapHasTile(mapLevel, col, row) || cachedTile(mapLevel, col, row)) continue;
        if (gStore.loadTile(mapStopId, mapStyle, stamp, mapLevel, col, row, v)) {
            if (decodeTile(v)) placeMapTiles();
        } else {
            askForTile(mapLevel, col, row);
        }
        return;
    }
}

void updateStopNavigation(); // below

void loadShownMap() {
    mapFrameValid = false;
    for (int i = 0; i < 4; i++) lv_obj_add_flag(mapTileImg[i], LV_OBJ_FLAG_HIDDEN);
    const PlanEntry *stop = planById(mapStopId);
    lv_label_set_text(mapTitle, stop ? stop->name : "No stop picked");
    updateStopNavigation();
    lv_label_set_text(mapStyleLabel, mapStyle == Protocol::kMapSatellite ? "Map" : "Satellite");
    if (!stop) {
        lv_label_set_text(mapStatus, gState.plans.valid ? "Tap Trips to pick a trip and a stop."
                                                        : "No planned trips yet. Plan a trip with stops in the app; the phone sends it here.");
        lv_obj_clear_flag(mapStatus, LV_OBJ_FLAG_HIDDEN);
        return;
    }
    if (!stop->hasCoordinate()) {
        lv_label_set_text(mapStatus, "This stop has no location in the plan, so it has no map.");
        lv_obj_clear_flag(mapStatus, LV_OBJ_FLAG_HIDDEN);
        return;
    }
    fillMapTiles();
}

// Stop k of n on its trip (k from 1), or 0 when the stop isn't in the plans.
int stopPosition(const char *stopId, int &count, int &tripIndex) {
    count = 0;
    tripIndex = -1;
    const int idx = planIndexById(stopId);
    if (idx < 0 || gState.plans.items[idx].kind != 1) return 0;
    tripIndex = tripOfEntry(idx);
    int position = 0;
    for (int i = tripIndex + 1; i < gState.plans.count && gState.plans.items[i].kind == 1; i++) {
        count++;
        if (i == idx) position = count;
    }
    return position;
}

void updateStopNavigation() {
    int count = 0, trip = -1;
    const int position = stopPosition(mapStopId, count, trip);
    if (position > 0 && trip >= 0) {
        const int pct = gStore.stopMapPercent(mapStopId);
        if (pct >= 0 && pct < 100) {
            lv_label_set_text_fmt(mapStopLabel, "Stop %d of %d - %s - map %d%%", position, count, gState.plans.items[trip].name, pct);
        } else {
            lv_label_set_text_fmt(mapStopLabel, "Stop %d of %d - %s", position, count, gState.plans.items[trip].name);
        }
    } else {
        lv_label_set_text(mapStopLabel, "");
    }
    auto show = [](lv_obj_t *o, bool on) { if (on) lv_obj_clear_flag(o, LV_OBJ_FLAG_HIDDEN); else lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN); };
    show(mapPrevBtn, count > 1);
    show(mapNextBtn, count > 1);
}

void showMapStop(const char *stopId);

// Previous / next stop on the same trip (wraps) -- browse a trip's maps before you get there.
void stepMapStop(int direction) {
    int count = 0, trip = -1;
    const int position = stopPosition(mapStopId, count, trip);
    if (position == 0 || count < 2) return;
    const int next = (position - 1 + direction + count) % count; // 0-based
    showMapStop(gState.plans.items[trip + 1 + next].id);
}

void showMapStop(const char *stopId) {
    strlcpy(mapStopId, stopId, sizeof(mapStopId));
    loadShownMap();
    lv_obj_invalidate(mapOverlay);
}

void openMap() {
    if (!mapStopId[0] || !planById(mapStopId)) {
        const PlanEntry *d = defaultMapStop();
        mapStopId[0] = 0;
        if (d) strlcpy(mapStopId, d->id, sizeof(mapStopId));
    }
    loadShownMap();
    shownMapsVersion = gState.mapsVersion;
    lv_obj_clear_flag(mapLayer, LV_OBJ_FLAG_HIDDEN);
}

// Stop marker, accuracy circle, your position, and where the scope points.
void mapOverlayDraw(lv_event_t *e) {
    if (!mapFrameValid) return;
    lv_obj_t *obj = lv_event_get_target(e);
    lv_draw_ctx_t *ctx = lv_event_get_draw_ctx(e);
    lv_area_t a;
    lv_obj_get_coords(obj, &a);
    auto toScreen = [](float &x, float &y) { x -= mapViewX; y -= mapViewY; };
    const PlanEntry *stop = planById(mapStopId);
    if (stop && stop->hasCoordinate()) {
        float x, y;
        mapProject(stop->latE6 / 1e6, stop->lonE6 / 1e6, x, y);
        toScreen(x, y);
        lv_draw_rect_dsc_t ring;
        lv_draw_rect_dsc_init(&ring);
        ring.radius = LV_RADIUS_CIRCLE;
        ring.bg_opa = LV_OPA_TRANSP;
        ring.border_color = kWarn;
        ring.border_width = 3;
        const lv_area_t r = {(lv_coord_t)(a.x1 + x - 9), (lv_coord_t)(a.y1 + y - 9), (lv_coord_t)(a.x1 + x + 9), (lv_coord_t)(a.y1 + y + 9)};
        lv_draw_rect(ctx, &ring, &r);
    }
    const uint32_t nowMs = millis();
    if (!gState.phone.valid || !phoneOnMap()) return; // the info line says where you are instead
    float x, y;
    mapProject(gState.phone.lat, gState.phone.lon, x, y);
    toScreen(x, y);
    const bool fresh = phoneFresh(nowMs);
    const lv_color_t dotColor = fresh ? lv_color_hex(0x2F80FF) : kMuted;
    const float accPx = gState.phone.accuracyM / mapMetersPerPixel();
    if (accPx > 8) {
        lv_draw_rect_dsc_t acc;
        lv_draw_rect_dsc_init(&acc);
        acc.radius = LV_RADIUS_CIRCLE;
        acc.bg_color = dotColor;
        acc.bg_opa = LV_OPA_20;
        acc.border_color = dotColor;
        acc.border_opa = LV_OPA_60;
        acc.border_width = 1;
        const lv_coord_t rr = (lv_coord_t)fminf(accPx, 400);
        const lv_area_t r = {(lv_coord_t)(a.x1 + x - rr), (lv_coord_t)(a.y1 + y - rr), (lv_coord_t)(a.x1 + x + rr), (lv_coord_t)(a.y1 + y + rr)};
        lv_draw_rect(ctx, &acc, &r);
    }
    // Where the scope points (its compass, true north), from your position.
    const float scopeAz = gState.scopeTrueAzimuthDeg();
    if (fresh && gState.compassPresent && !isnan(scopeAz)) {
        lv_draw_line_dsc_t line;
        lv_draw_line_dsc_init(&line);
        line.color = lv_color_white();
        line.width = 3;
        line.round_end = 1;
        const lv_point_t c = {(lv_coord_t)(a.x1 + x), (lv_coord_t)(a.y1 + y)};
        const lv_point_t tip = polar(c, scopeAz, 44);
        lv_draw_line(ctx, &line, &c, &tip);
    }
    lv_draw_rect_dsc_t dot;
    lv_draw_rect_dsc_init(&dot);
    dot.radius = LV_RADIUS_CIRCLE;
    dot.bg_color = dotColor;
    dot.border_color = lv_color_white();
    dot.border_width = 2;
    const lv_area_t r = {(lv_coord_t)(a.x1 + x - 7), (lv_coord_t)(a.y1 + y - 7), (lv_coord_t)(a.x1 + x + 7), (lv_coord_t)(a.y1 + y + 7)};
    lv_draw_rect(ctx, &dot, &r);
}

void updateMapInfo(uint32_t nowMs) {
    const PlanEntry *stop = planById(mapStopId);
    String t;
    if (!gState.phone.valid) {
        t = "Your position: start the trip (Trips)";
    } else {
        if (stop && stop->hasCoordinate()) {
            float meters, bearing;
            distanceBearing(gState.phone.lat, gState.phone.lon, stop->latE6 / 1e6, stop->lonE6 / 1e6, meters, bearing);
            t = meters < 15 ? String("You're at the stop") : "Stop: " + distanceText(meters) + " " + compassPointName(bearing);
            if (mapFrameValid && !phoneOnMap()) t += " (off map)";
        }
        t += "  +/-" + String((int)roundf(gState.phone.accuracyM)) + " m";
        const int32_t ageMs = (int32_t)(nowMs - gState.phone.updatedMs);
        if (ageMs >= phoneStaleAfterMs()) t += "  " + (ageMs < 3600000 ? String(ageMs / 60000) + " min old" : String("1 h+ old"));
    }
    lv_label_set_text(mapInfo, t.c_str());
}

void rebuildPicker() {
    lv_obj_clean(pickerList);
    shownPickerPlansVersion = gState.plansVersion;
    if (gState.plans.count == 0) {
        lv_obj_t *l = makeLabel(pickerList, &lv_font_montserrat_16, kMuted,
            "No planned trips. Plan a trip with stops in the app (today or later); it shows up here while the phone is connected.");
        lv_label_set_long_mode(l, LV_LABEL_LONG_WRAP);
        lv_obj_set_width(l, lv_pct(100));
        return;
    }
    bool tripActive = false, tripMapsOn = false;
    for (int i = 0; i < gState.plans.count; i++) {
        const PlanEntry &e = gState.plans.items[i];
        lv_obj_t *row = lv_obj_create(pickerList);
        styleSurface(row);
        lv_obj_set_width(row, lv_pct(100));
        lv_obj_set_height(row, LV_SIZE_CONTENT);
        lv_obj_set_style_pad_all(row, 8, 0);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
        lv_obj_set_flex_align(row, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
        lv_obj_set_style_pad_column(row, 6, 0);
        if (e.kind == 0) {
            tripActive = e.flags & Protocol::kPlanTripActive;
            tripMapsOn = e.flags & Protocol::kPlanTripMaps;
            lv_obj_set_style_bg_color(row, kBorder, 0);
            lv_obj_t *name = makeLabel(row, &lv_font_montserrat_16, kText, e.name);
            lv_label_set_long_mode(name, LV_LABEL_LONG_WRAP);
            lv_obj_set_flex_grow(name, 1);
            // Maps on / off for this trip (the one being logged always has them).
            const bool mapsOn = e.flags & Protocol::kPlanTripMaps;
            if (!tripActive) {
                lv_obj_t *m = makeButton(row, mapsOn ? LV_SYMBOL_OK " Maps" : "Maps", mapsOn ? kAccent : kBorder, [](lv_event_t *ev) {
                    const PlanEntry *p = planById((const char *)lv_event_get_user_data(ev));
                    if (!p) return;
                    gLink.sendTripMaps(p->id, !(p->flags & Protocol::kPlanTripMaps));
                    rebuildPicker();
                }, (void *)e.id);
                lv_obj_set_size(m, LV_SIZE_CONTENT, 38);
                lv_obj_set_style_pad_hor(m, 8, 0);
            }
            if (tripActive) {
                makeLabel(row, &lv_font_montserrat_12, kAccent, "Logging");
            } else {
                lv_obj_t *b = makeButton(row, (e.flags & Protocol::kPlanTripStarted) ? "Log here" : "Start trip", kAccent, [](lv_event_t *ev) {
                    const PlanEntry *p = planById((const char *)lv_event_get_user_data(ev));
                    if (p) gLink.sendStartTrip(p->id);
                }, (void *)e.id);
                lv_obj_set_size(b, LV_SIZE_CONTENT, 38);
                lv_obj_set_style_pad_hor(b, 10, 0);
            }
            continue;
        }
        const bool current = tripActive && (e.flags & Protocol::kPlanStopCurrent);
        const bool showing = strcmp(e.id, mapStopId) == 0;
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        if (showing) lv_obj_set_style_border_color(row, kAccent, 0);
        lv_obj_add_event_cb(row, [](lv_event_t *ev) { // tap = look at this stop's map
            showMapStop((const char *)lv_event_get_user_data(ev));
            lv_obj_add_flag(pickerLayer, LV_OBJ_FLAG_HIDDEN);
        }, LV_EVENT_CLICKED, (void *)e.id);
        String label = String(current ? LV_SYMBOL_GPS " " : "") + e.name;
        const int pct = e.hasCoordinate() ? gStore.stopMapPercent(e.id) : -1;
        if (pct >= 0 && pct < 100) label += "\nmap " + String(pct) + "% downloaded";
        else if (pct < 0 && !(tripMapsOn || tripActive)) label += "\nno map - turn on Maps for this trip";
        lv_obj_t *name = makeLabel(row, &lv_font_montserrat_16, current ? kAccent : kText, label.c_str());
        lv_label_set_long_mode(name, LV_LABEL_LONG_WRAP);
        lv_obj_set_flex_grow(name, 1);
        if (!current) {
            lv_obj_t *b = makeButton(row, "I'm here", kBorder, [](lv_event_t *ev) {
                const char *id = (const char *)lv_event_get_user_data(ev);
                gLink.sendArriveAt(id);
                showMapStop(id);
                lv_obj_add_flag(pickerLayer, LV_OBJ_FLAG_HIDDEN);
            }, (void *)e.id);
            lv_obj_set_size(b, LV_SIZE_CONTENT, 38);
            lv_obj_set_style_pad_hor(b, 10, 0);
        }
    }
}

void buildMapView() {
    mapLayer = makeOverlay();
    lv_obj_set_style_pad_all(mapLayer, 0, 0);
    lv_obj_clear_flag(mapLayer, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *bar = lv_obj_create(mapLayer);
    lv_obj_set_size(bar, Config::kScreenWidth, 44);
    lv_obj_align(bar, LV_ALIGN_TOP_MID, 0, 0);
    lv_obj_set_style_bg_color(bar, kSurface, 0);
    lv_obj_set_style_border_width(bar, 0, 0);
    lv_obj_set_style_radius(bar, 0, 0);
    lv_obj_set_style_pad_all(bar, 4, 0);
    lv_obj_clear_flag(bar, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *back = makeButton(bar, LV_SYMBOL_LEFT, kBorder, [](lv_event_t *) { lv_obj_add_flag(mapLayer, LV_OBJ_FLAG_HIDDEN); });
    lv_obj_set_size(back, 44, 36);
    lv_obj_align(back, LV_ALIGN_LEFT_MID, 0, 0);
    mapTitle = makeLabel(bar, &lv_font_montserrat_16, kText, "");
    lv_label_set_long_mode(mapTitle, LV_LABEL_LONG_DOT);
    lv_obj_set_width(mapTitle, 120);
    lv_obj_align(mapTitle, LV_ALIGN_LEFT_MID, 52, 0);
    lv_obj_t *style = makeButton(bar, "", kBorder, [](lv_event_t *) {
        mapStyle = mapStyle == Protocol::kMapSatellite ? Protocol::kMapStandard : Protocol::kMapSatellite;
        Preferences p;
        p.begin("scope", false);
        p.putUChar("mapstyle", mapStyle);
        p.end();
        // Same place and zoom, other style.
        lv_label_set_text(mapStyleLabel, mapStyle == Protocol::kMapSatellite ? "Map" : "Satellite");
        placeMapTiles();
        fillMapTiles();
    });
    lv_obj_set_size(style, 70, 36);
    lv_obj_align(style, LV_ALIGN_RIGHT_MID, -74, 0);
    mapStyleLabel = lv_obj_get_child(style, 0);
    lv_obj_t *trips = makeButton(bar, "Trips", kAccent, [](lv_event_t *) {
        rebuildPicker();
        updatePickerMapProgress();
        lv_obj_clear_flag(pickerLayer, LV_OBJ_FLAG_HIDDEN);
    });
    lv_obj_set_size(trips, 70, 36);
    lv_obj_align(trips, LV_ALIGN_RIGHT_MID, 0, 0);

    // The map: a clipping area holding the tile images (moved as you drag) and, on top, the
    // overlay that draws you / the stop and takes the drags.
    mapArea = lv_obj_create(mapLayer);
    lv_obj_set_size(mapArea, kMapViewW, kMapViewH);
    lv_obj_align(mapArea, LV_ALIGN_TOP_LEFT, 0, 44);
    lv_obj_set_style_bg_color(mapArea, kBg, 0);
    lv_obj_set_style_border_width(mapArea, 0, 0);
    lv_obj_set_style_radius(mapArea, 0, 0);
    lv_obj_set_style_pad_all(mapArea, 0, 0);
    lv_obj_clear_flag(mapArea, LV_OBJ_FLAG_SCROLLABLE);
    for (int i = 0; i < 4; i++) {
        mapTileImg[i] = lv_img_create(mapArea);
        lv_obj_add_flag(mapTileImg[i], LV_OBJ_FLAG_HIDDEN);
    }
    mapOverlay = lv_obj_create(mapArea);
    lv_obj_set_size(mapOverlay, kMapViewW, kMapViewH);
    lv_obj_set_pos(mapOverlay, 0, 0);
    lv_obj_set_style_bg_opa(mapOverlay, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(mapOverlay, 0, 0);
    lv_obj_set_style_radius(mapOverlay, 0, 0);
    lv_obj_clear_flag(mapOverlay, (lv_obj_flag_t)(LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_GESTURE_BUBBLE));
    lv_obj_add_flag(mapOverlay, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(mapOverlay, mapOverlayDraw, LV_EVENT_DRAW_MAIN, nullptr);
    lv_obj_add_event_cb(mapOverlay, [](lv_event_t *e) { // drag to pan
        if (!mapFrameValid || lv_event_get_code(e) != LV_EVENT_PRESSING) return;
        lv_point_t v;
        lv_indev_get_vect(lv_indev_get_act(), &v);
        if (v.x == 0 && v.y == 0) return;
        mapViewX -= v.x;
        mapViewY -= v.y;
        clampMapView();
        placeMapTiles();
    }, LV_EVENT_ALL, nullptr);
    // Zoom in / out / centre on you, down the right edge.
    int zy = 8;
    for (int i = 0; i < 3; i++) {
        static const char *labels[] = {LV_SYMBOL_PLUS, LV_SYMBOL_MINUS, LV_SYMBOL_GPS};
        lv_obj_t *b = makeButton(mapArea, labels[i], kSurface, [](lv_event_t *ev) {
            const int which = (int)(intptr_t)lv_event_get_user_data(ev);
            if (which == 0) zoomMap(1);
            else if (which == 1) zoomMap(-1);
            else if (mapFrameValid) { // centre on you (or the stop when the phone's position isn't known)
                float x, y;
                const PlanEntry *stop = planById(mapStopId);
                if (gState.phone.valid) mapProject(gState.phone.lat, gState.phone.lon, x, y);
                else if (stop) mapProject(stop->latE6 / 1e6, stop->lonE6 / 1e6, x, y);
                else return;
                centerMapOnFraction(x / mapLevelW(mapLevel), y / mapLevelH(mapLevel));
            }
            lv_obj_invalidate(mapOverlay);
        }, (void *)(intptr_t)i);
        lv_obj_set_size(b, 44, 44);
        lv_obj_set_style_bg_opa(b, LV_OPA_80, 0);
        lv_obj_align(b, LV_ALIGN_TOP_RIGHT, -6, zy);
        zy += 52;
    }
    mapStatus = makeLabel(mapLayer, &lv_font_montserrat_16, kMuted, "");
    lv_label_set_long_mode(mapStatus, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(mapStatus, Config::kScreenWidth - 40);
    lv_obj_align(mapStatus, LV_ALIGN_TOP_MID, 0, 160);
    lv_obj_t *attribution = makeLabel(mapArea, &lv_font_montserrat_12, lv_color_white(), "Apple Maps");
    lv_obj_align(attribution, LV_ALIGN_BOTTOM_LEFT, 4, -2);

    // Bottom strip: previous stop, "Stop 2 of 5 - trip" + where you are, next stop.
    mapPrevBtn = makeButton(mapLayer, LV_SYMBOL_LEFT, kBorder, [](lv_event_t *) { stepMapStop(-1); });
    lv_obj_set_size(mapPrevBtn, 40, 32);
    lv_obj_align(mapPrevBtn, LV_ALIGN_BOTTOM_LEFT, 2, -2);
    mapNextBtn = makeButton(mapLayer, LV_SYMBOL_RIGHT, kBorder, [](lv_event_t *) { stepMapStop(1); });
    lv_obj_set_size(mapNextBtn, 40, 32);
    lv_obj_align(mapNextBtn, LV_ALIGN_BOTTOM_RIGHT, -2, -2);
    mapStopLabel = makeLabel(mapLayer, &lv_font_montserrat_12, kMuted, "");
    lv_label_set_long_mode(mapStopLabel, LV_LABEL_LONG_DOT);
    lv_obj_set_width(mapStopLabel, Config::kScreenWidth - 96);
    lv_obj_set_style_text_align(mapStopLabel, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(mapStopLabel, LV_ALIGN_BOTTOM_MID, 0, -19);
    mapInfo = makeLabel(mapLayer, &lv_font_montserrat_12, kText, "");
    lv_label_set_long_mode(mapInfo, LV_LABEL_LONG_DOT);
    lv_obj_set_width(mapInfo, Config::kScreenWidth - 96);
    lv_obj_set_style_text_align(mapInfo, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(mapInfo, LV_ALIGN_BOTTOM_MID, 0, -3);

    Preferences p;
    p.begin("scope", true);
    mapStyle = p.getUChar("mapstyle", Protocol::kMapSatellite);
    p.end();

    // Picker: trips (Start trip) and their stops (tap = view its map, I'm here = arrived).
    pickerLayer = makeOverlay();
    lv_obj_set_flex_flow(pickerLayer, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_row(pickerLayer, 8, 0);
    lv_obj_t *pickerBack = makeButton(pickerLayer, LV_SYMBOL_LEFT "  Back", kBorder, [](lv_event_t *) {
        lv_obj_add_flag(pickerLayer, LV_OBJ_FLAG_HIDDEN);
    });
    lv_obj_set_size(pickerBack, 110, 40);
    makeLabel(pickerLayer, &lv_font_montserrat_20, kText, "Trips & stops");
    lv_obj_t *hint = makeLabel(pickerLayer, &lv_font_montserrat_12, kMuted,
        "Tap a stop to look at its map - any time, before you go too; < > on the map flips through the trip's stops. "
        "I'm here = you've arrived (starts the trip if needed); the phone logs your birds there.");
    lv_label_set_long_mode(hint, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(hint, lv_pct(100));
    pickerMapProgress = lv_bar_create(pickerLayer);
    lv_obj_set_size(pickerMapProgress, lv_pct(100), 10);
    lv_obj_set_style_bg_color(pickerMapProgress, kBorder, 0);
    lv_obj_set_style_bg_color(pickerMapProgress, kAccent, LV_PART_INDICATOR);
    pickerMapLabel = makeLabel(pickerLayer, &lv_font_montserrat_12, kMuted, "");
    lv_label_set_long_mode(pickerMapLabel, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(pickerMapLabel, lv_pct(100));
    pickerList = lv_obj_create(pickerLayer);
    lv_obj_set_size(pickerList, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(pickerList, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(pickerList, 0, 0);
    lv_obj_set_style_pad_all(pickerList, 0, 0);
    lv_obj_set_style_pad_row(pickerList, 6, 0);
    lv_obj_set_flex_flow(pickerList, LV_FLEX_FLOW_COLUMN);
}

void updateMapView(uint32_t nowMs) {
    if (!lv_obj_has_flag(pickerLayer, LV_OBJ_FLAG_HIDDEN)) {
        if (gState.plansVersion != shownPickerPlansVersion) rebuildPicker();
        static uint32_t lastProgress = 0, lastRows = 0;
        if ((int32_t)(nowMs - lastProgress) >= 1000) { lastProgress = nowMs; updatePickerMapProgress(); }
        if ((int32_t)(nowMs - lastRows) >= 15000) { lastRows = nowMs; rebuildPicker(); } // each stop's %
    }
    if (lv_obj_has_flag(mapLayer, LV_OBJ_FLAG_HIDDEN)) return;
    // A tile arrived -- it may be one the screen is waiting for.
    if (gState.mapsVersion != shownMapsVersion) {
        shownMapsVersion = gState.mapsVersion;
        mapAsked.ms = 0;
    }
    // At most 10 steps a second: a tile that isn't on the SD card yet would otherwise be looked for
    // on every pass.
    static uint32_t lastFill = 0;
    if ((int32_t)(nowMs - lastFill) >= 100) {
        lastFill = nowMs;
        const uint32_t t0 = millis();
        fillMapTiles();
        const uint32_t d = millis() - t0;
        if (d > 500) Serial.printf("[slow] map tiles took %lu ms (level %d, view %d,%d)\n", (unsigned long)d, mapLevel, mapViewX, mapViewY);
        if (d > 2000) gStore.logSlow("map tiles", d, "level " + String(mapLevel) + " style " + String(mapStyle));
    }
    static uint32_t last = 0;
    if ((int32_t)(nowMs - last) < 500) return;
    last = nowMs;
    lv_obj_invalidate(mapOverlay);
    updateMapInfo(nowMs);
    static uint32_t lastNav = 0;
    if ((int32_t)(nowMs - lastNav) >= 3000) { // the map's download %
        lastNav = nowMs;
        updateStopNavigation();
    }
}

void buildBirds() {
    lv_obj_set_flex_flow(tabBirds, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(tabBirds, 8, 0);
    lv_obj_set_scroll_dir(tabBirds, LV_DIR_VER); // horizontal swipes go to the rows, not the page

    lv_obj_t *header = lv_obj_create(tabBirds);
    lv_obj_set_size(header, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(header, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(header, 0, 0);
    lv_obj_set_style_pad_all(header, 0, 0);
    lv_obj_clear_flag(header, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(header, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(header, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_column(header, 6, 0);
    birdsHeardBtn = makeSegment(header, "Heard", nullptr, [](lv_event_t *) { setBirdsView(kViewHeard); });
    birdsTargetsBtn = makeSegment(header, "Targets", &birdsTargetsBtnLabel, [](lv_event_t *) { setBirdsView(kViewTargets); });
    birdsTripBtn = makeSegment(header, "Trip", nullptr, [](lv_event_t *) { setBirdsView(kViewTrip); });
    birdsCardsBtn = makeSegment(header, LV_SYMBOL_SD_CARD " Cards", nullptr, [](lv_event_t *) { setBirdsView(kViewCards); });
    // Mark / Confirm last / Undo -- big enough to hit with an eye still at the eyepiece. The label
    // flashes the result for a moment; the phone also says it.
    handsFreeRow = lv_obj_create(tabBirds);
    lv_obj_set_size(handsFreeRow, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(handsFreeRow, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(handsFreeRow, 0, 0);
    lv_obj_set_style_pad_all(handsFreeRow, 0, 0);
    lv_obj_set_style_pad_column(handsFreeRow, 6, 0);
    lv_obj_clear_flag(handsFreeRow, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(handsFreeRow, LV_FLEX_FLOW_ROW);
    static const HandsFreeButton buttons[] = {
        {LV_SYMBOL_GPS " Mark", Protocol::kCmdMark, kAccent},
        {LV_SYMBOL_OK " Saw it", Protocol::kCmdConfirmLast, kBorder},
        {LV_SYMBOL_LEFT " Undo", Protocol::kCmdUndoLast, kBorder},
    };
    for (const auto &spec : buttons) {
        lv_obj_t *b = makeButton(handsFreeRow, spec.text, spec.color, [](lv_event_t *e) {
            const HandsFreeButton *spec = (const HandsFreeButton *)lv_event_get_user_data(e);
            lv_obj_t *btn = lv_event_get_target(e);
            gTalk.chirp();
            if (!gLink.hasApp()) { flashHandsFree(btn, "No phone"); return; }
            // A new press replaces one still waiting: put that button's own label back.
            if (handsFreePending && handsFreePending != btn) {
                const HandsFreeButton *s = (const HandsFreeButton *)lv_obj_get_user_data(handsFreePending);
                lv_label_set_text(lv_obj_get_child(handsFreePending, 0), s->text);
            }
            gLink.sendButton(spec->command);
            handsFreePending = btn;
            lv_label_set_text(lv_obj_get_child(btn, 0), "Sending...");
        }, (void *)&spec);
        lv_obj_set_user_data(b, (void *)&spec);
        lv_obj_set_flex_grow(b, 1);
        lv_obj_set_height(b, 44);
    }

    birdsEmpty = makeLabel(tabBirds, &lv_font_montserrat_16, kMuted,
        "No detections yet.\n\nStart Bird Sounds on the phone - each bird it hears shows up here. Tap one for its card; swipe left to remove it.");
    lv_label_set_long_mode(birdsEmpty, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(birdsEmpty, lv_pct(100));
    birdsList = lv_obj_create(tabBirds);
    lv_obj_set_size(birdsList, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(birdsList, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(birdsList, 0, 0);
    lv_obj_set_style_pad_all(birdsList, 0, 0);
    lv_obj_set_style_pad_row(birdsList, 6, 0);
    lv_obj_set_flex_flow(birdsList, LV_FLEX_FLOW_COLUMN);
    // Under the list (the header row has no room left with four views).
    birdsClearBtn = lv_btn_create(tabBirds);
    lv_obj_set_size(birdsClearBtn, lv_pct(100), 40);
    lv_obj_set_style_bg_color(birdsClearBtn, kBorder, 0);
    lv_obj_set_style_radius(birdsClearBtn, 10, 0);
    birdsClearLabel = makeLabel(birdsClearBtn, &lv_font_montserrat_16, lv_color_white(), LV_SYMBOL_TRASH " Clear");
    lv_obj_center(birdsClearLabel);
    lv_obj_add_event_cb(birdsClearBtn, onClearBirds, LV_EVENT_CLICKED, nullptr);
    lv_obj_add_flag(birdsClearBtn, LV_OBJ_FLAG_HIDDEN);

    targetsInfo = makeLabel(tabBirds, &lv_font_montserrat_12, kMuted, "");
    lv_label_set_long_mode(targetsInfo, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(targetsInfo, lv_pct(100));
    // "I've moved": the app adds a new location where the phone is and the checklist starts fresh.
    targetsNewLocBtn = lv_btn_create(tabBirds);
    lv_obj_set_size(targetsNewLocBtn, lv_pct(100), 40);
    lv_obj_set_style_bg_color(targetsNewLocBtn, kBorder, 0);
    lv_obj_set_style_radius(targetsNewLocBtn, 10, 0);
    targetsNewLocLabel = makeLabel(targetsNewLocBtn, &lv_font_montserrat_16, lv_color_white(), LV_SYMBOL_PLUS "  New location (I've moved)");
    lv_obj_center(targetsNewLocLabel);
    lv_obj_add_event_cb(targetsNewLocBtn, [](lv_event_t *) {
        const uint32_t now = millis();
        if (newLocArmedMs && (int32_t)(now - newLocArmedMs) < 3000) {
            newLocArmedMs = 0;
            gLink.sendNewLocation(); // queued if the phone is out of reach
            lv_label_set_text(targetsNewLocLabel, "Starting a new location...");
            lv_obj_set_style_bg_color(targetsNewLocBtn, kBorder, 0);
            return;
        }
        newLocArmedMs = now;
        lv_label_set_text(targetsNewLocLabel, "Tap again: new location here");
        lv_obj_set_style_bg_color(targetsNewLocBtn, kAccent, 0);
    }, LV_EVENT_CLICKED, nullptr);
    targetsEmpty = makeLabel(tabBirds, &lv_font_montserrat_16, kMuted,
        "No trip is being logged.\n\nOn the phone, open a planned trip and tap Start Trip (or I'm here at a stop). "
        "Its target birds show up here - tap one to check it off. Birds that Sound ID hears are checked automatically.");
    lv_label_set_long_mode(targetsEmpty, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(targetsEmpty, lv_pct(100));
    targetsList = lv_obj_create(tabBirds);
    lv_obj_set_size(targetsList, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(targetsList, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(targetsList, 0, 0);
    lv_obj_set_style_pad_all(targetsList, 0, 0);
    lv_obj_set_style_pad_row(targetsList, 6, 0);
    lv_obj_set_flex_flow(targetsList, LV_FLEX_FLOW_COLUMN);

    tripMapBtn = makeButton(tabBirds, LV_SYMBOL_GPS "  Map & trip stops", kAccent, [](lv_event_t *) { openMap(); });
    lv_obj_set_size(tripMapBtn, lv_pct(100), 44);
    tripEmpty = makeLabel(tabBirds, &lv_font_montserrat_16, kMuted,
        "Nothing seen on this trip yet.\n\nWhat you see or hear at each location shows up here, newest location first - "
        "so you can look back at earlier stops while you're out. Tap a bird for its card.");
    lv_label_set_long_mode(tripEmpty, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(tripEmpty, lv_pct(100));
    tripList = lv_obj_create(tabBirds);
    lv_obj_set_size(tripList, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(tripList, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(tripList, 0, 0);
    lv_obj_set_style_pad_all(tripList, 0, 0);
    lv_obj_set_style_pad_row(tripList, 6, 0);
    lv_obj_set_flex_flow(tripList, LV_FLEX_FLOW_COLUMN);

    // Cards: search the bird cards saved on the SD card, by name and/or size + colors.
    lv_obj_t *cardsBar = lv_obj_create(tabBirds);
    lv_obj_set_size(cardsBar, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(cardsBar, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(cardsBar, 0, 0);
    lv_obj_set_style_pad_all(cardsBar, 0, 0);
    lv_obj_clear_flag(cardsBar, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(cardsBar, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(cardsBar, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_column(cardsBar, 6, 0);
    cardsSearch = lv_textarea_create(cardsBar);
    lv_obj_set_flex_grow(cardsSearch, 1);
    lv_textarea_set_one_line(cardsSearch, true);
    lv_textarea_set_max_length(cardsSearch, 40);
    lv_textarea_set_placeholder_text(cardsSearch, LV_SYMBOL_EYE_OPEN "  Search saved cards");
    lv_obj_set_style_text_font(cardsSearch, &lv_font_montserrat_16, 0);
    lv_obj_set_style_bg_color(cardsSearch, kSurface, 0);
    lv_obj_set_style_text_color(cardsSearch, kText, 0);
    lv_obj_set_style_border_color(cardsSearch, kBorder, 0);
    lv_obj_set_style_border_color(cardsSearch, kAccent, LV_STATE_FOCUSED);
    cardsFilterBtn = lv_btn_create(cardsBar);
    lv_obj_set_size(cardsFilterBtn, LV_SIZE_CONTENT, 44);
    lv_obj_set_style_pad_hor(cardsFilterBtn, 10, 0);
    lv_obj_set_style_radius(cardsFilterBtn, 10, 0);
    cardsFilterLabel = makeLabel(cardsFilterBtn, &lv_font_montserrat_16, lv_color_white(), "");
    lv_obj_center(cardsFilterLabel);
    lv_obj_add_event_cb(cardsFilterBtn, [](lv_event_t *) {
        lv_obj_add_flag(cardsKeyboard, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_state(cardsSearch, LV_STATE_FOCUSED);
        lv_obj_clear_flag(cardsFilterLayer, LV_OBJ_FLAG_HIDDEN);
    }, LV_EVENT_CLICKED, nullptr);
    lv_obj_add_event_cb(cardsSearch, [](lv_event_t *e) {
        const lv_event_code_t code = lv_event_get_code(e);
        if (code == LV_EVENT_FOCUSED || code == LV_EVENT_CLICKED) {
            lv_keyboard_set_textarea(cardsKeyboard, cardsSearch);
            lv_obj_clear_flag(cardsKeyboard, LV_OBJ_FLAG_HIDDEN);
        } else if (code == LV_EVENT_VALUE_CHANGED) {
            cardsEditedMs = millis();
        }
    }, LV_EVENT_ALL, nullptr);
    cardsInfo = makeLabel(tabBirds, &lv_font_montserrat_12, kMuted, "");
    lv_label_set_long_mode(cardsInfo, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(cardsInfo, lv_pct(100));
    cardsList = lv_obj_create(tabBirds);
    lv_obj_set_size(cardsList, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(cardsList, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(cardsList, 0, 0);
    lv_obj_set_style_pad_all(cardsList, 0, 0);
    lv_obj_set_style_pad_row(cardsList, 6, 0);
    lv_obj_set_flex_flow(cardsList, LV_FLEX_FLOW_COLUMN);
    // On the top layer, over the bottom of the screen; the list above stays scrollable.
    cardsKeyboard = lv_keyboard_create(lv_layer_top());
    lv_obj_set_size(cardsKeyboard, Config::kScreenWidth, 200);
    lv_obj_align(cardsKeyboard, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_keyboard_set_mode(cardsKeyboard, LV_KEYBOARD_MODE_TEXT_LOWER);
    lv_obj_set_style_text_font(cardsKeyboard, &lv_font_montserrat_16, 0);
    lv_obj_add_flag(cardsKeyboard, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_event_cb(cardsKeyboard, [](lv_event_t *e) {
        const lv_event_code_t code = lv_event_get_code(e);
        if (code == LV_EVENT_READY || code == LV_EVENT_CANCEL) {
            lv_obj_add_flag(cardsKeyboard, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_state(cardsSearch, LV_STATE_FOCUSED);
        }
    }, LV_EVENT_ALL, nullptr);
    buildCardsFilter();
    setBirdsView(kViewHeard);

    cardLayer = makeOverlay();
    lv_obj_set_flex_flow(cardLayer, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_row(cardLayer, 8, 0);
    lv_obj_t *close = makeButton(cardLayer, LV_SYMBOL_LEFT "  Back", kBorder, [](lv_event_t *) {
        lv_obj_add_flag(cardLayer, LV_OBJ_FLAG_HIDDEN);
    });
    lv_obj_set_size(close, 110, 40);
    cardTitle = makeLabel(cardLayer, &lv_font_montserrat_24, kText);
    lv_label_set_long_mode(cardTitle, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(cardTitle, lv_pct(100));
    cardSub = makeLabel(cardLayer, &lv_font_montserrat_16, kMuted);
    cardSeenBtn = lv_btn_create(cardLayer);
    lv_obj_set_size(cardSeenBtn, lv_pct(100), 44);
    lv_obj_set_style_bg_color(cardSeenBtn, kAccent, 0);
    lv_obj_set_style_radius(cardSeenBtn, 10, 0);
    cardSeenLabel = makeLabel(cardSeenBtn, &lv_font_montserrat_16, kBg, LV_SYMBOL_OK "  Seen it - check off here");
    lv_obj_center(cardSeenLabel);
    lv_obj_add_flag(cardSeenBtn, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_event_cb(cardSeenBtn, [](lv_event_t *) {
        setTargetSeen(cardTargetIndex, true);
        updateCardSeenButton();
        lv_label_set_text(cardStatus, "Checked off at this location.");
    }, LV_EVENT_CLICKED, nullptr);
    cardImg = lv_img_create(cardLayer);
    lv_obj_add_flag(cardImg, LV_OBJ_FLAG_HIDDEN);
    cardStatus = makeLabel(cardLayer, &lv_font_montserrat_12, kMuted);
    lv_label_set_long_mode(cardStatus, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(cardStatus, lv_pct(100));
    cardBody = makeLabel(cardLayer, &lv_font_montserrat_16, kText);
    lv_label_set_long_mode(cardBody, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(cardBody, lv_pct(100));
}

void updateCard(uint32_t now) {
    CardResult card;
    if (gLink.takeCard(card)) {
        presentCard(card, gState.sdPresent ? "From the phone - now saved on the display" : "");
        cardRequestedMs = 0;
    } else if (cardRequestedMs && !cardRetried && (int32_t)(now - cardRequestedMs) > 10000) {
        // The phone looks the photo up online when asked, which can be slow -- or a piece of the
        // reply was lost. Ask once more by itself before giving up.
        uint16_t got, expected;
        gLink.cardProgress(got, expected);
        Serial.printf("[card] no complete reply for %s after 10 s (%u of %u chunks) -- asking again\n", cardCommon.c_str(), got, expected);
        cardRetried = true;
        if (gLink.requestCard(cardCommon, cardScientific)) {
            lv_label_set_text(cardStatus, "Still waiting for the phone - asking again...");
            cardRequestedMs = now;
        }
    } else if (cardRequestedMs && cardRetried && (int32_t)(now - cardRequestedMs) > 15000) {
        uint16_t got, expected;
        gLink.cardProgress(got, expected);
        Serial.printf("[card] gave up on %s (%u of %u chunks)\n", cardCommon.c_str(), got, expected);
        gLink.cancelCard();
        lv_label_set_text(cardStatus,
            "No reply from the phone. The app has to be open on the phone to send a card (it can't while the phone is "
            "locked or the app is closed). To have cards with no phone at all, load them onto the display's SD card first: "
            "in the app, Mic Array > Fleet > this display > Load bird cards for this area.");
        cardRequestedMs = 0;
    }
}

// ---- Radar tab ----

int selectedTargetIndex() {
    if (gState.targetCount == 0) return -1;
    for (int i = 0; i < gState.targetCount; i++) {
        if (gState.targets[i].slot == gState.selectedTargetSlot) return i;
    }
    gState.selectedTargetSlot = gState.targets[0].slot;
    return 0;
}

void onTargetBtn(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i < gState.targetCount) gState.selectedTargetSlot = gState.targets[i].slot;
    lv_obj_invalidate(radarView);
}

// Screen angle: degrees clockwise from straight up (= where the scope points).
lv_point_t polar(const lv_point_t &c, float screenDeg, float r) {
    const float a = screenDeg * DEG_TO_RAD;
    return {(lv_coord_t)(c.x + r * sinf(a)), (lv_coord_t)(c.y - r * cosf(a))};
}

void radarDraw(lv_event_t *e) {
    lv_obj_t *obj = lv_event_get_target(e);
    lv_draw_ctx_t *ctx = lv_event_get_draw_ctx(e);
    lv_area_t a;
    lv_obj_get_coords(obj, &a);
    const lv_point_t c = {(lv_coord_t)((a.x1 + a.x2) / 2), (lv_coord_t)((a.y1 + a.y2) / 2)};
    const float R = min(lv_area_get_width(&a), lv_area_get_height(&a)) / 2.0f - 18;

    lv_draw_arc_dsc_t ring;
    lv_draw_arc_dsc_init(&ring);
    ring.color = kBorder;
    ring.width = 2;
    for (float f : {1.0f, 0.66f, 0.33f}) lv_draw_arc(ctx, &ring, &c, (uint16_t)(R * f), 0, 360);

    // Scope line of sight: always straight up.
    lv_draw_line_dsc_t line;
    lv_draw_line_dsc_init(&line);
    line.color = kAccent;
    line.width = 3;
    lv_point_t top = polar(c, 0, R);
    lv_draw_line(ctx, &line, &c, &top);

    const float scope = gState.scopeTrueAzimuthDeg();
    lv_draw_label_dsc_t label;
    lv_draw_label_dsc_init(&label);
    label.font = &lv_font_montserrat_16;
    label.color = kMuted;
    if (!isnan(scope)) {
        // North marker, rotated so the scope stays at the top.
        const lv_point_t n = polar(c, -scope, R + 10);
        lv_area_t la = {(lv_coord_t)(n.x - 8), (lv_coord_t)(n.y - 9), (lv_coord_t)(n.x + 8), (lv_coord_t)(n.y + 9)};
        label.color = kText;
        lv_draw_label(ctx, &label, &la, "N", nullptr);
    }

    const int sel = selectedTargetIndex();
    for (int i = 0; i < gState.targetCount && !isnan(scope); i++) {
        const Target &t = gState.targets[i];
        const float rel = wrap180(t.trueAzimuthDeg - scope);
        const bool selected = i == sel;
        // Uncertainty wedge: +/- sigma around the target bearing.
        if (!isnan(t.sigmaDeg) && t.sigmaDeg > 0) {
            lv_draw_arc_dsc_t wedge;
            lv_draw_arc_dsc_init(&wedge);
            wedge.color = selected ? kWarn : kMuted;
            wedge.opa = selected ? LV_OPA_60 : LV_OPA_30;
            wedge.width = (lv_coord_t)(R * 0.5f);
            const float s = fminf(t.sigmaDeg, 90);
            const int start = (int)roundf(rel - s - 90 + 720) % 360;
            const int end = (int)roundf(rel + s - 90 + 720) % 360;
            lv_draw_arc(ctx, &wedge, &c, (uint16_t)(R * 0.85f), start, end);
        }
        const lv_point_t p = polar(c, rel, R * 0.85f);
        lv_draw_rect_dsc_t dot;
        lv_draw_rect_dsc_init(&dot);
        dot.bg_color = selected ? kWarn : kText;
        dot.radius = LV_RADIUS_CIRCLE;
        const int r = selected ? 9 : 6;
        lv_area_t da = {(lv_coord_t)(p.x - r), (lv_coord_t)(p.y - r), (lv_coord_t)(p.x + r), (lv_coord_t)(p.y + r)};
        lv_draw_rect(ctx, &dot, &da);
    }
}

void updateRadar(uint32_t now) {
    if (now - lastRadarDrawMs < 100) return;
    lastRadarDrawMs = now;
    lv_obj_invalidate(radarView);

    if (gState.targetCount != shownTargetCount) {
        shownTargetCount = gState.targetCount;
        for (int i = 0; i < kMaxTargets; i++) {
            if (i < gState.targetCount) {
                lv_label_set_text(lv_obj_get_child(radarTargetBtns[i], 0), gState.targets[i].name.c_str());
                lv_obj_clear_flag(radarTargetBtns[i], LV_OBJ_FLAG_HIDDEN);
            } else {
                lv_obj_add_flag(radarTargetBtns[i], LV_OBJ_FLAG_HIDDEN);
            }
        }
    }
    for (int i = 0; i < gState.targetCount; i++) {
        lv_obj_set_style_bg_color(radarTargetBtns[i], gState.targets[i].slot == gState.selectedTargetSlot ? kWarn : kBorder, 0);
    }

    // Scope status line.
    String status;
    const float scope = gState.scopeTrueAzimuthDeg();
    if (!gState.compassPresent) {
        status = "No scope compass (BNO055) found.";
    } else if (isnan(scope)) {
        status = "Compass starting...";
    } else {
        status = "Scope " + String((int)roundf(scope)) + " deg";
        if (!isnan(gState.scopeElevationDeg)) status += ", " + String((int)roundf(gState.scopeElevationDeg)) + " deg up";
        status += " | cal " + String(gState.compassCal) + "/3";
        status += gState.lastAlignSeq ? " | aligned" : " | not aligned";
        if (gState.orientationInverted) status += "\nCompass data looks inverted - check mounting.";
        else if (gState.compassCal < 2) status += "\nMove the scope in a slow figure-8 to calibrate.";
    }
    lv_label_set_text(radarStatus, status.c_str());

    const int sel = selectedTargetIndex();
    const bool stale = gState.targetsUpdatedMs == 0 || now - gState.targetsUpdatedMs > 10000;
    if (sel < 0 || stale) {
        lv_label_set_text(radarMessage, gState.appLinked(now, Config::kAppLinkTimeoutMs)
            ? "No targets. Turn on Radar Mode in Bird Sounds on the phone."
            : "Phone not connected.");
        lv_obj_clear_flag(radarMessage, LV_OBJ_FLAG_HIDDEN);
        lv_label_set_text(radarArrow, "");
        lv_label_set_text(radarArrowSub, "");
        return;
    }
    lv_obj_add_flag(radarMessage, LV_OBJ_FLAG_HIDDEN);
    const Target &t = gState.targets[sel];
    if (isnan(scope)) {
        lv_label_set_text(radarArrow, "---");
        lv_label_set_text_fmt(radarArrowSub, "%s at %d deg", t.name.c_str(), (int)roundf(t.trueAzimuthDeg));
        return;
    }
    const float rel = wrap180(t.trueAzimuthDeg - scope);
    const float tolerance = fmaxf(2.0f, isnan(t.sigmaDeg) ? 5.0f : t.sigmaDeg * Config::kOnTargetSigmas);
    String arrow, sub;
    if (fabsf(rel) <= tolerance) {
        arrow = LV_SYMBOL_OK " ON TARGET";
        lv_obj_set_style_text_color(radarArrow, kAccent, 0);
    } else {
        arrow = String(rel < 0 ? LV_SYMBOL_LEFT " " : "") + String((int)roundf(fabsf(rel))) + " deg" + String(rel > 0 ? " " LV_SYMBOL_RIGHT : "");
        lv_obj_set_style_text_color(radarArrow, kWarn, 0);
    }
    if (!isnan(t.elevationDeg) && !isnan(gState.scopeElevationDeg)) {
        const float up = t.elevationDeg - gState.scopeElevationDeg;
        if (fabsf(up) > 2) sub += String(up > 0 ? LV_SYMBOL_UP " up " : LV_SYMBOL_DOWN " down ") + String((int)roundf(fabsf(up))) + " deg  ";
    }
    sub += t.name;
    if (!isnan(t.sigmaDeg)) sub += "  +/-" + String((int)roundf(t.sigmaDeg)) + " deg";
    if (!isnan(t.distanceM)) sub += "  ~" + String((int)roundf(t.distanceM * 3.28084f)) + " ft";
    lv_label_set_text(radarArrow, arrow.c_str());
    lv_label_set_text(radarArrowSub, sub.c_str());
}

void buildRadar() {
    lv_obj_set_flex_flow(tabRadar, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(tabRadar, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_all(tabRadar, 6, 0);
    lv_obj_set_style_pad_row(tabRadar, 4, 0);
    lv_obj_clear_flag(tabRadar, LV_OBJ_FLAG_SCROLLABLE);

    radarView = lv_obj_create(tabRadar);
    lv_obj_set_size(radarView, 250, 250);
    lv_obj_set_style_bg_opa(radarView, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(radarView, 0, 0);
    lv_obj_clear_flag(radarView, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(radarView, radarDraw, LV_EVENT_DRAW_MAIN, nullptr);

    radarMessage = makeLabel(tabRadar, &lv_font_montserrat_16, kMuted);
    lv_label_set_long_mode(radarMessage, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(radarMessage, lv_pct(95));
    lv_obj_set_style_text_align(radarMessage, LV_TEXT_ALIGN_CENTER, 0);

    radarArrow = makeLabel(tabRadar, &lv_font_montserrat_40, kWarn);
    radarArrowSub = makeLabel(tabRadar, &lv_font_montserrat_16, kText);

    radarTargetsRow = lv_obj_create(tabRadar);
    lv_obj_set_size(radarTargetsRow, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(radarTargetsRow, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(radarTargetsRow, 0, 0);
    lv_obj_set_style_pad_all(radarTargetsRow, 0, 0);
    lv_obj_set_flex_flow(radarTargetsRow, LV_FLEX_FLOW_ROW_WRAP);
    lv_obj_set_style_pad_gap(radarTargetsRow, 4, 0);
    for (int i = 0; i < kMaxTargets; i++) {
        radarTargetBtns[i] = makeButton(radarTargetsRow, "", kBorder, onTargetBtn, (void *)(intptr_t)i);
        lv_obj_set_height(radarTargetBtns[i], 34);
        lv_obj_set_style_text_font(lv_obj_get_child(radarTargetBtns[i], 0), &lv_font_montserrat_12, 0);
        lv_obj_add_flag(radarTargetBtns[i], LV_OBJ_FLAG_HIDDEN);
    }

    radarStatus = makeLabel(tabRadar, &lv_font_montserrat_12, kMuted);
    lv_label_set_long_mode(radarStatus, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(radarStatus, lv_pct(100));
}

// ---- Compass tab ----

const char *compassPointName(float deg) {
    static const char *names[] = {"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"};
    return names[(int)floorf(fmodf(deg + 11.25f + 360.0f, 360.0f) / 22.5f) % 16];
}

// Heading-up rose: the scope always points at the top marker and the card turns under it, like a
// real compass. Tick every 10 deg, longer every 30, labels at the cardinals and every 30.
void compassDraw(lv_event_t *e) {
    lv_obj_t *obj = lv_event_get_target(e);
    lv_draw_ctx_t *ctx = lv_event_get_draw_ctx(e);
    lv_area_t a;
    lv_obj_get_coords(obj, &a);
    const lv_point_t c = {(lv_coord_t)((a.x1 + a.x2) / 2), (lv_coord_t)((a.y1 + a.y2) / 2)};
    const float R = min(lv_area_get_width(&a), lv_area_get_height(&a)) / 2.0f - 6;

    lv_draw_arc_dsc_t ring;
    lv_draw_arc_dsc_init(&ring);
    ring.color = kBorder;
    ring.width = 2;
    lv_draw_arc(ctx, &ring, &c, (uint16_t)R, 0, 360);

    const bool haveHeading = !isnan(smoothedHeading);
    const float heading = haveHeading ? smoothedHeading : 0;

    lv_draw_line_dsc_t tick;
    lv_draw_line_dsc_init(&tick);
    lv_draw_label_dsc_t label;
    lv_draw_label_dsc_init(&label);
    for (int deg = 0; deg < 360; deg += 10) {
        const float screen = deg - heading; // where this bearing sits relative to the scope (top)
        const bool major = deg % 30 == 0;
        tick.color = haveHeading ? (deg == 0 ? kDanger : (major ? kText : kMuted)) : kBorder;
        tick.width = major ? 3 : 1;
        lv_point_t p1 = polar(c, screen, R);
        lv_point_t p2 = polar(c, screen, R - (major ? 16 : 8));
        lv_draw_line(ctx, &tick, &p1, &p2);
        if (!major || !haveHeading) continue;
        const char *text;
        char buf[4];
        switch (deg) {
            case 0: text = "N"; break;
            case 90: text = "E"; break;
            case 180: text = "S"; break;
            case 270: text = "W"; break;
            default: snprintf(buf, sizeof(buf), "%d", deg / 10); text = buf; break; // 3 = 30 deg, like a marine card
        }
        const bool cardinal = deg % 90 == 0;
        label.font = cardinal ? &lv_font_montserrat_24 : &lv_font_montserrat_16;
        label.color = deg == 0 ? kDanger : (cardinal ? kText : kMuted);
        const lv_point_t lp = polar(c, screen, R - (cardinal ? 34 : 30));
        const int hw = cardinal ? 12 : 10, hh = cardinal ? 13 : 10;
        lv_area_t la = {(lv_coord_t)(lp.x - hw), (lv_coord_t)(lp.y - hh), (lv_coord_t)(lp.x + hw), (lv_coord_t)(lp.y + hh)};
        label.align = LV_TEXT_ALIGN_CENTER;
        lv_draw_label(ctx, &label, &la, text, nullptr);
    }

    // Lubber line: where the scope points (fixed, top).
    lv_draw_line_dsc_t lubber;
    lv_draw_line_dsc_init(&lubber);
    lubber.color = kAccent;
    lubber.width = 5;
    lubber.round_end = 1;
    lv_point_t t1 = {c.x, (lv_coord_t)(a.y1 + 1)};
    lv_point_t t2 = {c.x, (lv_coord_t)(a.y1 + 24)};
    lv_draw_line(ctx, &lubber, &t1, &t2);
}

void updateCompass(uint32_t now) {
    if (now - lastCompassDrawMs < 100) return;
    lastCompassDrawMs = now;

    // Circular low-pass so the number doesn't flicker; the Radar arrow keeps using the raw value.
    const float raw = gState.scopeTrueAzimuthDeg();
    if (isnan(raw)) {
        smoothedHeading = NAN;
    } else if (isnan(smoothedHeading)) {
        smoothedHeading = raw;
    } else {
        smoothedHeading = fmodf(smoothedHeading + 0.35f * wrap180(raw - smoothedHeading) + 360.0f, 360.0f);
    }
    lv_obj_invalidate(compassRose);

    if (!gState.compassPresent) {
        lv_label_set_text(compassHeading, "--");
        lv_label_set_text(compassPoint, "");
        lv_label_set_text(compassRef, "No compass found");
        lv_label_set_text(compassTilt, "");
        lv_label_set_text(compassStatus, "Connect a BNO055 to the I2C header (SDA 16, SCL 15, 3V3, GND) and restart the display.");
        return;
    }
    if (isnan(smoothedHeading)) {
        lv_label_set_text(compassHeading, "--");
        lv_label_set_text(compassPoint, "");
        lv_label_set_text(compassRef, gState.campMode ? "Paused in Camp mode" : "Starting...");
        return;
    }
    lv_label_set_text_fmt(compassHeading, "%d", (int)roundf(smoothedHeading) % 360);
    lv_label_set_text(compassPoint, compassPointName(smoothedHeading));

    String ref;
    if (gState.declinationKnown) {
        ref = "deg TRUE";
        ref += " (decl " + String(gState.declinationDeg >= 0 ? "+" : "") + String(gState.declinationDeg, 1) + ")";
    } else {
        ref = "deg MAGNETIC - phone not connected";
    }
    lv_label_set_text(compassRef, ref.c_str());

    if (!isnan(gState.scopeElevationDeg)) {
        const int el = (int)roundf(gState.scopeElevationDeg);
        lv_label_set_text_fmt(compassTilt, "%s %d deg %s", el > 0 ? LV_SYMBOL_UP : (el < 0 ? LV_SYMBOL_DOWN : "-"), abs(el), el > 0 ? "up" : (el < 0 ? "down" : "level"));
    }

    String status = "Calibration " + String(gState.compassCal) + "/3";
    status += gState.lastAlignSeq ? "  |  aligned to the scope" : "  |  not aligned (Fleet > this display > Scope alignment in the app)";
    if (gState.orientationInverted) status += "\nCompass data looks inverted - check how the BNO055 is mounted.";
    else if (gState.compassCal < 2) status += "\nMove the scope slowly in a figure-8 to calibrate.";
    lv_label_set_text(compassStatus, status.c_str());
    lv_obj_set_style_text_color(compassStatus, gState.compassCal < 2 || gState.orientationInverted ? kWarn : kMuted, 0);
}

void buildCompass() {
    lv_obj_set_flex_flow(tabCompass, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(tabCompass, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_all(tabCompass, 6, 0);
    lv_obj_set_style_pad_row(tabCompass, 2, 0);
    lv_obj_clear_flag(tabCompass, LV_OBJ_FLAG_SCROLLABLE);

    compassRose = lv_obj_create(tabCompass);
    lv_obj_set_size(compassRose, 264, 264);
    lv_obj_set_style_bg_opa(compassRose, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(compassRose, 0, 0);
    lv_obj_set_style_pad_all(compassRose, 0, 0);
    lv_obj_clear_flag(compassRose, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(compassRose, compassDraw, LV_EVENT_DRAW_MAIN, nullptr);

    // Heading readout sits in the middle of the rose.
    lv_obj_t *center = lv_obj_create(compassRose);
    lv_obj_set_size(center, 150, 96);
    lv_obj_center(center);
    lv_obj_set_style_bg_opa(center, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(center, 0, 0);
    lv_obj_set_style_pad_all(center, 0, 0);
    lv_obj_clear_flag(center, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(center, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(center, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    compassHeading = makeLabel(center, &lv_font_montserrat_48, kText, "--");
    compassPoint = makeLabel(center, &lv_font_montserrat_20, kAccent, "");

    compassRef = makeLabel(tabCompass, &lv_font_montserrat_16, kMuted, "");
    compassTilt = makeLabel(tabCompass, &lv_font_montserrat_20, kText, "");
    compassStatus = makeLabel(tabCompass, &lv_font_montserrat_12, kMuted, "");
    lv_label_set_long_mode(compassStatus, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(compassStatus, lv_pct(100));
    lv_obj_set_style_text_align(compassStatus, LV_TEXT_ALIGN_CENTER, 0);
}

// ---- Fleet tab + setup aid ----

// The setup aid's needle follows the confidence-weighted average direction of the last 2 s of
// readings, and only while they agree -- a node near steady background noise (AC, traffic) reports
// a new direction several times a second, and a needle that jumps to each one is never still.
// Agreement = length of the average unit vector (1 = all the same direction, 0 = all over the place);
// hysteresis between showing and hiding so it doesn't flicker at the edge. Tuned on SecNode 3 by an
// AC vent (2026-10-07): ~80% of the time steady, ~2 deg per update instead of 30-90 deg jumps.
constexpr uint32_t kSteadyWindowMs = 2000;
constexpr float kSteadyMinConfidence = 0.5f;
constexpr float kSteadyShowAgreement = 0.8f, kSteadyHideAgreement = 0.7f;
struct SteadyBearing {
    bool steady = false;
    float az = NAN;      // last steady average (kept, dimmed, while readings disagree)
    float agreement = 0;
    int readings = 0;
} liveSteady;

void updateSteadyBearing() {
    const uint32_t nowMs = millis(); // fresh: samples are stamped as packets arrive, after the loop's `now`
    const LiveHistory &h = gState.liveHistory;
    float sx = 0, sy = 0, w = 0;
    int n = 0;
    for (int k = 0; k < h.count; k++) {
        const LiveHistory::Sample &s = h.recent(k);
        if ((int32_t)(nowMs - s.ms) > (int32_t)kSteadyWindowMs) break;
        if (s.conf < kSteadyMinConfidence) continue;
        const float rad = s.az * DEG_TO_RAD;
        sx += s.conf * cosf(rad);
        sy += s.conf * sinf(rad);
        w += s.conf;
        n++;
    }
    liveSteady.readings = n;
    liveSteady.agreement = (n >= 2 && w > 0) ? sqrtf(sx * sx + sy * sy) / w : 0;
    liveSteady.steady = liveSteady.agreement >= (liveSteady.steady ? kSteadyHideAgreement : kSteadyShowAgreement);
    if (liveSteady.steady) liveSteady.az = atan2f(sy, sx) * RAD_TO_DEG;
}

void liveNeedleDraw(lv_event_t *e) {
    lv_obj_t *obj = lv_event_get_target(e);
    lv_draw_ctx_t *ctx = lv_event_get_draw_ctx(e);
    lv_area_t a;
    lv_obj_get_coords(obj, &a);
    const lv_point_t c = {(lv_coord_t)((a.x1 + a.x2) / 2), (lv_coord_t)(a.y2 - 10)};
    const float R = lv_area_get_width(&a) / 2.0f - 12;
    lv_draw_arc_dsc_t ring;
    lv_draw_arc_dsc_init(&ring);
    ring.color = kBorder;
    ring.width = 3;
    lv_draw_arc(ctx, &ring, &c, (uint16_t)R, 180, 360); // the node's front half
    if (!gState.live.valid || isnan(liveSteady.az)) return;
    lv_draw_line_dsc_t line;
    lv_draw_line_dsc_init(&line);
    line.color = liveSteady.steady ? kAccent : kBorder;
    line.width = liveSteady.steady ? 5 : 3;
    line.round_end = 1;
    const float az = fmaxf(-90, fminf(90, wrap180(liveSteady.az)));
    lv_point_t tip = polar(c, az, R);
    lv_draw_line(ctx, &line, &c, &tip);
}

void openLive(int fleetIdx) {
    if (fleetIdx < 0 || fleetIdx >= gState.fleetCount) return;
    watchedIP = gState.fleet[fleetIdx].ip;
    gState.live = NodeLive();
    gState.liveHistory.clear();
    liveSteady = SteadyBearing();
    lv_label_set_text(liveTitle, gState.fleet[fleetIdx].name.c_str());
    gLink.sendCommand(Protocol::kCmdWatchNode, watchedIP);
    lv_obj_clear_flag(liveLayer, LV_OBJ_FLAG_HIDDEN);
}

void onFleetRow(lv_event_t *e) { openLive((int)(intptr_t)lv_event_get_user_data(e)); }

void rebuildFleet(uint32_t now) {
    lv_obj_clean(fleetList);
    for (int i = 0; i < gState.fleetCount; i++) {
        const FleetNode &n = gState.fleet[i];
        lv_obj_t *row = lv_obj_create(fleetList);
        styleSurface(row);
        lv_obj_set_width(row, lv_pct(100));
        lv_obj_set_height(row, LV_SIZE_CONTENT);
        lv_obj_set_flex_flow(row, LV_FLEX_FLOW_COLUMN);
        lv_obj_set_style_pad_row(row, 2, 0);
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(row, onFleetRow, LV_EVENT_CLICKED, (void *)(intptr_t)i);

        const bool connected = n.flags & Protocol::kFleetConnected;
        bool problem = false;
        String detail;
        if (n.flags & Protocol::kFleetHasGPS) {
            detail += (n.flags & Protocol::kFleetGPSFix) ? "GPS " + String(n.sats) + " sats" : "GPS no fix";
            if (!(n.flags & Protocol::kFleetGPSFix)) problem = true;
        }
        if ((n.flags & Protocol::kFleetHasCompass) && n.compassCal != 0xFF) {
            detail += String(detail.length() ? " | " : "") + "compass " + String(n.compassCal) + "/3";
            if (n.compassCal < 2) problem = true;
        }
        if (n.flags & Protocol::kFleetHasPresence) {
            const bool online = n.flags & Protocol::kFleetPresenceOnline;
            detail += String(detail.length() ? " | " : "") + (n.presenceModel == 2 ? "C4002 " : n.presenceModel == 1 ? "C4001 " : "radar ") + (online ? "ok" : "OFFLINE");
            if (!online) problem = true;
        }
        if (n.nodeType == 1) detail += String(detail.length() ? " | " : "") + ((n.flags & Protocol::kFleetCameraOn) ? "camera on" : "camera off");
        const lv_color_t dot = !connected ? kDanger : problem ? kWarn : kAccent;
        String title = String(LV_SYMBOL_BULLET " ") + n.name;
        lv_obj_t *t = makeLabel(row, &lv_font_montserrat_20, kText, title.c_str());
        lv_obj_set_style_text_color(t, dot, 0);
        String sub = connected ? "Connected" : (n.lastHeardS == 0xFFFF ? String("Not connected") : "Not heard " + ago((uint32_t)n.lastHeardS * 1000));
        sub += "  " + n.ip.toString();
        makeLabel(row, &lv_font_montserrat_12, kMuted, sub.c_str());
        if (detail.length()) makeLabel(row, &lv_font_montserrat_12, kText, detail.c_str());
    }
    if (gState.fleetCount == 0) lv_obj_clear_flag(fleetEmpty, LV_OBJ_FLAG_HIDDEN);
    else lv_obj_add_flag(fleetEmpty, LV_OBJ_FLAG_HIDDEN);
}

void buildFleet() {
    lv_obj_set_flex_flow(tabFleet, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(tabFleet, 8, 0);
    fleetEmpty = makeLabel(tabFleet, &lv_font_montserrat_16, kMuted, "Waiting for the phone's fleet status...");
    lv_label_set_long_mode(fleetEmpty, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(fleetEmpty, lv_pct(100));
    fleetList = lv_obj_create(tabFleet);
    lv_obj_set_size(fleetList, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(fleetList, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(fleetList, 0, 0);
    lv_obj_set_style_pad_all(fleetList, 0, 0);
    lv_obj_set_style_pad_row(fleetList, 6, 0);
    lv_obj_set_flex_flow(fleetList, LV_FLEX_FLOW_COLUMN);

    liveLayer = makeOverlay();
    lv_obj_set_flex_flow(liveLayer, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_row(liveLayer, 8, 0);
    lv_obj_t *back = makeButton(liveLayer, LV_SYMBOL_LEFT "  Back", kBorder, [](lv_event_t *) {
        gLink.sendCommand(Protocol::kCmdUnwatch, watchedIP);
        lv_obj_add_flag(liveLayer, LV_OBJ_FLAG_HIDDEN);
    });
    lv_obj_set_size(back, 110, 40);
    liveTitle = makeLabel(liveLayer, &lv_font_montserrat_24, kText);
    makeLabel(liveLayer, &lv_font_montserrat_12, kMuted, "Setup aid: bearing from this node, averaged over 2 s. Clap on\none side a few times - the needle should swing that way.");
    liveNeedle = lv_obj_create(liveLayer);
    lv_obj_set_size(liveNeedle, 280, 160);
    lv_obj_set_style_bg_opa(liveNeedle, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(liveNeedle, 0, 0);
    lv_obj_add_event_cb(liveNeedle, liveNeedleDraw, LV_EVENT_DRAW_MAIN, nullptr);
    liveText = makeLabel(liveLayer, &lv_font_montserrat_16, kText);
    lv_label_set_long_mode(liveText, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(liveText, lv_pct(100));
}

void updateLive(uint32_t now) {
    if (lv_obj_has_flag(liveLayer, LV_OBJ_FLAG_HIDDEN)) return;
    static uint32_t last = 0;
    if (now - last < 150) return;
    last = now;
    updateSteadyBearing();
    lv_obj_invalidate(liveNeedle);
    const NodeLive &l = gState.live;
    String t;
    if (!l.valid || now - l.updatedMs > 5000) {
        t = "Waiting for live data from the phone...";
    } else {
        if (liveSteady.steady) {
            t = "Bearing: " + String((int)roundf(wrap180(liveSteady.az))) + " deg from the node's front";
            t += "\nSteady: " + String(liveSteady.readings) + " readings agree " + String((int)roundf(liveSteady.agreement * 100)) + "%";
        } else if (liveSteady.readings >= 2) {
            t = "No steady direction - recent readings disagree (" + String((int)roundf(liveSteady.agreement * 100)) + "%)";
        } else {
            t = "No steady direction - waiting for sounds";
        }
        if (!isnan(l.azimuthDeg)) {
            t += "\nLatest " + String((int)roundf(wrap180(l.azimuthDeg))) + " deg, confidence " + String((int)roundf(l.confidence * 100)) +
                 "%, level " + String((int)roundf(l.level));
        }
        if (!isnan(l.headingDeg)) t += "\nCompass " + String((int)roundf(l.headingDeg)) + " deg";
        if (l.compassCal != 0xFF) {
            t += "   cal " + String(l.compassCal) + "/3";
            if (l.compassCal < 3) t += "\nFigure-8 the node slowly until cal reads 3/3.";
        }
        t += "\nGPS " + String(l.gpsFix ? "fix" : "no fix") + ", " + String(l.sats) + " sats";
    }
    lv_label_set_text(liveText, t.c_str());
}

// ---- Camp tab (6.2) ----

void talkTargets(IPAddress *out, int &count, int only) {
    count = 0;
    for (int i = 0; i < gState.fleetCount && count < 8; i++) {
        const FleetNode &n = gState.fleet[i];
        if (!(n.flags & Protocol::kFleetHasSpeaker)) continue;
        if (only >= 0 && !(n.ip == campTileIP[only])) continue;
        out[count++] = n.ip;
    }
}

void onTalk(lv_event_t *e) {
    const lv_event_code_t code = lv_event_get_code(e);
    // -2 = the Camp tab's button (selected tile, or all); -3 = the alert screen's (the alerting node)
    const int only = (int)(intptr_t)lv_event_get_user_data(e);
    if (code == LV_EVENT_PRESSED) {
        IPAddress targets[8];
        int count = 0;
        if (only == -3) {
            if (alertIP != IPAddress(0, 0, 0, 0)) targets[count++] = alertIP;
        } else {
            talkTargets(targets, count, only == -2 ? campSelected : only);
        }
        if (count == 0) return;
        gTalk.startTalk(targets, count);
        gState.talking = true;
        lv_obj_set_style_bg_color(lv_event_get_target(e), kDanger, 0);
    } else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) {
        gTalk.stopTalk();
        gState.talking = false;
        lv_obj_set_style_bg_color(lv_event_get_target(e), kAccent, 0);
    }
}

lv_obj_t *makeTalkButton(lv_obj_t *parent, int only, lv_obj_t **labelOut) {
    lv_obj_t *b = lv_btn_create(parent);
    lv_obj_set_style_bg_color(b, kAccent, 0);
    lv_obj_set_style_radius(b, 14, 0);
    lv_obj_t *l = makeLabel(b, &lv_font_montserrat_20, lv_color_white(), LV_SYMBOL_AUDIO "  Hold to talk");
    lv_obj_center(l);
    lv_obj_add_event_cb(b, onTalk, LV_EVENT_PRESSED, (void *)(intptr_t)only);
    lv_obj_add_event_cb(b, onTalk, LV_EVENT_RELEASED, (void *)(intptr_t)only);
    lv_obj_add_event_cb(b, onTalk, LV_EVENT_PRESS_LOST, (void *)(intptr_t)only);
    if (labelOut) *labelOut = l;
    return b;
}

void sirenAll(uint8_t cmd) {
    for (int i = 0; i < gState.fleetCount; i++) {
        const FleetNode &n = gState.fleet[i];
        if (!(n.flags & Protocol::kFleetHasSpeaker)) continue;
        if (campSelected >= 0 && !(n.ip == campTileIP[campSelected])) continue;
        gLink.sendCommand(cmd, n.ip);
    }
}

void onCampTile(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    campSelected = campSelected == i ? -1 : i;
    for (int t = 0; t < campTileCount; t++) {
        lv_obj_set_style_border_color(campTiles[t], t == campSelected ? kWarn : kBorder, 0);
        lv_obj_set_style_border_width(campTiles[t], t == campSelected ? 3 : 1, 0);
    }
    lv_label_set_text(campTalkLabel, campSelected >= 0
        ? (String(LV_SYMBOL_AUDIO "  Hold to talk: ") + lv_label_get_text(campTileName[campSelected])).c_str()
        : LV_SYMBOL_AUDIO "  Hold to talk to all");
}

void rebuildCamp() {
    IPAddress wanted[kSnapshotSlots];
    int n = 0;
    for (int i = 0; i < gState.fleetCount && n < kSnapshotSlots; i++) {
        if (isSecurityNode(gState.fleet[i]) || gState.fleet[i].nodeType == 1) wanted[n++] = gState.fleet[i].ip;
    }
    bool same = n == campTileCount;
    for (int i = 0; same && i < n; i++) same = wanted[i] == campTileIP[i];
    if (!same) {
        campSelected = -1;
        for (int i = 0; i < kSnapshotSlots; i++) {
            if (i < n) {
                campTileIP[i] = wanted[i];
                const int f = gState.fleetIndex(wanted[i]);
                lv_label_set_text(campTileName[i], f >= 0 ? gState.fleet[f].name.c_str() : wanted[i].toString().c_str());
                lv_img_set_src(campTileImg[i], nullptr);
                lv_obj_clear_flag(campTiles[i], LV_OBJ_FLAG_HIDDEN);
            } else {
                lv_obj_add_flag(campTiles[i], LV_OBJ_FLAG_HIDDEN);
            }
        }
        campTileCount = n;
        gSnapshots.setWanted(wanted, n);
        for (int t = 0; t < kSnapshotSlots; t++) {
            lv_obj_set_style_border_color(campTiles[t], kBorder, 0);
            lv_obj_set_style_border_width(campTiles[t], 1, 0);
        }
        lv_label_set_text(campTalkLabel, LV_SYMBOL_AUDIO "  Hold to talk to all");
    }
    if (n == 0) lv_obj_clear_flag(campEmpty, LV_OBJ_FLAG_HIDDEN);
    else lv_obj_add_flag(campEmpty, LV_OBJ_FLAG_HIDDEN);
}

void updateCampStates(uint32_t now) {
    for (int i = 0; i < campTileCount; i++) {
        const int f = gState.fleetIndex(campTileIP[i]);
        String s = "No presence data";
        lv_color_t color = kMuted;
        if (f >= 0) {
            const FleetNode &n = gState.fleet[f];
            const PresenceInfo &p = n.presence;
            if (!(n.flags & Protocol::kFleetConnected)) { s = "Node offline"; color = kDanger; }
            else if (p.valid && now - p.updatedMs < 15000) {
                s = movementText(p);
                color = p.sensorOffline ? kWarn : (p.targetState == 0 ? kAccent : kDanger);
            } else if (n.flags & Protocol::kFleetHasPresence) { s = "Clear"; color = kAccent; }
            SnapshotSlot *slot = gSnapshots.slotFor(n.ip);
            if (slot && slot->failed && !slot->front.pixels) s += "\n(no snapshot - camera off?)";
        }
        lv_label_set_text(campTileState[i], s.c_str());
        lv_obj_set_style_text_color(campTileState[i], color, 0);
    }
}

void buildCamp() {
    lv_obj_set_flex_flow(tabCamp, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(tabCamp, 6, 0);
    lv_obj_set_style_pad_row(tabCamp, 6, 0);
    campEmpty = makeLabel(tabCamp, &lv_font_montserrat_16, kMuted, "No security or camera nodes in the fleet status yet.");
    lv_label_set_long_mode(campEmpty, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(campEmpty, lv_pct(100));

    campGrid = lv_obj_create(tabCamp);
    lv_obj_set_size(campGrid, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(campGrid, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(campGrid, 0, 0);
    lv_obj_set_style_pad_all(campGrid, 0, 0);
    lv_obj_set_flex_flow(campGrid, LV_FLEX_FLOW_ROW_WRAP);
    lv_obj_set_style_pad_gap(campGrid, 6, 0);
    for (int i = 0; i < kSnapshotSlots; i++) {
        lv_obj_t *tile = lv_obj_create(campGrid);
        styleSurface(tile);
        lv_obj_set_style_pad_all(tile, 4, 0);
        lv_obj_set_size(tile, 148, LV_SIZE_CONTENT);
        lv_obj_set_flex_flow(tile, LV_FLEX_FLOW_COLUMN);
        lv_obj_set_style_pad_row(tile, 2, 0);
        lv_obj_clear_flag(tile, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_flag(tile, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(tile, onCampTile, LV_EVENT_CLICKED, (void *)(intptr_t)i);
        campTileImg[i] = lv_img_create(tile);
        lv_obj_set_size(campTileImg[i], 138, 104);
        lv_img_set_zoom(campTileImg[i], 176); // 200x150 -> ~138x104
        lv_img_set_pivot(campTileImg[i], 0, 0);
        campTileName[i] = makeLabel(tile, &lv_font_montserrat_16, kText);
        campTileState[i] = makeLabel(tile, &lv_font_montserrat_12, kMuted);
        lv_label_set_long_mode(campTileState[i], LV_LABEL_LONG_WRAP);
        lv_obj_set_width(campTileState[i], 138);
        lv_obj_add_flag(tile, LV_OBJ_FLAG_HIDDEN);
        campTiles[i] = tile;
    }

    lv_obj_t *row = lv_obj_create(tabCamp);
    lv_obj_set_size(row, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(row, 0, 0);
    lv_obj_set_style_pad_all(row, 0, 0);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_style_pad_gap(row, 6, 0);
    lv_obj_t *siren = makeButton(row, LV_SYMBOL_BELL " Siren", kDanger, [](lv_event_t *) { sirenAll(Protocol::kCmdSoundAlarm); });
    lv_obj_set_size(siren, 96, 44);
    lv_obj_t *stop = makeButton(row, LV_SYMBOL_STOP " Stop", kBorder, [](lv_event_t *) { sirenAll(Protocol::kCmdStopAlarm); });
    lv_obj_set_size(stop, 90, 44);
    lv_obj_t *snap = makeButton(row, LV_SYMBOL_REFRESH " Snap", kBorder, [](lv_event_t *) { gSnapshots.refreshNow(); });
    lv_obj_set_size(snap, 96, 44);

    campTalkBtn = makeTalkButton(tabCamp, -2, &campTalkLabel);
    lv_label_set_text(campTalkLabel, LV_SYMBOL_AUDIO "  Hold to talk to all");
    lv_obj_set_size(campTalkBtn, lv_pct(100), 64);

    makeLabel(tabCamp, &lv_font_montserrat_12, kMuted, "Tap a tile to talk to / siren just that node.");

    // Presence alert (full screen)
    alertLayer = makeOverlay();
    lv_obj_set_flex_flow(alertLayer, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_row(alertLayer, 8, 0);
    lv_obj_set_style_border_color(alertLayer, kDanger, 0);
    lv_obj_set_style_border_width(alertLayer, 4, 0);
    makeLabel(alertLayer, &lv_font_montserrat_16, kDanger, LV_SYMBOL_WARNING "  PRESENCE DETECTED");
    alertTitle = makeLabel(alertLayer, &lv_font_montserrat_28, kText);
    alertImg = lv_img_create(alertLayer);
    alertText = makeLabel(alertLayer, &lv_font_montserrat_20, kWarn);
    lv_obj_t *talk = makeTalkButton(alertLayer, -3, nullptr);
    lv_obj_set_size(talk, lv_pct(100), 70);
    lv_obj_t *arow = lv_obj_create(alertLayer);
    lv_obj_set_size(arow, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(arow, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(arow, 0, 0);
    lv_obj_set_style_pad_all(arow, 0, 0);
    lv_obj_set_flex_flow(arow, LV_FLEX_FLOW_ROW);
    lv_obj_set_style_pad_gap(arow, 8, 0);
    lv_obj_t *as = makeButton(arow, LV_SYMBOL_BELL " Siren", kDanger, [](lv_event_t *) { gLink.sendCommand(Protocol::kCmdSoundAlarm, alertIP); });
    lv_obj_set_size(as, 140, 50);
    lv_obj_t *ad = makeButton(arow, "Dismiss", kBorder, [](lv_event_t *) { lv_obj_add_flag(alertLayer, LV_OBJ_FLAG_HIDDEN); });
    lv_obj_set_size(ad, 140, 50);
}

void showAlert(int fleetIdx, uint32_t now) {
    const FleetNode &n = gState.fleet[fleetIdx];
    alertIP = n.ip;
    lv_label_set_text(alertTitle, n.name.c_str());
    lv_label_set_text(alertText, movementText(n.presence).c_str());
    SnapshotSlot *slot = gSnapshots.slotFor(n.ip);
    if (slot && slot->front.pixels) {
        lv_img_set_src(alertImg, &slot->front.dsc);
        lv_obj_clear_flag(alertImg, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_add_flag(alertImg, LV_OBJ_FLAG_HIDDEN);
    }
    if (slot) slot->forceNext = true;
    lv_obj_clear_flag(alertLayer, LV_OBJ_FLAG_HIDDEN);
    gTalk.chirp();
    lastAlertShownMs = now;
    gUI.noteTouch(now); // wake the backlight
}

// ---- Session tab ----

void buildSession() {
    lv_obj_set_flex_flow(tabSession, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(tabSession, 10, 0);
    lv_obj_set_style_pad_row(tabSession, 10, 0);
    sessionBig = makeLabel(tabSession, &lv_font_montserrat_48, kText, "--");
    sessionStats = makeLabel(tabSession, &lv_font_montserrat_20, kText, "");
    lv_label_set_long_mode(sessionStats, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(sessionStats, lv_pct(100));
    makeLabel(tabSession, &lv_font_montserrat_16, kMuted, "Recently heard");
    sessionRecent = makeLabel(tabSession, &lv_font_montserrat_20, kText, "");
    sessionStorage = makeLabel(tabSession, &lv_font_montserrat_12, kMuted, "");
    lv_label_set_long_mode(sessionStorage, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(sessionStorage, lv_pct(100));
    sessionMerlin = makeLabel(tabSession, &lv_font_montserrat_12, kMuted, "");
    lv_label_set_long_mode(sessionMerlin, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(sessionMerlin, lv_pct(100));
    lv_label_set_long_mode(sessionRecent, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(sessionRecent, lv_pct(100));

    // §6.5: this display's own mic -- sound detection on/off, mic level, live meter.
    lv_obj_t *mic = lv_obj_create(tabSession);
    styleSurface(mic);
    lv_obj_set_size(mic, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_clear_flag(mic, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(mic, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_row(mic, 8, 0);

    lv_obj_t *head = lv_obj_create(mic);
    lv_obj_set_size(head, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_style_bg_opa(head, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(head, 0, 0);
    lv_obj_set_style_pad_all(head, 0, 0);
    lv_obj_clear_flag(head, LV_OBJ_FLAG_SCROLLABLE);
    makeLabel(head, &lv_font_montserrat_16, kText, "Sound detection");
    lv_obj_t *micSwitch = lv_switch_create(head);
    lv_obj_align(micSwitch, LV_ALIGN_RIGHT_MID, 0, 0);
    if (gState.micStreamEnabled) lv_obj_add_state(micSwitch, LV_STATE_CHECKED);
    lv_obj_add_event_cb(micSwitch, [](lv_event_t *e) {
        gState.micStreamEnabled = lv_obj_has_state(lv_event_get_target(e), LV_STATE_CHECKED);
        saveMicSetting(gState.micStreamEnabled);
        gLink.announce(); // the app adds/drops it as a source from the identity's mic count
    }, LV_EVENT_VALUE_CHANGED, nullptr);
    lv_obj_t *hint = makeLabel(mic, &lv_font_montserrat_12, kMuted,
        "This display's mic as a Sound source in Bird Sounds. Off saves battery - the mic isn't read at all (Hold to talk still works).");
    lv_label_set_long_mode(hint, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(hint, lv_pct(100));

    micGainLabel = makeLabel(mic, &lv_font_montserrat_16, kText, "");
    lv_label_set_text_fmt(micGainLabel, "Mic level: %d dB", gState.micGainDb);
    lv_obj_t *slider = lv_slider_create(mic);
    lv_obj_set_width(slider, lv_pct(92));
    lv_slider_set_range(slider, 0, 7); // 0-42 dB in 6 dB steps
    lv_slider_set_value(slider, gState.micGainDb / 6, LV_ANIM_OFF);
    lv_obj_add_event_cb(slider, [](lv_event_t *e) {
        const int db = lv_slider_get_value(lv_event_get_target(e)) * 6;
        lv_label_set_text_fmt(micGainLabel, "Mic level: %d dB", db);
        if (db == gState.micGainDb) return;
        gState.micGainDb = db;
        gTalk.setMicGainDb(db);
    }, LV_EVENT_VALUE_CHANGED, nullptr);
    lv_obj_add_event_cb(slider, [](lv_event_t *) { saveMicGain(gState.micGainDb); }, LV_EVENT_RELEASED, nullptr);

    micMeter = lv_bar_create(mic);
    lv_obj_set_size(micMeter, lv_pct(100), 14);
    lv_bar_set_range(micMeter, 0, 100);
    lv_obj_set_style_bg_color(micMeter, kBorder, 0);
    lv_obj_set_style_bg_color(micMeter, kAccent, LV_PART_INDICATOR);
    micMeterLabel = makeLabel(mic, &lv_font_montserrat_12, kMuted, "");

    powerBtn = lv_btn_create(tabSession);
    lv_obj_set_size(powerBtn, lv_pct(100), 50);
    lv_obj_set_style_bg_color(powerBtn, kBorder, 0);
    lv_obj_set_style_radius(powerBtn, 12, 0);
    powerLabel = makeLabel(powerBtn, &lv_font_montserrat_16, lv_color_white(), LV_SYMBOL_POWER "  Power off");
    lv_obj_center(powerLabel);
    lv_obj_add_event_cb(powerBtn, [](lv_event_t *) {
        const uint32_t now = millis();
        if (powerArmedMs && now - powerArmedMs < 3000) {
            requestPowerOff();
            return;
        }
        powerArmedMs = now;
        lv_label_set_text(powerLabel, "Tap again to power off");
        lv_obj_set_style_bg_color(powerBtn, kDanger, 0);
    }, LV_EVENT_CLICKED, nullptr);
    makeLabel(tabSession, &lv_font_montserrat_12, kMuted, "Or hold BOOT for 3 s. Press BOOT to turn back on.");

    forgetBtn = lv_btn_create(tabSession);
    lv_obj_set_size(forgetBtn, lv_pct(100), 40);
    lv_obj_set_style_bg_color(forgetBtn, kBorder, 0);
    lv_obj_set_style_radius(forgetBtn, 12, 0);
    forgetLabel = makeLabel(forgetBtn, &lv_font_montserrat_12, lv_color_white(), LV_SYMBOL_BLUETOOTH "  Forget iPhone pairing");
    lv_obj_center(forgetLabel);
    lv_obj_add_event_cb(forgetBtn, [](lv_event_t *) {
        const uint32_t now = millis();
        if (forgetArmedMs && (int32_t)(now - forgetArmedMs) < 3000) {
            forgetArmedMs = 0;
            gBLE.forgetPairing();
            lv_label_set_text(forgetLabel, "Forgotten - also forget PPScope on the iPhone");
            lv_obj_set_style_bg_color(forgetBtn, kBorder, 0);
            return;
        }
        forgetArmedMs = now;
        lv_label_set_text(forgetLabel, "Tap again to forget the iPhone");
        lv_obj_set_style_bg_color(forgetBtn, kDanger, 0);
    }, LV_EVENT_CLICKED, nullptr);
}

void updateMicMeter(uint32_t now) {
    static uint32_t last = 0;
    if (now - last < 100) return;
    last = now;
    const float level = gState.micLevel;
    const int pct = (int)roundf(fminf(1.0f, level) * 100);
    lv_bar_set_value(micMeter, pct, LV_ANIM_OFF);
    // Clipping zone: keep loud sounds below ~90%.
    lv_obj_set_style_bg_color(micMeter, pct >= 90 ? kDanger : (pct >= 60 ? kWarn : kAccent), LV_PART_INDICATOR);
    const char *state = !gState.micStreamEnabled ? "Off - mic not in use"
                      : gState.campMode ? "Paused in Camp mode"
                      : gState.micStreamingNow ? "Streaming to the phone"
                      : "Listening - phone not connected";
    lv_label_set_text(micMeterLabel, state);
}

void updateSession(uint32_t now) {
    static uint32_t last = 0;
    if (now - last < 1000) return;
    last = now;
    if (!gState.sdPresent) {
        lv_label_set_text(sessionStorage, "No SD card - bird cards come from the phone each time.");
    } else {
        String st = "SD card: " + String(gState.cardsStored) + " bird cards saved";
        if (gState.cardsQueued) st += ", " + String(gState.cardsQueued) + " still loading (needs the phone)";
        if (gState.cardsFailed) st += ", " + String(gState.cardsFailed) + " couldn't be loaded";
        st += " - " + String(gState.sdFreeMB) + " MB free";
        lv_label_set_text(sessionStorage, st.c_str());
    }
    {
        static const char *kStates[] = {"waiting for the iPhone", "connecting...", "connected - checking permission",
                                         "receiving", "not allowed - on the iPhone, Settings > Bluetooth > PPScope (i) > turn on Share System Notifications"};
        String m = "Merlin (iPhone notifications): ";
        if (!gState.ancsPaired && gState.ancsState == 0) m += "not paired. On the iPhone: Settings > Bluetooth > tap PPScope, then Allow notifications.";
        else m += kStates[min<int>(gState.ancsState, 4)];
        if (gState.ancsState == 3) {
            m += " - " + String((unsigned long)gState.ancsCount) + " notification" + (gState.ancsCount == 1 ? "" : "s") +
                 ", " + String(gState.merlinCount) + " from Merlin";
            if (gState.ancsLastApp[0]) m += String(". Last from ") + gState.ancsLastApp;
        } else if (gState.merlinCount) {
            m += " - " + String(gState.merlinCount) + " Merlin bird" + (gState.merlinCount == 1 ? "" : "s");
        }
        lv_label_set_text(sessionMerlin, m.c_str());
    }
    const SessionInfo &s = gState.session;
    if (!s.valid || !s.active) {
        lv_label_set_text(sessionBig, "--:--");
        lv_label_set_text(sessionStats, "No listening session. Start Bird Sounds on the phone.");
        lv_label_set_text(sessionRecent, "");
        return;
    }
    const uint32_t elapsed = s.elapsedS + (now - s.updatedMs) / 1000;
    lv_label_set_text_fmt(sessionBig, "%lu:%02lu", (unsigned long)(elapsed / 3600 ? elapsed / 3600 : elapsed / 60),
                          (unsigned long)(elapsed / 3600 ? (elapsed / 60) % 60 : elapsed % 60));
    String stats = String(s.species) + " species this session\n" + String(s.detections10min) + " detections in the last 10 min";
    if (s.newLifeBirds) stats += "\n* " + String(s.newLifeBirds) + " new life bird" + (s.newLifeBirds == 1 ? "" : "s");
    lv_label_set_text(sessionStats, stats.c_str());
    String recent;
    for (int i = 0; i < s.recentCount; i++) recent += (i ? "\n" : "") + s.recent[i];
    lv_label_set_text(sessionRecent, recent.c_str());
}

// ---- Status strip + Camp mode ----

void updateStatus(uint32_t now) {
    static uint32_t last = 0;
    if (now - last < 1000) return;
    last = now;
    if (gState.wifiConnected) {
        lv_label_set_text_fmt(statusWifi, LV_SYMBOL_WIFI " %s", gState.myIP.toString().c_str());
        lv_obj_set_style_text_color(statusWifi, kText, 0);
    } else {
        lv_label_set_text(statusWifi, LV_SYMBOL_WIFI " no Wi-Fi");
        lv_obj_set_style_text_color(statusWifi, kDanger, 0);
    }
    const bool linked = gState.appLinked(now, Config::kAppLinkTimeoutMs);
    lv_label_set_text(statusLink, linked ? "Phone " LV_SYMBOL_OK : "Phone --");
    lv_obj_set_style_text_color(statusLink, linked ? kAccent : kWarn, 0);
    if (gState.batteryPercent < 0) {
        lv_label_set_text(statusBattery, LV_SYMBOL_USB);
    } else {
        const int p = gState.batteryPercent;
        const char *icon = p > 80 ? LV_SYMBOL_BATTERY_FULL : p > 55 ? LV_SYMBOL_BATTERY_3 : p > 30 ? LV_SYMBOL_BATTERY_2 : p > 10 ? LV_SYMBOL_BATTERY_1 : LV_SYMBOL_BATTERY_EMPTY;
        lv_label_set_text_fmt(statusBattery, "%s %d%%", icon, p);
        lv_obj_set_style_text_color(statusBattery, p <= 15 ? kDanger : kText, 0);
    }
    // The iPhone's Bluetooth link (Merlin notifications): blue when notifications are coming in.
    static const char *const kBleText[] = {LV_SYMBOL_BLUETOOTH " --", LV_SYMBOL_BLUETOOTH " ...", LV_SYMBOL_BLUETOOTH " ...",
                                           LV_SYMBOL_BLUETOOTH, LV_SYMBOL_BLUETOOTH " !"};
    const lv_color_t bleColor[] = {kMuted, kWarn, kWarn, lv_color_hex(0x3B8EE0), kDanger};
    const int ble = min<int>(gState.ancsState, 4);
    lv_label_set_text(statusBle, kBleText[ble]);
    lv_obj_set_style_text_color(statusBle, bleColor[ble], 0);
    lv_obj_align_to(statusBle, statusBattery, LV_ALIGN_OUT_LEFT_MID, -10, 0);
}

void setCampMode(bool on) {
    if (on == gState.campMode) return;
    gState.campMode = on;
    gCompass.setPaused(on);
    WiFi.setSleep(!on); // modem power-save adds 100 ms+ latency bursts -- off in Camp mode (§6.2.2)
    gLink.sendCommand(on ? Protocol::kCmdCampModeOn : Protocol::kCmdCampModeOff);
    if (!on) gSnapshots.setWanted(nullptr, 0);
    else { shownCampFleetVersion = 0xFFFFFFFF; }
    Serial.printf("[ui] Camp mode %s\n", on ? "ON" : "off");
}

void onTabChanged(lv_event_t *e) {
    const uint16_t tab = lv_tabview_get_tab_act(tabview);
    setCampMode(tab == campTabIndex);
    if (tab != kTabBirds) lv_obj_add_flag(cardsKeyboard, LV_OBJ_FLAG_HIDDEN);
}

} // namespace

void ScopeUI::showPowerOff() {
    lv_obj_t *o = makeOverlay();
    lv_obj_set_flex_flow(o, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(o, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    makeLabel(o, &lv_font_montserrat_28, kText, LV_SYMBOL_POWER "  Powering off");
    lv_obj_t *l = makeLabel(o, &lv_font_montserrat_16, kMuted, "Press BOOT to turn the display back on.");
    lv_label_set_long_mode(l, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(l, lv_pct(90));
    lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_clear_flag(o, LV_OBJ_FLAG_HIDDEN);
    analogWrite(TFT_BL, Config::kBacklightNormal);
    lv_refr_now(nullptr);
}

void ScopeUI::sleepHardware() {
    analogWrite(TFT_BL, 0);
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, LOW);
    tft.writecommand(0x28); // display off
    tft.writecommand(0x10); // sleep in
    // FT6336: power-mode register 0xA5 = 0x03 (hibernate).
    Wire.beginTransmission(0x38);
    Wire.write(0xA5);
    Wire.write(0x03);
    Wire.endTransmission();
}

void ScopeUI::noteTouch(uint32_t nowMs) {
    lastTouchMs = nowMs;
    gState.lastTouchMs = nowMs;
    if (dimmed) {
        analogWrite(TFT_BL, Config::kBacklightNormal);
        dimmed = false;
    }
}

void ScopeUI::begin() {
    tft.begin();
    tft.setRotation(0);
    tft.fillScreen(TFT_BLACK);
    analogWrite(TFT_BL, Config::kBacklightNormal);

    // Touch controller reset (the I2C bus itself is started in setup()).
    pinMode(Config::kTouchRST, OUTPUT);
    digitalWrite(Config::kTouchRST, LOW);
    delay(10);
    digitalWrite(Config::kTouchRST, HIGH);
    delay(300);

    lv_init();
    const size_t lines = 40;
    buf1 = (lv_color_t *)heap_caps_malloc(Config::kScreenWidth * lines * sizeof(lv_color_t), MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
    buf2 = (lv_color_t *)heap_caps_malloc(Config::kScreenWidth * lines * sizeof(lv_color_t), MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
    lv_disp_draw_buf_init(&drawBuf, buf1, buf2, Config::kScreenWidth * lines);
    static lv_disp_drv_t disp;
    lv_disp_drv_init(&disp);
    disp.hor_res = Config::kScreenWidth;
    disp.ver_res = Config::kScreenHeight;
    disp.flush_cb = flushCb;
    disp.draw_buf = &drawBuf;
    lv_disp_drv_register(&disp);
    static lv_indev_drv_t indev;
    lv_indev_drv_init(&indev);
    indev.type = LV_INDEV_TYPE_POINTER;
    indev.read_cb = touchCb;
    lv_indev_drv_register(&indev);

    lv_obj_t *scr = lv_scr_act();
    lv_obj_set_style_bg_color(scr, kBg, 0);
    lv_obj_set_style_text_color(scr, kText, 0);

    // Status strip
    lv_obj_t *strip = lv_obj_create(scr);
    lv_obj_set_size(strip, Config::kScreenWidth, 28);
    lv_obj_align(strip, LV_ALIGN_TOP_MID, 0, 0);
    lv_obj_set_style_bg_color(strip, kSurface, 0);
    lv_obj_set_style_border_width(strip, 0, 0);
    lv_obj_set_style_radius(strip, 0, 0);
    lv_obj_set_style_pad_hor(strip, 8, 0);
    lv_obj_set_style_pad_ver(strip, 0, 0);
    lv_obj_clear_flag(strip, LV_OBJ_FLAG_SCROLLABLE);
    statusWifi = makeLabel(strip, &lv_font_montserrat_12, kText, LV_SYMBOL_WIFI " ...");
    lv_obj_align(statusWifi, LV_ALIGN_LEFT_MID, 0, 0);
    statusLink = makeLabel(strip, &lv_font_montserrat_12, kWarn, "Phone --");
    lv_obj_align(statusLink, LV_ALIGN_CENTER, 20, 0);
    statusBattery = makeLabel(strip, &lv_font_montserrat_12, kText, "");
    lv_obj_align(statusBattery, LV_ALIGN_RIGHT_MID, 0, 0);
    statusBle = makeLabel(strip, &lv_font_montserrat_12, kMuted, LV_SYMBOL_BLUETOOTH " --");
    lv_obj_align_to(statusBle, statusBattery, LV_ALIGN_OUT_LEFT_MID, -10, 0);

    tabview = lv_tabview_create(scr, LV_DIR_BOTTOM, 56);
    lv_obj_set_size(tabview, Config::kScreenWidth, Config::kScreenHeight - 28);
    lv_obj_align(tabview, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_set_style_bg_color(tabview, kBg, 0);
    lv_obj_t *btns = lv_tabview_get_tab_btns(tabview);
    lv_obj_set_style_bg_color(btns, kSurface, 0);
    lv_obj_set_style_text_font(btns, &lv_font_montserrat_12, 0);
    lv_obj_set_style_text_color(btns, kMuted, 0);
    lv_obj_set_style_text_color(btns, kAccent, LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_border_color(btns, kAccent, LV_PART_ITEMS | LV_STATE_CHECKED);
    tabBirds = lv_tabview_add_tab(tabview, LV_SYMBOL_LIST "\nBirds");
    tabRadar = lv_tabview_add_tab(tabview, LV_SYMBOL_GPS "\nRadar");
    tabCompass = lv_tabview_add_tab(tabview, LV_SYMBOL_UP "\nCompass");
    tabFleet = lv_tabview_add_tab(tabview, LV_SYMBOL_SETTINGS "\nFleet");
    tabCamp = lv_tabview_add_tab(tabview, LV_SYMBOL_HOME "\nCamp");
    tabSession = lv_tabview_add_tab(tabview, LV_SYMBOL_EYE_OPEN "\nSession");
    lv_obj_add_event_cb(tabview, onTabChanged, LV_EVENT_VALUE_CHANGED, nullptr);
    // Swiping between tabs fights the lists' own scrolling -- tabs are tap-only.
    lv_obj_clear_flag(lv_tabview_get_content(tabview), LV_OBJ_FLAG_SCROLLABLE);

    buildBirds();
    buildRadar();
    buildCompass();
    buildFleet();
    buildCamp();
    buildSession();
    buildMapView();
    lastTouchMs = millis();
}

void ScopeUI::update(uint32_t now) {
    {
        const uint32_t t0 = millis();
        lv_timer_handler();
        const uint32_t d = millis() - t0;
        if (d > 500) Serial.printf("[slow] lvgl (drawing / taps) took %lu ms\n", (unsigned long)d);
        if (d > 2000) gStore.logSlow("lvgl", d, mapLayer && !lv_obj_has_flag(mapLayer, LV_OBJ_FLAG_HIDDEN) ? String("map open") : String());
    }
    now = millis(); // taps handled just above stamp times later than the caller's `now`

    if (!dimmed && now - lastTouchMs > Config::kDimAfterMs && !gState.talking) {
        analogWrite(TFT_BL, Config::kBacklightDim);
        dimmed = true;
    }

    updateStatus(now);
    updateHandsFree();
    updateCard(now);

    const uint16_t tab = lv_tabview_get_tab_act(tabview);
    // Two-tap confirms: the tap that arms one runs inside lv_timer_handler() above, AFTER `now` was
    // taken, so `now - armedMs` would wrap to a huge number and disarm it at once -- use millis().
    if (forgetArmedMs && (int32_t)(millis() - forgetArmedMs) >= 3000) {
        forgetArmedMs = 0;
        lv_label_set_text(forgetLabel, LV_SYMBOL_BLUETOOTH "  Forget iPhone pairing");
        lv_obj_set_style_bg_color(forgetBtn, kBorder, 0);
    }
    if (powerArmedMs && (int32_t)(millis() - powerArmedMs) >= 3000) {
        powerArmedMs = 0;
        lv_label_set_text(powerLabel, LV_SYMBOL_POWER "  Power off");
        lv_obj_set_style_bg_color(powerBtn, kBorder, 0);
    }
    if (clearArmedMs && (int32_t)(millis() - clearArmedMs) >= 3000) {
        clearArmedMs = 0;
        lv_label_set_text(birdsClearLabel, LV_SYMBOL_TRASH " Clear");
        lv_obj_set_style_bg_color(birdsClearBtn, kBorder, 0);
    }
    if (newLocArmedMs && (int32_t)(now - newLocArmedMs) >= 3000) {
        newLocArmedMs = 0;
        lv_label_set_text(targetsNewLocLabel, LV_SYMBOL_PLUS "  New location (I've moved)");
        lv_obj_set_style_bg_color(targetsNewLocBtn, kBorder, 0);
    }
    if (gState.outboxPending != shownOutboxPending) {
        shownOutboxPending = gState.outboxPending;
        shownTargetsVersion = 0xFFFFFFFF; // the "waiting for the phone" line
    }
    if (tab == kTabBirds && birdsView == kViewTrip && gState.tripHistoryVersion != shownHistoryVersion) {
        shownHistoryVersion = gState.tripHistoryVersion;
        rebuildTrip();
    }
    if (tab == kTabBirds && birdsView == kViewTargets && gState.tripTargetsVersion != shownTargetsVersion) {
        shownTargetsVersion = gState.tripTargetsVersion;
        if (!newLocArmedMs) lv_label_set_text(targetsNewLocLabel, LV_SYMBOL_PLUS "  New location (I've moved)");
        rebuildTargets();
    } else if (birdsView != kViewTargets && gState.tripTargetsVersion != shownTargetsVersion) {
        // Keep the segment's "Targets 3/40" count current while the Heard list is showing.
        shownTargetsVersion = gState.tripTargetsVersion;
        const TripTargetList &list = gState.tripTargets;
        if (list.valid && list.total) lv_label_set_text_fmt(birdsTargetsBtnLabel, "Targets %u/%u", list.seen, list.total);
        else lv_label_set_text(birdsTargetsBtnLabel, "Targets");
    }
    if (tab == kTabBirds && birdsView == kViewCards &&
        (gStore.indexVersion() != shownIndexVersion || (cardsEditedMs && (int32_t)(millis() - cardsEditedMs) >= 250))) {
        shownIndexVersion = gStore.indexVersion();
        cardsEditedMs = 0;
        rebuildCards();
    }
    if (!lv_obj_has_flag(cardLayer, LV_OBJ_FLAG_HIDDEN)) updateCardSeenButton();
    if (tab == kTabBirds && birdsView == kViewHeard && (gState.detectionsVersion != shownDetectionsVersion || now - lastBirdsRefreshMs > 30000)) {
        shownDetectionsVersion = gState.detectionsVersion;
        lastBirdsRefreshMs = now;
        rebuildBirds(now);
    }
    if (tab == kTabRadar) updateRadar(now);
    if (tab == kTabCompass) updateCompass(now);
    if (tab == kTabFleet && gState.fleetVersion != shownFleetVersion) {
        shownFleetVersion = gState.fleetVersion;
        rebuildFleet(now);
    }
    updateLive(now);
    updateMapView(now);
    if (tab == campTabIndex) {
        if (gState.fleetVersion != shownCampFleetVersion) {
            shownCampFleetVersion = gState.fleetVersion;
            rebuildCamp();
        }
        static uint32_t lastCampState = 0;
        if (gState.presenceVersion != shownPresenceVersion || now - lastCampState > 2000) {
            shownPresenceVersion = gState.presenceVersion;
            lastCampState = now;
            updateCampStates(now);
        }
    }
    if (tab == kTabSession) {
        updateSession(now);
        updateMicMeter(now);
    }

    // New snapshot frames -> their tiles (and the alert screen if it's showing that node).
    while (SnapshotSlot *slot = gSnapshots.takeReady()) {
        for (int i = 0; i < campTileCount; i++) {
            if (campTileIP[i] == slot->ip) lv_img_set_src(campTileImg[i], &slot->front.dsc);
        }
        if (!lv_obj_has_flag(alertLayer, LV_OBJ_FLAG_HIDDEN) && alertIP == slot->ip) {
            lv_img_set_src(alertImg, &slot->front.dsc);
            lv_obj_clear_flag(alertImg, LV_OBJ_FLAG_HIDDEN);
        }
    }

    // Presence alerts can arrive on any tab.
    for (int i = 0; i < gState.fleetCount; i++) {
        const PresenceInfo &p = gState.fleet[i].presence;
        if (p.lastAlertMs && p.lastAlertMs > lastAlertShownMs) {
            showAlert(i, now);
            break;
        }
    }
}
