// TalkAudio.h -- hold-to-talk from the display's mic to security nodes' speakers, and alert chirps on
// the display's own speaker (SCOPE_DISPLAY_PLAN.md §6.2.1).
//
// Route: display -> node DIRECTLY. A security node plays kPlaybackAudioFrame from any sender with
// no session, so the phone keeps its stream and there's no extra hop. Same wire format as the app's
// push-to-talk: AudioFrameHeader + mono int16 @ 44.1 kHz, 441 samples (10 ms) per packet.
//
// Runs in its own task on core 0 (LVGL + Wi-Fi housekeeping stay on core 1's loop) with its own UDP
// socket, so a busy UI frame never delays a talk packet.
#pragma once

#include <Arduino.h>
#include <IPAddress.h>

class TalkAudio {
public:
    // Starts I2S + the ES8311 codec (I2C already running). False if the codec didn't answer.
    bool begin();

    // Talk to these nodes while held. Up to 8 targets ("Talk to all").
    void startTalk(const IPAddress *targets, int count);
    void stopTalk();
    bool isTalking() const { return talking_; }

    // Short two-tone alert on the display's own speaker (muted while talking).
    void chirp();

    bool ready() const { return ready_; }

    // Mic gain (ES8311 PGA), 0-42 dB in 6 dB steps; applied immediately. Call from the main loop --
    // it uses the I2C bus the touch controller shares.
    void setMicGainDb(int db);

    // Power-off: amplifier off and the ES8311 powered down. Set gState.poweringOff first so the
    // talk task has stopped touching I2S.
    void shutdown();

private:
    static void taskEntry(void *self);
    void taskLoop();

    volatile bool talking_ = false;
    volatile bool chirpRequested_ = false;
    bool ready_ = false;
    IPAddress targets_[8];
    volatile int targetCount_ = 0;
};

extern TalkAudio gTalk;
