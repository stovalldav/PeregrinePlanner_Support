// ScopeStorage.h -- the display's microSD card (optional): bird-card cache, the "load cards for this
// area" download queue, and copies of the trip target list / trip history so they survive a reboot
// with the phone out of reach. Plus a plain-text log of every check made on the display.
//
// SD_MMC 4-bit on Freenove's FNK0104S pins (CLK 38, CMD 40, D0 39, D1 41, D2 48, D3 47 -- from
// Freenove's own Sketch_06.1_SDMMC_Test for the 4.0" board). No card = everything still works; cards
// just come from the phone each time and nothing is kept across a reboot.
//
// Layout:  /cards/<key>.card    one bird card = the app's card payload as received
//                               (textLen u32, jpegLen u32, text, jpeg)
//          /cards/queue.tsv     cards still to download: "common<TAB>scientific" per line
//          /cards/index.tsv     the real names behind each file: "file<TAB>common<TAB>scientific<TAB>derived
//                               <TAB>sizeLo<TAB>sizeHi<TAB>colors<TAB>rulesVersion" (size in tenths of an
//                               inch, colors a bitmask -- both read from the card's own text; empty or an
//                               older rules version = read again at boot);
//                               appended on every save (a later line wins), rewritten compact at boot
//          /state/targets.tsv   last target list      /state/history.tsv   last trip history
//          /log/checks.tsv      unixTime, action, bird, location -- one line per check / new location
//          /maps/<stopId>-<m|s>-<stamp>/   one version of a stop's standard / satellite map: its
//                               tiles <level>-<col>-<row>.t (the app's payload as received, header +
//                               JPEG, ScopeProtocol.h kScopeMapData), `got` (saved tiles' indexes) and
//                               `done` once every tile is in
//          /state/plans.bin     last trip plans (trips + stops), so maps work without the phone
#pragma once

#include <Arduino.h>
#include <FS.h>
#include "ScopeLink.h"
#include "ScopeProtocol.h"

class ScopeStorage {
public:
    // Mounts the card if one is in. Call after Serial, before the UI needs cards.
    void begin();
    // Runs the card download queue (one card at a time, only while the phone is linked and no card
    // you tapped is loading). Call every loop().
    void poll(uint32_t nowMs);

    bool present() const { return mounted_; }

    // Bird cards
    bool hasCard(const String &common);
    // Loads a stored card; `out.jpeg` points into this class's own buffer until the next load.
    // Tries the common name, then the scientific name (Sound ID and eBird sometimes name a species
    // differently -- a card saved under one is still found by the other).
    bool loadCard(const String &common, const String &scientific, CardResult &out);
    void saveCard(const String &common, const uint8_t *payload, size_t len, const String &scientific = String());
    // Adds a species to the download queue unless it's already stored or queued.
    void enqueueCard(const String &common, const String &scientific);

    // What the Cards filter matches on, read from the card's "Size:" and "Field marks:" lines.
    struct CardAttrs {
        uint16_t sizeLo, sizeHi; // tenths of an inch; 0 = the card gives no size
        uint16_t colors;         // bit per color (colorName()) on the bird's body, not its accents
        bool known;              // read from the card yet
    };
    // Size classes for the filter (0 = any). A bird matches every class its size range touches.
    static constexpr int kSizeClassCount = 6;
    static const char *sizeClassName(int sizeClass);
    static constexpr int kColorCount = 13;
    static const char *colorName(int bit);

    // Saved-card index, for the Birds tab's Cards view. Sorted by common name.
    struct IndexEntry {
        char file[61];       // keyFor() without "/cards/" and ".card"
        char common[49];
        char scientific[49];
        bool derived;        // name rebuilt from the file name (cards saved before the index existed)
        bool onCard;         // loadIndex() only: the card file was found
        CardAttrs attrs;
    };
    int cardCount() const { return indexCount_; }
    const IndexEntry &cardAt(int i) const { return index_[i]; }
    // Bumped whenever the index changes.
    uint32_t indexVersion() const { return indexVersion_; }
    // Up to `max` matches for `query` (any part of the common or scientific name; case, spaces and
    // punctuation ignored -- "bcch" won't match, "capped chick" will), alphabetical, narrowed to
    // `sizeClass` (0 = any) and to birds showing every color in `colorMask`. Returns how many
    // matched in total, which can be more than `max`.
    int searchCards(const String &query, int sizeClass, uint16_t colorMask, int *out, int max) const;
    // A card's real name, seen somewhere else (a detection, a target, the card list): fixes an entry
    // whose name was only rebuilt from its file name.
    void noteName(const String &common, const String &scientific);

    // Stop map tiles. A tile you look at comes from the SD card; without a card, from the last one
    // the phone sent. `jpeg` points into this class's buffer until the next loadTile().
    struct MapView {
        const uint8_t *jpeg = nullptr;
        size_t jpegLen = 0;
        uint32_t stamp = 0;
        double north = 0, south = 0, west = 0, east = 0; // the whole map's bounds
        uint8_t level = 0, col = 0, row = 0;
    };
    static bool parseMap(const uint8_t *payload, size_t len, MapView &out);
    bool loadTile(const char *stopId, uint8_t style, uint32_t stamp, uint8_t level, uint8_t col, uint8_t row, MapView &out);
    // Queues every stop map tile from the trip plans that isn't on the card (or is out of date).
    void enqueueMissingMaps();
    // Map tiles on the card / wanted, across the trip plans -- and one stop's % (-1 = unknown).
    void mapProgress(int &stored, int &total) const;
    int stopMapPercent(const char *stopId);

    // Persisted copies (no-ops without a card)
    void savePlans();
    void loadPlans();
    void saveTargetList();
    void loadTargetList();
    void saveHistory();
    void loadHistory();
    void logEvent(const char *action, const String &bird);
    // A step that held the main loop for seconds -> /log/slow.txt, printed at the next boot, so a
    // freeze can be diagnosed after the fact without the USB cable in (a 76 s one, 2026-10-08).
    void logSlow(const char *step, uint32_t ms, const String &detail = String());
    void printSlowLog();

private:
    static String keyFor(const String &common);
    static String aliasFor(const String &scientific);
    void saveQueue();
    void refreshStats();
    // Index
    void loadIndex();
    void writeIndex();
    void appendIndex(const IndexEntry &e);
    int findIndex(const char *file) const;
    // `attrs` null = keep the entry's current ones.
    void upsertIndex(const String &file, const String &common, const String &scientific, bool derived, bool persist,
                     const CardAttrs *attrs = nullptr);
    static void printEntry(File &f, const IndexEntry &e);
    static String fileKey(const String &common); // keyFor() without the folder / extension
    static constexpr int kMaxIndex = 2000;
    IndexEntry *index_ = nullptr; // PSRAM
    int indexCount_ = 0;
    uint32_t indexVersion_ = 0;

    bool mounted_ = false;
    uint8_t *loadBuffer_ = nullptr; // PSRAM, for loadCard()

    // Download queue (also on the card as /cards/queue.tsv)
    // Fixed-size so the whole queue lives in PSRAM (Strings would put every name in internal RAM).
    struct QueueItem { char common[49]; char scientific[49]; uint8_t tries; };
    static constexpr int kMaxQueue = 600;
    QueueItem *queue_ = nullptr; // PSRAM array of kMaxQueue
    int queueCount_ = 0;
    bool fetching_ = false;
    String fetchingCommon_;
    uint32_t fetchStartMs_ = 0;
    uint32_t lastStatsMs_ = 0;
    int savedSinceQueueWrite_ = 0;

    // Stop maps
    static String mapFolder(const char *stopId, uint8_t style, uint32_t stamp);
    static String tilePath(const char *stopId, uint8_t style, uint32_t stamp, uint8_t level, uint8_t col, uint8_t row);
    typedef bool TileBits[Protocol::kMapTilesPerStyle]; // by tile index (see tileIndex)
    void readGot(const String &folder, TileBits &got, int &count);
    bool setQueued(const char *stopId, uint8_t style, uint8_t minLevel, uint8_t maxLevel) const;
    bool scanNextMapSet();
    void scanMapSet(const PlanEntry &e, uint8_t style, uint8_t minLevel, uint8_t maxLevel);
    bool scanning_ = false;
    int scanEntry_ = 0;
    uint8_t scanStyle_ = 0;
    uint8_t scanPhase_ = 0; // 0 = overview levels of every map, 1 = the closest two
    // Download progress of each map in the trip plans (tiles on the card, of kMapTilesPerStyle).
    struct MapSetProgress {
        char id[41] = {0};
        uint8_t style = 0;
        uint32_t stamp = 0;
        int have = 0;
        bool scannedAll = false; // its closest levels are queued too (or were all there)
    };
    static constexpr int kMaxMapSets = 64;
    MapSetProgress *sets_ = nullptr; // PSRAM, kMaxMapSets
    int setCount_ = 0;
    MapSetProgress *setProgress(const char *stopId, uint8_t style);
    TileBits *tileBits_ = nullptr; // PSRAM, scanMapSet's scratch

    void markDoneIfComplete(const char *stopId, uint8_t style, uint32_t stamp);
    void pollMaps(uint32_t nowMs);
    struct MapQueueItem { char id[41]; uint8_t style, level, col, row, tries; uint32_t stamp; };
    static constexpr int kMaxMapQueue = 8000; // 682 tiles a stop (341 per style)
    MapQueueItem *mapQueue_ = nullptr; // PSRAM
    int mapQueueCount_ = 0;
    bool mapFetching_ = false;
    uint32_t mapFetchStartMs_ = 0;
    uint8_t *mapBuffer_ = nullptr; // PSRAM, for loadMap()
    char lastMapId_[41] = {0};     // what mapBuffer_ holds when there's no SD card
    uint8_t lastMapStyle_ = 0, lastMapLevel_ = 0, lastMapCol_ = 0, lastMapRow_ = 0;
    bool lastMapValid_ = false;
};

extern ScopeStorage gStore;
