// ScopeStorage.h -- the display's microSD card (optional): bird-card cache, the "load cards for this
// area" download queue, and copies of the trip target list / trip history so they survive a reboot
// with the phone out of reach. Plus a plain-text log of every check made on the display.
//
// SD_MMC 4-bit on Freenove's FNK0104S pins (CLK 38, CMD 40, D0 39, D1 41, D2 48, D3 47 -- from
// Freenove's own Sketch_06.1_SDMMC_Test for the 4.0" board). No card = everything still works; cards
// just come from the phone each time and nothing is kept across a reboot.
//
// Layout:  /cards/<key>.card    one bird card = the app's card payload as received
//                               (textLen u32, jpegLen u32, text, jpeg)
//          /cards/queue.tsv     cards still to download: "common<TAB>scientific" per line
//          /cards/index.tsv     the real names behind each file: "file<TAB>common<TAB>scientific<TAB>derived";
//                               appended on every save (a later line wins), rewritten compact at boot
//          /state/targets.tsv   last target list      /state/history.tsv   last trip history
//          /log/checks.tsv      unixTime, action, bird, location -- one line per check / new location
#pragma once

#include <Arduino.h>
#include "ScopeLink.h"

class ScopeStorage {
public:
    // Mounts the card if one is in. Call after Serial, before the UI needs cards.
    void begin();
    // Runs the card download queue (one card at a time, only while the phone is linked and no card
    // you tapped is loading). Call every loop().
    void poll(uint32_t nowMs);

    bool present() const { return mounted_; }

    // Bird cards
    bool hasCard(const String &common);
    // Loads a stored card; `out.jpeg` points into this class's own buffer until the next load.
    // Tries the common name, then the scientific name (Sound ID and eBird sometimes name a species
    // differently -- a card saved under one is still found by the other).
    bool loadCard(const String &common, const String &scientific, CardResult &out);
    void saveCard(const String &common, const uint8_t *payload, size_t len, const String &scientific = String());
    // Adds a species to the download queue unless it's already stored or queued.
    void enqueueCard(const String &common, const String &scientific);

    // Saved-card index, for the Birds tab's Cards view. Sorted by common name.
    struct IndexEntry {
        char file[61];       // keyFor() without "/cards/" and ".card"
        char common[49];
        char scientific[49];
        bool derived;        // name rebuilt from the file name (cards saved before the index existed)
        bool onCard;         // loadIndex() only: the card file was found
    };
    int cardCount() const { return indexCount_; }
    const IndexEntry &cardAt(int i) const { return index_[i]; }
    // Bumped whenever the index changes.
    uint32_t indexVersion() const { return indexVersion_; }
    // Up to `max` matches for `query` (any part of the common or scientific name; case, spaces and
    // punctuation ignored -- "bcch" won't match, "capped chick" will), alphabetical. Returns how many
    // matched in total, which can be more than `max`.
    int searchCards(const String &query, int *out, int max) const;
    // A card's real name, seen somewhere else (a detection, a target, the card list): fixes an entry
    // whose name was only rebuilt from its file name.
    void noteName(const String &common, const String &scientific);

    // Persisted copies (no-ops without a card)
    void saveTargetList();
    void loadTargetList();
    void saveHistory();
    void loadHistory();
    void logEvent(const char *action, const String &bird);

private:
    static String keyFor(const String &common);
    static String aliasFor(const String &scientific);
    void saveQueue();
    void refreshStats();
    // Index
    void loadIndex();
    void writeIndex();
    void appendIndex(const IndexEntry &e);
    int findIndex(const char *file) const;
    void upsertIndex(const String &file, const String &common, const String &scientific, bool derived, bool persist);
    static String fileKey(const String &common); // keyFor() without the folder / extension
    static constexpr int kMaxIndex = 2000;
    IndexEntry *index_ = nullptr; // PSRAM
    int indexCount_ = 0;
    uint32_t indexVersion_ = 0;

    bool mounted_ = false;
    uint8_t *loadBuffer_ = nullptr; // PSRAM, for loadCard()

    // Download queue (also on the card as /cards/queue.tsv)
    // Fixed-size so the whole queue lives in PSRAM (Strings would put every name in internal RAM).
    struct QueueItem { char common[49]; char scientific[49]; uint8_t tries; };
    static constexpr int kMaxQueue = 600;
    QueueItem *queue_ = nullptr; // PSRAM array of kMaxQueue
    int queueCount_ = 0;
    bool fetching_ = false;
    String fetchingCommon_;
    uint32_t fetchStartMs_ = 0;
    uint32_t lastStatsMs_ = 0;
    int savedSinceQueueWrite_ = 0;
};

extern ScopeStorage gStore;
