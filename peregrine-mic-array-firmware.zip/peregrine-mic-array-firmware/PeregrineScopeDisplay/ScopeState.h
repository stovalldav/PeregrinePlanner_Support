// ScopeState.h -- everything the display knows, filled in by ScopeLink (from the app), ScopeCompass,
// the snapshot task and the battery reader, and read by ScopeUI. Owned by the main loop: only the
// snapshot task writes from another core, and it only touches `SnapshotSlot`s through their own
// `ready` flag (see SnapshotFetcher.h).
#pragma once

#include <Arduino.h>
#include <IPAddress.h>
#include <cmath>

constexpr int kMaxDetections = 40;
constexpr int kMaxTargets = 4;
constexpr int kMaxFleetNodes = 12;
constexpr int kMaxRecent = 6;
constexpr int kMaxTripTargets = 120; // the app sends at most this many (unseen first)
constexpr int kMaxHistoryEntries = 200; // trip history: locations + the birds seen at each

struct Detection {
    String common;
    String scientific;
    String nodeName;
    uint8_t confidencePct = 0;
    float trueBearingDeg = NAN;
    bool newLifeBird = false;
    uint32_t receivedMs = 0;
    uint16_t hits = 1; // repeated detections of the same species bump this instead of a new row
    uint8_t source = 0; // 0 = Peregrine (our app's Sound ID), 1 = Merlin (iPhone notification)
};

struct Target {
    uint8_t slot = 0;
    String name;
    float trueAzimuthDeg = NAN;
    float elevationDeg = NAN;
    float sigmaDeg = NAN;
    float distanceM = NAN;
};

struct PresenceInfo {
    bool valid = false;
    float distanceCm = 0;
    uint16_t speedCmPerSec = 0xFFFF;
    uint8_t movement = 0;
    uint8_t targetState = 0;
    uint8_t nodeMode = 0;
    bool sensorOffline = false;
    uint32_t updatedMs = 0;
    uint32_t lastAlertMs = 0;
};

struct FleetNode {
    IPAddress ip;
    String name;
    uint8_t nodeType = 0;
    uint8_t flags = 0;
    uint8_t sats = 0;
    uint8_t compassCal = 0xFF;
    uint16_t lastHeardS = 0;
    uint8_t presenceModel = 0;
    // Relayed presence for this node (kept across fleet-status refreshes, matched by IP).
    PresenceInfo presence;
};

struct NodeLive {
    IPAddress ip;
    bool valid = false;
    float azimuthDeg = NAN;
    float confidence = 0;
    float level = 0;
    float headingDeg = NAN;
    uint8_t compassCal = 0xFF;
    uint8_t gpsFix = 0;
    uint8_t sats = 0;
    uint32_t updatedMs = 0;
};

struct SessionInfo {
    bool valid = false;
    bool active = false;
    uint32_t elapsedS = 0;
    uint16_t species = 0;
    uint16_t detections10min = 0;
    uint16_t newLifeBirds = 0;
    String recent[kMaxRecent];
    int recentCount = 0;
    uint32_t updatedMs = 0;
};

// The trip's target birds (kScopeTargetList).
struct TripTarget {
    String name;
    uint8_t flags = 0; // Protocol::kTripTargetSeen / kTripTargetHere
};

struct TripTargetList {
    bool valid = false; // a complete list has arrived
    String tripName;
    String stopName;
    uint16_t total = 0;
    uint16_t seen = 0;
    TripTarget items[kMaxTripTargets];
    int count = 0;
};

// What you've seen at each location on the trip (kScopeTripHistory), newest location first.
struct HistoryEntry {
    uint8_t kind = 0;  // 0 = location, 1 = bird seen there
    uint8_t flags = 0; // location: bit0 you're here; bird: bit0 heard, bit1 seen
    String name;
};

struct TripHistory {
    bool valid = false;
    HistoryEntry items[kMaxHistoryEntries];
    int count = 0;
};

struct ScopeState {
    // Link
    bool wifiConnected = false;
    String ssid;
    IPAddress myIP;
    uint32_t lastAppPacketMs = 0;
    // Signed: a packet stamped after the caller read `now` (it arrived during this loop pass) is
    // "0 ms ago", not ~49 days -- that wrap made the link flap LOST/LINKED many times a second.
    bool appLinked(uint32_t now, uint32_t timeoutMs) const { return lastAppPacketMs && (int32_t)(now - lastAppPacketMs) < (int32_t)timeoutMs; }

    // Battery
    float batteryVolts = 0;
    int batteryPercent = -1; // -1 = no battery / unknown

    // Function 1
    Detection detections[kMaxDetections];
    int detectionCount = 0;
    uint32_t detectionsVersion = 0; // bumped on every change so the UI rebuilds only when needed

    // Function 2
    float declinationDeg = 0;
    bool declinationKnown = false; // the app has sent one (kScopeTargets header)
    Target targets[kMaxTargets];
    int targetCount = 0;
    uint32_t targetsUpdatedMs = 0;
    uint16_t lastAlignSeq = 0;
    int selectedTargetSlot = -1;

    // Scope compass (ScopeCompass)
    bool compassPresent = false;
    float scopeMagAzimuthDeg = NAN; // magnetic, of the scope's line of sight
    float scopeElevationDeg = NAN;
    uint8_t compassCal = 0; // magnetometer 0-3
    bool orientationInverted = false;
    float alignmentOffsetDeg = 0; // NVS; true = magnetic + declination + offset

    float scopeTrueAzimuthDeg() const {
        if (std::isnan(scopeMagAzimuthDeg)) return NAN;
        return fmodf(scopeMagAzimuthDeg + declinationDeg + alignmentOffsetDeg + 720.0f, 360.0f);
    }

    // Fleet (6.1)
    FleetNode fleet[kMaxFleetNodes];
    int fleetCount = 0;
    uint32_t fleetVersion = 0;
    uint32_t presenceVersion = 0;
    int fleetIndex(const IPAddress &ip) const {
        for (int i = 0; i < fleetCount; i++) if (fleet[i].ip == ip) return i;
        return -1;
    }

    // 6.3 / 6.4
    NodeLive live;
    SessionInfo session;

    // Trip target list
    TripTargetList tripTargets;
    uint32_t tripTargetsVersion = 0;
    TripHistory tripHistory;
    uint32_t tripHistoryVersion = 0;

    // Phone clock (from kScopeTripHistory) -- the display has no RTC. 0 = not known yet.
    uint32_t phoneUnix = 0;
    uint32_t phoneUnixAtMs = 0;
    uint32_t unixNow() const { return phoneUnix ? phoneUnix + (millis() - phoneUnixAtMs) / 1000 : 0; }

    // SD card + bird-card cache (ScopeStorage)
    bool sdPresent = false;
    uint16_t cardsStored = 0;
    uint16_t cardsQueued = 0;
    uint16_t cardsFailed = 0; // gave up after 3 tries, since the last card list
    uint32_t sdFreeMB = 0;
    // Checks / new locations waiting for the phone (ScopeLink outbox)
    int outboxPending = 0;

    // iPhone notifications (ScopeBLE): 0 waiting for the iPhone, 1 connecting, 2 secured,
    // 3 receiving, 4 not allowed / no notification service
    volatile uint8_t ancsState = 0;
    volatile bool ancsPaired = false;
    volatile uint32_t ancsCount = 0; // notifications seen (any app)
    uint32_t merlinCount = 0;
    char ancsLastApp[64] = {0}; // app id of the most recent notification (main loop only)

    // Modes
    bool campMode = false;
    bool talking = false;
    volatile bool poweringOff = false; // set just before deep sleep -- the talk task stops using I2S
    bool micStreamEnabled = true; // NVS "scope"/"mic" -- see Config::kMicStreamDefault
    bool micStreamingNow = false; // actually sending right now (enabled + phone linked + not paused)
    int micGainDb = 18;           // ES8311 mic PGA, 0-42 in 6 dB steps (NVS scope/gain)
    volatile uint32_t micFramesSent = 0, micShortReads = 0; // [link-stat] diagnostics, reset every 10 s
    volatile float micPeak10s = 0;
    volatile float micLevel = 0;  // recent peak, 0-1, for the Session tab's meter

    // Link diagnostics ([link-stat] every 10 s)
    uint32_t loopMaxMs = 0; // slowest loop() pass since the last report
};

extern ScopeState gState;
