#include "JpegImage.h"
#include <TJpg_Decoder.h>
#include <freertos/semphr.h>

namespace {

SemaphoreHandle_t decodeLock = nullptr;
RGBImage *target = nullptr;
int originX = 0, originY = 0; // where the target's (0, 0) is in the decoded image (window decodes)
bool pastWindow = false;      // stopped on purpose below the window

bool onBlock(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *data) {
    if (!target || !target->pixels) return false;
    x -= originX;
    y -= originY;
    if (y >= target->height) { pastWindow = true; return false; } // blocks come row by row: done
    for (int row = 0; row < h; row++) {
        const int ty = y + row;
        if (ty < 0 || ty >= target->height) continue;
        for (int col = 0; col < w; col++) {
            const int tx = x + col;
            if (tx < 0 || tx >= target->width) continue;
            target->pixels[ty * target->width + tx] = data[row * w + col];
        }
    }
    return true;
}

} // namespace

void RGBImage::release() {
    if (pixels) free(pixels);
    pixels = nullptr;
    width = height = 0;
    capacity = 0;
    dsc = {};
}

void jpegInit() {
    if (!decodeLock) decodeLock = xSemaphoreCreateMutex();
    TJpgDec.setSwapBytes(false);
    TJpgDec.setCallback(onBlock);
}

bool jpegSize(const uint8_t *jpeg, size_t len, int &w, int &h) {
    uint16_t jw = 0, jh = 0;
    xSemaphoreTake(decodeLock, portMAX_DELAY);
    const bool ok = jpeg && len && TJpgDec.getJpgSize(&jw, &jh, jpeg, len) == JDR_OK && jw && jh;
    xSemaphoreGive(decodeLock);
    w = jw;
    h = jh;
    return ok;
}

bool decodeJpegWindow(const uint8_t *jpeg, size_t len, uint8_t scale, int x0, int y0, int w, int h, RGBImage &out) {
    if (!jpeg || len == 0 || w <= 0 || h <= 0) return false;
    const size_t needed = (size_t)w * h;
    xSemaphoreTake(decodeLock, portMAX_DELAY);
    if (out.capacity < needed) {
        if (out.pixels) free(out.pixels);
        out.pixels = (uint16_t *)ps_malloc(needed * 2);
        out.capacity = out.pixels ? needed : 0;
    }
    bool ok = out.pixels != nullptr;
    if (ok) {
        out.width = w;
        out.height = h;
        memset(out.pixels, 0, needed * 2);
        target = &out;
        originX = x0;
        originY = y0;
        pastWindow = false;
        TJpgDec.setJpgScale(scale);
        const JRESULT r = TJpgDec.drawJpg(0, 0, jpeg, len);
        ok = r == JDR_OK || pastWindow;
        target = nullptr;
        originX = originY = 0;
    }
    xSemaphoreGive(decodeLock);
    if (!ok) return false;
    out.dsc.header.always_zero = 0;
    out.dsc.header.cf = LV_IMG_CF_TRUE_COLOR;
    out.dsc.header.w = out.width;
    out.dsc.header.h = out.height;
    out.dsc.data_size = out.width * out.height * 2;
    out.dsc.data = (const uint8_t *)out.pixels;
    return true;
}

uint8_t jpegScaleToFit(const uint8_t *jpeg, size_t len, int maxW, int maxH) {
    uint16_t w = 0, h = 0;
    xSemaphoreTake(decodeLock, portMAX_DELAY);
    const bool ok = TJpgDec.getJpgSize(&w, &h, jpeg, len) == JDR_OK;
    xSemaphoreGive(decodeLock);
    if (!ok || w == 0) return 1;
    for (uint8_t s : {1, 2, 4, 8}) {
        if (w / s <= maxW && h / s <= maxH) return s;
    }
    return 8;
}

bool decodeJpeg(const uint8_t *jpeg, size_t len, uint8_t scale, RGBImage &out) {
    if (!jpeg || len == 0) return false;
    xSemaphoreTake(decodeLock, portMAX_DELAY);
    uint16_t w = 0, h = 0;
    bool ok = TJpgDec.getJpgSize(&w, &h, jpeg, len) == JDR_OK && w > 0 && h > 0;
    if (ok) {
        const int ow = (w + scale - 1) / scale;
        const int oh = (h + scale - 1) / scale;
        const size_t needed = (size_t)ow * oh;
        if (out.capacity < needed) {
            if (out.pixels) free(out.pixels);
            out.pixels = (uint16_t *)ps_malloc(needed * 2);
            out.capacity = out.pixels ? needed : 0;
        }
        ok = out.pixels != nullptr;
        if (ok) {
            out.width = ow;
            out.height = oh;
            memset(out.pixels, 0, needed * 2);
            target = &out;
            TJpgDec.setJpgScale(scale);
            ok = TJpgDec.drawJpg(0, 0, jpeg, len) == JDR_OK;
            target = nullptr;
        }
    }
    xSemaphoreGive(decodeLock);
    if (!ok) return false;
    out.dsc.header.always_zero = 0;
    out.dsc.header.cf = LV_IMG_CF_TRUE_COLOR;
    out.dsc.header.w = out.width;
    out.dsc.header.h = out.height;
    out.dsc.data_size = out.width * out.height * 2;
    out.dsc.data = (const uint8_t *)out.pixels;
    return true;
}
