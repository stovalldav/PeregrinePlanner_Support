#include "JpegImage.h"
#include <TJpg_Decoder.h>
#include <freertos/semphr.h>

namespace {

SemaphoreHandle_t decodeLock = nullptr;
RGBImage *target = nullptr;

bool onBlock(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *data) {
    if (!target || !target->pixels) return false;
    for (int row = 0; row < h; row++) {
        const int ty = y + row;
        if (ty < 0 || ty >= target->height) continue;
        for (int col = 0; col < w; col++) {
            const int tx = x + col;
            if (tx < 0 || tx >= target->width) continue;
            target->pixels[ty * target->width + tx] = data[row * w + col];
        }
    }
    return true;
}

} // namespace

void RGBImage::release() {
    if (pixels) free(pixels);
    pixels = nullptr;
    width = height = 0;
    capacity = 0;
    dsc = {};
}

void jpegInit() {
    if (!decodeLock) decodeLock = xSemaphoreCreateMutex();
    TJpgDec.setSwapBytes(false);
    TJpgDec.setCallback(onBlock);
}

uint8_t jpegScaleToFit(const uint8_t *jpeg, size_t len, int maxW, int maxH) {
    uint16_t w = 0, h = 0;
    xSemaphoreTake(decodeLock, portMAX_DELAY);
    const bool ok = TJpgDec.getJpgSize(&w, &h, jpeg, len) == JDR_OK;
    xSemaphoreGive(decodeLock);
    if (!ok || w == 0) return 1;
    for (uint8_t s : {1, 2, 4, 8}) {
        if (w / s <= maxW && h / s <= maxH) return s;
    }
    return 8;
}

bool decodeJpeg(const uint8_t *jpeg, size_t len, uint8_t scale, RGBImage &out) {
    if (!jpeg || len == 0) return false;
    xSemaphoreTake(decodeLock, portMAX_DELAY);
    uint16_t w = 0, h = 0;
    bool ok = TJpgDec.getJpgSize(&w, &h, jpeg, len) == JDR_OK && w > 0 && h > 0;
    if (ok) {
        const int ow = (w + scale - 1) / scale;
        const int oh = (h + scale - 1) / scale;
        const size_t needed = (size_t)ow * oh;
        if (out.capacity < needed) {
            if (out.pixels) free(out.pixels);
            out.pixels = (uint16_t *)ps_malloc(needed * 2);
            out.capacity = out.pixels ? needed : 0;
        }
        ok = out.pixels != nullptr;
        if (ok) {
            out.width = ow;
            out.height = oh;
            memset(out.pixels, 0, needed * 2);
            target = &out;
            TJpgDec.setJpgScale(scale);
            ok = TJpgDec.drawJpg(0, 0, jpeg, len) == JDR_OK;
            target = nullptr;
        }
    }
    xSemaphoreGive(decodeLock);
    if (!ok) return false;
    out.dsc.header.always_zero = 0;
    out.dsc.header.cf = LV_IMG_CF_TRUE_COLOR;
    out.dsc.header.w = out.width;
    out.dsc.header.h = out.height;
    out.dsc.data_size = out.width * out.height * 2;
    out.dsc.data = (const uint8_t *)out.pixels;
    return true;
}
