#include "ScopeCompass.h"
#include "Config.h"
#include "ScopeState.h"
#include <Adafruit_BNO055.h>
#include <Preferences.h>
#include <Wire.h>
#include <cmath>

ScopeCompass gCompass;

namespace {

struct V3 {
    float x, y, z;
    V3 operator-() const { return {-x, -y, -z}; }
    float dot(const V3 &o) const { return x * o.x + y * o.y + z * o.z; }
    V3 cross(const V3 &o) const { return {y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x}; }
    float norm() const { return sqrtf(x * x + y * y + z * z); }
    V3 unit() const { float n = norm(); return n > 1e-6f ? V3{x / n, y / n, z / n} : V3{0, 0, 0}; }
};

V3 axisVector(uint8_t axis) {
    switch (axis) {
        case 1: return {-1, 0, 0};
        case 2: return {0, 1, 0};
        case 3: return {0, -1, 0};
        case 4: return {0, 0, 1};
        case 5: return {0, 0, -1};
        default: return {1, 0, 0};
    }
}

constexpr float kRadToDeg = 57.29578f;

} // namespace

bool ScopeCompass::begin() {
    for (uint8_t address : {(uint8_t)0x28, (uint8_t)0x29}) {
        auto *candidate = new Adafruit_BNO055(55, address, &Wire);
        if (candidate->begin()) {
            bno_ = candidate;
            bno_->setExtCrystalUse(true);
            Serial.printf("[compass] BNO055 found at 0x%02X\n", address);
            gState.compassPresent = true;
            return true;
        }
        delete candidate;
    }
    Serial.println("[compass] BNO055 not found at 0x28 or 0x29 -- the Radar tab's arrow needs it");
    gState.compassPresent = false;
    return false;
}

void ScopeCompass::poll(uint32_t nowMs) {
    if (!bno_ || paused_) return;
    if (nowMs - lastReadMs_ < Config::kCompassReadIntervalMs) return;
    lastReadMs_ = nowMs;

    imu::Vector<3> g = bno_->getVector(Adafruit_BNO055::VECTOR_GRAVITY);
    imu::Vector<3> m = bno_->getVector(Adafruit_BNO055::VECTOR_MAGNETOMETER);
    uint8_t sys, gyro, accel, mag;
    bno_->getCalibration(&sys, &gyro, &accel, &mag);
    gState.compassCal = mag;

    const V3 gravity{(float)g.x(), (float)g.y(), (float)g.z()};
    const V3 magnetic{(float)m.x(), (float)m.y(), (float)m.z()};
    if (gravity.norm() < 1.0f || magnetic.norm() < 1.0f) return; // not settled yet

    const V3 down = (-gravity).unit();
    const V3 east = down.cross(magnetic).unit();
    const V3 north = east.cross(down).unit();
    const V3 axis = axisVector(Config::kScopeAxis);

    const float e = axis.dot(east);
    const float n = axis.dot(north);
    const float u = -axis.dot(down);
    float az = atan2f(e, n) * kRadToDeg;
    if (az < 0) az += 360.0f;
    gState.scopeMagAzimuthDeg = az;
    gState.scopeElevationDeg = asinf(fmaxf(-1.0f, fminf(1.0f, u))) * kRadToDeg;

    // Dip self-check (see header): clearly negative = the gravity sign assumption is wrong here.
    gState.orientationInverted = down.dot(magnetic.unit()) < -0.3f;
}

void ScopeCompass::suspend() {
    if (bno_) bno_->enterSuspendMode();
}

void saveAlignment(float offsetDeg, uint16_t seq) {
    Preferences prefs;
    prefs.begin("scope", false);
    prefs.putFloat("offset", offsetDeg);
    prefs.putUShort("alignSeq", seq);
    prefs.end();
}

void loadAlignment() {
    Preferences prefs;
    prefs.begin("scope", true);
    gState.alignmentOffsetDeg = prefs.getFloat("offset", 0.0f);
    gState.lastAlignSeq = prefs.getUShort("alignSeq", 0);
    prefs.end();
}
