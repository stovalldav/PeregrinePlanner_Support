// JpegImage.h -- decode a JPEG (bird-card photo, node snapshot) into a PSRAM RGB565 buffer that an
// LVGL image can show. TJpg_Decoder is a single global decoder, so every decode takes one lock --
// the card (main loop) and snapshots (SnapshotFetcher task) never decode at the same time.
#pragma once

#include <Arduino.h>
#include <lvgl.h>

struct RGBImage {
    uint16_t *pixels = nullptr; // PSRAM, native RGB565 (LV_COLOR_16_SWAP 0)
    int width = 0;
    int height = 0;
    size_t capacity = 0; // pixels allocated
    lv_img_dsc_t dsc = {};

    void release();
};

// Decodes `jpeg` at 1/`scale` size (1, 2, 4 or 8) into `out`, reusing its buffer when big enough.
bool decodeJpeg(const uint8_t *jpeg, size_t len, uint8_t scale, RGBImage &out);

// Decodes only the part of `jpeg` (at 1/`scale` size) from (x0, y0), w x h pixels, into `out` --
// for an image far bigger than the screen (a 1280x1600 stop map would need 4 MB whole). Stops
// decoding once it's past the window's bottom edge.
bool decodeJpegWindow(const uint8_t *jpeg, size_t len, uint8_t scale, int x0, int y0, int w, int h, RGBImage &out);

// The JPEG's own size, unscaled. False if it isn't a JPEG this decoder reads.
bool jpegSize(const uint8_t *jpeg, size_t len, int &w, int &h);

// Smallest scale (1/2/4/8) whose output fits within maxW x maxH.
uint8_t jpegScaleToFit(const uint8_t *jpeg, size_t len, int maxW, int maxH);

void jpegInit();
