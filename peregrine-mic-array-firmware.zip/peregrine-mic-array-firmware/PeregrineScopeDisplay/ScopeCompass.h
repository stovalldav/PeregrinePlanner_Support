// ScopeCompass.h -- the BNO055 mounted on the scope (SCOPE_DISPLAY_PLAN.md §4).
//
// Where the scope's line of sight points, computed the same way as the app's NodeOrientation3D
// (TRIAD from the raw gravity + magnetic vectors, not the BNO055's Euler angles, which break when
// the sensor isn't level): down = -gravity, east = down x mag, north = east x down; the chosen
// sensor axis (Config::kScopeAxis) then has a magnetic azimuth and an elevation. True azimuth =
// magnetic + declination (from the phone) + the alignment offset (NVS, set via the app).
//
// Same gravity-sign assumption as NODE_ORIENTATION_3D_PLAN.md §2, self-checked the same way: in the
// northern hemisphere the field dips downward, so down . mag must be clearly positive -- if it's
// clearly negative, `orientationInverted` is raised instead of silently trusting the numbers.
#pragma once

#include <Arduino.h>

class Adafruit_BNO055;

class ScopeCompass {
public:
    // Wire must already be running (touch + codec share it). Probes 0x28 then 0x29.
    bool begin();
    // Reads at Config::kCompassReadIntervalMs and updates gState. Call every loop().
    void poll(uint32_t nowMs);
    // Suspended in Camp mode (no I2C traffic, no CPU) -- see plan §6.2.2.
    void setPaused(bool paused) { paused_ = paused; }
    // Power-off: BNO055 into suspend mode (its lowest-power state). begin() wakes it on next boot.
    void suspend();

private:
    Adafruit_BNO055 *bno_ = nullptr;
    uint32_t lastReadMs_ = 0;
    bool paused_ = false;
};

// NVS persistence for the alignment offset (called from ScopeLink when the app sends an alignment).
void saveAlignment(float offsetDeg, uint16_t seq);
void loadAlignment();

extern ScopeCompass gCompass;
