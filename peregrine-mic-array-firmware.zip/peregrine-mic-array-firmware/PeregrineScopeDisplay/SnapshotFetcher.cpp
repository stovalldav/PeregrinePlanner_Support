#include "SnapshotFetcher.h"
#include "Config.h"
#include "ScopeState.h"
#include "TalkAudio.h"
#include <HTTPClient.h>
#include <WiFi.h>

SnapshotFetcher gSnapshots;

void SnapshotFetcher::begin() {
    httpBuffer_ = (uint8_t *)ps_malloc(Config::kSnapshotMaxBytes);
    xTaskCreatePinnedToCore(taskEntry, "snapshots", 8192, this, 1, nullptr, 0);
}

void SnapshotFetcher::setWanted(const IPAddress *ips, int count) {
    const int n = min(count, kSnapshotSlots);
    bool same = n == slotCount_;
    for (int i = 0; same && i < n; i++) same = slots_[i].ip == ips[i];
    if (same) return;
    slotCount_ = 0; // stop the task touching slots while they're re-keyed
    for (int i = 0; i < n; i++) {
        if (!(slots_[i].ip == ips[i])) {
            slots_[i].ip = ips[i];
            slots_[i].ready = false;
            slots_[i].failed = false;
            slots_[i].lastFetchMs = 0;
            slots_[i].front.release();
        }
    }
    slotCount_ = n;
}

void SnapshotFetcher::refreshNow() {
    for (int i = 0; i < slotCount_; i++) slots_[i].forceNext = true;
}

SnapshotSlot *SnapshotFetcher::takeReady() {
    for (int i = 0; i < slotCount_; i++) {
        SnapshotSlot &s = slots_[i];
        if (!s.ready) continue;
        RGBImage tmp = s.front;
        s.front = s.back;
        s.back = tmp;
        s.ready = false;
        return &s;
    }
    return nullptr;
}

SnapshotSlot *SnapshotFetcher::slotFor(const IPAddress &ip) {
    for (int i = 0; i < slotCount_; i++) if (slots_[i].ip == ip) return &slots_[i];
    return nullptr;
}

void SnapshotFetcher::taskEntry(void *self) { static_cast<SnapshotFetcher *>(self)->taskLoop(); }

void SnapshotFetcher::taskLoop() {
    HTTPClient http;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(200));
        if (!httpBuffer_ || WiFi.status() != WL_CONNECTED || gTalk.isTalking()) continue;
        const uint32_t now = millis();
        for (int i = 0; i < slotCount_; i++) {
            if (gTalk.isTalking()) break;
            SnapshotSlot &s = slots_[i];
            if (s.ready) continue; // main loop hasn't taken the last one yet
            if (!s.forceNext && s.lastFetchMs && now - s.lastFetchMs < Config::kSnapshotRefreshMs) continue;
            s.forceNext = false;
            s.lastFetchMs = now;

            const String url = "http://" + s.ip.toString() + "/snapshot";
            http.setTimeout(Config::kSnapshotTimeoutMs);
            http.setConnectTimeout(Config::kSnapshotTimeoutMs);
            if (!http.begin(url)) { s.failed = true; continue; }
            const int code = http.GET();
            size_t got = 0;
            if (code == HTTP_CODE_OK) {
                WiFiClient *stream = http.getStreamPtr();
                const int total = http.getSize();
                const uint32_t deadline = millis() + Config::kSnapshotTimeoutMs;
                while ((total < 0 || (int)got < total) && got < Config::kSnapshotMaxBytes && millis() < deadline) {
                    const size_t avail = stream->available();
                    if (avail) {
                        got += stream->readBytes(httpBuffer_ + got, min(avail, Config::kSnapshotMaxBytes - got));
                    } else if (!stream->connected()) {
                        break;
                    } else {
                        vTaskDelay(pdMS_TO_TICKS(2));
                    }
                }
            }
            http.end();
            // SVGA (800x600) from the node -> 1/4 scale = 200x150 tiles.
            const bool ok = got > 0 && decodeJpeg(httpBuffer_, got, jpegScaleToFit(httpBuffer_, got, 200, 150), s.back);
            s.failed = !ok;
            if (ok) s.ready = true;
        }
    }
}
