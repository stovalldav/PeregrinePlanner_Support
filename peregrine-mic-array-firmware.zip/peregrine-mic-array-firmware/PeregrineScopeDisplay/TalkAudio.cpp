#include "TalkAudio.h"
#include "Config.h"
#include "NetworkProtocol.h"
#include "ScopeLink.h"
#include "ScopeProtocol.h"
#include "ScopeState.h"
#include "es8311.h"
#include <ESP_I2S.h>
#include <Wire.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <cmath>

TalkAudio gTalk;

namespace {

I2SClass i2s;
es8311_handle_t codec = nullptr;

es8311_mic_gain_t gainFor(int db) {
    switch (db) {
        case 0: return ES8311_MIC_GAIN_0DB;
        case 6: return ES8311_MIC_GAIN_6DB;
        case 12: return ES8311_MIC_GAIN_12DB;
        case 24: return ES8311_MIC_GAIN_24DB;
        case 30: return ES8311_MIC_GAIN_30DB;
        case 36: return ES8311_MIC_GAIN_36DB;
        case 42: return ES8311_MIC_GAIN_42DB;
        default: return ES8311_MIC_GAIN_18DB;
    }
}

void ampOn(bool on) { digitalWrite(Config::kAmpEnable, on ? LOW : HIGH); }

} // namespace

bool TalkAudio::begin() {
    pinMode(Config::kAmpEnable, OUTPUT);
    ampOn(false);

    i2s.setPins(Config::kI2SBCLK, Config::kI2SWS, Config::kI2SDout, Config::kI2SDin, Config::kI2SMCLK);
    if (!i2s.begin(I2S_MODE_STD, Config::kTalkSampleRate, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO, I2S_STD_SLOT_LEFT)) {
        Serial.println("[audio] I2S init failed");
        return false;
    }

    codec = es8311_create(I2C_NUM_0, Config::kCodecAddress);
    const es8311_clock_config_t clk = {
        .mclk_inverted = false,
        .sclk_inverted = false,
        .mclk_from_mclk_pin = true,
        .mclk_frequency = (int)(Config::kTalkSampleRate * 256), // 11.2896 MHz, I2S MCLK default x256
        .sample_frequency = (int)Config::kTalkSampleRate,
    };
    if (!codec || es8311_init(codec, &clk, ES8311_RESOLUTION_16, ES8311_RESOLUTION_16) != ESP_OK) {
        Serial.println("[audio] ES8311 not answering on I2C 0x18 -- talk and chirps disabled");
        return false;
    }
    es8311_sample_frequency_config(codec, clk.mclk_frequency, clk.sample_frequency);
    es8311_microphone_config(codec, false); // analog MEMS mic
    es8311_microphone_gain_set(codec, gainFor(gState.micGainDb));
    es8311_voice_volume_set(codec, Config::kSpeakerVolume, nullptr);

    // Spoken-alert queue: 8 s in PSRAM, or 2 s of internal RAM without it.
    speechCap_ = (size_t)Protocol::kSpeechSampleRate * 8;
    speech_ = (int16_t *)ps_malloc(speechCap_ * sizeof(int16_t));
    if (!speech_) {
        speechCap_ = (size_t)Protocol::kSpeechSampleRate * 2;
        speech_ = (int16_t *)malloc(speechCap_ * sizeof(int16_t));
    }
    if (!speech_) speechCap_ = 0;

    ready_ = true;
    xTaskCreatePinnedToCore(taskEntry, "talk", 6144, this, 5, nullptr, 0);
    Serial.println("[audio] ES8311 ready (talk + chirps)");
    return true;
}

void TalkAudio::startTalk(const IPAddress *targets, int count) {
    if (!ready_ || count <= 0) return;
    const int n = min(count, 8);
    for (int i = 0; i < n; i++) targets_[i] = targets[i];
    targetCount_ = n;
    talking_ = true;
}

void TalkAudio::stopTalk() { talking_ = false; }

void TalkAudio::shutdown() {
    talking_ = false;
    ampOn(false);
    if (!ready_) return;
    // ES8311 stop sequence, as in Espressif's ESP-ADF es8311 driver: DAC/ADC volume to zero, then
    // the analog blocks (PGA/ADC, DAC, mic bias, VMID, reference) powered down.
    static const uint8_t seq[][2] = {
        {0x32, 0x00}, {0x17, 0x00}, {0x0E, 0xFF}, {0x12, 0x02}, {0x14, 0x00},
        {0x0D, 0xFA}, {0x15, 0x00}, {0x37, 0x08}, {0x45, 0x01},
    };
    for (const auto &reg : seq) {
        Wire.beginTransmission(Config::kCodecAddress);
        Wire.write(reg[0]);
        Wire.write(reg[1]);
        Wire.endTransmission();
    }
}

void TalkAudio::setMicGainDb(int db) {
    if (!ready_ || !codec) return;
    es8311_microphone_gain_set(codec, gainFor(db));
}

namespace {
// Peak meter with a quick attack and a ~0.5 s fall, read by the UI.
void meter(const int16_t *s, int n) {
    int peak = 0;
    for (int i = 0; i < n; i++) { const int v = abs((int)s[i]); if (v > peak) peak = v; }
    const float level = peak / 32768.0f;
    if (level > gState.micPeak10s) gState.micPeak10s = level;
    gState.micLevel = level > gState.micLevel ? level : gState.micLevel * 0.95f;
}
} // namespace

void TalkAudio::chirp() {
    if (ready_ && !talking_) chirpRequested_ = true;
}

void TalkAudio::queueSpeech(const int16_t *samples, int count) {
    if (!ready_ || talking_ || speechCap_ == 0 || gState.poweringOff) return;
    size_t head = speechHead_;
    for (int i = 0; i < count; i++) {
        const size_t next = (head + 1) % speechCap_;
        if (next == speechTail_) break; // full: drop the rest
        speech_[head] = samples[i];
        head = next;
    }
    __sync_synchronize(); // samples visible before the new head is
    speechHead_ = head;
}

void TalkAudio::taskEntry(void *self) { static_cast<TalkAudio *>(self)->taskLoop(); }

void TalkAudio::taskLoop() {
    WiFiUDP udp;
    bool udpOpen = false;
    uint32_t seq = 0;
    uint32_t audioSeq = 0;
    struct __attribute__((packed)) Frame {
        Protocol::AudioFrameHeader header;
        int16_t samples[Config::kTalkSamplesPerPacket];
    };
    static Frame frame;
    static int16_t silence[Config::kTalkSamplesPerPacket];
    uint32_t lastSpeechMs = 0;

    for (;;) {
        if (gState.poweringOff) { vTaskDelay(pdMS_TO_TICKS(1000)); continue; }
        if (talking_) {
            if (speaking_) { ampOn(false); speaking_ = false; speechTail_ = speechHead_; } // Talk wins
            if (!udpOpen && WiFi.status() == WL_CONNECTED) udpOpen = udp.begin(0);
            const size_t want = sizeof(frame.samples);
            const size_t got = i2s.readBytes((char *)frame.samples, want);
            if (got == want) meter(frame.samples, Config::kTalkSamplesPerPacket);
            if (got != want || !udpOpen) continue;
            frame.header.version = Protocol::kVersion;
            frame.header.type = Protocol::kPlaybackAudioFrame;
            frame.header.seq = seq++;
            frame.header.sampleRate = Config::kTalkSampleRate;
            frame.header.encoding = Protocol::kEncodingInt16;
            frame.header.reserved = 0;
            const int n = targetCount_;
            for (int i = 0; i < n; i++) {
                udp.beginPacket(targets_[i], Config::kUDPPort);
                udp.write((const uint8_t *)&frame, sizeof(frame));
                udp.endPacket();
            }
            continue;
        }

        // Spoken alert (kScopeSpeech): 22.05 kHz queued samples, doubled to the codec's 44.1 kHz
        // (linear in between). The mic isn't read meanwhile, so the display never streams -- or
        // hears -- its own voice.
        if (speechTail_ != speechHead_) {
            if (!speaking_) {
                speaking_ = true;
                gState.micStreamingNow = false;
                ampOn(true);
            }
            size_t tail = speechTail_;
            const size_t head = speechHead_;
            int i = 0;
            while (i < Config::kTalkSamplesPerPacket && tail != head) {
                const int16_t a = speech_[tail];
                tail = (tail + 1) % speechCap_;
                const int16_t b = tail != head ? speech_[tail] : a;
                frame.samples[i++] = a;
                if (i < Config::kTalkSamplesPerPacket) frame.samples[i++] = (int16_t)(((int)a + (int)b) / 2);
            }
            speechTail_ = tail;
            while (i < Config::kTalkSamplesPerPacket) frame.samples[i++] = 0;
            i2s.write((const uint8_t *)frame.samples, sizeof(frame.samples));
            lastSpeechMs = millis();
            continue;
        }
        if (speaking_) {
            // Queue ran dry: wait a moment for late packets, then let the speaker go quiet.
            i2s.write((const uint8_t *)silence, sizeof(silence));
            if (millis() - lastSpeechMs > 400) {
                for (int i = 0; i < 3; i++) i2s.write((const uint8_t *)silence, sizeof(silence));
                ampOn(false);
                speaking_ = false;
            }
            continue;
        }

        if (chirpRequested_) {
            chirpRequested_ = false;
            ampOn(true);
            // Two short tones, 1.8 kHz then 2.4 kHz, ~120 ms each.
            for (float freq : {1800.0f, 2400.0f}) {
                for (int block = 0; block < 12; block++) {
                    for (int i = 0; i < Config::kTalkSamplesPerPacket; i++) {
                        const float t = (float)(block * Config::kTalkSamplesPerPacket + i) / Config::kTalkSampleRate;
                        frame.samples[i] = (int16_t)(sinf(2.0f * PI * freq * t) * 9000.0f);
                    }
                    i2s.write((const uint8_t *)frame.samples, sizeof(frame.samples));
                }
            }
            for (int i = 0; i < 4; i++) i2s.write((const uint8_t *)silence, sizeof(silence));
            ampOn(false);
            continue;
        }

        // Sound detection off (Session tab): don't read the mic at all -- saves the CPU work and the
        // ~710 kbit/s uplink. Talk still works (handled above).
        if (!gState.micStreamEnabled) {
            gState.micStreamingNow = false;
            gState.micLevel = 0;
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        // Listening (§6.5): stream the mic to the app as a one-mic node during a Sound ID session.
        // Otherwise just keep reading (the level meter still works with no session or no phone).
        const size_t got = i2s.readBytes((char *)frame.samples, sizeof(frame.samples));
        if (got == sizeof(frame.samples)) meter(frame.samples, Config::kTalkSamplesPerPacket);
        else gState.micShortReads++;
        const bool stream = !gState.campMode && gLink.hasApp() && gState.appLinked(millis(), Config::kAppLinkTimeoutMs) &&
                            gState.session.valid && gState.session.active;
        gState.micStreamingNow = stream;
        if (stream && got == sizeof(frame.samples)) {
            {
                frame.header.version = Protocol::kVersion;
                frame.header.type = Protocol::kAudioFrame;
                frame.header.seq = audioSeq++;
                frame.header.sampleRate = Config::kTalkSampleRate;
                frame.header.encoding = Protocol::kEncodingInt16;
                frame.header.reserved = 0;
                if (gLink.sendToApp((const uint8_t *)&frame, sizeof(frame))) gState.micFramesSent++;
            }
            continue; // the read itself paces this loop at 10 ms
        }
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}
