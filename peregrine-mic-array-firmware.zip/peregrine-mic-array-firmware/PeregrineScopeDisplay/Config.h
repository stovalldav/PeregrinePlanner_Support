// Config.h — the Scope Display node (Freenove ESP32-S3 Display 4.0", FNK0104S) mounted on the
// spotting scope. See SCOPE_DISPLAY_PLAN.md (repo root) and README.md here.
//
// Pins confirmed 2026-10-02 from Freenove's 4.0" schematic and their FNK0104S example sketches
// (github.com/Freenove/Freenove_ESP32_S3_Display) -- not guessed. The display's own SPI pins
// (MOSI 11, SCLK 12, CS 10, DC 46, backlight 45) live in TFT_eSPI's FNK0104S setup file, not here.
//
// Secrets: put your real Wi-Fi networks in a gitignored Config.local.h copy (same pattern as the
// node firmware) -- this tracked file keeps only the shipped defaults.
#pragma once

#include <cstddef>
#include <cstdint>

namespace Config {

// ---- Board pins (FNK0104S) ----
constexpr int kI2CSDA = 16;      // shared: FT6336U touch (0x38), ES8311 codec (0x18), BNO055 (0x28/0x29)
constexpr int kI2CSCL = 15;
constexpr uint32_t kI2CHz = 400000;
constexpr int kTouchRST = 18;
constexpr int kTouchINT = 17;
constexpr int kBatteryADC = 9;   // 100k/100k divider -> millivolts x2
constexpr int kRGBLed = 42;      // one WS2812
constexpr int kBootKey = 0;
constexpr int kI2SMCLK = 4;      // ES8311
constexpr int kI2SBCLK = 5;
constexpr int kI2SWS = 7;
constexpr int kI2SDout = 8;      // ESP32 -> codec DAC -> speaker amp
constexpr int kI2SDin = 6;       // codec ADC (MEMS mic) -> ESP32
constexpr int kAmpEnable = 1;    // SC8002B SHUTDOWN: LOW = amplifier on
constexpr uint8_t kCodecAddress = 0x18;

// ---- Display ----
constexpr int kScreenWidth = 320;
constexpr int kScreenHeight = 480;
constexpr uint8_t kBacklightNormal = 255; // 0-255 PWM on the backlight pin
constexpr uint8_t kBacklightDim = 60;     // after kDimAfterMs with no touch
constexpr uint32_t kDimAfterMs = 120000;

// ---- Wi-Fi (client of the fleet network: a node's AP, a travel router, or a phone hotspot) ----
struct WiFiCredential {
    const char *ssid;
    const char *password;
};
constexpr const char *kWiFiSSID = "PeregrineMicArray";
constexpr const char *kWiFiPassword = "birding123";
constexpr WiFiCredential kWiFiCandidates[] = {
    { kWiFiSSID, kWiFiPassword },
    // Add your own networks here (most-preferred first) in Config.local.h, e.g.:
    // { "MyHomeWiFi", "homepassword123" },
    // { "My iPhone", "hotspotpassword" },  -- iOS uses a typographic ’ in possessive hotspot names
};
constexpr uint32_t kWiFiPerCandidateTimeoutMs = 8000;
constexpr uint32_t kWiFiRetryMs = 15000;

// ---- Fleet protocol ----
constexpr uint16_t kUDPPort = 3333;          // same port every node listens on
constexpr uint32_t kFleetId = 0x00000000;
constexpr uint32_t kIdentityIntervalMs = 5000;
// The app pings every 3 s while connected; nothing from it for this long = "phone not connected".
constexpr uint32_t kAppLinkTimeoutMs = 10000;

// ---- Scope compass (BNO055 on the I2C header, mounted on the scope body) ----
constexpr bool kCompassEnabled = true;
constexpr uint32_t kCompassReadIntervalMs = 100; // 10 Hz for the guidance arrow
// Which BNO055 sensor axis points along the scope's line of sight (toward the far end). One-time
// per mounting; check with the Radar tab's "Scope heading" readout while turning the scope.
// 0 = +X, 1 = -X, 2 = +Y, 3 = -Y, 4 = +Z, 5 = -Z.
constexpr uint8_t kScopeAxis = 0;
// The arrow turns green when the scope is within this many target-sigmas of the target.
constexpr float kOnTargetSigmas = 1.0f;

// ---- Talk (hold-to-talk -> a security node's speaker, SCOPE_DISPLAY_PLAN.md §6.2.1) ----
// Same wire format as the app's push-to-talk: mono int16 @ 44.1 kHz, 441 samples (10 ms) a packet.
constexpr uint32_t kTalkSampleRate = 44100;
constexpr int kTalkSamplesPerPacket = 441;
constexpr int kMicGainDb = 18; // ES8311 PGA: 0, 6, 12, 18, 24, 30, 36, 42
constexpr int kSpeakerVolume = 70; // 0-100, alert chirps only

// ---- Listening (SCOPE_DISPLAY_PLAN.md §6.5) ----
// Stream this display's own mic to the app as a one-mic node (Bird Sounds source / Fleet-Wide
// Classification). Same kAudioFrame format as the nodes: mono int16 @ 44.1 kHz, 441-sample packets
// (~710 kbit/s while on). Toggle on the Session tab; the choice is remembered (NVS). Paused while
// Talk is held and in Camp mode.
constexpr bool kMicStreamDefault = true;

// ---- Snapshots (Camp tab) ----
constexpr uint32_t kSnapshotRefreshMs = 12000;   // per visible tile; paused while talking
constexpr uint32_t kSnapshotTimeoutMs = 4000;
constexpr size_t kSnapshotMaxBytes = 160 * 1024; // SVGA JPEG from a node is ~30-60 KB

// ---- Battery (single-cell LiPo on the JP1 port, charged by the onboard TP4054) ----
constexpr uint32_t kBatteryReadIntervalMs = 5000;

} // namespace Config
