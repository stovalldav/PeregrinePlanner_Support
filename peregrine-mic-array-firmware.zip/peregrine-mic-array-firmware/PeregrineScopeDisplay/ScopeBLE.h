// ScopeBLE.h -- the display's Bluetooth: discovery advertising + iPhone notifications (ANCS).
//
// Discovery: same payload as the nodes' BLEAdvertiser (BLE_NODE_DISCOVERY_PLAN.md) -- 'P','P',
// deviceId[6], nodeType, flags, IPv4[4] as manufacturer data -- so the app re-finds the display when
// its IP changes (open Mic Array > Fleet; NodeDiscoveryReconciler updates the saved address).
//
// iPhone notifications (Apple Notification Center Service): the display advertises as an accessory
// that wants notifications. Pair it once in the iPhone's Settings > Bluetooth ("PPScope") and allow
// "Share System Notifications"; from then on the iPhone reconnects by itself and sends every
// notification. Merlin's (app ID containing "merlin") become Heard-list rows tagged MERLIN, separate
// from the birds our own app relays. Other apps' notifications are ignored -- only their app ID is
// logged, never their text.
//
// Runs on NimBLE directly (the Arduino BLE wrapper can't act as a GATT client on a connection the
// iPhone opened). NimBLE callbacks run on the host task; parsed notifications reach the main loop
// through a queue.
#pragma once

#include <IPAddress.h>
#include <cstdint>

class ScopeBLE {
public:
    void begin();
    // Every loop(): keeps advertising right (connectable until the iPhone connects; discovery-only
    // while connected and the app isn't linked) and hands Merlin notifications to the Heard list.
    void poll(bool hasApp, bool wifiUp, const IPAddress &ip);
    // Forgets the iPhone pairing (Session tab) -- pair again from the iPhone's Bluetooth settings.
    void forgetPairing();
};

// Same 6-byte deviceId the nodes use (ESP.getEfuseMac(), low byte first) -- the app matches the
// BLE advertisement to the declared node by it, so identity and BLE must agree.
void fillDeviceId(uint8_t *out);

extern ScopeBLE gBLE;
