#include "ScopeLink.h"
#include "ScopeStorage.h"
#include <Preferences.h>
#include "Config.h"
#include "NetworkProtocol.h"
#include "ScopeProtocol.h"
#include "ScopeState.h"
#include "ScopeBLE.h"

ScopeLink gLink;

namespace {

constexpr size_t kMaxCardBytes = 256 * Protocol::kScopeCardChunkBytes; // ~225 KB

// Little-endian reader over one packet, bounds-checked: a short/malformed packet reads as zeros
// and `ok` goes false, so parsers never walk past the end.
struct Reader {
    const uint8_t *d;
    int len;
    int pos;
    bool ok = true;
    Reader(const uint8_t *data, int n, int start) : d(data), len(n), pos(start) {}
    bool need(int n) { if (pos + n > len) { ok = false; return false; } return true; }
    uint8_t u8() { if (!need(1)) return 0; return d[pos++]; }
    uint16_t u16() { if (!need(2)) return 0; uint16_t v = d[pos] | (d[pos + 1] << 8); pos += 2; return v; }
    uint32_t u32() {
        if (!need(4)) return 0;
        uint32_t v = (uint32_t)d[pos] | ((uint32_t)d[pos + 1] << 8) | ((uint32_t)d[pos + 2] << 16) | ((uint32_t)d[pos + 3] << 24);
        pos += 4;
        return v;
    }
    float f32() { uint32_t bits = u32(); float f; memcpy(&f, &bits, 4); return f; }
    String str() {
        uint8_t n = u8();
        if (!need(n)) return String();
        String s;
        s.reserve(n);
        for (int i = 0; i < n; i++) s += (char)d[pos + i];
        pos += n;
        return s;
    }
    IPAddress ip() { uint8_t a = u8(), b = u8(), c = u8(), e = u8(); return IPAddress(a, b, c, e); }
};

void putU16(uint8_t *p, uint16_t v) { p[0] = v & 0xFF; p[1] = v >> 8; }

} // namespace

void ScopeLink::begin() {
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    connectWiFi(millis());
}

void ScopeLink::connectWiFi(uint32_t nowMs) {
    constexpr int count = sizeof(Config::kWiFiCandidates) / sizeof(Config::kWiFiCandidates[0]);
    wifiCandidate_ = (wifiCandidate_ + 1) % count;
    const auto &c = Config::kWiFiCandidates[wifiCandidate_];
    Serial.printf("[wifi] trying %d/%d: %s\n", wifiCandidate_ + 1, count, c.ssid);
    WiFi.disconnect();
    WiFi.begin(c.ssid, c.password);
    wifiAttemptStartMs_ = nowMs;
}

void ScopeLink::poll(uint32_t nowMs) {
    // Wi-Fi: non-blocking walk through the candidates until one sticks.
    const bool connected = WiFi.status() == WL_CONNECTED;
    if (connected && !wifiWasConnected_) {
        Serial.printf("[wifi] joined %s, IP %s\n", WiFi.SSID().c_str(), WiFi.localIP().toString().c_str());
        gState.ssid = WiFi.SSID();
        gState.myIP = WiFi.localIP();
        if (!udpStarted_) udpStarted_ = udp_.begin(Config::kUDPPort);
    } else if (!connected && wifiWasConnected_) {
        Serial.println("[wifi] lost connection");
        wifiAttemptStartMs_ = nowMs;
    }
    wifiWasConnected_ = connected;
    gState.wifiConnected = connected;
    if (!connected && nowMs - wifiAttemptStartMs_ > Config::kWiFiPerCandidateTimeoutMs) {
        connectWiFi(nowMs);
    }
    if (!connected || !udpStarted_) return;

    // Receive everything waiting (bounded so a flood can't starve the UI).
    static uint8_t buf[1500];
    for (int i = 0; i < 24; i++) {
        xSemaphoreTakeRecursive(udpLock_, portMAX_DELAY);
        const int size = udp_.parsePacket();
        const int len = size > 0 ? udp_.read(buf, sizeof(buf)) : 0;
        const IPAddress fromIP = udp_.remoteIP();
        const uint16_t fromPort = udp_.remotePort();
        xSemaphoreGiveRecursive(udpLock_);
        if (size <= 0) break;
        if (len >= 2) handlePacket(buf, len, fromIP, fromPort);
    }
    logLinkStats(millis());
    pollOutbox(millis());
    if (appPort_ != 0 && millis() - lastCardStatusMs_ >= 5000) {
        lastCardStatusMs_ = millis();
        sendCardStatus();
    }

    if (appPort_ != 0 && nowMs - lastIdentityMs_ >= Config::kIdentityIntervalMs) {
        sendIdentity();
        lastIdentityMs_ = nowMs;
    }
}

void ScopeLink::sendTo(const uint8_t *data, size_t len, const IPAddress &ip, uint16_t port) {
    xSemaphoreTakeRecursive(udpLock_, portMAX_DELAY);
    udp_.beginPacket(ip, port);
    udp_.write(data, len);
    udp_.endPacket();
    xSemaphoreGiveRecursive(udpLock_);
}

bool ScopeLink::sendToApp(const uint8_t *data, size_t len) {
    if (!udpStarted_ || appPort_ == 0) return false;
    xSemaphoreTakeRecursive(udpLock_, portMAX_DELAY);
    udp_.beginPacket(appIP_, appPort_);
    udp_.write(data, len);
    const bool ok = udp_.endPacket();
    xSemaphoreGiveRecursive(udpLock_);
    return ok;
}

void ScopeLink::sendIdentity() {
    if (appPort_ == 0) return;
    Protocol::NodeIdentityPacket p = {};
    p.version = Protocol::kVersion;
    p.type = Protocol::kNodeIdentity;
    p.nodeType = Protocol::kNodeTypeScopeDisplay;
    p.hasGPS = 0;
    p.hasCompass = gState.compassPresent ? 1 : 0;
    p.hasMotionSensor = 0;
    p.micCount = gState.micStreamEnabled ? 1 : 0; // one mic, no direction -- see §6.5
    p.fleetId = Config::kFleetId;
    fillDeviceId(p.deviceId); // same bytes as the BLE advertisement
    p.hasPresenceSensor = 0;
    p.hasSpeaker = 1;
    sendTo((const uint8_t *)&p, sizeof(p), appIP_, appPort_);
}

void ScopeLink::logLinkStats(uint32_t nowMs) {
    const bool linked = gState.appLinked(nowMs, Config::kAppLinkTimeoutMs);
    if (linked != wasLinked_) {
        Serial.printf("[link] app %s (last app packet %ld ms ago)\n", linked ? "LINKED" : "LOST",
                      (long)(gState.lastAppPacketMs ? (int32_t)(nowMs - gState.lastAppPacketMs) : 0));
        wasLinked_ = linked;
    }
    if (nowMs - lastStatMs_ < 10000) return;
    lastStatMs_ = nowMs;
    Serial.printf("[link-stat] wifi %s rssi %d ip %s | app %s:%u last %lu ms ago, max gap %lu ms | rx %lu (pings %lu, from app %lu) | "
                  "sleep %s | loop max %lu ms | heap %u | iphone %s, %lu notifications, %lu merlin | "
                  "mic %s%s, %lu frames sent, %lu short reads, peak %.4f\n",
                  WiFi.status() == WL_CONNECTED ? "up" : "DOWN", WiFi.RSSI(), WiFi.localIP().toString().c_str(),
                  appIP_.toString().c_str(), appPort_,
                  (unsigned long)(gState.lastAppPacketMs ? nowMs - gState.lastAppPacketMs : 0), (unsigned long)maxAppGapMs_,
                  (unsigned long)rxPackets_, (unsigned long)rxPings_, (unsigned long)rxFromApp_,
                  WiFi.getSleep() ? "modem" : "off", (unsigned long)gState.loopMaxMs, (unsigned)ESP.getFreeHeap(),
                  gState.ancsState == 3 ? "receiving" : gState.ancsState == 2 ? "secured" : gState.ancsState == 1 ? "connecting"
                  : gState.ancsState == 4 ? "NOT ALLOWED" : (gState.ancsPaired ? "paired, not connected" : "not paired"),
                  (unsigned long)gState.ancsCount, (unsigned long)gState.merlinCount,
                  gState.micStreamEnabled ? "on" : "OFF", gState.micStreamingNow ? " streaming" : "",
                  (unsigned long)gState.micFramesSent, (unsigned long)gState.micShortReads, gState.micPeak10s);
    gState.micFramesSent = gState.micShortReads = 0;
    gState.micPeak10s = 0;
    rxPackets_ = rxPings_ = rxFromApp_ = 0;
    maxAppGapMs_ = 0;
    gState.loopMaxMs = 0;
}

void ScopeLink::handlePacket(const uint8_t *data, int len, const IPAddress &from, uint16_t fromPort) {
    if (data[0] != Protocol::kVersion) return;
    const uint8_t type = data[1];
    rxPackets_++;
    if (type == Protocol::kHandshakePing) rxPings_++;
    if (from == appIP_ && fromPort == appPort_) {
        const uint32_t now = millis();
        if (lastAppSeenMs_ && now - lastAppSeenMs_ > maxAppGapMs_) maxAppGapMs_ = now - lastAppSeenMs_;
        lastAppSeenMs_ = now;
        rxFromApp_++;
        gState.lastAppPacketMs = now;
    }

    switch (type) {
        case Protocol::kHandshakePing: {
            Protocol::HandshakePongPacket pong = {Protocol::kVersion, Protocol::kHandshakePong, Protocol::kPongMagic0, Protocol::kPongMagic1};
            sendTo((const uint8_t *)&pong, sizeof(pong), from, fromPort);
            return;
        }
        case Protocol::kSessionStart: {
            const bool isNew = !(from == appIP_ && fromPort == appPort_);
            appIP_ = from;
            appPort_ = fromPort;
            gState.lastAppPacketMs = millis();
            if (isNew) {
                Serial.printf("[link] app at %s:%u\n", from.toString().c_str(), fromPort);
                sendIdentity();
                lastIdentityMs_ = millis();
                // Re-assert Camp mode after an app restart.
                if (gState.campMode) sendCommand(Protocol::kCmdCampModeOn);
            }
            return;
        }
        case Protocol::kSessionStop:
            if (from == appIP_ && fromPort == appPort_) appPort_ = 0;
            return;
        case Protocol::kScopeDetection:   onDetection(data, len); return;
        case Protocol::kScopeCardData:    onCardChunk(data, len); return;
        case Protocol::kScopeTargets:     onTargets(data, len); return;
        case Protocol::kScopeFleetStatus: onFleetStatus(data, len); return;
        case Protocol::kScopeNodeLive:    onNodeLive(data, len); return;
        case Protocol::kScopeSession:     onSession(data, len); return;
        case Protocol::kScopePresence:    onPresence(data, len); return;
        case Protocol::kScopeTargetList:  onTargetList(data, len); return;
        case Protocol::kScopeAck:         onAck(data, len); return;
        case Protocol::kScopePrefetchList: onPrefetchList(data, len); return;
        case Protocol::kScopeTripHistory: onTripHistory(data, len); return;
        default:
            return; // other fleet packets (Wi-Fi config requests etc.) aren't meaningful here
    }
}

// Adds a bird to the Heard list (newest first). The same species from the same source refreshes
// its row; Merlin's and ours stay separate rows so you can tell who heard what.
void addDetection(const Detection &incoming) {
    Detection det = incoming;
    int existing = -1;
    for (int i = 0; i < gState.detectionCount; i++) {
        if (gState.detections[i].common == det.common && gState.detections[i].source == det.source) { existing = i; break; }
    }
    if (existing >= 0) {
        det.hits = gState.detections[existing].hits + 1;
        det.newLifeBird = det.newLifeBird || gState.detections[existing].newLifeBird;
        if (det.confidencePct < gState.detections[existing].confidencePct) det.confidencePct = gState.detections[existing].confidencePct;
        if (det.scientific.isEmpty()) det.scientific = gState.detections[existing].scientific;
        for (int i = existing; i > 0; i--) gState.detections[i] = gState.detections[i - 1];
    } else {
        const int n = min(gState.detectionCount, kMaxDetections - 1);
        for (int i = n; i > 0; i--) gState.detections[i] = gState.detections[i - 1];
        gState.detectionCount = n + 1;
    }
    gState.detections[0] = det;
    gState.detectionsVersion++;
}

void ScopeLink::onDetection(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    Detection det;
    det.confidencePct = r.u8();
    const uint8_t flags = r.u8();
    det.trueBearingDeg = r.f32();
    det.common = r.str();
    det.scientific = r.str();
    det.nodeName = r.str();
    if (!r.ok || det.common.isEmpty()) return;
    if (!(flags & 0x01)) det.trueBearingDeg = NAN;
    det.newLifeBird = flags & 0x02;
    det.receivedMs = millis();
    det.source = 0;
    addDetection(det);
}

uint16_t ScopeLink::requestCard(const String &common, const String &scientific, bool prefetch) {
    if (appPort_ == 0) return 0;
    if (!cardBuffer_) cardBuffer_ = (uint8_t *)ps_malloc(kMaxCardBytes);
    if (!cardChunkSeen_) cardChunkSeen_ = (uint8_t *)ps_malloc(256);
    if (!cardBuffer_ || !cardChunkSeen_) return 0;
    cardRequestId_ = nextRequestId_++;
    if (nextRequestId_ == 0) nextRequestId_ = 1;
    cardChunkCount_ = 0;
    cardChunksReceived_ = 0;
    cardComplete_ = false;
    cardTaken_ = false;
    cardIsPrefetch_ = prefetch;
    cardRequestMs_ = millis();
    cardCommon_ = common;
    cardScientific_ = scientific;
    memset(cardChunkSeen_, 0, 256);

    uint8_t pkt[2 + 2 + 1 + 255 + 1 + 255];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeCardRequest;
    putU16(pkt + n, cardRequestId_); n += 2;
    for (const String *s : {&common, &scientific}) {
        const size_t l = min((size_t)255, (size_t)s->length());
        pkt[n++] = (uint8_t)l;
        memcpy(pkt + n, s->c_str(), l);
        n += l;
    }
    sendTo(pkt, n, appIP_, appPort_);
    return cardRequestId_;
}

void ScopeLink::onCardChunk(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t requestId = r.u16();
    const uint16_t index = r.u16();
    const uint16_t count = r.u16();
    if (!r.ok || requestId != cardRequestId_ || cardComplete_ || count == 0 || count > 256 || index >= count) return;
    cardChunkCount_ = count;
    const int payload = len - r.pos;
    if (payload <= 0 || payload > Protocol::kScopeCardChunkBytes) return;
    if (!cardChunkSeen_[index]) {
        memcpy(cardBuffer_ + (size_t)index * Protocol::kScopeCardChunkBytes, d + r.pos, payload);
        cardChunkSeen_[index] = 1;
        cardChunksReceived_++;
    }
    if (cardChunksReceived_ == cardChunkCount_) cardComplete_ = true;
}

bool ScopeLink::takePrefetchCard(String &common, const uint8_t *&payload, size_t &len) {
    if (!cardComplete_ || cardTaken_ || !cardIsPrefetch_) return false;
    cardTaken_ = true;
    common = cardCommon_;
    payload = cardBuffer_;
    len = (size_t)cardChunkCount_ * Protocol::kScopeCardChunkBytes;
    return true;
}

bool ScopeLink::takeCard(CardResult &out) {
    if (!cardComplete_ || cardTaken_ || cardIsPrefetch_) return false;
    cardTaken_ = true;
    Reader r(cardBuffer_, 8, 0);
    const uint32_t textLen = r.u32();
    const uint32_t jpegLen = r.u32();
    const size_t total = (size_t)cardChunkCount_ * Protocol::kScopeCardChunkBytes;
    if (8 + (size_t)textLen + jpegLen > total) return false;
    out.requestId = cardRequestId_;
    out.text = String((const char *)(cardBuffer_ + 8), textLen);
    out.jpeg = jpegLen ? cardBuffer_ + 8 + textLen : nullptr;
    out.jpegLen = jpegLen;
    gStore.saveCard(cardCommon_, cardBuffer_, total, cardScientific_); // next time it opens without the phone
    return true;
}

void ScopeLink::onTargets(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const float declination = r.f32();
    const uint16_t alignSeq = r.u16();
    const float alignTrue = r.f32();
    const uint8_t count = r.u8();
    if (!r.ok) return;
    gState.declinationDeg = declination;
    gState.declinationKnown = true;
    // Alignment: the user pointed the scope at something of known true bearing and tapped Align
    // in the app. Applied once per new sequence number (the app repeats it in every packet).
    if (alignSeq != 0 && alignSeq != gState.lastAlignSeq && !isnan(alignTrue) && !isnan(gState.scopeMagAzimuthDeg)) {
        gState.lastAlignSeq = alignSeq;
        float offset = alignTrue - (gState.scopeMagAzimuthDeg + declination);
        offset = fmodf(offset + 540.0f, 360.0f) - 180.0f;
        gState.alignmentOffsetDeg = offset;
        extern void saveAlignment(float, uint16_t);
        saveAlignment(offset, alignSeq);
        Serial.printf("[scope] aligned: offset %.1f deg (true %.1f, mag %.1f, decl %.1f)\n", offset, alignTrue, gState.scopeMagAzimuthDeg, declination);
    }
    int n = 0;
    for (int i = 0; i < count && n < kMaxTargets; i++) {
        Target t;
        t.slot = r.u8();
        t.trueAzimuthDeg = r.f32();
        t.elevationDeg = r.f32();
        t.sigmaDeg = r.f32();
        t.distanceM = r.f32();
        t.name = r.str();
        if (!r.ok) break;
        gState.targets[n++] = t;
    }
    gState.targetCount = n;
    gState.targetsUpdatedMs = millis();
}

void ScopeLink::onFleetStatus(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint8_t count = r.u8();
    FleetNode incoming[kMaxFleetNodes];
    int n = 0;
    for (int i = 0; i < count && n < kMaxFleetNodes; i++) {
        FleetNode f;
        f.ip = r.ip();
        f.nodeType = r.u8();
        f.flags = r.u8();
        f.sats = r.u8();
        f.compassCal = r.u8();
        f.lastHeardS = r.u16();
        f.presenceModel = r.u8();
        f.name = r.str();
        if (!r.ok) break;
        const int old = gState.fleetIndex(f.ip);
        if (old >= 0) f.presence = gState.fleet[old].presence; // keep relayed presence
        incoming[n++] = f;
    }
    if (!r.ok && n == 0) return;
    for (int i = 0; i < n; i++) gState.fleet[i] = incoming[i];
    gState.fleetCount = n;
    gState.fleetVersion++;
}

void ScopeLink::onNodeLive(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    NodeLive l;
    l.ip = r.ip();
    l.azimuthDeg = r.f32();
    l.confidence = r.f32();
    l.level = r.f32();
    l.headingDeg = r.f32();
    l.compassCal = r.u8();
    l.gpsFix = r.u8();
    l.sats = r.u8();
    if (!r.ok) return;
    l.valid = true;
    l.updatedMs = millis();
    gState.live = l;
}

void ScopeLink::onSession(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    SessionInfo s;
    s.active = r.u8();
    s.elapsedS = r.u32();
    s.species = r.u16();
    s.detections10min = r.u16();
    s.newLifeBirds = r.u16();
    const uint8_t count = r.u8();
    for (int i = 0; i < count && s.recentCount < kMaxRecent; i++) {
        String name = r.str();
        if (!r.ok) break;
        s.recent[s.recentCount++] = name;
    }
    if (!r.ok && s.recentCount == 0 && s.species == 0) return;
    s.valid = true;
    s.updatedMs = millis();
    gState.session = s;
}

void ScopeLink::onPresence(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const IPAddress ip = r.ip();
    PresenceInfo p;
    p.distanceCm = r.f32();
    p.speedCmPerSec = r.u16();
    p.movement = r.u8();
    p.targetState = r.u8();
    p.nodeMode = r.u8();
    const uint8_t flags = r.u8();
    const String name = r.str();
    if (!r.ok) return;
    p.sensorOffline = flags & 0x01;
    p.valid = true;
    p.updatedMs = millis();

    int idx = gState.fleetIndex(ip);
    if (idx < 0 && gState.fleetCount < kMaxFleetNodes) {
        idx = gState.fleetCount++;
        gState.fleet[idx] = FleetNode();
        gState.fleet[idx].ip = ip;
        gState.fleet[idx].name = name;
        gState.fleet[idx].flags = Protocol::kFleetConnected | Protocol::kFleetHasPresence | Protocol::kFleetHasSpeaker;
        gState.fleetVersion++;
    }
    if (idx < 0) return;
    p.lastAlertMs = gState.fleet[idx].presence.lastAlertMs;
    if (flags & 0x02) p.lastAlertMs = millis();
    gState.fleet[idx].presence = p;
    gState.presenceVersion++;
}

void ScopeLink::onTargetList(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t seq = r.u16();
    const uint8_t chunkIndex = r.u8();
    const uint8_t chunkCount = r.u8();
    const uint16_t total = r.u16();
    const uint16_t seen = r.u16();
    const uint16_t firstIndex = r.u16();
    const String tripName = r.str();
    const String stopName = r.str();
    const uint8_t count = r.u8();
    if (!r.ok || chunkCount == 0 || chunkCount > 32 || chunkIndex >= chunkCount) return;
    // The periodic resend of a list that's already showing changes nothing.
    if (targetHaveCommitted_ && seq == targetCommittedSeq_) return;

    if (seq != targetStagingSeq_ || chunkCount != targetStagingChunks_ || !targetStagingSeen_) {
        targetStaging_.count = 0;
        targetStagingSeq_ = seq;
        targetStagingChunks_ = chunkCount;
        targetStagingSeen_ = 0;
    }
    targetStaging_.tripName = tripName;
    targetStaging_.stopName = stopName;
    targetStaging_.total = total;
    targetStaging_.seen = seen;
    for (int i = 0; i < count; i++) {
        const uint8_t flags = r.u8();
        String name = r.str();
        if (!r.ok) return;
        const int at = firstIndex + i;
        if (at >= kMaxTripTargets) continue;
        targetStaging_.items[at].name = name;
        targetStaging_.items[at].flags = flags;
        if (at + 1 > targetStaging_.count) targetStaging_.count = at + 1;
    }
    targetStagingSeen_ |= 1UL << chunkIndex;
    const uint32_t all = chunkCount == 32 ? 0xFFFFFFFFUL : ((1UL << chunkCount) - 1);
    if (targetStagingSeen_ != all) return;

    targetStaging_.valid = true;
    gState.tripTargets = targetStaging_;
    applyOutboxToList();
    gState.tripTargetsVersion++;
    gStore.saveTargetList();
    targetCommittedSeq_ = seq;
    targetHaveCommitted_ = true;
    targetStagingSeen_ = 0;
}

// ---- Outbox: checks / new locations, delivered in order, survive power-off ----

void ScopeLink::loadOutbox() {
    Preferences p;
    p.begin("outbox", true);
    nextSeq_ = p.getUShort("seq", 1);
    const size_t bytes = p.getBytesLength("q");
    outboxCount_ = 0;
    if (bytes && bytes % sizeof(OutboxEntry) == 0 && bytes <= sizeof(outbox_)) {
        p.getBytes("q", outbox_, bytes);
        outboxCount_ = bytes / sizeof(OutboxEntry);
    }
    p.end();
    gState.outboxPending = outboxCount_;
    if (outboxCount_) Serial.printf("[outbox] %d change(s) waiting for the phone\n", outboxCount_);
}

void ScopeLink::saveOutbox() {
    Preferences p;
    p.begin("outbox", false);
    p.putUShort("seq", nextSeq_);
    if (outboxCount_) p.putBytes("q", outbox_, sizeof(OutboxEntry) * outboxCount_);
    else p.remove("q");
    p.end();
    gState.outboxPending = outboxCount_;
}

void ScopeLink::enqueue(uint8_t kind, const String &name, bool seen) {
    // A second tap on the same bird (no new location in between) replaces the first, unless the
    // first is already on its way -- then both go, in order.
    if (kind == 0) {
        for (int i = outboxCount_ - 1; i >= 1; i--) {
            if (outbox_[i].kind == 1) break;
            if (outbox_[i].kind == 0 && name.equals(outbox_[i].name)) {
                outbox_[i].seen = seen;
                saveOutbox();
                return;
            }
        }
    }
    if (outboxCount_ >= kOutboxMax) { // full: drop the oldest (it's been waiting longest)
        memmove(&outbox_[0], &outbox_[1], sizeof(OutboxEntry) * (kOutboxMax - 1));
        outboxCount_--;
    }
    OutboxEntry &e = outbox_[outboxCount_++];
    e.seq = nextSeq_++;
    if (nextSeq_ == 0) nextSeq_ = 1;
    e.kind = kind;
    e.seen = seen ? 1 : 0;
    strlcpy(e.name, name.c_str(), sizeof(e.name));
    saveOutbox();
    if (outboxCount_ == 1) lastOutboxSendMs_ = 0; // send now if linked
}

void ScopeLink::sendTargetToggle(const String &name, bool seen) {
    enqueue(0, name, seen);
    gStore.logEvent(seen ? "seen" : "unchecked", name);
}

void ScopeLink::sendNewLocation() {
    enqueue(1, String(), false);
    applyNewLocationLocally(gState.tripTargets);
    gState.tripTargetsVersion++;
    gStore.logEvent("new-location", String());
}

void ScopeLink::sendOutboxHead() {
    if (!outboxCount_ || appPort_ == 0) return;
    const OutboxEntry &e = outbox_[0];
    if (e.kind == 1) {
        uint8_t pkt[7] = {Protocol::kVersion, Protocol::kScopeCommand, Protocol::kCmdNewLocation,
                          (uint8_t)(e.seq & 0xFF), (uint8_t)(e.seq >> 8), 0, 0};
        sendTo(pkt, sizeof(pkt), appIP_, appPort_);
        return;
    }
    uint8_t pkt[3 + 1 + 48 + 2];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeTargetToggle;
    pkt[n++] = e.seen;
    const size_t l = strnlen(e.name, 48);
    pkt[n++] = (uint8_t)l;
    memcpy(pkt + n, e.name, l);
    n += l;
    putU16(pkt + n, e.seq); n += 2;
    sendTo(pkt, n, appIP_, appPort_);
}

void ScopeLink::pollOutbox(uint32_t nowMs) {
    if (!outboxCount_ || appPort_ == 0 || !gState.appLinked(nowMs, Config::kAppLinkTimeoutMs)) return;
    if (lastOutboxSendMs_ && nowMs - lastOutboxSendMs_ < 1000) return; // resend the head every 1 s until acked
    lastOutboxSendMs_ = nowMs;
    sendOutboxHead();
}

void ScopeLink::onAck(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t seq = r.u16();
    if (!r.ok) return;
    for (int i = 0; i < outboxCount_; i++) {
        if (outbox_[i].seq != seq) continue;
        memmove(&outbox_[i], &outbox_[i + 1], sizeof(OutboxEntry) * (outboxCount_ - i - 1));
        outboxCount_--;
        saveOutbox();
        lastOutboxSendMs_ = 0;
        sendOutboxHead(); // next one right away
        // Take the app's next list even if its seq is one we've shown (it now reflects this change).
        targetHaveCommitted_ = false;
        return;
    }
}

void ScopeLink::applyNewLocationLocally(TripTargetList &list) {
    list.stopName = "New location (waiting for the phone)";
    list.seen = 0;
    for (int i = 0; i < list.count; i++) {
        TripTarget &t = list.items[i];
        if (t.flags & Protocol::kTripTargetHeading) { t.flags &= ~Protocol::kTripTargetCurrentHeading; continue; }
        if (t.flags & Protocol::kTripTargetSeen) t.flags |= Protocol::kTripTargetSeenEarlier;
        t.flags &= ~(Protocol::kTripTargetSeen | Protocol::kTripTargetHere);
    }
}

void ScopeLink::applyOutboxToList() {
    TripTargetList &list = gState.tripTargets;
    for (int k = 0; k < outboxCount_; k++) {
        const OutboxEntry &e = outbox_[k];
        if (e.kind == 1) { applyNewLocationLocally(list); continue; }
        for (int i = 0; i < list.count; i++) {
            TripTarget &t = list.items[i];
            if ((t.flags & Protocol::kTripTargetHeading) || !t.name.equals(e.name)) continue;
            const bool was = t.flags & Protocol::kTripTargetSeen;
            if (e.seen && !was) { t.flags |= Protocol::kTripTargetSeen; list.seen++; }
            if (!e.seen && was) { t.flags &= ~Protocol::kTripTargetSeen; if (list.seen) list.seen--; }
        }
    }
}

// ---- Card downloads + trip history ----

void ScopeLink::onPrefetchList(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    r.u16(); // listId -- entries are merged into the queue, so repeats are harmless
    const uint8_t chunkIndex = r.u8();
    r.u8();
    if (chunkIndex == 0) gState.cardsFailed = 0; // a new "Load" -- count failures afresh
    const uint8_t count = r.u8();
    for (int i = 0; i < count; i++) {
        const String common = r.str();
        const String scientific = r.str();
        if (!r.ok) return;
        gStore.enqueueCard(common, scientific);
    }
    Serial.printf("[sd] card list received: %u species, %u now queued\n", count, gState.cardsQueued);
}

void ScopeLink::onTripHistory(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t seq = r.u16();
    const uint8_t chunkIndex = r.u8();
    const uint8_t chunkCount = r.u8();
    const uint32_t unixTime = r.u32();
    const uint16_t firstIndex = r.u16();
    const uint8_t count = r.u8();
    if (!r.ok || chunkCount == 0 || chunkCount > 32 || chunkIndex >= chunkCount) return;
    if (unixTime) {
        gState.phoneUnix = unixTime;
        gState.phoneUnixAtMs = millis();
    }
    if (historyHaveCommitted_ && seq == historyCommittedSeq_) return;
    if (seq != historyStagingSeq_ || chunkCount != historyStagingChunks_ || !historyStagingSeen_) {
        historyStaging_.count = 0;
        historyStagingSeq_ = seq;
        historyStagingChunks_ = chunkCount;
        historyStagingSeen_ = 0;
    }
    for (int i = 0; i < count; i++) {
        const uint8_t kind = r.u8();
        const uint8_t flags = r.u8();
        String name = r.str();
        if (!r.ok) return;
        const int at = firstIndex + i;
        if (at >= kMaxHistoryEntries) continue;
        historyStaging_.items[at].kind = kind;
        historyStaging_.items[at].flags = flags;
        historyStaging_.items[at].name = name;
        if (at + 1 > historyStaging_.count) historyStaging_.count = at + 1;
    }
    historyStagingSeen_ |= 1UL << chunkIndex;
    const uint32_t all = chunkCount == 32 ? 0xFFFFFFFFUL : ((1UL << chunkCount) - 1);
    if (historyStagingSeen_ != all) return;
    historyStaging_.valid = true;
    gState.tripHistory = historyStaging_;
    gState.tripHistoryVersion++;
    historyCommittedSeq_ = seq;
    historyHaveCommitted_ = true;
    historyStagingSeen_ = 0;
    gStore.saveHistory();
}

void ScopeLink::sendCardStatus() {
    uint8_t pkt[2 + 1 + 2 + 2 + 4 + 1 + 2];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeCardStatus;
    pkt[n++] = gState.sdPresent ? 1 : 0;
    putU16(pkt + n, gState.cardsStored); n += 2;
    putU16(pkt + n, gState.cardsQueued); n += 2;
    const uint32_t mb = gState.sdFreeMB;
    pkt[n++] = mb & 0xFF; pkt[n++] = (mb >> 8) & 0xFF; pkt[n++] = (mb >> 16) & 0xFF; pkt[n++] = mb >> 24;
    pkt[n++] = (uint8_t)min(outboxCount_, 255);
    putU16(pkt + n, gState.cardsFailed); n += 2;
    sendTo(pkt, n, appIP_, appPort_);
}

void ScopeLink::sendCommand(uint8_t command, const IPAddress &ip) {
    if (appPort_ == 0) return;
    uint8_t pkt[7] = {Protocol::kVersion, Protocol::kScopeCommand, command, ip[0], ip[1], ip[2], ip[3]};
    sendTo(pkt, sizeof(pkt), appIP_, appPort_);
}
