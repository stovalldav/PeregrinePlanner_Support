#include "ScopeLink.h"
#include "ScopeStorage.h"
#include <Preferences.h>
#include "Config.h"
#include "NetworkProtocol.h"
#include "ScopeProtocol.h"
#include "ScopeState.h"
#include "ScopeBLE.h"
#include "TalkAudio.h"

ScopeLink gLink;

namespace {

constexpr size_t kMaxCardBytes = 256 * Protocol::kScopeCardChunkBytes; // ~225 KB

// Little-endian reader over one packet, bounds-checked: a short/malformed packet reads as zeros
// and `ok` goes false, so parsers never walk past the end.
struct Reader {
    const uint8_t *d;
    int len;
    int pos;
    bool ok = true;
    Reader(const uint8_t *data, int n, int start) : d(data), len(n), pos(start) {}
    bool need(int n) { if (pos + n > len) { ok = false; return false; } return true; }
    uint8_t u8() { if (!need(1)) return 0; return d[pos++]; }
    uint16_t u16() { if (!need(2)) return 0; uint16_t v = d[pos] | (d[pos + 1] << 8); pos += 2; return v; }
    uint32_t u32() {
        if (!need(4)) return 0;
        uint32_t v = (uint32_t)d[pos] | ((uint32_t)d[pos + 1] << 8) | ((uint32_t)d[pos + 2] << 16) | ((uint32_t)d[pos + 3] << 24);
        pos += 4;
        return v;
    }
    float f32() { uint32_t bits = u32(); float f; memcpy(&f, &bits, 4); return f; }
    String str() {
        uint8_t n = u8();
        if (!need(n)) return String();
        String s;
        s.reserve(n);
        for (int i = 0; i < n; i++) s += (char)d[pos + i];
        pos += n;
        return s;
    }
    IPAddress ip() { uint8_t a = u8(), b = u8(), c = u8(), e = u8(); return IPAddress(a, b, c, e); }
};

void putU16(uint8_t *p, uint16_t v) { p[0] = v & 0xFF; p[1] = v >> 8; }

} // namespace

void ScopeLink::begin() {
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    connectWiFi(millis());
}

void ScopeLink::connectWiFi(uint32_t nowMs) {
    constexpr int count = sizeof(Config::kWiFiCandidates) / sizeof(Config::kWiFiCandidates[0]);
    wifiCandidate_ = (wifiCandidate_ + 1) % count;
    const auto &c = Config::kWiFiCandidates[wifiCandidate_];
    Serial.printf("[wifi] trying %d/%d: %s\n", wifiCandidate_ + 1, count, c.ssid);
    WiFi.disconnect();
    WiFi.begin(c.ssid, c.password);
    wifiAttemptStartMs_ = nowMs;
}

void ScopeLink::poll(uint32_t nowMs) {
    // Wi-Fi: non-blocking walk through the candidates until one sticks.
    const bool connected = WiFi.status() == WL_CONNECTED;
    if (connected && !wifiWasConnected_) {
        Serial.printf("[wifi] joined %s, IP %s\n", WiFi.SSID().c_str(), WiFi.localIP().toString().c_str());
        gState.ssid = WiFi.SSID();
        gState.myIP = WiFi.localIP();
        if (!udpStarted_) udpStarted_ = udp_.begin(Config::kUDPPort);
    } else if (!connected && wifiWasConnected_) {
        Serial.println("[wifi] lost connection");
        wifiAttemptStartMs_ = nowMs;
    }
    wifiWasConnected_ = connected;
    gState.wifiConnected = connected;
    if (!connected && nowMs - wifiAttemptStartMs_ > Config::kWiFiPerCandidateTimeoutMs) {
        connectWiFi(nowMs);
    }
    if (!connected || !udpStarted_) return;

    // Receive everything waiting (bounded so a flood can't starve the UI).
    static uint8_t buf[1500];
    for (int i = 0; i < 24; i++) {
        xSemaphoreTakeRecursive(udpLock_, portMAX_DELAY);
        const int size = udp_.parsePacket();
        const int len = size > 0 ? udp_.read(buf, sizeof(buf)) : 0;
        const IPAddress fromIP = udp_.remoteIP();
        const uint16_t fromPort = udp_.remotePort();
        xSemaphoreGiveRecursive(udpLock_);
        if (size <= 0) break;
        if (len >= 2) handlePacket(buf, len, fromIP, fromPort);
    }
    logLinkStats(millis());
    pollOutbox(millis());
    pollMapResend();
    if (appPort_ != 0 && millis() - lastCardStatusMs_ >= 5000) {
        lastCardStatusMs_ = millis();
        sendCardStatus();
    }
    if (appPort_ != 0 && millis() - lastHeadingMs_ >= 1000) {
        lastHeadingMs_ = millis();
        sendHeading();
    }

    if (appPort_ != 0 && nowMs - lastIdentityMs_ >= Config::kIdentityIntervalMs) {
        sendIdentity();
        lastIdentityMs_ = nowMs;
    }
}

void ScopeLink::sendTo(const uint8_t *data, size_t len, const IPAddress &ip, uint16_t port) {
    xSemaphoreTakeRecursive(udpLock_, portMAX_DELAY);
    udp_.beginPacket(ip, port);
    udp_.write(data, len);
    udp_.endPacket();
    xSemaphoreGiveRecursive(udpLock_);
}

bool ScopeLink::sendToApp(const uint8_t *data, size_t len) {
    if (!udpStarted_ || appPort_ == 0) return false;
    xSemaphoreTakeRecursive(udpLock_, portMAX_DELAY);
    udp_.beginPacket(appIP_, appPort_);
    udp_.write(data, len);
    const bool ok = udp_.endPacket();
    xSemaphoreGiveRecursive(udpLock_);
    return ok;
}

void ScopeLink::sendIdentity() {
    if (appPort_ == 0) return;
    Protocol::NodeIdentityPacket p = {};
    p.version = Protocol::kVersion;
    p.type = Protocol::kNodeIdentity;
    p.nodeType = Protocol::kNodeTypeScopeDisplay;
    p.hasGPS = 0;
    p.hasCompass = gState.compassPresent ? 1 : 0;
    p.hasMotionSensor = 0;
    p.micCount = gState.micStreamEnabled ? 1 : 0; // one mic, no direction -- see §6.5
    p.fleetId = Config::kFleetId;
    fillDeviceId(p.deviceId); // same bytes as the BLE advertisement
    p.hasPresenceSensor = 0;
    p.hasSpeaker = 1;
    sendTo((const uint8_t *)&p, sizeof(p), appIP_, appPort_);
}

void ScopeLink::logLinkStats(uint32_t nowMs) {
    const bool linked = gState.appLinked(nowMs, Config::kAppLinkTimeoutMs);
    if (linked != wasLinked_) {
        Serial.printf("[link] app %s (last app packet %ld ms ago)\n", linked ? "LINKED" : "LOST",
                      (long)(gState.lastAppPacketMs ? (int32_t)(nowMs - gState.lastAppPacketMs) : 0));
        wasLinked_ = linked;
    }
    if (nowMs - lastStatMs_ < 10000) return;
    lastStatMs_ = nowMs;
    Serial.printf("[link-stat] wifi %s rssi %d ip %s | app %s:%u last %lu ms ago, max gap %lu ms | rx %lu (pings %lu, from app %lu) | "
                  "sleep %s | loop max %lu ms | heap %u | iphone %s, %lu notifications, %lu merlin | "
                  "mic %s%s, %lu frames sent, %lu short reads, peak %.4f\n",
                  WiFi.status() == WL_CONNECTED ? "up" : "DOWN", WiFi.RSSI(), WiFi.localIP().toString().c_str(),
                  appIP_.toString().c_str(), appPort_,
                  (unsigned long)(gState.lastAppPacketMs ? nowMs - gState.lastAppPacketMs : 0), (unsigned long)maxAppGapMs_,
                  (unsigned long)rxPackets_, (unsigned long)rxPings_, (unsigned long)rxFromApp_,
                  WiFi.getSleep() ? "modem" : "off", (unsigned long)gState.loopMaxMs, (unsigned)ESP.getFreeHeap(),
                  gState.ancsState == 3 ? "receiving" : gState.ancsState == 2 ? "secured" : gState.ancsState == 1 ? "connecting"
                  : gState.ancsState == 4 ? "NOT ALLOWED" : (gState.ancsPaired ? "paired, not connected" : "not paired"),
                  (unsigned long)gState.ancsCount, (unsigned long)gState.merlinCount,
                  gState.micStreamEnabled ? "on" : "OFF", gState.micStreamingNow ? " streaming" : "",
                  (unsigned long)gState.micFramesSent, (unsigned long)gState.micShortReads, gState.micPeak10s);
    gState.micFramesSent = gState.micShortReads = 0;
    gState.micPeak10s = 0;
    rxPackets_ = rxPings_ = rxFromApp_ = 0;
    maxAppGapMs_ = 0;
    gState.loopMaxMs = 0;
}

void ScopeLink::handlePacket(const uint8_t *data, int len, const IPAddress &from, uint16_t fromPort) {
    if (data[0] != Protocol::kVersion) return;
    const uint8_t type = data[1];
    rxPackets_++;
    if (type == Protocol::kHandshakePing) rxPings_++;
    if (from == appIP_ && fromPort == appPort_) {
        const uint32_t now = millis();
        if (lastAppSeenMs_ && now - lastAppSeenMs_ > maxAppGapMs_) maxAppGapMs_ = now - lastAppSeenMs_;
        lastAppSeenMs_ = now;
        rxFromApp_++;
        gState.lastAppPacketMs = now;
    }

    switch (type) {
        case Protocol::kHandshakePing: {
            Protocol::HandshakePongPacket pong = {Protocol::kVersion, Protocol::kHandshakePong, Protocol::kPongMagic0, Protocol::kPongMagic1};
            sendTo((const uint8_t *)&pong, sizeof(pong), from, fromPort);
            return;
        }
        case Protocol::kSessionStart: {
            const bool isNew = !(from == appIP_ && fromPort == appPort_);
            appIP_ = from;
            appPort_ = fromPort;
            gState.lastAppPacketMs = millis();
            if (isNew) {
                Serial.printf("[link] app at %s:%u\n", from.toString().c_str(), fromPort);
                sendIdentity();
                lastIdentityMs_ = millis();
                // Re-assert Camp mode after an app restart.
                if (gState.campMode) sendCommand(Protocol::kCmdCampModeOn);
            }
            return;
        }
        case Protocol::kSessionStop:
            if (from == appIP_ && fromPort == appPort_) appPort_ = 0;
            return;
        case Protocol::kScopeDetection:   onDetection(data, len); return;
        case Protocol::kScopeCardData:    onCardChunk(data, len); return;
        case Protocol::kScopeTargets:     onTargets(data, len); return;
        case Protocol::kScopeFleetStatus: onFleetStatus(data, len); return;
        case Protocol::kScopeNodeLive:    onNodeLive(data, len); return;
        case Protocol::kScopeSession:     onSession(data, len); return;
        case Protocol::kScopePresence:    onPresence(data, len); return;
        case Protocol::kScopeTargetList:  onTargetList(data, len); return;
        case Protocol::kScopeAck:         onAck(data, len); return;
        case Protocol::kScopePrefetchList: onPrefetchList(data, len); return;
        case Protocol::kScopeTripHistory: onTripHistory(data, len); return;
        case Protocol::kScopeTripPlans:   onTripPlans(data, len); return;
        case Protocol::kScopeMapData:     onMapChunk(data, len); return;
        case Protocol::kScopePhonePosition: onPhonePosition(data, len); return;
        case Protocol::kScopeSpeech:      onSpeech(data, len); return;
        default:
            return; // other fleet packets (Wi-Fi config requests etc.) aren't meaningful here
    }
}

// Adds a bird to the Heard list (newest first). The same species from the same source refreshes
// its row; Merlin's and ours stay separate rows so you can tell who heard what.
void addDetection(const Detection &incoming) {
    Detection det = incoming;
    int existing = -1;
    for (int i = 0; i < gState.detectionCount; i++) {
        if (gState.detections[i].common == det.common && gState.detections[i].source == det.source) { existing = i; break; }
    }
    if (existing >= 0) {
        det.hits = gState.detections[existing].hits + 1;
        det.newLifeBird = det.newLifeBird || gState.detections[existing].newLifeBird;
        if (det.confidencePct < gState.detections[existing].confidencePct) det.confidencePct = gState.detections[existing].confidencePct;
        if (det.scientific.isEmpty()) det.scientific = gState.detections[existing].scientific;
        for (int i = existing; i > 0; i--) gState.detections[i] = gState.detections[i - 1];
    } else {
        const int n = min(gState.detectionCount, kMaxDetections - 1);
        for (int i = n; i > 0; i--) gState.detections[i] = gState.detections[i - 1];
        gState.detectionCount = n + 1;
    }
    gState.detections[0] = det;
    gState.detectionsVersion++;
}

void ScopeLink::onDetection(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    Detection det;
    det.confidencePct = r.u8();
    const uint8_t flags = r.u8();
    det.trueBearingDeg = r.f32();
    det.common = r.str();
    det.scientific = r.str();
    det.nodeName = r.str();
    if (!r.ok || det.common.isEmpty()) return;
    if (!(flags & 0x01)) det.trueBearingDeg = NAN;
    det.newLifeBird = flags & 0x02;
    det.receivedMs = millis();
    det.source = 0;
    addDetection(det);
}

uint16_t ScopeLink::requestCard(const String &common, const String &scientific, bool prefetch) {
    if (appPort_ == 0) return 0;
    if (!cardBuffer_) cardBuffer_ = (uint8_t *)ps_malloc(kMaxCardBytes);
    if (!cardChunkSeen_) cardChunkSeen_ = (uint8_t *)ps_malloc(256);
    if (!cardBuffer_ || !cardChunkSeen_) return 0;
    cardRequestId_ = nextRequestId_++;
    if (nextRequestId_ == 0) nextRequestId_ = 1;
    cardChunkCount_ = 0;
    cardChunksReceived_ = 0;
    cardComplete_ = false;
    cardTaken_ = false;
    cardIsPrefetch_ = prefetch;
    cardRequestMs_ = millis();
    cardCommon_ = common;
    cardScientific_ = scientific;
    memset(cardChunkSeen_, 0, 256);

    uint8_t pkt[2 + 2 + 1 + 255 + 1 + 255];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeCardRequest;
    putU16(pkt + n, cardRequestId_); n += 2;
    for (const String *s : {&common, &scientific}) {
        const size_t l = min((size_t)255, (size_t)s->length());
        pkt[n++] = (uint8_t)l;
        memcpy(pkt + n, s->c_str(), l);
        n += l;
    }
    sendTo(pkt, n, appIP_, appPort_);
    return cardRequestId_;
}

void ScopeLink::onCardChunk(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t requestId = r.u16();
    const uint16_t index = r.u16();
    const uint16_t count = r.u16();
    if (!r.ok || requestId != cardRequestId_ || cardComplete_ || count == 0 || count > 256 || index >= count) return;
    cardChunkCount_ = count;
    const int payload = len - r.pos;
    if (payload <= 0 || payload > Protocol::kScopeCardChunkBytes) return;
    if (!cardChunkSeen_[index]) {
        memcpy(cardBuffer_ + (size_t)index * Protocol::kScopeCardChunkBytes, d + r.pos, payload);
        cardChunkSeen_[index] = 1;
        cardChunksReceived_++;
    }
    if (cardChunksReceived_ == cardChunkCount_) cardComplete_ = true;
}

bool ScopeLink::takePrefetchCard(String &common, const uint8_t *&payload, size_t &len) {
    if (!cardComplete_ || cardTaken_ || !cardIsPrefetch_) return false;
    cardTaken_ = true;
    common = cardCommon_;
    payload = cardBuffer_;
    len = (size_t)cardChunkCount_ * Protocol::kScopeCardChunkBytes;
    return true;
}

bool ScopeLink::takeCard(CardResult &out) {
    if (!cardComplete_ || cardTaken_ || cardIsPrefetch_) return false;
    cardTaken_ = true;
    Reader r(cardBuffer_, 8, 0);
    const uint32_t textLen = r.u32();
    const uint32_t jpegLen = r.u32();
    const size_t total = (size_t)cardChunkCount_ * Protocol::kScopeCardChunkBytes;
    if (8 + (size_t)textLen + jpegLen > total) return false;
    out.requestId = cardRequestId_;
    out.text = String((const char *)(cardBuffer_ + 8), textLen);
    out.jpeg = jpegLen ? cardBuffer_ + 8 + textLen : nullptr;
    out.jpegLen = jpegLen;
    gStore.saveCard(cardCommon_, cardBuffer_, total, cardScientific_); // next time it opens without the phone
    return true;
}

void ScopeLink::onTargets(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const float declination = r.f32();
    const uint16_t alignSeq = r.u16();
    const float alignTrue = r.f32();
    const uint8_t count = r.u8();
    if (!r.ok) return;
    gState.declinationDeg = declination;
    gState.declinationKnown = true;
    // Alignment: the user pointed the scope at something of known true bearing and tapped Align
    // in the app. Applied once per new sequence number (the app repeats it in every packet).
    if (alignSeq != 0 && alignSeq != gState.lastAlignSeq && !isnan(alignTrue) && !isnan(gState.scopeMagAzimuthDeg)) {
        gState.lastAlignSeq = alignSeq;
        float offset = alignTrue - (gState.scopeMagAzimuthDeg + declination);
        offset = fmodf(offset + 540.0f, 360.0f) - 180.0f;
        gState.alignmentOffsetDeg = offset;
        extern void saveAlignment(float, uint16_t);
        saveAlignment(offset, alignSeq);
        Serial.printf("[scope] aligned: offset %.1f deg (true %.1f, mag %.1f, decl %.1f)\n", offset, alignTrue, gState.scopeMagAzimuthDeg, declination);
    }
    int n = 0;
    for (int i = 0; i < count && n < kMaxTargets; i++) {
        Target t;
        t.slot = r.u8();
        t.trueAzimuthDeg = r.f32();
        t.elevationDeg = r.f32();
        t.sigmaDeg = r.f32();
        t.distanceM = r.f32();
        t.name = r.str();
        if (!r.ok) break;
        gState.targets[n++] = t;
    }
    gState.targetCount = n;
    gState.targetsUpdatedMs = millis();
}

void ScopeLink::onFleetStatus(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint8_t count = r.u8();
    FleetNode incoming[kMaxFleetNodes];
    int n = 0;
    for (int i = 0; i < count && n < kMaxFleetNodes; i++) {
        FleetNode f;
        f.ip = r.ip();
        f.nodeType = r.u8();
        f.flags = r.u8();
        f.sats = r.u8();
        f.compassCal = r.u8();
        f.lastHeardS = r.u16();
        f.presenceModel = r.u8();
        f.name = r.str();
        if (!r.ok) break;
        const int old = gState.fleetIndex(f.ip);
        if (old >= 0) f.presence = gState.fleet[old].presence; // keep relayed presence
        incoming[n++] = f;
    }
    if (!r.ok && n == 0) return;
    for (int i = 0; i < n; i++) gState.fleet[i] = incoming[i];
    gState.fleetCount = n;
    gState.fleetVersion++;
}

void ScopeLink::onNodeLive(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    NodeLive l;
    l.ip = r.ip();
    l.azimuthDeg = r.f32();
    l.confidence = r.f32();
    l.level = r.f32();
    l.headingDeg = r.f32();
    l.compassCal = r.u8();
    l.gpsFix = r.u8();
    l.sats = r.u8();
    if (!r.ok) return;
    l.valid = true;
    l.updatedMs = millis();
    // A new reading, not the phone repeating the last one.
    if (!isnan(l.azimuthDeg) && (!(l.azimuthDeg == gState.live.azimuthDeg) || !(l.confidence == gState.live.confidence))) {
        gState.liveHistory.push(l.updatedMs, l.azimuthDeg, l.confidence);
    }
    gState.live = l;
}

void ScopeLink::onSession(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    SessionInfo s;
    s.active = r.u8();
    s.elapsedS = r.u32();
    s.species = r.u16();
    s.detections10min = r.u16();
    s.newLifeBirds = r.u16();
    const uint8_t count = r.u8();
    for (int i = 0; i < count && s.recentCount < kMaxRecent; i++) {
        String name = r.str();
        if (!r.ok) break;
        s.recent[s.recentCount++] = name;
    }
    if (!r.ok && s.recentCount == 0 && s.species == 0) return;
    s.valid = true;
    s.updatedMs = millis();
    gState.session = s;
}

void ScopeLink::onPresence(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const IPAddress ip = r.ip();
    PresenceInfo p;
    p.distanceCm = r.f32();
    p.speedCmPerSec = r.u16();
    p.movement = r.u8();
    p.targetState = r.u8();
    p.nodeMode = r.u8();
    const uint8_t flags = r.u8();
    const String name = r.str();
    if (!r.ok) return;
    p.sensorOffline = flags & 0x01;
    p.valid = true;
    p.updatedMs = millis();

    int idx = gState.fleetIndex(ip);
    if (idx < 0 && gState.fleetCount < kMaxFleetNodes) {
        idx = gState.fleetCount++;
        gState.fleet[idx] = FleetNode();
        gState.fleet[idx].ip = ip;
        gState.fleet[idx].name = name;
        gState.fleet[idx].flags = Protocol::kFleetConnected | Protocol::kFleetHasPresence | Protocol::kFleetHasSpeaker;
        gState.fleetVersion++;
    }
    if (idx < 0) return;
    p.lastAlertMs = gState.fleet[idx].presence.lastAlertMs;
    if (flags & 0x02) p.lastAlertMs = millis();
    gState.fleet[idx].presence = p;
    gState.presenceVersion++;
}

void ScopeLink::onTargetList(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t seq = r.u16();
    const uint8_t chunkIndex = r.u8();
    const uint8_t chunkCount = r.u8();
    const uint16_t total = r.u16();
    const uint16_t seen = r.u16();
    const uint16_t firstIndex = r.u16();
    const String tripName = r.str();
    const String stopName = r.str();
    const uint8_t count = r.u8();
    if (!r.ok || chunkCount == 0 || chunkCount > 32 || chunkIndex >= chunkCount) return;
    // The periodic resend of a list that's already showing changes nothing.
    if (targetHaveCommitted_ && seq == targetCommittedSeq_) return;

    if (seq != targetStagingSeq_ || chunkCount != targetStagingChunks_ || !targetStagingSeen_) {
        targetStaging_.count = 0;
        targetStagingSeq_ = seq;
        targetStagingChunks_ = chunkCount;
        targetStagingSeen_ = 0;
    }
    targetStaging_.tripName = tripName;
    targetStaging_.stopName = stopName;
    targetStaging_.total = total;
    targetStaging_.seen = seen;
    for (int i = 0; i < count; i++) {
        const uint8_t flags = r.u8();
        String name = r.str();
        if (!r.ok) return;
        const int at = firstIndex + i;
        if (at >= kMaxTripTargets) continue;
        targetStaging_.items[at].name = name;
        targetStaging_.items[at].flags = flags;
        if (at + 1 > targetStaging_.count) targetStaging_.count = at + 1;
    }
    targetStagingSeen_ |= 1UL << chunkIndex;
    const uint32_t all = chunkCount == 32 ? 0xFFFFFFFFUL : ((1UL << chunkCount) - 1);
    if (targetStagingSeen_ != all) return;

    targetStaging_.valid = true;
    gState.tripTargets = targetStaging_;
    applyOutboxToList();
    gState.tripTargetsVersion++;
    gStore.saveTargetList();
    targetCommittedSeq_ = seq;
    targetHaveCommitted_ = true;
    targetStagingSeen_ = 0;
}

// ---- Outbox: checks / new locations, delivered in order, survive power-off ----

void ScopeLink::loadOutbox() {
    Preferences p;
    p.begin("outbox", true);
    nextSeq_ = p.getUShort("seq", 1);
    const size_t bytes = p.getBytesLength("q");
    outboxCount_ = 0;
    if (bytes && bytes % sizeof(OutboxEntry) == 0 && bytes <= sizeof(outbox_)) {
        p.getBytes("q", outbox_, bytes);
        outboxCount_ = bytes / sizeof(OutboxEntry);
    }
    p.end();
    gState.outboxPending = outboxCount_;
    if (outboxCount_) Serial.printf("[outbox] %d change(s) waiting for the phone\n", outboxCount_);
}

void ScopeLink::saveOutbox() {
    Preferences p;
    p.begin("outbox", false);
    p.putUShort("seq", nextSeq_);
    if (outboxCount_) p.putBytes("q", outbox_, sizeof(OutboxEntry) * outboxCount_);
    else p.remove("q");
    p.end();
    gState.outboxPending = outboxCount_;
}

void ScopeLink::enqueue(uint8_t kind, const String &name, bool seen) {
    // A second tap on the same bird (no new location in between) replaces the first, unless the
    // first is already on its way -- then both go, in order.
    if (kind == 0) {
        for (int i = outboxCount_ - 1; i >= 1; i--) {
            if (outbox_[i].kind == 1) break;
            if (outbox_[i].kind == 0 && name.equals(outbox_[i].name)) {
                outbox_[i].seen = seen;
                saveOutbox();
                return;
            }
        }
    }
    if (outboxCount_ >= kOutboxMax) { // full: drop the oldest (it's been waiting longest)
        memmove(&outbox_[0], &outbox_[1], sizeof(OutboxEntry) * (kOutboxMax - 1));
        outboxCount_--;
    }
    OutboxEntry &e = outbox_[outboxCount_++];
    e.seq = nextSeq_++;
    if (nextSeq_ == 0) nextSeq_ = 1;
    e.kind = kind;
    e.seen = seen ? 1 : 0;
    strlcpy(e.name, name.c_str(), sizeof(e.name));
    saveOutbox();
    if (outboxCount_ == 1) lastOutboxSendMs_ = 0; // send now if linked
}

void ScopeLink::sendTargetToggle(const String &name, bool seen) {
    enqueue(0, name, seen);
    gStore.logEvent(seen ? "seen" : "unchecked", name);
}

void ScopeLink::sendNewLocation() {
    enqueue(1, String(), false);
    applyNewLocationLocally(gState.tripTargets);
    gState.tripTargetsVersion++;
    gStore.logEvent("new-location", String());
}

void ScopeLink::sendOutboxHead() {
    if (!outboxCount_ || appPort_ == 0) return;
    const OutboxEntry &e = outbox_[0];
    if (e.kind >= 2 && e.kind <= 5) {
        uint8_t pkt[2 + 1 + 1 + 48 + 2];
        size_t n = 0;
        pkt[n++] = Protocol::kVersion;
        pkt[n++] = Protocol::kScopeTripCommand;
        static const uint8_t ops[] = {Protocol::kTripOpStart, Protocol::kTripOpArrive, Protocol::kTripOpMapsOn, Protocol::kTripOpMapsOff};
        pkt[n++] = ops[e.kind - 2];
        const size_t l = strnlen(e.name, 48);
        pkt[n++] = (uint8_t)l;
        memcpy(pkt + n, e.name, l);
        n += l;
        putU16(pkt + n, e.seq); n += 2;
        sendTo(pkt, n, appIP_, appPort_);
        return;
    }
    if (e.kind == 1) {
        uint8_t pkt[7] = {Protocol::kVersion, Protocol::kScopeCommand, Protocol::kCmdNewLocation,
                          (uint8_t)(e.seq & 0xFF), (uint8_t)(e.seq >> 8), 0, 0};
        sendTo(pkt, sizeof(pkt), appIP_, appPort_);
        return;
    }
    uint8_t pkt[3 + 1 + 48 + 2];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeTargetToggle;
    pkt[n++] = e.seen;
    const size_t l = strnlen(e.name, 48);
    pkt[n++] = (uint8_t)l;
    memcpy(pkt + n, e.name, l);
    n += l;
    putU16(pkt + n, e.seq); n += 2;
    sendTo(pkt, n, appIP_, appPort_);
}

void ScopeLink::pollOutbox(uint32_t nowMs) {
    if (!outboxCount_ || appPort_ == 0 || !gState.appLinked(nowMs, Config::kAppLinkTimeoutMs)) return;
    if (lastOutboxSendMs_ && nowMs - lastOutboxSendMs_ < 1000) return; // resend the head every 1 s until acked
    lastOutboxSendMs_ = nowMs;
    sendOutboxHead();
}

void ScopeLink::onAck(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t seq = r.u16();
    if (!r.ok) return;
    for (int i = 0; i < outboxCount_; i++) {
        if (outbox_[i].seq != seq) continue;
        memmove(&outbox_[i], &outbox_[i + 1], sizeof(OutboxEntry) * (outboxCount_ - i - 1));
        outboxCount_--;
        saveOutbox();
        lastOutboxSendMs_ = 0;
        sendOutboxHead(); // next one right away
        // Take the app's next lists even if their seq is one we've shown (they now reflect this change).
        targetHaveCommitted_ = false;
        planHaveCommitted_ = false;
        return;
    }
}

void ScopeLink::sendStartTrip(const char *tripId) {
    enqueue(2, String(tripId), false);
    applyTripCommandLocally(2, tripId);
    gState.plansVersion++;
    gStore.logEvent("start-trip", String(tripId));
}

void ScopeLink::sendTripMaps(const char *tripId, bool on) {
    enqueue(on ? 4 : 5, String(tripId), false);
    applyTripCommandLocally(on ? 4 : 5, tripId);
    gState.plansVersion++;
}

void ScopeLink::sendArriveAt(const char *stopId) {
    enqueue(3, String(stopId), false);
    applyTripCommandLocally(3, stopId);
    gState.plansVersion++;
    gStore.logEvent("arrive", String(stopId));
}

// What the app will do, shown before it confirms: the trip becomes the one being logged (and
// started); for an arrival, that stop becomes the current one.
void ScopeLink::applyTripCommandLocally(uint8_t kind, const char *id) {
    TripPlans &plans = gState.plans;
    if (!plans.items) return;
    if (kind == 4 || kind == 5) { // maps on / off: just the trip's flag (the phone sends the stamps)
        for (int i = 0; i < plans.count; i++) {
            PlanEntry &e = plans.items[i];
            if (e.kind != 0 || strcmp(e.id, id) != 0) continue;
            if (kind == 4) e.flags |= Protocol::kPlanTripMaps;
            else e.flags &= ~Protocol::kPlanTripMaps;
        }
        return;
    }
    int trip = -1, stop = -1, owner = -1; // owner = the trip the entries being walked belong to
    for (int i = 0; i < plans.count && trip < 0; i++) {
        const PlanEntry &e = plans.items[i];
        if (e.kind == 0) owner = i;
        if (strcmp(e.id, id) != 0) continue;
        if (kind == 2 && e.kind == 0) trip = i;
        if (kind == 3 && e.kind == 1) { stop = i; trip = owner; }
    }
    if (trip < 0) return;
    for (int i = 0; i < plans.count; i++) {
        PlanEntry &e = plans.items[i];
        if (e.kind == 0) e.flags &= ~Protocol::kPlanTripActive;
        else if (stop >= 0) e.flags &= ~Protocol::kPlanStopCurrent;
    }
    plans.items[trip].flags |= Protocol::kPlanTripActive | Protocol::kPlanTripStarted;
    if (stop >= 0) plans.items[stop].flags |= Protocol::kPlanStopCurrent;
}

void ScopeLink::applyOutboxToPlans() {
    for (int k = 0; k < outboxCount_; k++) {
        if (outbox_[k].kind >= 2 && outbox_[k].kind <= 5) applyTripCommandLocally(outbox_[k].kind, outbox_[k].name);
    }
}

void ScopeLink::applyNewLocationLocally(TripTargetList &list) {
    list.stopName = "New location (waiting for the phone)";
    list.seen = 0;
    for (int i = 0; i < list.count; i++) {
        TripTarget &t = list.items[i];
        if (t.flags & Protocol::kTripTargetHeading) { t.flags &= ~Protocol::kTripTargetCurrentHeading; continue; }
        if (t.flags & Protocol::kTripTargetSeen) t.flags |= Protocol::kTripTargetSeenEarlier;
        t.flags &= ~(Protocol::kTripTargetSeen | Protocol::kTripTargetHere);
    }
}

void ScopeLink::applyOutboxToList() {
    TripTargetList &list = gState.tripTargets;
    for (int k = 0; k < outboxCount_; k++) {
        const OutboxEntry &e = outbox_[k];
        if (e.kind == 1) { applyNewLocationLocally(list); continue; }
        if (e.kind != 0) continue; // trip commands -- see applyOutboxToPlans
        for (int i = 0; i < list.count; i++) {
            TripTarget &t = list.items[i];
            if ((t.flags & Protocol::kTripTargetHeading) || !t.name.equals(e.name)) continue;
            const bool was = t.flags & Protocol::kTripTargetSeen;
            if (e.seen && !was) { t.flags |= Protocol::kTripTargetSeen; list.seen++; }
            if (!e.seen && was) { t.flags &= ~Protocol::kTripTargetSeen; if (list.seen) list.seen--; }
        }
    }
}

// ---- Card downloads + trip history ----

void ScopeLink::onPrefetchList(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    r.u16(); // listId -- entries are merged into the queue, so repeats are harmless
    const uint8_t chunkIndex = r.u8();
    r.u8();
    if (chunkIndex == 0) gState.cardsFailed = 0; // a new "Load" -- count failures afresh
    const uint8_t count = r.u8();
    for (int i = 0; i < count; i++) {
        const String common = r.str();
        const String scientific = r.str();
        if (!r.ok) return;
        gStore.enqueueCard(common, scientific);
    }
    Serial.printf("[sd] card list received: %u species, %u now queued\n", count, gState.cardsQueued);
}

void ScopeLink::onTripHistory(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t seq = r.u16();
    const uint8_t chunkIndex = r.u8();
    const uint8_t chunkCount = r.u8();
    const uint32_t unixTime = r.u32();
    const uint16_t firstIndex = r.u16();
    const uint8_t count = r.u8();
    if (!r.ok || chunkCount == 0 || chunkCount > 32 || chunkIndex >= chunkCount) return;
    if (unixTime) {
        gState.phoneUnix = unixTime;
        gState.phoneUnixAtMs = millis();
    }
    if (historyHaveCommitted_ && seq == historyCommittedSeq_) return;
    if (seq != historyStagingSeq_ || chunkCount != historyStagingChunks_ || !historyStagingSeen_) {
        historyStaging_.count = 0;
        historyStagingSeq_ = seq;
        historyStagingChunks_ = chunkCount;
        historyStagingSeen_ = 0;
    }
    for (int i = 0; i < count; i++) {
        const uint8_t kind = r.u8();
        const uint8_t flags = r.u8();
        String name = r.str();
        if (!r.ok) return;
        const int at = firstIndex + i;
        if (at >= kMaxHistoryEntries) continue;
        historyStaging_.items[at].kind = kind;
        historyStaging_.items[at].flags = flags;
        historyStaging_.items[at].name = name;
        if (at + 1 > historyStaging_.count) historyStaging_.count = at + 1;
    }
    historyStagingSeen_ |= 1UL << chunkIndex;
    const uint32_t all = chunkCount == 32 ? 0xFFFFFFFFUL : ((1UL << chunkCount) - 1);
    if (historyStagingSeen_ != all) return;
    historyStaging_.valid = true;
    gState.tripHistory = historyStaging_;
    gState.tripHistoryVersion++;
    historyCommittedSeq_ = seq;
    historyHaveCommitted_ = true;
    historyStagingSeen_ = 0;
    gStore.saveHistory();
}

// ---- Trip plans, stop maps, phone position ----

void ScopeLink::onTripPlans(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t seq = r.u16();
    const uint8_t chunkIndex = r.u8();
    const uint8_t chunkCount = r.u8();
    const uint16_t firstIndex = r.u16();
    const uint8_t count = r.u8();
    if (!r.ok || chunkCount == 0 || chunkCount > 32 || chunkIndex >= chunkCount) return;
    if (planHaveCommitted_ && seq == planCommittedSeq_) return;
    if (!planStaging_.items) planStaging_.items = (PlanEntry *)ps_calloc(kMaxPlanEntries, sizeof(PlanEntry));
    if (!planStaging_.items || !gState.plans.items) return;
    if (seq != planStagingSeq_ || chunkCount != planStagingChunks_ || !planStagingSeen_) {
        planStaging_.count = 0;
        planStagingSeq_ = seq;
        planStagingChunks_ = chunkCount;
        planStagingSeen_ = 0;
    }
    for (int i = 0; i < count; i++) {
        PlanEntry e = {};
        e.kind = r.u8();
        e.flags = r.u8();
        strlcpy(e.id, r.str().c_str(), sizeof(e.id));
        strlcpy(e.name, r.str().c_str(), sizeof(e.name));
        e.latE6 = e.lonE6 = INT32_MIN;
        if (e.kind == 1) {
            e.latE6 = (int32_t)r.u32();
            e.lonE6 = (int32_t)r.u32();
            e.stamp[0] = r.u32();
            e.stamp[1] = r.u32();
        }
        if (!r.ok) return;
        const int at = firstIndex + i;
        if (at >= kMaxPlanEntries) continue;
        planStaging_.items[at] = e;
        if (at + 1 > planStaging_.count) planStaging_.count = at + 1;
    }
    planStagingSeen_ |= 1UL << chunkIndex;
    const uint32_t all = chunkCount == 32 ? 0xFFFFFFFFUL : ((1UL << chunkCount) - 1);
    if (planStagingSeen_ != all) return;
    memcpy(gState.plans.items, planStaging_.items, sizeof(PlanEntry) * planStaging_.count);
    gState.plans.count = planStaging_.count;
    gState.plans.valid = true;
    {
        int trips = 0, stops = 0, located = 0, withMaps = 0;
        for (int i = 0; i < gState.plans.count; i++) {
            const PlanEntry &e = gState.plans.items[i];
            if (e.kind == 0) { trips++; continue; }
            stops++;
            located += e.hasCoordinate();
            withMaps += e.stamp[0] != 0 || e.stamp[1] != 0;
        }
        Serial.printf("[plans] %d trip(s), %d stop(s), %d with a location, %d with maps made by the phone\n", trips, stops, located, withMaps);
    }
    applyOutboxToPlans();
    gState.plansVersion++;
    planCommittedSeq_ = seq;
    planHaveCommitted_ = true;
    planStagingSeen_ = 0;
    gStore.savePlans();
    gStore.enqueueMissingMaps();
}

// A spoken alert from the app (kScopeSpeech): hand the samples to the talk task's speech queue.
// Chunks of an utterance arrive in order or not at all (UDP); a lost one is just a short gap.
void ScopeLink::onSpeech(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    r.u16(); // utteranceId -- the queue plays whatever arrives, in order
    r.u16(); // chunkIndex
    r.u8();  // flags
    if (!r.ok) return;
    const int n = (len - r.pos) / 2;
    if (n <= 0) return;
    static int16_t samples[Protocol::kSpeechSamplesPerChunk];
    const int count = n > Protocol::kSpeechSamplesPerChunk ? Protocol::kSpeechSamplesPerChunk : n;
    memcpy(samples, d + r.pos, (size_t)count * 2); // packet bytes aren't 2-byte aligned
    gTalk.queueSpeech(samples, count);
}

// Where the scope points (kScopeHeading), so the app can word directions relative to it.
void ScopeLink::sendHeading() {
    uint8_t pkt[11];
    pkt[0] = Protocol::kVersion;
    pkt[1] = Protocol::kScopeHeading;
    const float az = gState.compassPresent ? gState.scopeTrueAzimuthDeg() : NAN;
    const float el = gState.compassPresent ? gState.scopeElevationDeg : NAN;
    memcpy(pkt + 2, &az, 4);
    memcpy(pkt + 6, &el, 4);
    pkt[10] = gState.compassCal;
    sendToApp(pkt, sizeof(pkt));
}

void ScopeLink::onPhonePosition(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const int32_t lat = (int32_t)r.u32();
    const int32_t lon = (int32_t)r.u32();
    const float accuracy = r.f32();
    const float course = r.f32();
    const float speed = r.f32();
    const uint16_t ageS = r.u16();
    if (!r.ok || lat == INT32_MIN || lon == INT32_MIN) return;
    const uint16_t intervalS = r.u16(); // newer apps only
    gState.phone.intervalS = r.ok && intervalS ? intervalS : 1;
    PhonePosition &p = gState.phone;
    p.valid = true;
    p.lat = lat / 1e6;
    p.lon = lon / 1e6;
    p.accuracyM = accuracy;
    p.courseDeg = course;
    p.speedMps = speed;
    p.updatedMs = millis() - (uint32_t)ageS * 1000;
}

uint16_t ScopeLink::requestMap(const char *stopId, uint8_t style, uint8_t level, uint8_t col, uint8_t row, bool prefetch) {
    if (appPort_ == 0) return 0;
    if (!mapBuffer_) mapBuffer_ = (uint8_t *)ps_malloc(Protocol::kMaxMapBytes);
    if (!mapChunkSeen_) mapChunkSeen_ = (uint8_t *)ps_malloc(Protocol::kMaxMapChunks);
    if (!mapBuffer_ || !mapChunkSeen_) return 0;
    mapRequestId_ = nextRequestId_++;
    if (nextRequestId_ == 0) nextRequestId_ = 1;
    mapChunkCount_ = 0;
    mapChunksReceived_ = 0;
    mapComplete_ = false;
    mapTaken_ = false;
    mapIsPrefetch_ = prefetch;
    mapRequestMs_ = millis();
    mapStopId_ = stopId;
    mapStyle_ = style;
    mapLevel_ = level;
    mapCol_ = col;
    mapRow_ = row;
    lastMapChunkMs_ = 0;
    lastMapResendMs_ = millis();
    mapResendGapMs_ = 300;
    chunksAtLastResend_ = 0;
    memset(mapChunkSeen_, 0, Protocol::kMaxMapChunks);
    sendMapRequestPacket();
    if (!prefetch) Serial.printf("[map] requested %s %s tile %u-%u-%u (opened)\n", stopId, style ? "satellite" : "standard", level, col, row);
    return mapRequestId_;
}

void ScopeLink::sendMapRequestPacket() {
    uint8_t pkt[2 + 2 + 1 + 48 + 4];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeMapRequest;
    putU16(pkt + n, mapRequestId_); n += 2;
    const size_t l = min((size_t)48, (size_t)mapStopId_.length());
    pkt[n++] = (uint8_t)l;
    memcpy(pkt + n, mapStopId_.c_str(), l);
    n += l;
    pkt[n++] = mapStyle_;
    pkt[n++] = mapLevel_;
    pkt[n++] = mapCol_;
    pkt[n++] = mapRow_;
    sendTo(pkt, n, appIP_, appPort_);
}

void ScopeLink::pollMapResend() {
    if (!mapPending() || appPort_ == 0) return;
    const uint32_t nowMs = millis();
    // Chunks arrive ~8 ms apart; 200 ms without one = the burst is over (or never started). Ask
    // again then -- less and less often while asking brings nothing new (a busy phone).
    const uint32_t lastHeard = lastMapChunkMs_ ? lastMapChunkMs_ : mapRequestMs_;
    if ((int32_t)(nowMs - lastHeard) < 200 || (int32_t)(nowMs - lastMapResendMs_) < (int32_t)mapResendGapMs_) return;
    if (mapChunksReceived_ > chunksAtLastResend_) mapResendGapMs_ = 300;
    else mapResendGapMs_ = min<uint32_t>(mapResendGapMs_ * 2, 3000);
    chunksAtLastResend_ = mapChunksReceived_;
    lastMapResendMs_ = nowMs;
    if (mapChunkCount_ == 0) { // nothing yet: the request itself may have been lost
        sendMapRequestPacket();
        return;
    }
    uint8_t pkt[2 + 2 + 1 + 2 * 120];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeMapResend;
    putU16(pkt + n, mapRequestId_); n += 2;
    const size_t countAt = n++;
    uint8_t count = 0;
    for (uint16_t i = 0; i < mapChunkCount_ && count < 120; i++) {
        if (mapChunkSeen_[i]) continue;
        putU16(pkt + n, i); n += 2;
        count++;
    }
    pkt[countAt] = count;
    if (count == 0) return;
    sendTo(pkt, n, appIP_, appPort_);
}

void ScopeLink::onMapChunk(const uint8_t *d, int len) {
    Reader r(d, len, 2);
    const uint16_t requestId = r.u16();
    const uint16_t index = r.u16();
    const uint16_t count = r.u16();
    if (!r.ok || requestId != mapRequestId_ || mapComplete_ || count == 0 || count > Protocol::kMaxMapChunks || index >= count) return;
    mapChunkCount_ = count;
    const int payload = len - r.pos;
    if (payload <= 0 || payload > Protocol::kScopeCardChunkBytes) return;
    lastMapChunkMs_ = millis();
    if (!mapChunkSeen_[index]) {
        memcpy(mapBuffer_ + (size_t)index * Protocol::kScopeCardChunkBytes, d + r.pos, payload);
        mapChunkSeen_[index] = 1;
        mapChunksReceived_++;
    }
    if (mapChunksReceived_ == mapChunkCount_) mapComplete_ = true;
}

bool ScopeLink::takeMap(String &stopId, uint8_t &style, bool &prefetch, const uint8_t *&payload, size_t &len) {
    if (!mapComplete_ || mapTaken_) return false;
    mapTaken_ = true;
    stopId = mapStopId_;
    style = mapStyle_;
    prefetch = mapIsPrefetch_;
    payload = mapBuffer_;
    len = (size_t)mapChunkCount_ * Protocol::kScopeCardChunkBytes;
    return true;
}

void ScopeLink::sendCardStatus() {
    uint8_t pkt[2 + 1 + 2 + 2 + 4 + 1 + 2 + 4];
    size_t n = 0;
    pkt[n++] = Protocol::kVersion;
    pkt[n++] = Protocol::kScopeCardStatus;
    pkt[n++] = gState.sdPresent ? 1 : 0;
    putU16(pkt + n, gState.cardsStored); n += 2;
    putU16(pkt + n, gState.cardsQueued); n += 2;
    const uint32_t mb = gState.sdFreeMB;
    pkt[n++] = mb & 0xFF; pkt[n++] = (mb >> 8) & 0xFF; pkt[n++] = (mb >> 16) & 0xFF; pkt[n++] = mb >> 24;
    pkt[n++] = (uint8_t)min(outboxCount_, 255);
    putU16(pkt + n, gState.cardsFailed); n += 2;
    int mapStored = 0, mapTotal = 0;
    gStore.mapProgress(mapStored, mapTotal);
    putU16(pkt + n, (uint16_t)min(mapTotal, 65535)); n += 2;
    putU16(pkt + n, (uint16_t)min(mapStored, 65535)); n += 2;
    sendTo(pkt, n, appIP_, appPort_);
}

void ScopeLink::sendCountAdd(const String &name, int8_t delta) {
    if (appPort_ == 0) return;
    uint8_t pkt[4 + 255];
    const size_t n = name.length() > 255 ? 255 : name.length();
    pkt[0] = Protocol::kVersion;
    pkt[1] = Protocol::kScopeCountAdd;
    pkt[2] = (uint8_t)delta;
    pkt[3] = (uint8_t)n;
    memcpy(pkt + 4, name.c_str(), n);
    sendTo(pkt, 4 + n, appIP_, appPort_);
}

void ScopeLink::sendCommand(uint8_t command, const IPAddress &ip) {
    if (appPort_ == 0) return;
    uint8_t pkt[7] = {Protocol::kVersion, Protocol::kScopeCommand, command, ip[0], ip[1], ip[2], ip[3]};
    sendTo(pkt, sizeof(pkt), appIP_, appPort_);
}
