// SnapshotFetcher.h -- camera-node snapshots for the Camp tab, fetched DIRECTLY from each node's
// `GET /snapshot` (PhotoServer) -- stateless HTTP, no session, works even with the phone off
// (SCOPE_DISPLAY_PLAN.md §5, §6.2). Runs on core 0; paused entirely while Talk is held (each
// snapshot is a 30-60 KB burst from the same node that's receiving your voice -- plan §6.2.2).
//
// Each slot is double-buffered: the task decodes into `back` only while `ready` is false; the main
// loop swaps it to the screen and clears `ready`. No locks needed beyond that handshake.
#pragma once

#include "JpegImage.h"
#include <IPAddress.h>

constexpr int kSnapshotSlots = 4;

struct SnapshotSlot {
    IPAddress ip;
    RGBImage front;
    RGBImage back;
    volatile bool ready = false;   // back holds a new frame for the main loop
    volatile bool failed = false;  // last attempt failed (camera off / unreachable)
    uint32_t lastFetchMs = 0;
    bool forceNext = false;
};

class SnapshotFetcher {
public:
    void begin();
    // The nodes whose tiles are on screen right now (Camp tab), max kSnapshotSlots.
    void setWanted(const IPAddress *ips, int count);
    // Fetch everything wanted on the next pass, ignoring the refresh interval ("Snapshot all").
    void refreshNow();
    // Main loop: if a slot has a new frame, swap it to front and return the slot (else nullptr).
    SnapshotSlot *takeReady();
    SnapshotSlot *slotFor(const IPAddress &ip);

private:
    static void taskEntry(void *self);
    void taskLoop();

    SnapshotSlot slots_[kSnapshotSlots];
    volatile int slotCount_ = 0;
    uint8_t *httpBuffer_ = nullptr;
};

extern SnapshotFetcher gSnapshots;
