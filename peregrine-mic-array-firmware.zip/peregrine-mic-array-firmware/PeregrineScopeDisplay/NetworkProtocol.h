// NetworkProtocol.h — wire format shared by the firmware and the Swift app's
// `MicArrayProtocol.swift`. Keep both sides in sync if you change anything here. Also duplicated
// verbatim (Protocol namespace only) in ../PeregrineMicArrayRearSensor/NetworkProtocol.h, since
// Arduino sketches can't share headers across folders -- keep that copy in sync too.
//
// All multi-byte fields little-endian (native on both ESP32-S3 and arm64 iOS — zero byte-swap
// cost either side). Every packet starts with a version byte for forward compatibility.
#pragma once

#include <cstdint>

namespace Protocol {
// NodeIdentityPacket.hasPresenceSensor bit: set while the presence sensor has gone silent (missing,
// unpowered, unplugged). Added 2026-09-26.
constexpr uint8_t kPresenceSensorOfflineFlag = 0x80;


constexpr uint8_t kVersion = 1;

enum PacketType : uint8_t {
    kAudioFrame          = 0x01, // device -> phone (mono reference channel, any node)
    kDOATelemetry        = 0x02, // device -> phone (front array only)
    kHandshakePing       = 0x03, // phone -> device
    kHandshakePong       = 0x04, // device -> phone
    kSessionStart        = 0x05, // phone -> device
    kSessionStop         = 0x06, // phone -> device
    kRearSensorTelemetry = 0x07, // device -> phone (rear sensor only, see PeregrineMicArrayRearSensor)
    kNodeIdentity        = 0x08, // device -> phone (multi-node network only, see CAMERA_NODE_NETWORK_SPEC.md)
    kSetFrequencyBands   = 0x09, // phone -> device (front array only)
    kGPSPosition         = 0x0A, // device -> phone (GPS-equipped nodes only)
    kCompassHeading      = 0x0B, // device -> phone (compass-equipped nodes only)
    kMotionTrigger       = 0x0C, // device -> phone (motion-sensor-equipped nodes only)
    kPhotoReady          = 0x0D, // device -> phone (camera nodes only)
    kNodeAnnounce        = 0x0E, // device -> device, LAN broadcast (roster discovery only, see MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #1)
    kRosterRequest       = 0x0F, // phone -> device
    kRosterResponse      = 0x10, // device -> phone
    kPhotoCaptureNow     = 0x11, // phone -> device (camera nodes only) -- manual trigger, bypasses the onset gate
    kSetPhotoMode        = 0x12, // phone -> device (camera nodes only) -- 0=automatic (onset-gated), 1=manual-only
    kVideoRecordStart    = 0x13, // phone -> device (camera nodes only)
    kVideoRecordStop     = 0x14, // phone -> device (camera nodes only)
    kVideoReady          = 0x15, // device -> phone (camera nodes only)
    kVideoStreamStart    = 0x16, // phone -> device (camera nodes only) -- start live MJPEG preview
    kVideoStreamStop     = 0x17, // phone -> device (camera nodes only)
    kLogLine             = 0x18, // device -> phone -- FIELD_DEBUG_PLAN.md, mirrors this node's Serial0 output
    kSetRemoteLogging    = 0x19, // phone -> device -- FIELD_DEBUG_PLAN.md, 0=off (default) / 1=on
    kStereoAudioFrame    = 0x1A, // device -> phone (4-mic nodes only, Config::kMicCount==4) -- see AudioFrameHeader
    kAudioLevels         = 0x1B, // device -> phone (4-mic nodes only) -- see AudioLevelsPacket
    kSetFeederCamMode    = 0x1C, // phone -> device (camera nodes only) -- 0=off (mic array) / 1=feeder cam (HOME_ASSISTANT.md)
    kTimedOnset          = 0x1D, // device -> phone -- GPS-PPS-disciplined onset arrival time (MULTI_NODE_TDOA_PLAN.md)
    kSetPhotoInterval    = 0x1E, // phone -> device (camera nodes only) -- runtime min gap between onset-triggered captures, u32 ms
    kGetWiFiConfig       = 0x1F, // phone -> device -- request the current Wi-Fi/AP/role config (CONFIGURABLE_FLEET_PLAN.md Part A)
    kWiFiConfigReport    = 0x20, // device -> phone -- current config; carries NO password material
    kSetWiFiConfig       = 0x21, // phone -> device -- staged mutation of Wi-Fi config, op byte selects (see kWiFiOp*)
    kSetCameraEnabled    = 0x22, // phone -> device (camera nodes only) -- 1-byte payload, 0=off (esp_camera_deinit(),
                                  // frees CPU/PSRAM/DMA for GPS fix + sound capture) / 1=on. Not persisted -- comes
                                  // back on at boot. Turning off force-stops any in-progress recording/live stream.
    // --- CAMPING_SECURITY_NODE_PLAN.md additions (2026-09-18). Only meaningful on a camping-
    // security-capable node (NodeIdentityPacket.hasPresenceSensor/hasSpeaker); other node types
    // never send/receive these, same "additive, opt-in" convention as the multi-node block above.
    kSetNodeMode         = 0x23, // phone -> device -- see SetNodeModePacket. Not persisted -- app re-sends on reconnect.
    kSetAutomaticAlarm   = 0x24, // phone -> device -- see SetAutomaticAlarmPacket. Not persisted.
    kSoundAlarm          = 0x25, // phone -> device -- fire-and-forget manual alarm trigger (mirrors kPhotoCaptureNow's
                                  // shape: a bare ControlPacket, no payload beyond the 2-byte header).
    kPlaybackAudioFrame  = 0x26, // phone -> device -- "speak through the node." First reverse-direction audio packet
                                  // in this protocol (every other audio type flows device -> phone) -- same
                                  // AudioFrameHeader shape, mono int16 PCM samples follow. Streamed only while the
                                  // app's push-to-talk button is held.
    // Home Assistant MQTT broker config (CAMPING_SECURITY_NODE_PLAN.md's "Home Assistant
    // integration"), added 2026-09-18 -- camping-security-capable node firmware only (not used
    // here), reserved so the enum numbering stays in sync. Deliberately no staged/commit/rollback
    // dance like kSetWiFiConfig -- a bad MQTT config can never strand the node off the network the
    // way a bad Wi-Fi config could, so kSetMQTTConfig applies and persists immediately.
    kGetMQTTConfig       = 0x27, // phone -> device -- request the current MQTT config
    kMQTTConfigReport    = 0x28, // device -> phone -- current config; carries NO password material, same convention as kWiFiConfigReport
    kSetMQTTConfig       = 0x29, // phone -> device -- see SetMQTTConfigPacket
    kStopAlarm           = 0x2A, // phone -> device -- added 2026-09-22: the app had no way to silence an alarm
                                  // early, only wait out kAlarmAutoStopMs. Fire-and-forget, same bare-ControlPacket
                                  // shape as kSoundAlarm; safe to send even if no alarm is currently sounding
                                  // (AudioOutput::stopAlarm() is a no-op then).
    kSetPresenceCapture  = 0x2B, // phone -> device -- added 2026-09-22: the C4001 presence trigger was firing
                                  // an autonomous photo capture unconditionally, in every Node Mode, with no
                                  // way to turn it off -- confirmed as a real surprise, not the intended
                                  // design, once a user actually hit it. Off by default (Config::
                                  // kPresenceCaptureDefault); see SetPresenceCapturePacket. Home Assistant's
                                  // own "Presence Capture" switch is the second front door onto the same
                                  // gPresenceCaptureEnabled flag (HomeAssistantMQTT.h), not a separate toggle.
    kOrientation         = 0x2C, // device -> phone -- raw BNO055 gravity + magnetic vectors (NODE_ORIENTATION_3D_PLAN.md);
                                  // only when Config::kCompassEnabled (optional BNO055 on GPIO20/48, 2026-09-28)
    kPresenceUpdate      = 0x2D, // device -> phone -- live presence readout, ~1/s while someone is there
                                  // (distance, radial speed, approaching/away). See PresenceUpdatePacket.
    kSetPresenceRange    = 0x2E, // phone -> device -- see SetPresenceRangePacket. Persisted in NVS (PresenceConfigStore).
    kPresenceConfig      = 0x2F, // device -> phone -- see PresenceConfigPacket; sent with every NodeIdentity.
};

// kSetWiFiConfig op byte (data[2]). Staging ops touch NVS but not the running radio; only
// kWiFiOpCommit / kWiFiOpResetDefaults reboot the node. See WiFiConfigStore + CONFIGURABLE_FLEET_PLAN.md.
constexpr uint8_t kWiFiOpSetAp         = 0x01; // data[3]=channel, then ss(u8 len + bytes), pw(u8 len + bytes)
constexpr uint8_t kWiFiOpSetRole       = 0x02; // data[3]=role (kRole*), data[4]=rosterMaster (0/1)
constexpr uint8_t kWiFiOpSetCandidates = 0x03; // data[3]=count, count x ( ss(u8 len+bytes), pw(u8 len+bytes) ), then disabledMask(u8)
constexpr uint8_t kWiFiOpResetDefaults = 0x04; // wipe NVS -> Config.h defaults, then reboot
constexpr uint8_t kWiFiOpCommit        = 0x05; // persist staged config, arm the recovery timer, then reboot

// kWiFiConfigReport (device -> phone) wire layout, after the 2-byte version/type header:
//   role(u8), apChannel(u8), rosterMaster(u8), apPasswordIsDefault(u8), awaitingProof(u8),
//   apSsidLen(u8), apSsid[...],
//   candidateCount(u8), then candidateCount x ( ssidLen(u8), ssid[...] ),   -- SSIDs only, never passwords
//   disabledMask(u8)   -- bit i set = candidate i kept but disabled (never joined). Additive: an
//                         older reader stops after `candidateCount` entries and never sees this byte.
// kWiFiOpSetCandidates payload mirrors this: count(u8), count x (ssLen+ss, pwLen+pw), disabledMask(u8).
constexpr uint8_t kMaxWiFiCandidatesOverWire = 6;

// Max sibling nodes one roster response can report -- generous for the small networks this system
// targets (CAMERA_NODE_NETWORK_SPEC.md's cost table tops out around 5 nodes), bounded rather than
// unbounded for the same reason kMaxDOABands is.
constexpr int kMaxRosterEntries = 8;

// Max simultaneous species bands the phone can ask the front array to filter+correlate per onset
// capture (see kSetFrequencyBands / UDPStreamer's activeBands_ on the firmware side). Each band
// costs one extra bandpass-filter+cross-correlate pass over the same captured window -- cheap per
// pass, and DOA capture is onset-gated (transient-triggered), not continuous, but this bounds the
// worst case rather than accepting an unbounded list from the phone. Lives here (not Config.h) so
// this header stays a single self-contained file, matching the verbatim copy in
// ../PeregrineMicArrayRearSensor/NetworkProtocol.h.
constexpr int kMaxDOABands = 5;

constexpr uint8_t kPongMagic0 = 'P';
constexpr uint8_t kPongMagic1 = 'B';

#pragma pack(push, 1)

// Shared 12-byte header for both kAudioFrame and kStereoAudioFrame (added 2026-08-18 for stereo --
// same shape, `type`/`reserved` distinguish which payload follows, so no new struct was needed):
//   - kAudioFrame: `reserved` = 0. Followed by N little-endian int16 PCM samples, one mono
//     reference channel (2-mic nodes always; 4-mic nodes only when NOT sending kStereoAudioFrame
//     instead -- see Config::kMicCount, the two are mutually exclusive per node, never both).
//   - kStereoAudioFrame: `reserved` = 2 (channel count -- informational; the packet `type` byte
//     alone is what the decoder actually switches on). Followed by N *interleaved* little-endian
//     int16 PCM sample pairs (L0, R0, L1, R1, ...) -- the top bus's TL/TR pair, which share one
//     I2S read call and are therefore genuinely sample-synchronized (unlike top-vs-bottom, whose
//     buses run on independent, unsynchronized clocks -- see Config.h's architecture note).
//   - kPlaybackAudioFrame (added 2026-09-18, CAMPING_SECURITY_NODE_PLAN.md): phone -> device, the
//     ONLY reverse-direction use of this header -- `reserved` = 0, followed by N mono int16 PCM
//     samples, same encoding as kAudioFrame just flowing the other way. "Speak through the node":
//     streamed only while the app's push-to-talk button is held, fed into a jitter/ring buffer that
//     drains into the NS4168 speaker's I2S TX. `sampleRate` should match Config::kSampleRateHz
//     (44100) -- the device does not resample.
struct AudioFrameHeader {
    uint8_t version;
    uint8_t type; // kAudioFrame or kStereoAudioFrame
    uint32_t seq;
    uint32_t sampleRate; // 44100
    uint8_t encoding;    // 0x10 = int16 PCM
    uint8_t reserved;    // channel count for kStereoAudioFrame: 2 = interleaved L/R; 4 = interleaved
                         // TL,TR,BL,BR from a clock-synced 4-mic array (CONFIGURABLE_FLEET_PLAN.md
                         // Part C). unused (0) for kAudioFrame.
};
constexpr uint8_t kEncodingInt16 = 0x10;

// 15 bytes total. Device -> phone, 4-mic nodes only (Config::kMicCount==4), sent alongside the
// existing periodic [status]/[levels] Serial report (~every 2s) -- added 2026-08-20 after a real
// finding: the top pair (TL/TR) was confirmed completely silent (peak level exactly 0) on real
// hardware, while the bottom pair (BL/BR) stayed healthy. Peak absolute int16 sample value seen on
// each channel since the LAST report (not cumulative since boot), plus which pair the node is
// CURRENTLY streaming as the reference/stereo audio (see the .ino's own
// usingBottomPairForStream / Config::kAudioFallbackSilenceThreshold for the automatic-fallback
// logic that decides this). Lets the app show real per-channel levels and the active pair without
// a USB tether, and is what a future app-side manual override (if ever wanted) would read to decide
// whether one's even needed.
struct AudioLevelsPacket {
    uint8_t version;
    uint8_t type; // kAudioLevels
    uint32_t timestampMs;
    int16_t topLeftPeak;
    int16_t topRightPeak;
    int16_t bottomLeftPeak;
    int16_t bottomRightPeak;
    uint8_t activePair; // 0 = top (TL/TR), 1 = bottom (BL/BR)
};

// 23 bytes total. Sent only on gated onset events, not continuously -- once per populated
// frequency band per onset capture (see kSetFrequencyBands below), all against the SAME captured
// 4-channel window, so multiple simultaneous callers in different frequency ranges can each get
// their own azimuth from one onset event. `bandId` echoes back whichever id the phone assigned via
// kSetFrequencyBands (0 when no bands are set -- the default full-spectrum single-reading case,
// unchanged from the original single-band behavior).
struct DOATelemetryPacket {
    uint8_t version;
    uint8_t type; // kDOATelemetry
    uint32_t seq;
    uint32_t timestampMs;
    // [0, 360) — relative to the array's own front mark, never true north. This firmware's DOA
    // comes from a single left-right mic pair at a time (the two I2S buses run independently,
    // unsynchronized) -- so in practice this only ever falls in the forward hemisphere
    // (270..360..90), never indicating "behind." See DOAEstimator.h/Config.h for why (and why a
    // working cross-bus comparison, if the clock-sync problem were ever solved, would give
    // elevation, not front-back -- the two mic pairs sit on the same front-back axis, only height
    // differs). The field itself is unchanged from a hypothetical full-2D version, so the wire
    // format and the phone app need no changes -- only the range of values actually produced
    // differs.
    float azimuthDeg;
    float confidence;    // [0, 1]
    float relativeLevel; // raw onset-window amplitude figure; NOT a distance measurement
    uint8_t bandId;       // which kSetFrequencyBands slot produced this reading (0 = default/unfiltered)
};

// 14 bytes total. Streamed continuously (every ~100ms) while a session is active, not gated on
// this unit's own onset trigger -- the phone needs a recent rear-sensor level sample available
// whenever the FRONT array's own onset happens to fire, and the two run on independent,
// unsynchronized clocks with no way to guarantee both gates trip on the same block. See
// MIC_ARRAY_MULTI_UNIT_PLAN.md (repo root) for what the phone does with this: compares it against
// the front array's own relativeLevel for roughly-contemporaneous events to flag/correct that
// unit's known front-back blind spot, and as a coarse proximity cue -- not for triangulation.
struct RearSensorTelemetryPacket {
    uint8_t version;
    uint8_t type; // kRearSensorTelemetry
    uint32_t seq;
    uint32_t timestampMs;
    float relativeLevel; // same smoothed-envelope figure as DOATelemetryPacket's relativeLevel
};

// 2-byte control packets, phone -> device.
struct ControlPacket {
    uint8_t version;
    uint8_t type; // kHandshakePing / kSessionStart / kSessionStop / kSoundAlarm
};

// One requested band within a kSetFrequencyBands packet. `bandId` is an opaque phone-assigned
// label (0..254) echoed back in DOATelemetryPacket.bandId -- the firmware attaches no species
// meaning to it, that mapping lives entirely on the phone. `bandId == 0xFF` marks a slot unused
// when a packet's `count` is padded with empty entries (not currently produced, but decoders
// should tolerate/ignore it).
struct FrequencyBandSlot {
    uint8_t bandId;
    float lowHz;
    float highHz;
};

// 3 + kMaxDOABands*9 bytes total (48 bytes at kMaxDOABands=5). phone -> device (front array only).
// Fully replaces the array's active band set every time -- `count` (0..kMaxDOABands) says how
// many of `slots` are valid; the rest are ignored. An empty packet (count=0) clears all bands,
// reverting to full-spectrum DOA (today's original behavior) -- the default when nothing is being
// tracked. See DOAEstimator.h's `estimate()` comment for what the filtering itself does.
struct SetFrequencyBandsPacket {
    uint8_t version;
    uint8_t type; // kSetFrequencyBands
    uint8_t count;
    FrequencyBandSlot slots[kMaxDOABands];
};

// 4-byte reply, device -> phone.
struct HandshakePongPacket {
    uint8_t version;
    uint8_t type; // kHandshakePong
    uint8_t magic0; // 'P'
    uint8_t magic1; // 'B'
};

// --- Multi-node network additions (see CAMERA_NODE_NETWORK_SPEC.md / MIC_ARRAY_MULTI_UNIT_PLAN.md) ---
// Everything below is additive: existing single-front-array + single-rear-sensor deployments never
// send or expect these, so their behavior is unchanged. New node types opt in by sending them.

// 17 bytes. Sent once after handshake and periodically thereafter (a node can be power-cycled or
// reconnect without the phone re-pinging first), so the phone can tell nodes apart without the
// user having to declare capabilities out-of-band for every reconnect -- it still cross-checks
// against the user's own declared configuration (see MicArrayNodeConfiguration.swift) rather than
// trusting this alone, since a node could be miswired/misflashed. Also reused verbatim (just a
// different `type` byte) for kNodeAnnounce -- see `fleetId`'s own comment below.
struct NodeIdentityPacket {
    uint8_t version;
    uint8_t type; // kNodeIdentity or kNodeAnnounce
    uint8_t nodeType;        // 0 = mic-only array, 1 = camera + mic array
    uint8_t hasGPS;          // 0/1
    uint8_t hasCompass;      // 0/1
    uint8_t hasMotionSensor; // 0/1
    uint8_t micCount;        // 4 (both I2S buses) or 2 (single bus) -- see CAMERA_NODE_NETWORK_SPEC.md's pin budget
    // Scopes kNodeAnnounce/roster aggregation to one owner's own fleet of nodes (see
    // Config::kFleetId) -- without this, a master node on a WiFi network shared with a DIFFERENT
    // user's camera nodes (a shared venue WiFi, a portable hotspot on a joint outing) would
    // aggregate THEIR nodes into its own roster too, since kNodeAnnounce is a plain LAN broadcast
    // with no other identity concept. A master only keeps announces whose fleetId matches its own
    // Config::kFleetId (see UDPStreamer's kNodeAnnounce handler); irrelevant for kNodeIdentity
    // (phone already knows which node it's talking to), just along for the ride since it's the
    // same struct.
    uint32_t fleetId;
    // Added 2026-08-14 -- a stable per-physical-chip identifier (ESP32's own factory-burned eFuse
    // base MAC, via ESP.getEfuseMac(), NOT WiFi.macAddress()/softAPmacAddress() -- those differ
    // from each other on the same chip and depend on which WiFi mode is currently active, which
    // would make a Secondary's own reported identity change when it fails over between STA and
    // AP+STA. eFuse is a direct register read, independent of WiFi state entirely). Distinct from
    // (and doesn't change when) this node's network address does -- exists specifically so the
    // phone can tell "my saved node moved to a new IP" apart from "this is a genuinely new node,"
    // and can tell two nodes of the identical hardware type apart, neither of which the wire
    // protocol could do before this field existed. Byte order isn't a meaningful convention here
    // (not asserted to match how MAC addresses are conventionally printed) -- only stability and
    // per-chip uniqueness matter for its purpose, both guaranteed by eFuse regardless of order.
    uint8_t deviceId[6];
    // Added 2026-09-18 (CAMPING_SECURITY_NODE_PLAN.md) -- additive, at the true end of the struct:
    // an older reader (built before these fields existed) never looks past deviceId above and is
    // completely unaffected, same convention as kWiFiConfigReport's trailing disabledMask. Fixed
    // hardware capabilities of a camping-security-capable node (DFRobot C4001 mmWave + NS4168
    // speaker), NOT gated by a Config::kXEnabled flag the way hasMotionSensor is -- this variant has
    // no "build without the sensor" option, both parts are always physically present.
    uint8_t hasPresenceSensor; // 0 none, 1 C4001, 2 C4002 (added 2026-09-26), OR'd with
                               // kPresenceSensorOfflineFlag (0x80) while the sensor has sent nothing
                               // for Config::kPresenceSensorSilenceMs. Any non-zero = has one -- older
                               // app builds read it as a plain bool and stay correct.
    uint8_t hasSpeaker;        // 0/1 -- 1 on camping-security-capable nodes (NS4168); gates whether
                               // the app's alarm/speak-through-the-node controls make sense at all.
};

// 48 bytes. Sent periodically (every 1-5s is plenty; position doesn't change during a session)
// once the node's GPS module reports a fix. Latitude/longitude as plain signed decimal degrees
// (matches this app's own `Coordinate` struct/`CLLocationCoordinate2D` -- no fixed-point encoding)
// using `double`, not `float`: a float32's ~7 significant decimal digits leaves only ~1m of
// latitude precision, uncomfortably close to the GPS module's own ~2.5m real-world accuracy: not
// worth stacking additional precision loss on top of an already-limited measurement.
struct GPSPositionPacket {
    uint8_t version;
    uint8_t type; // kGPSPosition
    uint32_t timestampMs;
    double latitude;
    double longitude;
    float horizontalAccuracyMeters; // 0 = unknown/not reported by this GPS module
    uint8_t hasFix;                 // 0/1 -- distinguishes "no fix yet" from "fix at exactly (0,0)"
    // Added 2026-08-14 for in-field GPS troubleshooting (no other way to see any of this without a
    // laptop tethered to Serial0) -- straight passthrough of GPSReader's/PPSReader's own running
    // counters, see GPSReader.h's doc comment for the exact diagnostic reasoning these support
    // (charsProcessed==0 -> wiring/baud; sentencesValid==0 despite charsProcessed>0 -> garbled;
    // sentencesValid climbing with hasFix still false -> genuine cold-start, needs sky view).
    uint8_t satellitesInView;      // 0 until at least one sentence with satellite-count info parses
    uint32_t charsProcessed;       // TinyGPSPlus's own running total, never resets
    uint32_t sentencesValid;       // NMEA sentences that passed checksum
    uint32_t sentencesInvalid;     // NMEA sentences that failed checksum (garbled/noisy link)
    uint32_t ppsEdgeCount;         // total PPS rising edges seen since boot, 0 if disabled/unwired
    uint32_t ppsLastIntervalMicros; // between the two most recent edges; ~1,000,000 on a healthy 1Hz signal, 0 before the second edge
};

// 10 bytes. Sent periodically. Degrees [0, 360), clockwise from magnetic north -- raw magnetometer
// reading, no magnetic declination correction applied (declination varies by location and this
// firmware has no way to know the user's region; correct for it on the phone side if true-north
// accuracy ever matters more than the relative bearing-intersection math needs).
struct CompassHeadingPacket {
    uint8_t version;
    uint8_t type; // kCompassHeading
    uint32_t timestampMs;
    float headingDeg;
};

// 31 bytes -- mirrors ../PeregrineMicArrayCam/NetworkProtocol.h's OrientationPacket exactly (see its
// comment). Sent alongside every CompassHeadingPacket when the optional BNO055 is enabled.
struct OrientationPacket {
    uint8_t version;
    uint8_t type; // kOrientation
    uint32_t timestampMs;
    float gravity[3];
    float magnetic[3];
    uint8_t calibration; // sys<<6 | gyro<<4 | accel<<2 | mag, each 0-3
};

// 10 bytes. Sent once per motion-sensor trigger event (rising edge of detected presence/motion),
// mirroring DOATelemetryPacket's onset-gated design rather than streaming a continuous level.
struct MotionTriggerPacket {
    uint8_t version;
    uint8_t type; // kMotionTrigger
    uint32_t timestampMs;
    float signalStrength; // sensor-specific relative figure, not calibrated across sensor types
};

// 14 bytes. Live presence readout (added 2026-09-30), sent at most once per
// Config::kPresenceUpdateIntervalMs while the sensor sees someone, plus once when they leave
// (targetState 0). Separate from MotionTriggerPacket on purpose: that one is the throttled
// "presence detected" alert event and stays exactly 10 bytes so older apps keep alerting.
// speedCmPerSec is along the sensor's beam only (0xFFFF = sensor doesn't report speed) -- someone
// walking straight across the field reads ~0 / movement "none".
struct PresenceUpdatePacket {
    uint8_t version;
    uint8_t type; // kPresenceUpdate
    uint32_t timestampMs;
    float distanceCm;       // 0 when no target
    uint16_t speedCmPerSec; // magnitude, >= 0; 0xFFFF = not reported
    uint8_t movement;       // 0 unknown, 1 none, 2 approaching, 3 away
    uint8_t targetState;    // 0 none, 1 still, 2 moving, 3 present (still/moving unknown)
};

// 6 bytes (added 2026-09-30). Sets the presence sensor's detection range and/or hold time from the
// app. 0xFFFF in either field = leave that one unchanged. Applied to the sensor right away and saved
// in NVS, so it survives a reboot with no phone around; the node answers with a PresenceConfigPacket.
struct SetPresenceRangePacket {
    uint8_t version;
    uint8_t type;        // kSetPresenceRange
    uint16_t maxRangeCm; // clamped to the fitted sensor's own limits
    uint16_t holdS;      // seconds the sensor keeps a target after losing it (C4002 only)
};

// 10 bytes (added 2026-09-30). The presence sensor's current range/hold settings and limits, so the
// app's controls show the real values. Sent with every NodeIdentity and after each change.
struct PresenceConfigPacket {
    uint8_t version;
    uint8_t type;            // kPresenceConfig
    uint16_t maxRangeCm;     // 0 = not known (a C4001 the app has never set keeps its own saved range)
    uint16_t holdS;          // 0xFFFF = this sensor has no settable hold time
    uint16_t minSupportedCm;
    uint16_t maxSupportedCm;
};

// 14 bytes. Sent once per captured photo. The image bytes themselves never travel over this UDP
// protocol -- this just notifies the phone it can now GET the photo over plain HTTP from this
// node's own small web server (see CAMERA_NODE_NETWORK_SPEC.md's "HTTP pull, node runs a tiny
// server" decision). `photoId` is an opaque token the phone echoes back in its request path (e.g.
// `GET /photo/<photoId>`), so the node can keep serving the correct photo even if another capture
// happens before the phone's GET arrives.
struct PhotoReadyPacket {
    uint8_t version;
    uint8_t type; // kPhotoReady
    uint32_t timestampMs;
    uint32_t photoId;
    uint32_t photoSizeBytes;
};

// One discovered sibling within a kRosterResponse packet. IP octets are transmitted in their
// natural dotted-quad order (not a little-endian scalar -- these are 4 independent bytes, not one
// multi-byte field), so the phone can reconstruct "a.b.c.d" directly. Capability fields mirror
// NodeIdentityPacket's -- this entry IS that node's own most recently announced identity, just
// relayed by whichever node the phone happened to ask. Deliberately doesn't carry `fleetId` --
// every entry that made it into the roster already passed the master's fleetId filter (see
// NodeIdentityPacket's comment), so there's nothing left to check by the time the phone sees it.
// `deviceId` added 2026-08-14, mirrors NodeIdentityPacket's own field -- see that struct's comment.
struct RosterEntryPacket {
    uint8_t ipOctet0;
    uint8_t ipOctet1;
    uint8_t ipOctet2;
    uint8_t ipOctet3;
    uint8_t nodeType;        // see NodeIdentityPacket.nodeType
    uint8_t hasGPS;
    uint8_t hasCompass;
    uint8_t hasMotionSensor;
    uint8_t micCount;
    uint8_t deviceId[6];
    // Added 2026-09-18, mirrors NodeIdentityPacket's own trailing additive fields -- see that
    // struct's comment for why they're appended here too, at the true end.
    uint8_t hasPresenceSensor;
    uint8_t hasSpeaker;
};

// 3 + count*17 bytes (139 bytes at kMaxRosterEntries=8). device -> phone, reply to kRosterRequest.
// Only ever non-empty on whichever node is currently acting as the roster master -- how that's
// decided is up to each node type's own firmware (a fixed Config::kIsMasterNode-style flag, or
// MIC_ARRAY_MASTER_AP_PLAN.md's "whoever is currently hosting the AP" model on
// PeregrineMicArrayCam); every other node always replies with count=0, so the phone can send
// kRosterRequest to any connected node uniformly rather than needing to already know which one is
// master. See kNodeAnnounce (this file's PacketType enum) for how the master actually learns about
// its siblings: each node periodically broadcasts its own NodeIdentityPacket-shaped announcement to
// the LAN, and only the master does anything with what it hears -- and only from announces matching
// its own Config::kFleetId, so a different user's nodes sharing the same WiFi network never end up
// in this roster (see NodeIdentityPacket's fleetId comment).
struct RosterResponsePacket {
    uint8_t version;
    uint8_t type; // kRosterResponse
    uint8_t count;
    RosterEntryPacket entries[kMaxRosterEntries];
};

// 3 bytes. phone -> device. mode: 0 = automatic (the original onset-gated behavior -- a photo is
// taken whenever the mic array's own onset detector fires, same trigger as a DOA capture),
// 1 = manual-only (onset-gated capture suppressed entirely; the DOA/audio pipeline itself is
// unaffected, only whether it also fires the camera). kPhotoCaptureNow still works regardless of
// this mode -- manual mode doesn't mean "no automatic photos AND no manual ones," it means the
// user has full control over when a photo is taken instead of the node deciding on its own.
struct SetPhotoModePacket {
    uint8_t version;
    uint8_t type; // kSetPhotoMode
    uint8_t mode; // 0 = automatic, 1 = manual-only
};

// 3 bytes. phone -> device. Starts a bounded video-recording session (see Config::kVideoMaxDurationMs
// for the safety cutoff if the phone never sends kVideoRecordStop -- e.g. it's backgrounded or the
// connection drops) -- runs independently on the node itself once started, not tied to the phone
// staying connected/foregrounded (see MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3's "runs in the
// background" requirement). Frames are JPEG stills captured at Config::kVideoFrameIntervalMs
// (this hardware has no video encoder -- see that doc for why a still sequence, not true
// hardware-encoded video, is the realistic approach), written to the SD card alongside a WAV audio
// track if requested. The phone composes an actual playable video file from the fetched frames +
// audio afterward (MicArrayVideoFetcher) -- same "capture raw ingredients on the node, do the
// heavy lifting on the phone" division already used for photo classification.
struct VideoRecordStartPacket {
    uint8_t version;
    uint8_t type; // kVideoRecordStart
    uint8_t includeAudio; // 0/1
};

// 18 bytes. device -> phone, sent once a recording session ends (explicit kVideoRecordStop,
// Config::kVideoMaxDurationMs safety cutoff, or an SD write failure mid-recording). The phone
// fetches the manifest this describes over HTTP the same way it already pulls a still photo (see
// PhotoReadyPacket) -- video bytes never travel over this UDP protocol either, for the same reason.
struct VideoReadyPacket {
    uint8_t version;
    uint8_t type; // kVideoReady
    uint32_t videoId;
    uint32_t timestampMs;
    uint16_t frameCount;
    uint16_t frameIntervalMs;
    uint32_t audioSampleCount; // 0 if includeAudio was false or no audio was actually captured
};

// device -> phone. FIELD_DEBUG_PLAN.md, added 2026-08-18. Mirrors one already-newline-terminated
// line this node would otherwise only ever print to its own Serial0 console -- see RemoteLogger.h.
// `length` bytes of UTF-8 text follow immediately after this fixed header on the wire (same
// header-then-raw-bytes composition AudioFrameHeader/sendAudioFrame already uses for its sample
// data) -- not null-terminated, the receiver already knows the exact byte count. Capped well under
// the practical ~1472-byte UDP-over-WiFi MTU -- real log lines here are always short printf
// one-liners, no need to push the limit and risk fragmentation.
constexpr uint8_t kMaxLogLineLength = 200;
struct LogLineHeader {
    uint8_t version;
    uint8_t type; // kLogLine
    uint8_t length; // bytes of text following this header, <= kMaxLogLineLength
};

// 3 bytes. phone -> device. FIELD_DEBUG_PLAN.md, added 2026-08-18.
struct SetRemoteLoggingPacket {
    uint8_t version;
    uint8_t type; // kSetRemoteLogging
    uint8_t enabled; // 0/1, default 0 (off) at boot on every node
};

// 3 bytes. phone -> device. Runtime toggle for feeder-cam mode (HOME_ASSISTANT.md) -- no on-device
// persistence, same as SetPhotoModePacket: the app re-sends the node's saved choice on reconnect.
// 0 = normal mic-array node; 1 = act as a Home-Assistant-facing camera (stream auto-starts + stays
// up, still capture is motion/on-demand instead of onset-triggered, a record request makes the
// stream yield). The compile-time Config::kFeederCamMode additionally skips the I2S capture tasks
// for a lean dedicated build -- that part can't be toggled at runtime.
struct SetFeederCamModePacket {
    uint8_t version;
    uint8_t type; // kSetFeederCamMode
    uint8_t enabled; // 0/1, default 0 at boot
};

// 24 bytes. device -> phone. One onset event, timestamped on this node's GPS-PPS-disciplined
// local->UTC clock (PPSReader::utcForLocalMicros), sent only when that clock is anchored (a PPS
// edge + a parsed GPS time both exist). The phone collects one of these per participating node
// and multilaterates the source position from the inter-node arrival-time differences
// (MULTI_NODE_TDOA_PLAN.md Phases 3-4). Sent ALONGSIDE the existing kDOATelemetry for the same
// event, not instead of it -- bearing-only nodes and the map's bearing fallback still use that.
struct TimedOnsetPacket {
    uint8_t version;
    uint8_t type; // kTimedOnset
    uint32_t seq;
    uint32_t utcSecond;  // seconds-of-day, 0..86399 (nodes align within a session; midnight wrap is a documented once-a-day glitch)
    uint32_t utcMicros;  // 0..999999
    uint16_t bandId;     // 0 = full-spectrum onset gate; else the kSetFrequencyBands slot
    float peakLevel;     // onset.lastRelativeLevel() at trigger -- for SNR weighting in the solver
    float confidence;    // DOA confidence for this event if one was computed, else 0
};

// 6 bytes. phone -> device. Runtime override for the minimum gap between onset-triggered stills
// (Config::kPhotoMinIntervalMs is now just the boot default) -- auto capture on a busy feeder can
// otherwise pile up thousands of JPEGs. No on-device persistence, same as SetPhotoModePacket: the
// app re-sends the node's saved value on reconnect. Manual (kPhotoCaptureNow) and motion captures
// use this same limiter. The node clamps to a sane range (see UDPStreamer's kSetPhotoInterval case).
struct SetPhotoIntervalPacket {
    uint8_t version;
    uint8_t type; // kSetPhotoInterval
    uint32_t intervalMs;
};

// 3 bytes. phone -> device (camping-security-capable nodes only, CAMPING_SECURITY_NODE_PLAN.md).
// No on-device persistence, same as SetPhotoModePacket/SetFeederCamModePacket -- the app re-sends
// the node's saved choice on reconnect. Which job this physical node is doing right now: it's still
// the same hardware underneath (onset/DOA + camera + presence sensor + speaker all exist
// regardless), this just picks the behavior profile.
struct SetNodeModePacket {
    uint8_t version;
    uint8_t type; // kSetNodeMode
    uint8_t mode; // 0 = Birding, 1 = Camping Security, 2 = Home Security -- see NodeMode.h
};

// 3 bytes. phone -> device. Only meaningful in Camping Security mode (a no-op if received in
// Birding or Home Security -- Home Security's equivalent decision lives in Home Assistant
// automations instead, see CAMPING_SECURITY_NODE_PLAN.md's "Home Assistant integration"). No
// on-device persistence, same shape as SetNodeModePacket. 0 = off (default -- a qualifying C4001
// presence event only captures + notifies, never sounds the siren on its own) / 1 = on (also fires
// the alarm tone automatically, for a genuinely unattended site where that's wanted).
struct SetAutomaticAlarmPacket {
    uint8_t version;
    uint8_t type; // kSetAutomaticAlarm
    uint8_t enabled; // 0/1, default 0
};

// 3 bytes. phone -> device. See kSetPresenceCapture's comment above.
struct SetPresenceCapturePacket {
    uint8_t version;
    uint8_t type; // kSetPresenceCapture
    uint8_t enabled; // 0/1, default 0
};

// `kMQTTConfigReport` (device -> phone), added 2026-09-18. Length-driven, not a fixed struct, same
// convention as kWiFiConfigReport -- layout after the 2-byte version/type header:
//   configured(u8), connected(u8), port(u16),
//   hostLen(u8), host[...], usernameSet(u8), topicPrefixLen(u8), topicPrefix[...]
// Deliberately carries NO password material, same as kWiFiConfigReport -- `usernameSet` only says
// whether a username is currently stored, never its value, since a username alone is far less
// sensitive than the pairing password would be but still not worth echoing back unnecessarily.
//
// `kSetMQTTConfig` (phone -> device) mirrors this shape for input: version, type,
// port(u16), hostLen(u8)+host, usernameLen(u8)+username, passwordLen(u8)+password,
// topicPrefixLen(u8)+topicPrefix. Applies and persists immediately (see MQTTConfigStore.h for why
// this needs no staged/commit/rollback dance the way kSetWiFiConfig does) and reconnects the MQTT
// client on its next poll() using whatever's now current.

#pragma pack(pop)

} // namespace Protocol
