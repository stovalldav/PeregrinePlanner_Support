// ScopeProtocol.h -- the Scope Display's own packets (SCOPE_DISPLAY_PLAN.md §5), 0x30-0x3E.
// Everything else (handshake, session, identity, orientation, kPlaybackAudioFrame) is the shared
// fleet protocol in NetworkProtocol.h. Mirrored in the app: MicArrayProtocol.swift ("Scope Display").
//
// All little-endian, variable length, parsed by explicit offsets (no packed structs -- the strings
// make the shapes variable). Every packet starts with `version (u8), type (u8)`. A "str" is
// `len (u8)` + that many UTF-8 bytes. A "f32?" is a float that is NaN when absent.
//
// 0x30 kScopeDetection          app -> display, one per new detection
//      confidencePct u8, flags u8 (bit0 hasBearing, bit1 newLifeBird), trueBearingDeg f32?,
//      common str, scientific str, nodeName str
// 0x31 kScopeCardRequest        display -> app, on tap
//      requestId u16, common str, scientific str
// 0x32 kScopeCardData           app -> display, chunked reply
//      requestId u16, chunkIndex u16, chunkCount u16, payload (<= kScopeCardChunkBytes)
//      Reassembled payload: textLen u32, jpegLen u32, text (UTF-8, "\n"-separated lines,
//      first line = section title convention "# Title"), jpeg bytes (may be 0 length)
// 0x33 kScopeTargets            app -> display, ~2 Hz (also with 0 targets, for the header)
//      declinationDeg f32, alignSeq u16, alignTrueBearingDeg f32? (NaN unless an alignment is
//      being requested -- the display applies it once per new alignSeq), count u8, then count x
//      (slot u8, trueAzimuthDeg f32, elevationDeg f32?, sigmaDeg f32, distanceM f32?, name str)
// 0x34 kScopeFleetStatus        app -> display, every 2 s (10 s in Camp mode)
//      count u8, then count x (ip 4xu8, nodeType u8, flags u8, sats u8, compassCal u8 (0xFF n/a),
//      lastHeardS u16, presenceModel u8 (0 none, 1 C4001, 2 C4002), name str)
//      flags: bit0 connected, bit1 gpsFix, bit2 hasPresence, bit3 presenceOnline, bit4 cameraOn,
//             bit5 hasCompass, bit6 hasSpeaker, bit7 hasGPS
// 0x35 kScopeNodeLive           app -> display, ~5 Hz for the watched node only
//      ip 4xu8, azimuthDeg f32?, confidence f32, level f32, headingDeg f32?, compassCal u8,
//      gpsFix u8, sats u8
// 0x36 kScopeSession            app -> display, every 10 s
//      active u8, elapsedS u32, species u16, detections10min u16, newLifeBirds u16, count u8,
//      then count x name str (most recent first)
// 0x37 kScopePresence           app -> display, relayed per kPresenceUpdate / trigger
//      ip 4xu8, distanceCm f32, speedCmPerSec u16 (0xFFFF n/a), movement u8, targetState u8,
//      nodeMode u8, flags u8 (bit0 sensorOffline, bit1 alert), name str
// 0x38 kScopeCommand            display -> app
//      command u8, ip 4xu8 (0.0.0.0 = none). kCmdNewLocation carries its outbox seq in the ip
//      bytes instead (seq lo, seq hi, 0, 0) and is answered with kScopeAck.
// 0x39 kScopeTargetList         app -> display, on change + every 5 s, chunked (one MTU each)
//      listSeq u16, chunkIndex u8, chunkCount u8, total u16, seen u16, firstIndex u16,
//      tripName str, stopName str, count u8, then count x (flags u8, name str)
//      The target birds of the trip being logged (the one started / arrived at in the app), in
//      display order; entry i of a chunk is list position firstIndex + i. total 0 = no trip.
//      flags: bit0 seen (at the location you're at), bit1 expected at this stop, bit2 seen at an
//      earlier location on the trip, bit7 = a location heading row (not a bird; bit6 = the one
//      you're at). Rows are grouped by location, the current one first. The checklist is per
//      location -- see kCmdNewLocation.
// 0x3A kScopeTargetToggle       display -> app, on tap (and replayed from the outbox)
//      seen u8, name str (exactly as received), seq u16 -- the app marks it seen / not seen at the
//      current location and answers kScopeAck(seq). (seq absent = no ack wanted; older displays.)
// 0x3B kScopeAck                app -> display
//      seq u16 -- an outbox entry (toggle or kCmdNewLocation) was applied; the display drops it
// 0x3C kScopePrefetchList       app -> display, chunked, on "Load bird cards for this area"
//      listId u16, chunkIndex u8, chunkCount u8, count u8, then count x (common str, scientific str)
//      The display requests each card it doesn't already have on its SD card (kScopeCardRequest),
//      one at a time, and stores it.
// 0x3D kScopeTripHistory        app -> display, on change + every 10 s, chunked
//      seq u16, chunkIndex u8, chunkCount u8, unixTime u32 (phone clock), firstIndex u16, count u8,
//      then count x (kind u8, flags u8, name str). kind 0 = a location (flags bit0 = you're here),
//      kind 1 = a bird seen there (flags bit0 heard, bit1 seen) -- birds follow their location.
//      Locations newest first.
// 0x3E kScopeCardStatus         display -> app, every 5 s while linked
//      sdPresent u8, cardsStored u16, cardsQueued u16, sdFreeMB u32, outboxPending u8,
//      cardsFailed u16 (since the last kScopePrefetchList -- sending the list again retries them)
#pragma once

#include <cstdint>

namespace Protocol {

constexpr uint8_t kNodeTypeScopeDisplay = 3; // 2 = the removed rear sensor (rejected by the app)

constexpr uint8_t kScopeDetection   = 0x30;
constexpr uint8_t kScopeCardRequest = 0x31;
constexpr uint8_t kScopeCardData    = 0x32;
constexpr uint8_t kScopeTargets     = 0x33;
constexpr uint8_t kScopeFleetStatus = 0x34;
constexpr uint8_t kScopeNodeLive    = 0x35;
constexpr uint8_t kScopeSession     = 0x36;
constexpr uint8_t kScopePresence    = 0x37;
constexpr uint8_t kScopeCommand     = 0x38;
constexpr uint8_t kScopeTargetList  = 0x39;
constexpr uint8_t kScopeTargetToggle = 0x3A;
constexpr uint8_t kScopeAck          = 0x3B;
constexpr uint8_t kScopePrefetchList = 0x3C;
constexpr uint8_t kScopeTripHistory  = 0x3D;
constexpr uint8_t kScopeCardStatus   = 0x3E;
constexpr uint8_t kTripTargetSeen = 0x01;
constexpr uint8_t kTripTargetHere = 0x02;
constexpr uint8_t kTripTargetSeenEarlier = 0x04;
constexpr uint8_t kTripTargetCurrentHeading = 0x40;
constexpr uint8_t kTripTargetHeading = 0x80;

constexpr uint16_t kScopeCardChunkBytes = 900;

// kScopeCommand.command
constexpr uint8_t kCmdSoundAlarm = 1;
constexpr uint8_t kCmdStopAlarm  = 2;
constexpr uint8_t kCmdWatchNode  = 3; // ip = node; app starts kScopeNodeLive
constexpr uint8_t kCmdUnwatch    = 4;
constexpr uint8_t kCmdCampModeOn = 5; // app relays only presence + slow fleet status
constexpr uint8_t kCmdCampModeOff = 6;
constexpr uint8_t kCmdNewLocation = 7; // "I've moved": a new location on the logged trip, fresh checklist

// Fleet-status flags
constexpr uint8_t kFleetConnected      = 0x01;
constexpr uint8_t kFleetGPSFix         = 0x02;
constexpr uint8_t kFleetHasPresence    = 0x04;
constexpr uint8_t kFleetPresenceOnline = 0x08;
constexpr uint8_t kFleetCameraOn       = 0x10;
constexpr uint8_t kFleetHasCompass     = 0x20;
constexpr uint8_t kFleetHasSpeaker     = 0x40;
constexpr uint8_t kFleetHasGPS         = 0x80;

} // namespace Protocol
