// ScopeProtocol.h -- the Scope Display's own packets (SCOPE_DISPLAY_PLAN.md §5), 0x30-0x43.
// Everything else (handshake, session, identity, orientation, kPlaybackAudioFrame) is the shared
// fleet protocol in NetworkProtocol.h. Mirrored in the app: MicArrayProtocol.swift ("Scope Display").
//
// All little-endian, variable length, parsed by explicit offsets (no packed structs -- the strings
// make the shapes variable). Every packet starts with `version (u8), type (u8)`. A "str" is
// `len (u8)` + that many UTF-8 bytes. A "f32?" is a float that is NaN when absent.
//
// 0x30 kScopeDetection          app -> display, one per new detection
//      confidencePct u8, flags u8 (bit0 hasBearing, bit1 newLifeBird), trueBearingDeg f32?,
//      common str, scientific str, nodeName str
// 0x31 kScopeCardRequest        display -> app, on tap
//      requestId u16, common str, scientific str
// 0x32 kScopeCardData           app -> display, chunked reply
//      requestId u16, chunkIndex u16, chunkCount u16, payload (<= kScopeCardChunkBytes)
//      Reassembled payload: textLen u32, jpegLen u32, text (UTF-8, "\n"-separated lines,
//      first line = section title convention "# Title"), jpeg bytes (may be 0 length)
// 0x33 kScopeTargets            app -> display, ~2 Hz (also with 0 targets, for the header)
//      declinationDeg f32, alignSeq u16, alignTrueBearingDeg f32? (NaN unless an alignment is
//      being requested -- the display applies it once per new alignSeq), count u8, then count x
//      (slot u8, trueAzimuthDeg f32, elevationDeg f32?, sigmaDeg f32, distanceM f32?, name str)
// 0x34 kScopeFleetStatus        app -> display, every 2 s (10 s in Camp mode)
//      count u8, then count x (ip 4xu8, nodeType u8, flags u8, sats u8, compassCal u8 (0xFF n/a),
//      lastHeardS u16, presenceModel u8 (0 none, 1 C4001, 2 C4002), name str)
//      flags: bit0 connected, bit1 gpsFix, bit2 hasPresence, bit3 presenceOnline, bit4 cameraOn,
//             bit5 hasCompass, bit6 hasSpeaker, bit7 hasGPS
// 0x35 kScopeNodeLive           app -> display, ~5 Hz for the watched node only
//      ip 4xu8, azimuthDeg f32?, confidence f32, level f32, headingDeg f32?, compassCal u8,
//      gpsFix u8, sats u8
// 0x36 kScopeSession            app -> display, every 10 s
//      active u8, elapsedS u32, species u16, detections10min u16, newLifeBirds u16, count u8,
//      then count x name str (most recent first)
// 0x37 kScopePresence           app -> display, relayed per kPresenceUpdate / trigger
//      ip 4xu8, distanceCm f32, speedCmPerSec u16 (0xFFFF n/a), movement u8, targetState u8,
//      nodeMode u8, flags u8 (bit0 sensorOffline, bit1 alert), name str
// 0x38 kScopeCommand            display -> app
//      command u8, ip 4xu8 (0.0.0.0 = none). kCmdNewLocation carries its outbox seq in the ip
//      bytes instead (seq lo, seq hi, 0, 0) and is answered with kScopeAck.
// 0x39 kScopeTargetList         app -> display, on change + every 5 s, chunked (one MTU each)
//      listSeq u16, chunkIndex u8, chunkCount u8, total u16, seen u16, firstIndex u16,
//      tripName str, stopName str, count u8, then count x (flags u8, name str)
//      The target birds of the trip being logged (the one started / arrived at in the app), in
//      display order; entry i of a chunk is list position firstIndex + i. total 0 = no trip.
//      flags: bit0 seen (at the location you're at), bit1 expected at this stop, bit2 seen at an
//      earlier location on the trip, bit7 = a location heading row (not a bird; bit6 = the one
//      you're at). Rows are grouped by location, the current one first. The checklist is per
//      location -- see kCmdNewLocation.
// 0x3A kScopeTargetToggle       display -> app, on tap (and replayed from the outbox)
//      seen u8, name str (exactly as received), seq u16 -- the app marks it seen / not seen at the
//      current location and answers kScopeAck(seq). (seq absent = no ack wanted; older displays.)
// 0x3B kScopeAck                app -> display
//      seq u16 -- an outbox entry (toggle or kCmdNewLocation) was applied; the display drops it
// 0x3C kScopePrefetchList       app -> display, chunked, on "Load bird cards for this area"
//      listId u16, chunkIndex u8, chunkCount u8, count u8, then count x (common str, scientific str)
//      The display requests each card it doesn't already have on its SD card (kScopeCardRequest),
//      one at a time, and stores it.
// 0x3D kScopeTripHistory        app -> display, on change + every 10 s, chunked
//      seq u16, chunkIndex u8, chunkCount u8, unixTime u32 (phone clock), firstIndex u16, count u8,
//      then count x (kind u8, flags u8, name str). kind 0 = a location (flags bit0 = you're here),
//      kind 1 = a bird seen there (flags bit0 heard, bit1 seen) -- birds follow their location.
//      Locations newest first.
// 0x3E kScopeCardStatus         display -> app, every 5 s while linked
//      sdPresent u8, cardsStored u16, cardsQueued u16, sdFreeMB u32, outboxPending u8,
//      cardsFailed u16 (since the last kScopePrefetchList -- sending the list again retries them),
//      mapTilesTotal u16, mapTilesStored u16 (stop maps of the trip plans)
// 0x3F kScopeTripPlans          app -> display, on change + every 10 s, chunked
//      seq u16, chunkIndex u8, chunkCount u8, firstIndex u16, count u8, then count x
//      (kind u8, flags u8, id str, name str, and for a stop: latE6 i32, lonE6 i32, stdStamp u32,
//      satStamp u32). kind 0 = a trip (flags bit0 being logged, bit1 started, bit2 maps on -- its
//      stops' stamps are 0 when off, so nothing downloads), kind 1 = one of its
//      stops, following its trip (flags bit0 the stop you're at). latE6/lonE6 = degrees x 1e6,
//      INT32_MIN = no coordinate. A stamp is when that stop's map was made (0 = not yet); a stored
//      map with another stamp is out of date.
// 0x40 kScopeMapRequest         display -> app, one tile of a stop's map
//      requestId u16, stopId str, style u8 (0 standard, 1 satellite), level u8, col u8, row u8
//      A stop's map is 4 x 5 km, north up, centred on the stop, as 320x400 tiles at 5 zoom levels,
//      each covering the whole map: level 4 = 1 tile, 3 = 2x2, 2 = 4x4, 1 = 8x8, 0 = 16x16 (250 m on
//      screen, 0.8 m a pixel) -- 341 tiles a style. (col, row) = place in the level's grid.
// 0x41 kScopeMapData            app -> display, chunked like kScopeCardData
//      requestId u16, chunkIndex u16, chunkCount u16, payload (<= kScopeCardChunkBytes)
//      Reassembled payload (also the SD file, /maps/<stopId>-<m|s>/<level>-<col>-<row>.t): "PM" u8 x2,
//      version u8 (2), style u8, stamp u32, northE6 i32, southE6 i32, westE6 i32, eastE6 i32 (the
//      whole map's bounds), level u8, col u8, row u8, 0, jpegLen u32, jpeg (320x400). North-up Web
//      Mercator: x is linear in longitude, y in mercator(latitude).
// 0x42 kScopePhonePosition      app -> display, 1 Hz while a trip is being logged
//      latE6 i32, lonE6 i32, accuracyM f32, courseDeg f32?, speedMps f32?, ageS u16,
//      intervalS u16 (how often the phone takes a fix -- Settings > Trip GPS Updates; absent = 1)
// 0x43 kScopeTripCommand        display -> app (outbox, answered with kScopeAck)
//      op u8 (1 start trip, 2 I'm at this stop -- starts its trip if needed, 3 / 4 the trip's stop
//      maps on / off), id str, seq u16
// 0x44 kScopeMapResend          display -> app, while a map reply has gaps
//      requestId u16, count u8, then count x chunkIndex u16 -- the app sends just those chunks again.
//      UDP drops part of a ~75-chunk map burst (a third of it on the first try, 2026-10-08).
// 0x45 kScopeSpeech             app -> display, a spoken alert (HANDS_FREE_LOGGING_PLAN.md §2)
//      utteranceId u16, chunkIndex u16, flags u8 (bit0 last chunk), then int16 mono samples at
//      kSpeechSampleRate (22.05 kHz) to the end of the packet (<= kSpeechSamplesPerChunk). The display
//      queues them and plays them on its speaker; its mic isn't read while it speaks.
// 0x46 kScopeHeading            display -> app, 1 Hz while linked
//      trueAzimuthDeg f32? (where the scope points, NaN when unknown), elevationDeg f32?, compassCal u8
//      (magnetometer 0-3). Lets the app say a direction relative to the scope ("40 degrees right").
// 0x47 kScopeCountAdd           display -> app, long-press on a target (HANDS_FREE_LOGGING_PLAN.md §3)
//      delta i8, name str (as received) -- adds to that bird's count at the current location (checks
//      it off first if needed). The app answers by voice ("3 Ruddy Ducks").
// kScopeCommand also carries kCmdMark / kCmdConfirmLast / kCmdUndoLast (the Heard/Targets buttons).
#pragma once

#include <cstddef>
#include <cstdint>

namespace Protocol {

constexpr uint8_t kNodeTypeScopeDisplay = 3; // 2 = the removed rear sensor (rejected by the app)

constexpr uint8_t kScopeDetection   = 0x30;
constexpr uint8_t kScopeCardRequest = 0x31;
constexpr uint8_t kScopeCardData    = 0x32;
constexpr uint8_t kScopeTargets     = 0x33;
constexpr uint8_t kScopeFleetStatus = 0x34;
constexpr uint8_t kScopeNodeLive    = 0x35;
constexpr uint8_t kScopeSession     = 0x36;
constexpr uint8_t kScopePresence    = 0x37;
constexpr uint8_t kScopeCommand     = 0x38;
constexpr uint8_t kScopeTargetList  = 0x39;
constexpr uint8_t kScopeTargetToggle = 0x3A;
constexpr uint8_t kScopeAck          = 0x3B;
constexpr uint8_t kScopePrefetchList = 0x3C;
constexpr uint8_t kScopeTripHistory  = 0x3D;
constexpr uint8_t kScopeCardStatus   = 0x3E;
constexpr uint8_t kScopeTripPlans    = 0x3F;
constexpr uint8_t kScopeMapRequest   = 0x40;
constexpr uint8_t kScopeMapData      = 0x41;
constexpr uint8_t kScopePhonePosition = 0x42;
constexpr uint8_t kScopeTripCommand  = 0x43;
constexpr uint8_t kScopeMapResend    = 0x44;
constexpr uint8_t kScopeSpeech       = 0x45;
constexpr uint8_t kScopeHeading      = 0x46;
constexpr uint8_t kScopeCountAdd     = 0x47;
constexpr uint32_t kSpeechSampleRate = 22050;
constexpr int kSpeechSamplesPerChunk = 600;
constexpr uint8_t kSpeechLastChunk = 0x01;
constexpr uint8_t kTripOpStart = 1;
constexpr uint8_t kTripOpArrive = 2;
constexpr uint8_t kTripOpMapsOn = 3;
constexpr uint8_t kTripOpMapsOff = 4;
constexpr uint8_t kPlanTripMaps = 0x04;
constexpr uint8_t kPlanTripActive = 0x01;
constexpr uint8_t kPlanTripStarted = 0x02;
constexpr uint8_t kPlanStopCurrent = 0x01;
constexpr uint8_t kMapStandard = 0;
constexpr uint8_t kMapSatellite = 1;
constexpr size_t kMapHeaderBytes = 32;
constexpr uint8_t kTripTargetSeen = 0x01;
constexpr uint8_t kTripTargetHere = 0x02;
constexpr uint8_t kTripTargetSeenEarlier = 0x04;
constexpr uint8_t kTripTargetCurrentHeading = 0x40;
constexpr uint8_t kTripTargetHeading = 0x80;

constexpr uint16_t kScopeCardChunkBytes = 900;
// One map tile (a 320x400 JPEG, ~10-80 KB) -- same reassembly limit as a card.
constexpr uint16_t kMaxMapChunks = 256;
constexpr size_t kMaxMapBytes = (size_t)kMaxMapChunks * kScopeCardChunkBytes; // ~230 KB
constexpr int kMapTileW = 320, kMapTileH = 400, kMapLevels = 5;
constexpr int kMapTilesPerStyle = 1 + 4 + 16 + 64 + 256;
inline int mapGridSize(int level) { return 1 << (kMapLevels - 1 - level); }
inline bool mapHasTile(int level, int col, int row) {
    if (level < 0 || level >= kMapLevels) return false;
    const int n = mapGridSize(level);
    return col >= 0 && row >= 0 && col < n && row < n;
}

// kScopeCommand.command
constexpr uint8_t kCmdSoundAlarm = 1;
constexpr uint8_t kCmdStopAlarm  = 2;
constexpr uint8_t kCmdWatchNode  = 3; // ip = node; app starts kScopeNodeLive
constexpr uint8_t kCmdUnwatch    = 4;
constexpr uint8_t kCmdCampModeOn = 5; // app relays only presence + slow fleet status
constexpr uint8_t kCmdCampModeOff = 6;
constexpr uint8_t kCmdNewLocation = 7; // "I've moved": a new location on the logged trip, fresh checklist
constexpr uint8_t kCmdMark = 8;        // drop a mark: time, place, where the scope points -- identify later
constexpr uint8_t kCmdConfirmLast = 9; // the bird Sound ID just heard -- I saw it too
constexpr uint8_t kCmdUndoLast = 10;   // undo the last thing logged

// Fleet-status flags
constexpr uint8_t kFleetConnected      = 0x01;
constexpr uint8_t kFleetGPSFix         = 0x02;
constexpr uint8_t kFleetHasPresence    = 0x04;
constexpr uint8_t kFleetPresenceOnline = 0x08;
constexpr uint8_t kFleetCameraOn       = 0x10;
constexpr uint8_t kFleetHasCompass     = 0x20;
constexpr uint8_t kFleetHasSpeaker     = 0x40;
constexpr uint8_t kFleetHasGPS         = 0x80;

} // namespace Protocol
