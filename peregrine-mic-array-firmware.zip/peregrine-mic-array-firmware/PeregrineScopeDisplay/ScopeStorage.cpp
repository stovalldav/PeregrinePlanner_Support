#include "ScopeStorage.h"
#include "Config.h"
#include "ScopeState.h"
#include <FS.h>
#include <SD_MMC.h>

ScopeStorage gStore;

namespace {

constexpr int kSdClk = 38, kSdCmd = 40, kSdD0 = 39, kSdD1 = 41, kSdD2 = 48, kSdD3 = 47; // Freenove FNK0104S
constexpr size_t kMaxCardBytes = 256 * 900;  // matches ScopeLink's card buffer
constexpr uint32_t kFetchTimeoutMs = 15000;
constexpr uint8_t kMaxTries = 3;

String field(const String &line, int index) {
    int start = 0;
    for (int i = 0; i < index; i++) {
        start = line.indexOf('\t', start);
        if (start < 0) return String();
        start++;
    }
    const int end = line.indexOf('\t', start);
    return end < 0 ? line.substring(start) : line.substring(start, end);
}

String clean(const String &s) { // no tabs/newlines inside a TSV field
    String out = s;
    out.replace('\t', ' ');
    out.replace('\n', ' ');
    out.replace('\r', ' ');
    return out;
}

// "bewick_s_wren" -> "Bewick's Wren"; "black_capped_chickadee" -> "Black Capped Chickadee". The
// file name drops punctuation, so this is only a stand-in until the real name is seen again.
String nameFromKey(const String &key, bool scientific) {
    String out;
    bool wordStart = true;
    for (size_t i = 0; i < key.length(); i++) {
        const char c = key[i];
        if (c == '_') {
            // A lone "s" after a word was a possessive.
            if (!scientific && i + 2 <= key.length() && key[i + 1] == 's' && (i + 2 == key.length() || key[i + 2] == '_')) {
                out += "'s";
                i++;
                continue;
            }
            out += ' ';
            wordStart = true;
            continue;
        }
        out += (wordStart && (!scientific || out.isEmpty())) ? (char)toupper(c) : c;
        wordStart = false;
    }
    return out;
}

// Lowercase letters and digits only, for search.
void squash(const char *in, char *out, size_t cap) {
    size_t n = 0;
    for (; *in && n + 1 < cap; in++) {
        const char c = tolower(*in);
        if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) out[n++] = c;
    }
    out[n] = 0;
}

} // namespace

void ScopeStorage::begin() {
    loadBuffer_ = (uint8_t *)ps_malloc(kMaxCardBytes);
    queue_ = (QueueItem *)ps_malloc(sizeof(QueueItem) * kMaxQueue);
    index_ = (IndexEntry *)ps_malloc(sizeof(IndexEntry) * kMaxIndex);
    SD_MMC.setPins(kSdClk, kSdCmd, kSdD0, kSdD1, kSdD2, kSdD3);
    mounted_ = SD_MMC.begin("/sdcard", false, false, SDMMC_FREQ_DEFAULT, 5);
    if (!mounted_) {
        SD_MMC.end();
        SD_MMC.setPins(kSdClk, kSdCmd, kSdD0);
        mounted_ = SD_MMC.begin("/sdcard", true, false, SDMMC_FREQ_DEFAULT, 5); // 1-bit fallback
    }
    gState.sdPresent = mounted_;
    if (!mounted_ || SD_MMC.cardType() == CARD_NONE) {
        mounted_ = false;
        gState.sdPresent = false;
        Serial.println("[sd] no card -- bird cards come from the phone each time");
        return;
    }
    for (const char *dir : {"/cards", "/cards/sci", "/state", "/log"}) {
        if (!SD_MMC.exists(dir)) SD_MMC.mkdir(dir);
    }
    // Reload the download queue.
    queueCount_ = 0;
    File q = SD_MMC.open("/cards/queue.tsv", FILE_READ);
    while (q && q.available() && queueCount_ < kMaxQueue) {
        const String line = q.readStringUntil('\n');
        const String common = field(line, 0);
        if (common.isEmpty()) continue;
        QueueItem &item = queue_[queueCount_++];
        strlcpy(item.common, common.c_str(), sizeof(item.common));
        strlcpy(item.scientific, field(line, 1).c_str(), sizeof(item.scientific));
        item.tries = 0;
    }
    if (q) q.close();
    refreshStats();
    loadIndex();
    Serial.printf("[sd] card mounted (%s), %u bird cards stored, %d queued, %lu MB free\n",
                  SD_MMC.cardType() == CARD_SDHC ? "SDHC" : "SD", gState.cardsStored, queueCount_, (unsigned long)gState.sdFreeMB);
}

void ScopeStorage::refreshStats() {
    if (!mounted_) return;
    uint16_t count = 0;
    File dir = SD_MMC.open("/cards");
    for (File f = dir.openNextFile(); f; f = dir.openNextFile()) {
        if (String(f.name()).endsWith(".card")) count++;
        f.close();
    }
    gState.cardsStored = count;
    gState.cardsQueued = queueCount_;
    gState.sdFreeMB = (uint32_t)((SD_MMC.totalBytes() - SD_MMC.usedBytes()) / (1024ULL * 1024ULL));
}

String ScopeStorage::keyFor(const String &common) {
    String key;
    for (size_t i = 0; i < common.length() && key.length() < 60; i++) {
        const char c = tolower(common[i]);
        if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) key += c;
        else if (key.length() && key[key.length() - 1] != '_') key += '_';
    }
    return "/cards/" + key + ".card";
}

// /cards/sci/<genus_species>.txt holds the card file's path, for lookups by scientific name.
String ScopeStorage::aliasFor(const String &scientific) {
    String key = keyFor(scientific);
    key.replace("/cards/", "/cards/sci/");
    key.replace(".card", ".txt");
    return key;
}

bool ScopeStorage::hasCard(const String &common) {
    return mounted_ && SD_MMC.exists(keyFor(common));
}

bool ScopeStorage::loadCard(const String &common, const String &scientific, CardResult &out) {
    if (!mounted_ || !loadBuffer_) return false;
    String path = keyFor(common);
    if (!SD_MMC.exists(path) && scientific.length()) {
        File alias = SD_MMC.open(aliasFor(scientific), FILE_READ);
        if (alias) {
            path = alias.readStringUntil('\n');
            alias.close();
        }
    }
    File f = SD_MMC.open(path, FILE_READ);
    if (!f) return false;
    const size_t size = f.size();
    if (size < 8 || size > kMaxCardBytes) { f.close(); return false; }
    const size_t got = f.read(loadBuffer_, size);
    f.close();
    if (got != size) return false;
    uint32_t textLen, jpegLen;
    memcpy(&textLen, loadBuffer_, 4);
    memcpy(&jpegLen, loadBuffer_ + 4, 4);
    if (8 + (size_t)textLen + jpegLen > size) return false;
    out.requestId = 0;
    out.text = String((const char *)(loadBuffer_ + 8), textLen);
    out.jpeg = jpegLen ? loadBuffer_ + 8 + textLen : nullptr;
    out.jpegLen = jpegLen;
    return true;
}

void ScopeStorage::saveCard(const String &common, const uint8_t *payload, size_t len, const String &scientific) {
    if (!mounted_ || len < 8 || len > kMaxCardBytes) return;
    uint32_t textLen, jpegLen;
    memcpy(&textLen, payload, 4);
    memcpy(&jpegLen, payload + 4, 4);
    const size_t used = 8 + (size_t)textLen + jpegLen;
    if (used > len) return;
    const bool existed = SD_MMC.exists(keyFor(common));
    File f = SD_MMC.open(keyFor(common), FILE_WRITE);
    if (!f) return;
    f.write(payload, used);
    f.close();
    if (!existed) gState.cardsStored++;
    upsertIndex(fileKey(common), common, scientific, false, true);
    if (scientific.length()) {
        File alias = SD_MMC.open(aliasFor(scientific), FILE_WRITE);
        if (alias) {
            alias.print(keyFor(common));
            alias.close();
        }
    }
    Serial.printf("[sd] saved card: %s (%u B text, %u B photo)\n", common.c_str(), (unsigned)textLen, (unsigned)jpegLen);
}

void ScopeStorage::enqueueCard(const String &common, const String &scientific) {
    if (!mounted_ || common.isEmpty()) return;
    if (hasCard(common)) {
        // Already stored -- just make sure it can also be found by its scientific name.
        if (scientific.length() && !SD_MMC.exists(aliasFor(scientific))) {
            File alias = SD_MMC.open(aliasFor(scientific), FILE_WRITE);
            if (alias) { alias.print(keyFor(common)); alias.close(); }
        }
        noteName(common, scientific);
        return;
    }
    if (queueCount_ >= kMaxQueue) return;
    for (int i = 0; i < queueCount_; i++) {
        if (common.equalsIgnoreCase(queue_[i].common)) return;
    }
    QueueItem &item = queue_[queueCount_++];
    strlcpy(item.common, common.c_str(), sizeof(item.common));
    strlcpy(item.scientific, scientific.c_str(), sizeof(item.scientific));
    item.tries = 0;
    gState.cardsQueued = queueCount_;
    File q = SD_MMC.open("/cards/queue.tsv", FILE_APPEND);
    if (q) {
        q.printf("%s\t%s\n", clean(common).c_str(), clean(scientific).c_str());
        q.close();
    }
}

void ScopeStorage::saveQueue() {
    if (!mounted_) return;
    File q = SD_MMC.open("/cards/queue.tsv", FILE_WRITE);
    if (!q) return;
    for (int i = 0; i < queueCount_; i++) q.printf("%s\t%s\n", queue_[i].common, queue_[i].scientific);
    q.close();
    savedSinceQueueWrite_ = 0;
}

void ScopeStorage::poll(uint32_t nowMs) {
    if (!mounted_) return;
    if (nowMs - lastStatsMs_ > 60000) {
        lastStatsMs_ = nowMs;
        gState.sdFreeMB = (uint32_t)((SD_MMC.totalBytes() - SD_MMC.usedBytes()) / (1024ULL * 1024ULL));
    }

    // A queued card arrived -> store it, drop it from the queue.
    String common;
    const uint8_t *payload = nullptr;
    size_t len = 0;
    if (gLink.takePrefetchCard(common, payload, len)) {
        String scientific;
        for (int i = 0; i < queueCount_; i++) {
            if (common.equalsIgnoreCase(queue_[i].common)) { scientific = queue_[i].scientific; break; }
        }
        saveCard(common, payload, len, scientific);
        for (int i = 0; i < queueCount_; i++) {
            if (common.equalsIgnoreCase(queue_[i].common)) {
                memmove(&queue_[i], &queue_[i + 1], sizeof(QueueItem) * (queueCount_ - i - 1));
                queueCount_--;
                break;
            }
        }
        gState.cardsQueued = queueCount_;
        fetching_ = false;
        if (++savedSinceQueueWrite_ >= 10 || queueCount_ == 0) saveQueue();
    }

    // A card you tapped replaced our download request: not a failure -- the same card is still
    // first in the queue and is asked for again once yours is in.
    if (fetching_ && gLink.cardPending() && !gLink.prefetchInFlight()) {
        fetching_ = false;
        return;
    }
    if (fetching_ && nowMs - fetchStartMs_ > kFetchTimeoutMs) {
        // No (complete) reply -- try it again later, at the back of the queue; give up after 3 tries.
        fetching_ = false;
        uint16_t got, expected;
        gLink.cardProgress(got, expected);
        Serial.printf("[sd] card timed out: %s (%u of %u chunks)\n", fetchingCommon_.c_str(), got, expected);
        gLink.cancelCard();
        for (int i = 0; i < queueCount_; i++) {
            if (!fetchingCommon_.equalsIgnoreCase(queue_[i].common)) continue;
            QueueItem item = queue_[i];
            memmove(&queue_[i], &queue_[i + 1], sizeof(QueueItem) * (queueCount_ - i - 1));
            queueCount_--;
            if (++item.tries < kMaxTries) queue_[queueCount_++] = item;
            else {
                gState.cardsFailed++;
                Serial.printf("[sd] gave up on the card for %s\n", item.common);
            }
            break;
        }
        gState.cardsQueued = queueCount_;
        saveQueue();
    }

    // Next download: only with the phone linked, and never over a card you tapped.
    if (fetching_ || queueCount_ == 0 || gLink.cardPending()) return;
    if (!gState.appLinked(millis(), Config::kAppLinkTimeoutMs) || gState.campMode) return;
    const QueueItem &next = queue_[0];
    if (hasCard(next.common)) { // stored meanwhile (e.g. you tapped it)
        memmove(&queue_[0], &queue_[1], sizeof(QueueItem) * (queueCount_ - 1));
        queueCount_--;
        gState.cardsQueued = queueCount_;
        return;
    }
    if (gLink.requestCard(next.common, next.scientific, true)) {
        Serial.printf("[sd] downloading card %s (%d queued)\n", next.common, queueCount_);
        fetching_ = true;
        fetchingCommon_ = next.common;
        fetchStartMs_ = nowMs;
    }
}

// ---- Persisted state ----

void ScopeStorage::saveTargetList() {
    if (!mounted_) return;
    const TripTargetList &list = gState.tripTargets;
    File f = SD_MMC.open("/state/targets.tsv", FILE_WRITE);
    if (!f) return;
    f.printf("%s\t%s\t%u\t%u\n", clean(list.tripName).c_str(), clean(list.stopName).c_str(), list.total, list.seen);
    for (int i = 0; i < list.count; i++) f.printf("%u\t%s\n", list.items[i].flags, clean(list.items[i].name).c_str());
    f.close();
}

void ScopeStorage::loadTargetList() {
    if (!mounted_) return;
    File f = SD_MMC.open("/state/targets.tsv", FILE_READ);
    if (!f) return;
    TripTargetList &list = gState.tripTargets;
    const String header = f.readStringUntil('\n');
    list.tripName = field(header, 0);
    list.stopName = field(header, 1);
    list.total = field(header, 2).toInt();
    list.seen = field(header, 3).toInt();
    list.count = 0;
    while (f.available() && list.count < kMaxTripTargets) {
        const String line = f.readStringUntil('\n');
        if (line.isEmpty()) continue;
        list.items[list.count].flags = field(line, 0).toInt();
        list.items[list.count].name = field(line, 1);
        list.count++;
    }
    f.close();
    list.valid = list.total > 0;
    gState.tripTargetsVersion++;
}

void ScopeStorage::saveHistory() {
    if (!mounted_) return;
    File f = SD_MMC.open("/state/history.tsv", FILE_WRITE);
    if (!f) return;
    const TripHistory &h = gState.tripHistory;
    for (int i = 0; i < h.count; i++) f.printf("%u\t%u\t%s\n", h.items[i].kind, h.items[i].flags, clean(h.items[i].name).c_str());
    f.close();
}

void ScopeStorage::loadHistory() {
    if (!mounted_) return;
    File f = SD_MMC.open("/state/history.tsv", FILE_READ);
    if (!f) return;
    TripHistory &h = gState.tripHistory;
    h.count = 0;
    while (f.available() && h.count < kMaxHistoryEntries) {
        const String line = f.readStringUntil('\n');
        if (line.isEmpty()) continue;
        h.items[h.count].kind = field(line, 0).toInt();
        h.items[h.count].flags = field(line, 1).toInt();
        h.items[h.count].name = field(line, 2);
        h.count++;
    }
    f.close();
    h.valid = h.count > 0;
    gState.tripHistoryVersion++;
}

void ScopeStorage::logEvent(const char *action, const String &bird) {
    if (!mounted_) return;
    File f = SD_MMC.open("/log/checks.tsv", FILE_APPEND);
    if (!f) return;
    f.printf("%lu\t%s\t%s\t%s\n", (unsigned long)gState.unixNow(), action, clean(bird).c_str(), clean(gState.tripTargets.stopName).c_str());
    f.close();
}

// ---- Saved-card index ----

String ScopeStorage::fileKey(const String &common) {
    String k = keyFor(common);
    return k.substring(7, k.length() - 5); // strip "/cards/" and ".card"
}

int ScopeStorage::findIndex(const char *file) const {
    for (int i = 0; i < indexCount_; i++) {
        if (strcmp(index_[i].file, file) == 0) return i;
    }
    return -1;
}

void ScopeStorage::upsertIndex(const String &file, const String &common, const String &scientific, bool derived, bool persist) {
    if (!index_ || file.isEmpty()) return;
    int i = findIndex(file.c_str());
    if (i >= 0) {
        IndexEntry &e = index_[i];
        if (derived && !e.derived) return; // never replace a real name with a rebuilt one
        const bool sameName = common.equals(e.common);
        if (sameName && e.derived == derived && (scientific.isEmpty() || scientific.equals(e.scientific))) return;
        // Remove and re-insert below so the list stays sorted.
        IndexEntry keep = e;
        memmove(&index_[i], &index_[i + 1], sizeof(IndexEntry) * (indexCount_ - i - 1));
        indexCount_--;
        if (scientific.isEmpty() && keep.scientific[0]) {
            upsertIndex(file, common, String(keep.scientific), derived, persist);
            return;
        }
    }
    if (indexCount_ >= kMaxIndex) return;
    IndexEntry e = {};
    strlcpy(e.file, file.c_str(), sizeof(e.file));
    strlcpy(e.common, common.c_str(), sizeof(e.common));
    strlcpy(e.scientific, scientific.c_str(), sizeof(e.scientific));
    e.derived = derived;
    int at = 0;
    while (at < indexCount_ && strcasecmp(index_[at].common, e.common) < 0) at++;
    memmove(&index_[at + 1], &index_[at], sizeof(IndexEntry) * (indexCount_ - at));
    index_[at] = e;
    indexCount_++;
    indexVersion_++;
    if (persist) appendIndex(e);
}

void ScopeStorage::appendIndex(const IndexEntry &e) {
    File f = SD_MMC.open("/cards/index.tsv", FILE_APPEND);
    if (!f) return;
    f.printf("%s\t%s\t%s\t%d\n", e.file, e.common, e.scientific, e.derived ? 1 : 0);
    f.close();
}

void ScopeStorage::writeIndex() {
    File f = SD_MMC.open("/cards/index.tsv", FILE_WRITE);
    if (!f) return;
    for (int i = 0; i < indexCount_; i++) {
        const IndexEntry &e = index_[i];
        f.printf("%s\t%s\t%s\t%d\n", e.file, e.common, e.scientific, e.derived ? 1 : 0);
    }
    f.close();
}

// Reads index.tsv (later lines win), then makes sure every card file has an entry -- cards saved
// before the index existed get a name rebuilt from the file name, and their scientific name from
// the /cards/sci/ alias that points at them -- and drops entries whose file is gone. Rewrites the
// file compact.
void ScopeStorage::loadIndex() {
    if (!index_) return;
    indexCount_ = 0;
    File f = SD_MMC.open("/cards/index.tsv", FILE_READ);
    while (f && f.available()) {
        const String line = f.readStringUntil('\n');
        const String file = field(line, 0);
        if (file.isEmpty()) continue;
        upsertIndex(file, clean(field(line, 1)), clean(field(line, 2)), field(line, 3) == "1", false);
    }
    if (f) f.close();
    const int fromFile = indexCount_;

    // Every stored card, with or without an entry.
    for (int i = 0; i < indexCount_; i++) index_[i].onCard = false;
    File dir = SD_MMC.open("/cards");
    for (File c = dir.openNextFile(); c; c = dir.openNextFile()) {
        String name = c.name();
        c.close();
        const int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (!name.endsWith(".card")) continue;
        const String file = name.substring(0, name.length() - 5);
        if (findIndex(file.c_str()) < 0) upsertIndex(file, nameFromKey(file, false), String(), true, false);
        const int i = findIndex(file.c_str()); // entries move as others are inserted -- look it up again
        if (i >= 0) index_[i].onCard = true;
    }
    // Entries whose card file is gone.
    int kept = 0;
    for (int i = 0; i < indexCount_; i++) {
        if (index_[i].onCard) index_[kept++] = index_[i];
    }
    indexCount_ = kept;
    // Scientific names for rebuilt entries, from the aliases ("/cards/sci/poecile_atricapillus.txt"
    // holds "/cards/black_capped_chickadee.card").
    File sci = SD_MMC.open("/cards/sci");
    for (File a = sci.openNextFile(); a; a = sci.openNextFile()) {
        String name = a.name();
        String target = a.readStringUntil('\n');
        a.close();
        const int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (!name.endsWith(".txt") || !target.startsWith("/cards/") || !target.endsWith(".card")) continue;
        const String file = target.substring(7, target.length() - 5);
        const int i = findIndex(file.c_str());
        if (i >= 0 && !index_[i].scientific[0]) {
            strlcpy(index_[i].scientific, nameFromKey(name.substring(0, name.length() - 4), true).c_str(), sizeof(index_[i].scientific));
        }
    }
    writeIndex();
    indexVersion_++;
    int derived = 0;
    for (int i = 0; i < indexCount_; i++) derived += index_[i].derived;
    Serial.printf("[sd] card index: %d cards (%d from index.tsv, %d named from their file only)\n", indexCount_, fromFile, derived);
}

void ScopeStorage::noteName(const String &common, const String &scientific) {
    if (!mounted_ || common.isEmpty()) return;
    const String file = fileKey(common);
    const int i = findIndex(file.c_str());
    if (i < 0) return; // not stored
    const IndexEntry &e = index_[i];
    if (!e.derived && (scientific.isEmpty() || e.scientific[0])) return;
    upsertIndex(file, common, scientific.length() ? scientific : String(e.scientific), false, true);
}

int ScopeStorage::searchCards(const String &query, int *out, int max) const {
    char q[64], buf[64];
    squash(query.c_str(), q, sizeof(q));
    int matched = 0;
    for (int i = 0; i < indexCount_; i++) {
        bool hit = !q[0];
        if (!hit) {
            squash(index_[i].common, buf, sizeof(buf));
            hit = strstr(buf, q) != nullptr;
        }
        if (!hit && index_[i].scientific[0]) {
            squash(index_[i].scientific, buf, sizeof(buf));
            hit = strstr(buf, q) != nullptr;
        }
        if (!hit) continue;
        if (matched < max) out[matched] = i;
        matched++;
    }
    return matched;
}
