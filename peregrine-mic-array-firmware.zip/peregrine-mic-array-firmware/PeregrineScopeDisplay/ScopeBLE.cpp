#include "ScopeBLE.h"
#include "ScopeProtocol.h"
#include "ScopeState.h"
#include "ScopeStorage.h"
#include <Arduino.h>
#include <BLEDevice.h>
#include <host/ble_gap.h>
#include <host/ble_hs.h>
#include <host/ble_store.h>
#include <freertos/queue.h>

ScopeBLE gBLE;
void addDetection(const Detection &det); // ScopeLink.cpp

void fillDeviceId(uint8_t *out) {
    const uint64_t mac = ESP.getEfuseMac();
    for (int i = 0; i < 6; i++) out[i] = (uint8_t)(mac >> (8 * i));
}

namespace {

// ANCS (Apple's spec), little-endian for BLE_UUID128_INIT.
const ble_uuid128_t kAncsService = BLE_UUID128_INIT(0xD0, 0x00, 0x2D, 0x12, 0x1E, 0x4B, 0x0F, 0xA4, 0x99, 0x4E, 0xCE, 0xB5, 0x31, 0xF4, 0x05, 0x79); // 7905F431-B5CE-4E99-A40F-4B1E122D00D0
const ble_uuid128_t kAncsNotificationSource = BLE_UUID128_INIT(0xBD, 0x1D, 0xA2, 0x99, 0xE6, 0x25, 0x58, 0x8C, 0xD9, 0x42, 0x01, 0x63, 0x0D, 0x12, 0xBF, 0x9F); // 9FBF120D-6301-42D9-8C58-25E699A21DBD
const ble_uuid128_t kAncsControlPoint = BLE_UUID128_INIT(0xD9, 0xD9, 0xAA, 0xFD, 0xBD, 0x9B, 0x21, 0x98, 0xA8, 0x49, 0xE1, 0x45, 0xF3, 0xD8, 0xD1, 0x69); // 69D1D8F3-45E1-49A8-9821-9BBDFDAAD9D9
const ble_uuid128_t kAncsDataSource = BLE_UUID128_INIT(0xFB, 0x7B, 0x7C, 0xCE, 0x6A, 0xB3, 0x44, 0xBE, 0xB5, 0x4B, 0xD6, 0x24, 0xE9, 0xC6, 0xEA, 0x22); // 22EAC6E9-24D6-4BB5-BE44-B36ACE7C7BFB

constexpr uint8_t kAttrAppId = 0, kAttrTitle = 1, kAttrMessage = 3;
constexpr uint16_t kTitleMax = 96, kMessageMax = 160;

struct AncsNote {
    char app[64];
    char title[kTitleMax + 1];
    char message[kMessageMax + 1];
    bool preExisting; // already in Notification Center when we connected: logged, not listed
};
QueueHandle_t noteQueue = nullptr;

// Connection state (host task writes, main loop reads)
volatile uint16_t conn = BLE_HS_CONN_HANDLE_NONE;
uint16_t svcStart = 0, svcEnd = 0, nsHandle = 0, cpHandle = 0, dsHandle = 0, nsCccd = 0, dsCccd = 0;
// Every characteristic's declaration handle in the service, to bound each one's descriptor search.
uint16_t chrDefHandles[8];
int chrCount = 0;

// A characteristic's descriptors sit between its value handle and the next declaration.
uint16_t descriptorEnd(uint16_t valHandle) {
    uint16_t end = svcEnd;
    for (int i = 0; i < chrCount; i++) {
        if (chrDefHandles[i] > valHandle && chrDefHandles[i] - 1 < end) end = chrDefHandles[i] - 1;
    }
    return end;
}

// Data Source reassembly: one Get Notification Attributes reply at a time.
uint8_t dsBuf[512];
size_t dsLen = 0;

// Attribute requests go out one at a time: a second request mid-reply would reset the
// reassembly and lose the first notification (seen: 62 added, 60 read, while our own app
// posts every ~3 s). Host task only.
struct PendingUid { uint8_t uid[4]; bool preExisting; bool canClear; };
PendingUid pending[32];
uint8_t pendingHead = 0, pendingCount = 0;
bool requestInFlight = false;
bool inFlightPreExisting = false;
bool inFlightCanClear = false;
uint8_t inFlightUid[4];
uint32_t requestSentMs = 0;

// Advertising
enum class AdvMode { None, Connectable, DiscoveryOnly };
AdvMode advMode = AdvMode::None;
IPAddress advIP;
uint8_t discoveryPayload[14];

int gapEvent(struct ble_gap_event *event, void *arg);

void fillDiscovery(const IPAddress &ip) {
    discoveryPayload[0] = 'P';
    discoveryPayload[1] = 'P';
    fillDeviceId(&discoveryPayload[2]);
    discoveryPayload[8] = Protocol::kNodeTypeScopeDisplay;
    discoveryPayload[9] = 0; // no GPS, no BLE provisioning
    for (int i = 0; i < 4; i++) discoveryPayload[10 + i] = ip[i];
}

void stopAdvertising() {
    if (advMode != AdvMode::None) ble_gap_adv_stop();
    advMode = AdvMode::None;
}

void startAdvertising(AdvMode mode, const IPAddress &ip) {
    ble_gap_adv_stop();
    fillDiscovery(ip);
    // Connectable: the "I want notifications" solicitation goes in the advertisement itself (as in
    // Espressif's ble_ancs example -- iOS's Bluetooth settings look there), name too; the discovery
    // payload rides in the scan response. Discovery-only: just name + payload.
    static const char *kName = "PPScope";
    struct ble_hs_adv_fields fields = {};
    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    fields.name = (const uint8_t *)kName;
    fields.name_len = strlen(kName);
    fields.name_is_complete = 1;
    struct ble_hs_adv_fields rsp = {};
    if (mode == AdvMode::Connectable) {
        fields.sol_uuids128 = &kAncsService;
        fields.sol_num_uuids128 = 1;
        rsp.mfg_data = discoveryPayload;
        rsp.mfg_data_len = sizeof(discoveryPayload);
    } else {
        fields.mfg_data = discoveryPayload;
        fields.mfg_data_len = sizeof(discoveryPayload);
    }
    int rc = ble_gap_adv_set_fields(&fields);
    if (rc) { Serial.printf("[ble] adv fields rc=%d\n", rc); return; }
    rc = ble_gap_adv_rsp_set_fields(&rsp);
    if (rc) Serial.printf("[ble] scan response rc=%d\n", rc);
    struct ble_gap_adv_params params = {};
    params.conn_mode = mode == AdvMode::Connectable ? BLE_GAP_CONN_MODE_UND : BLE_GAP_CONN_MODE_NON;
    params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    params.itvl_min = 480; // 300 ms -- light on the radio Wi-Fi shares
    params.itvl_max = 640; // 400 ms
    rc = ble_gap_adv_start(BLE_OWN_ADDR_PUBLIC, nullptr, BLE_HS_FOREVER, &params, gapEvent, nullptr);
    if (rc) { Serial.printf("[ble] adv start rc=%d\n", rc); advMode = AdvMode::None; return; }
    Serial.printf("[ble] advertising (%s)\n", mode == AdvMode::Connectable ? "ready to pair / reconnect with the iPhone" : "discovery only");
    advMode = mode;
    advIP = ip;
}

void copyAttr(char *out, size_t cap, const uint8_t *data, uint16_t len) {
    size_t n = 0;
    for (uint16_t i = 0; i < len && n + 1 < cap; i++) {
        const uint8_t c = data[i];
        if (c >= 0x20 && c < 0x7F) out[n++] = (char)c; // LVGL fonts are ASCII; drop emoji/accents
        else if (c == '\n' && n) out[n++] = ' ';
    }
    out[n] = 0;
}

// Parses a complete Get Notification Attributes reply; false while more fragments are due.
bool parseDataSource() {
    if (dsLen < 5 || dsBuf[0] != 0) { dsLen = 0; return false; }
    AncsNote note = {};
    size_t pos = 5; // command id + notification uid
    int got = 0;
    while (got < 3) {
        if (pos + 3 > dsLen) return false;
        const uint8_t id = dsBuf[pos];
        const uint16_t len = dsBuf[pos + 1] | (dsBuf[pos + 2] << 8);
        if (pos + 3 + len > dsLen) return false;
        const uint8_t *val = dsBuf + pos + 3;
        if (id == kAttrAppId) copyAttr(note.app, sizeof(note.app), val, len);
        else if (id == kAttrTitle) copyAttr(note.title, sizeof(note.title), val, len);
        else if (id == kAttrMessage) copyAttr(note.message, sizeof(note.message), val, len);
        pos += 3 + len;
        got++;
    }
    dsLen = 0;
    note.preExisting = inFlightPreExisting;
    // Merlin rewrites ONE notification in place for each new bird, and iOS doesn't pass the rewrite
    // on to accessories (seen on hardware: the wren replaced the chickadee, no event; the iPhone even
    // kept serving the chickadee). Once Merlin's notification is gone it posts a fresh one, which does
    // reach us -- so clear each one (its negative action) as soon as we've read it.
    if (inFlightCanClear && strstr(note.app, "merlin")) {
        const uint8_t cmd[] = {0x02, inFlightUid[0], inFlightUid[1], inFlightUid[2], inFlightUid[3], 0x01};
        ble_gattc_write_flat(conn, cpHandle, cmd, sizeof(cmd), nullptr, nullptr);
        Serial.println("[ancs] cleared Merlin's notification on the iPhone so its next bird arrives as a new one");
    }
    if (noteQueue) xQueueSend(noteQueue, &note, 0);
    return true;
}

void requestAttributes(const uint8_t *uid) {
    const uint8_t cmd[] = {0x00, uid[0], uid[1], uid[2], uid[3],
                           kAttrAppId,
                           kAttrTitle, (uint8_t)(kTitleMax & 0xFF), (uint8_t)(kTitleMax >> 8),
                           kAttrMessage, (uint8_t)(kMessageMax & 0xFF), (uint8_t)(kMessageMax >> 8)};
    dsLen = 0;
    ble_gattc_write_flat(conn, cpHandle, cmd, sizeof(cmd), nullptr, nullptr);
}

void sendNextRequest() {
    if (requestInFlight || !pendingCount) return;
    const PendingUid &p = pending[pendingHead];
    inFlightPreExisting = p.preExisting;
    inFlightCanClear = p.canClear;
    memcpy(inFlightUid, p.uid, 4);
    requestInFlight = true;
    requestSentMs = millis();
    requestAttributes(p.uid);
    pendingHead = (pendingHead + 1) % 32;
    pendingCount--;
}

void enqueueRequest(const uint8_t *uid, bool preExisting, bool canClear) {
    if (requestInFlight && millis() - requestSentMs > 2000) requestInFlight = false; // reply never came
    if (pendingCount == 32) {
        Serial.println("[ancs] request queue full -- dropping a notification");
        return;
    }
    PendingUid &p = pending[(pendingHead + pendingCount) % 32];
    memcpy(p.uid, uid, 4);
    p.preExisting = preExisting;
    p.canClear = canClear;
    pendingCount++;
    sendNextRequest();
}

int onSubscribed(uint16_t connHandle, const struct ble_gatt_error *error, struct ble_gatt_attr *attr, void *arg);

void subscribe(uint16_t cccd, void *step) {
    const uint8_t on[2] = {0x01, 0x00};
    ble_gattc_write_flat(conn, cccd, on, sizeof(on), onSubscribed, step);
}

int onSubscribed(uint16_t connHandle, const struct ble_gatt_error *error, struct ble_gatt_attr *attr, void *arg) {
    if (error->status != 0) {
        // Usually "insufficient authorization": the iPhone hasn't allowed notifications yet.
        Serial.printf("[ancs] subscribe failed (status %d) -- allow \"Share System Notifications\" for PPScope on the iPhone\n", error->status);
        gState.ancsState = 4;
        return 0;
    }
    if (arg == (void *)1) { // Data Source done -> Notification Source
        subscribe(nsCccd, (void *)2);
    } else {
        gState.ancsState = 3;
        Serial.println("[ancs] receiving iPhone notifications");
    }
    return 0;
}

// NimBLE passes the search's start handle as chrValHandle, so search one characteristic at a time:
// Notification Source first (arg 1), then Data Source (arg 2).
int onDescriptor(uint16_t connHandle, const struct ble_gatt_error *error, uint16_t chrValHandle, const struct ble_gatt_dsc *dsc, void *arg) {
    static const ble_uuid16_t kCccd = BLE_UUID16_INIT(BLE_GATT_DSC_CLT_CFG_UUID16);
    if (error->status == 0) {
        if (ble_uuid_cmp(&dsc->uuid.u, &kCccd.u) == 0) {
            if (arg == (void *)1) nsCccd = dsc->handle;
            else dsCccd = dsc->handle;
        }
        return 0;
    }
    if (error->status != BLE_HS_EDONE) {
        Serial.printf("[ancs] descriptor search failed (status %d)\n", error->status);
        return 0;
    }
    if (arg == (void *)1) {
        ble_gattc_disc_all_dscs(conn, dsHandle, descriptorEnd(dsHandle), onDescriptor, (void *)2);
        return 0;
    }
    if (nsCccd && dsCccd && cpHandle) subscribe(dsCccd, (void *)1); // Data Source first (Apple's order)
    else Serial.printf("[ancs] notification characteristics incomplete (ns cccd %u, ds cccd %u, cp %u)\n", nsCccd, dsCccd, cpHandle);
    return 0;
}

int onCharacteristic(uint16_t connHandle, const struct ble_gatt_error *error, const struct ble_gatt_chr *chr, void *arg) {
    if (error->status == 0) {
        if (chrCount < 8) chrDefHandles[chrCount++] = chr->def_handle;
        if (ble_uuid_cmp(&chr->uuid.u, &kAncsNotificationSource.u) == 0) nsHandle = chr->val_handle;
        if (ble_uuid_cmp(&chr->uuid.u, &kAncsControlPoint.u) == 0) cpHandle = chr->val_handle;
        if (ble_uuid_cmp(&chr->uuid.u, &kAncsDataSource.u) == 0) dsHandle = chr->val_handle;
        return 0;
    }
    if (error->status == BLE_HS_EDONE) {
        if (nsHandle && dsHandle && cpHandle) ble_gattc_disc_all_dscs(conn, nsHandle, descriptorEnd(nsHandle), onDescriptor, (void *)1);
        else Serial.printf("[ancs] notification characteristics missing (ns %u ds %u cp %u)\n", nsHandle, dsHandle, cpHandle);
    }
    return 0;
}

int onService(uint16_t connHandle, const struct ble_gatt_error *error, const struct ble_gatt_svc *svc, void *arg) {
    if (error->status == 0) {
        svcStart = svc->start_handle;
        svcEnd = svc->end_handle;
        return 0;
    }
    if (error->status == BLE_HS_EDONE) {
        if (svcStart) ble_gattc_disc_all_chrs(conn, svcStart, svcEnd, onCharacteristic, nullptr);
        else { Serial.println("[ancs] the connected device has no notification service (not an iPhone?)"); gState.ancsState = 4; }
    }
    return 0;
}

// Starts the notification-service search once per connection. A bonded iPhone can re-encrypt so
// fast that ENC_CHANGE is handled BEFORE CONNECT (seen on hardware) -- either event may come first.
bool discoveryStarted = false;

void startDiscovery(uint16_t handle) {
    conn = handle;
    if (discoveryStarted) return;
    discoveryStarted = true;
    svcStart = svcEnd = nsHandle = cpHandle = dsHandle = nsCccd = dsCccd = 0;
    chrCount = 0;
    gState.ancsState = 2;
    gState.ancsPaired = true;
    Serial.println("[ble] link secured -- looking for the iPhone's notification service");
    ble_gattc_disc_svc_by_uuid(conn, &kAncsService.u, onService, nullptr);
}

int gapEvent(struct ble_gap_event *event, void *arg) {
    switch (event->type) {
        case BLE_GAP_EVENT_CONNECT:
            if (event->connect.status == 0) {
                conn = event->connect.conn_handle;
                advMode = AdvMode::None; // legacy advertising stops on connect
                if (discoveryStarted) return 0; // already secured (ENC_CHANGE came first)
                struct ble_gap_conn_desc desc;
                if (ble_gap_conn_find(conn, &desc) == 0 && desc.sec_state.encrypted) {
                    startDiscovery(conn);
                    return 0;
                }
                gState.ancsState = 1;
                Serial.println("[ble] iPhone connected -- securing the link");
                ble_gap_security_initiate(conn); // ANCS needs an encrypted, bonded link
            } else {
                advMode = AdvMode::None;
            }
            return 0;
        case BLE_GAP_EVENT_DISCONNECT:
            Serial.printf("[ble] iPhone disconnected (reason 0x%x)\n", event->disconnect.reason);
            conn = BLE_HS_CONN_HANDLE_NONE;
            advMode = AdvMode::None; // poll() restarts advertising
            discoveryStarted = false;
            pendingCount = 0;
            requestInFlight = false;
            dsLen = 0;
            gState.ancsState = 0;
            return 0;
        case BLE_GAP_EVENT_ENC_CHANGE:
            if (event->enc_change.status == 0) {
                startDiscovery(event->enc_change.conn_handle);
            } else {
                // Drop the half-open link so the iPhone reconnects and tries again (seen after a
                // reflash: status 13 timeout, then stuck "connecting" for good).
                Serial.printf("[ble] pairing failed (status %d) -- disconnecting so the iPhone retries\n", event->enc_change.status);
                ble_gap_terminate(event->enc_change.conn_handle, BLE_ERR_REM_USER_CONN_TERM);
            }
            return 0;
        case BLE_GAP_EVENT_REPEAT_PAIRING: {
            // The iPhone forgot us (or we forgot it): drop the old bond and pair fresh.
            struct ble_gap_conn_desc desc;
            if (ble_gap_conn_find(event->repeat_pairing.conn_handle, &desc) == 0) ble_store_util_delete_peer(&desc.peer_id_addr);
            return BLE_GAP_REPEAT_PAIRING_RETRY;
        }
        case BLE_GAP_EVENT_NOTIFY_RX: {
            uint8_t buf[256];
            uint16_t len = 0;
            if (ble_hs_mbuf_to_flat(event->notify_rx.om, buf, sizeof(buf), &len) != 0 && len == 0) return 0;
            if (event->notify_rx.attr_handle == nsHandle && len >= 8) {
                const uint8_t eventId = buf[0], flags = buf[1];
                gState.ancsCount++;
                Serial.printf("[ancs] notification event %u (flags 0x%02x, category %u)\n", eventId, flags, buf[2]);
                // Added. Ones already in Notification Center when we connected are read too, but only
                // logged (shows which apps' notifications reach us at all).
                if (eventId == 0) enqueueRequest(buf + 4, flags & 0x04, flags & 0x20); // 0x20: has a negative (clear) action
            } else if (event->notify_rx.attr_handle == dsHandle) {
                if (dsLen + len > sizeof(dsBuf)) dsLen = 0;
                memcpy(dsBuf + dsLen, buf, len);
                dsLen += len;
                if (parseDataSource()) {
                    requestInFlight = false;
                    sendNextRequest();
                }
            }
            return 0;
        }
        default:
            return 0;
    }
}

// Merlin notification -> bird names. Seen on hardware: title "Merlin heard a new bird!" with the
// name as the message, or "Merlin heard new birds!" with "Hermit Thrush, Red-breasted Nuthatch".
// Up to kMaxBirds names; "and" before the last one is dropped in case Merlin writes "A, B and C".
constexpr int kMaxBirds = 6;
int birdsFromMerlin(const AncsNote &n, String (&birds)[kMaxBirds]) {
    String title = n.title, message = n.message;
    title.trim();
    message.trim();
    String lower = title;
    lower.toLowerCase();
    String text = (title.length() && lower.indexOf("merlin") < 0) ? title : message;
    const int cut = text.indexOf(" - ");
    if (cut > 0) text = text.substring(0, cut);
    text.replace(" and ", ", ");
    int count = 0;
    while (text.length() && count < kMaxBirds) {
        const int comma = text.indexOf(',');
        String bird = comma < 0 ? text : text.substring(0, comma);
        text = comma < 0 ? String() : text.substring(comma + 1);
        bird.trim();
        if (bird.startsWith("and ")) bird = bird.substring(4);
        bird.trim();
        if (bird.length()) birds[count++] = bird;
    }
    return count;
}

} // namespace

void ScopeBLE::begin() {
    BLEDevice::init("PPScope");
    // Bonded, so the iPhone remembers the display and reconnects on its own (the BLE library
    // defaults to no bonding).
    ble_hs_cfg.sm_bonding = 1;
    ble_hs_cfg.sm_sc = 1;
    ble_hs_cfg.sm_mitm = 0;
    ble_hs_cfg.sm_io_cap = BLE_HS_IO_NO_INPUT_OUTPUT;
    ble_hs_cfg.sm_our_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.sm_their_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    noteQueue = xQueueCreate(8, sizeof(AncsNote));
    int bonds = 0;
    ble_store_util_count(BLE_STORE_OBJ_TYPE_OUR_SEC, &bonds);
    gState.ancsPaired = bonds > 0;
    Serial.printf("[ble] ready (%s)\n", bonds ? "paired with an iPhone" : "not paired -- pair from the iPhone's Bluetooth settings to get Merlin");
}

void ScopeBLE::poll(bool hasApp, bool wifiUp, const IPAddress &ip) {
    // Merlin notifications -> Heard list
    AncsNote note;
    while (noteQueue && xQueueReceive(noteQueue, &note, 0) == pdTRUE) {
        strlcpy(gState.ancsLastApp, note.app, sizeof(gState.ancsLastApp));
        String app = note.app;
        app.toLowerCase();
        if (note.preExisting) {
            if (app.indexOf("merlin") >= 0)
                Serial.printf("[ancs] already on the iPhone: %s title=\"%s\" message=\"%s\"\n", note.app, note.title, note.message);
            else
                Serial.printf("[ancs] already on the iPhone: %s\n", note.app);
            continue;
        }
        if (app.indexOf("merlin") < 0) {
            Serial.printf("[ancs] notification from %s (ignored)\n", note.app);
            continue;
        }
        Serial.printf("[ancs] MERLIN title=\"%s\" message=\"%s\"\n", note.title, note.message);
        String birds[kMaxBirds];
        const int count = birdsFromMerlin(note, birds);
        for (int i = 0; i < count; i++) {
            Detection det;
            det.common = birds[i];
            det.source = 1;
            det.nodeName = "Merlin";
            det.receivedMs = millis();
            addDetection(det);
            gState.merlinCount++;
            gStore.logEvent("merlin", birds[i]);
        }
    }

    // Advertising: connectable (for the iPhone) while it isn't connected; discovery-only while it is
    // and the app has lost the display's address.
    const bool connected = conn != BLE_HS_CONN_HANDLE_NONE;
    static uint32_t lastAdvAttemptMs = 0;
    const bool wantChange = !connected ? (advMode != AdvMode::Connectable || (wifiUp && ip != advIP))
                                       : (!hasApp && wifiUp) ? (advMode != AdvMode::DiscoveryOnly || ip != advIP)
                                                             : advMode != AdvMode::None;
    if (!wantChange) return;
    if (lastAdvAttemptMs && millis() - lastAdvAttemptMs < 5000) return; // a failed start retries every 5 s
    lastAdvAttemptMs = millis();
    if (!connected) {
        if (advMode != AdvMode::Connectable || (wifiUp && ip != advIP)) startAdvertising(AdvMode::Connectable, wifiUp ? ip : IPAddress());
    } else if (!hasApp && wifiUp) {
        if (advMode != AdvMode::DiscoveryOnly || ip != advIP) startAdvertising(AdvMode::DiscoveryOnly, ip);
    } else if (advMode != AdvMode::None) {
        stopAdvertising();
    }
}

void ScopeBLE::forgetPairing() {
    if (conn != BLE_HS_CONN_HANDLE_NONE) ble_gap_terminate(conn, BLE_ERR_REM_USER_CONN_TERM);
    ble_store_clear();
    gState.ancsPaired = false;
    gState.ancsState = 0;
    Serial.println("[ble] iPhone pairing forgotten");
}
