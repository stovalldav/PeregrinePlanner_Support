# PeregrineScopeDisplay — the Scope Display node

A touch display mounted on the spotting scope (design: `SCOPE_DISPLAY_PLAN.md` at the repo root). It
joins the fleet like any other node (node type 3) and shows what the app relays:

| Tab | What it does |
|---|---|
| **Birds** | Three views. **Heard:** each detection from Bird Sounds, newest first (`PEREGRINE` + confidence and which node heard it, `* LIFER` for a bird not on your life list before this session), plus Merlin's birds from the iPhone tagged `MERLIN`. **Targets:** the logged trip's checklist for where you are now ("n of N seen") — tap the box to check off, the name for the card; **New location (I've moved)** starts a fresh list. **Trip:** what you've seen at each location, newest first. **Cards:** every card on the SD card, alphabetical, with a search box (on-screen keyboard; matches any part of the common or scientific name, ignoring case/spaces/punctuation). Tap any bird for its card — field-guide text plus a photo, from the SD card when it's there, otherwise through the app. |
| **Radar** | Radar Mode's species around the scope (the scope always points up) and a big **"< 23 deg"** / **"ON TARGET"** arrow, with up/down when the target's elevation is known. Needs the BNO055 on the scope. |
| **Compass** | Heading-up compass rose with the scope's heading and tilt; true north once the app has sent declination and the scope is aligned, magnetic before that. Needs the BNO055. |
| **Fleet** | Every node's status (connection, GPS, compass calibration, presence sensor, camera). Tap a node for the **setup aid**: a live bearing needle, compass calibration and GPS while you stand at it. |
| **Camp** | Snapshot tiles for camera / security nodes, presence with the movement readout, **Siren / Stop / Snap**, and **Hold to talk** (to a tapped tile, or to all). A presence alert takes over the screen from any tab. Opening this tab turns on **Camp mode**. |
| **Session** | Session timer, species count, detections in the last 10 minutes, new lifers, recently heard. Also the display's own mic (**Sound detection** switch + **Mic level** slider and meter — it's a Bird Sounds sound source while on), SD card status, the Merlin / iPhone link (notification and Merlin counts, **Forget iPhone pairing**) and **Power off**. |

On the Birds tab, swipe a bird left to remove it, or tap **Clear** (under the Heard list) twice to empty it.

**Power off:** tap **Power off** on the Session tab (tap again within 3 s), or hold **BOOT** for 3 s.
Backlight, panel, touch, speaker amp, codec, BNO055 and Wi-Fi are shut down and the ESP32-S3 goes into
deep sleep; press **BOOT** (or RESET) to wake. Not a true zero-current off — the battery divider and
regulator still draw a little — and USB still charges.

**Trip checks offline:** checks and new locations made on the display are kept in NVS and sent to the
app in order, each acknowledged, so they survive the phone being out of range or the display being
turned off.

**Bird cards on the SD card:** with a microSD card (FAT32; SD_MMC 4-bit, pins in `Config.h`) cards
are cached in `/cards/`. In the app: the display's node › **Bird cards on the display** › pick the
Area (where I am / the Plan screen's search area / a planned trip) and radius › **Load bird cards for
this area**. The display then pulls each missing card through the app, one at a time (~1–2 s each),
so keep the app open and online until it says Done. Tapped cards are saved too. `/cards/index.tsv`
keeps each card's real name for the Cards view (file names drop punctuation); cards saved before it
existed are named from the file until the real name turns up (a detection, a target, or loading cards
again).

**Merlin via iPhone notifications (ANCS):** the display is also a Bluetooth notification accessory.
Pair once: iPhone Settings › Bluetooth › **PPScope** › allow notifications (if PPScope isn't listed
under Other Devices, connect once from nRF Connect, then tap it under My Devices). Run Merlin's Sound
ID in the background (phone locked or another app open). Merlin rewrites ONE notification per new
bird and iOS sends accessories nothing for a rewrite, so the display clears each Merlin notification
(ANCS negative action) once it has read it — Merlin then posts a fresh one for the next bird. The bird
is the message ("Merlin heard new birds!" lists several, comma-separated, each its own entry). Other
apps' notifications are ignored and never stored.

**Network changes:** while the app isn't linked, the display advertises itself over BLE (as other
nodes do), so the app re-finds it at a new IP when it moves to another network (e.g. a phone hotspot).

## Hardware

**Freenove ESP32-S3 Display 4.0" (FNK0104S)** — ST7796 320×480, FT6336U capacitive touch, ES8311
codec + MEMS mic + speaker amp, TP4054 LiPo charger, WS2812, microSD. Pins are in `Config.h` and
were taken from Freenove's schematic and example sketches, not guessed.

**BNO055 (scope compass):** a GY-BNO055 on the board's **I2C header** (SDA GPIO16 / SCL GPIO15, 3V3,
GND). It shares the bus with the touch chip (0x38) and the codec (0x18); the BNO055 answers at 0x28
or 0x29 and both are tried. Mount it **rigidly on the scope body**, square to the scope, and **away
from the speaker magnet and the battery leads**. Set `Config::kScopeAxis` to the sensor axis that
points down the scope's line of sight (default +X).

**Battery:** single-cell 3.7 V LiPo on the 2-pin battery port; it charges from USB-C (~0.3 A, so a
3000 mAh cell takes ~10 h). **Check polarity with a meter before the first plug-in** — LiPo leads
aren't consistent and a reversed cell can kill the charger.

## Libraries (one-time setup)

Freenove's own bundle (`Libraries/FNK0104S/` in github.com/Freenove/Freenove_ESP32_S3_Display):

1. Unzip **TFT_eSPI_v2.5.43**, **lvgl_v8.4.0**, **TJpg_Decoder_v1.1.0** into your Arduino
   `libraries/` folder. Also unzip **TFT_eSPI_Setups_v1.2** there — Freenove's TFT_eSPI selector
   includes its setups from that sibling folder, and it already selects `FNK0104S_4P0_320x480_ST7796`.
2. LVGL: Freenove's bundle has its own `lvgl/src/lv_conf.h`, which LVGL picks up first. Copy this
   folder's `lv_conf.h` **over `libraries/lvgl/src/lv_conf.h`** (keep theirs as a backup) — it adds
   the 12–48 pt fonts and the dark theme this UI uses.
3. `arduino-cli lib install "Adafruit BNO055"` (pulls Adafruit Unified Sensor + BusIO).

Not used: Freenove's FT6336U library (it sleeps 10 ms per register read — touch is read directly).

## Build & flash

Board **ESP32S3 Dev Module**, Flash 16 MB, **PSRAM OPI**, Partition **Huge APP**:

```
arduino-cli compile --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,PartitionScheme=huge_app" PeregrineScopeDisplay
arduino-cli upload  --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,PartitionScheme=huge_app,UploadSpeed=115200" -p <port> PeregrineScopeDisplay
```

Wi-Fi: put your networks in a gitignored `Config.local.h` copy (same pattern as the node firmware)
and build from that; the tracked `Config.h` keeps only the shipped default (`PeregrineMicArray`).

## In the app

1. Mic Array tab › Fleet › **Add Node**, type **Scope Display**, address = the IP shown in the
   display's status strip. The strip's **Phone** indicator turns green once the app connects.
2. Edit the node › **Scope alignment**: stand at the scope, aim it at another node (or anything whose
   true bearing you know) and tap **Align**. The Radar tab then says "aligned". Redo it whenever the
   display or compass is remounted.
3. Calibrate the compass: move the scope slowly in a figure-8 until the Radar tab shows `cal 3/3`.

## How it talks to the fleet

- **Through the app:** detections, cards, targets, fleet status, the setup aid's live node, session
  stats, presence, and siren commands. A node streams to exactly one client (the phone), so the display
  never opens a session with another node — relayed features need the app running.
- **Directly:** hold-to-talk audio goes display → security node (`kPlaybackAudioFrame`, accepted from
  any sender), and snapshots are plain HTTP `GET /snapshot` from camera nodes — both work with the
  phone off.
- Packet formats: `ScopeProtocol.h`. Mirrored in the app: `Stores/ScopeDisplayRelay.swift` (`ScopeWire`).

**Camp mode** (Camp tab open): the scope compass is paused, Wi-Fi power-save is off (it adds 100 ms+
latency bursts), the app stops sending targets/session stats and slows fleet status to every 10 s,
and snapshots pause while Talk is held. Security nodes pause their own mic upload while their speaker
plays your voice, buffer ~60 ms before playing, and let only one talker at a time use the speaker.

## Known limitations

- **Fonts are ASCII only** — the app folds names and card text to ASCII before sending.
- **Guidance accuracy:** a scope at 20–60× sees ~1–2°; a single node's bearing is good to several
  degrees at best, and a lone 2-mic node can't tell front from back (those targets show a `?`). The
  arrow gets you facing the right way; then scan at the lowest zoom.
- Node IP addresses must be entered as IPs (not hostnames) for snapshots, talk and siren to find them.
- Merlin's birds only arrive while Merlin posts real notifications (running in the background);
  birds it shows on its own screen while open never reach the display.
- Running on real hardware since 2026-10-02 (Wi-Fi link, SD card downloads and Merlin confirmed
  on the board).
