// ScopeUI.h -- the touch interface (LVGL 8.4 on TFT_eSPI, FT6336U touch). SCOPE_DISPLAY_PLAN.md §5:
// a status strip on top (battery, Wi-Fi, phone link) and a bottom tab bar --
// Birds · Radar · Fleet · Camp · Session.
//
//   Birds   -- detections relayed by the app, newest first; tap one for its bird card (§3)
//   Radar   -- Radar Mode targets around the scope + "turn right 23° · up 4°" arrow (§4)
//   Fleet   -- every node's status; tap one for the live setup aid (§6.1, §6.3)
//   Camp    -- security-node tiles, presence, siren, hold-to-talk; entering it turns on Camp mode
//              (§6.2, §6.2.1, §6.2.2)
//   Session -- trip timer, species count, recent birds, new lifers (§6.4)
#pragma once

#include <Arduino.h>

class ScopeUI {
public:
    void begin();
    // Runs LVGL and refreshes whatever changed in gState. Call every loop().
    void update(uint32_t nowMs);
    // Any touch -> backlight back to full (and dims again after Config::kDimAfterMs).
    void noteTouch(uint32_t nowMs);

    // Power-off: a full-screen "Powering off" note, then the panel to sleep and the backlight off,
    // and the touch controller into hibernate (its reset pulse on the next boot wakes it).
    void showPowerOff();
    void sleepHardware();
};

extern ScopeUI gUI;
