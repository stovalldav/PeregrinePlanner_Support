// PeregrineScopeDisplay -- the Scope Display node: a Freenove ESP32-S3 4.0" touch display (FNK0104S)
// on the spotting scope. See SCOPE_DISPLAY_PLAN.md (repo root) and README.md here.
//
// Joins the fleet like any node (nodeType 3) and shows what the phone relays: detections + bird
// cards, Radar Mode guidance for the scope (with a BNO055 on the scope), fleet status + a live
// setup aid, the camp security console with hold-to-talk, and a session dashboard.
//
// Core use: loop() (core 1) runs LVGL, the fleet link, the compass and the battery. The talk task
// and the snapshot task run on core 0 so a slow UI frame never delays your voice or a download.

#include <Arduino.h>
#include <Preferences.h>
#include <WiFi.h>
#include <Wire.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <esp_sleep.h>
#include "Config.h"
#include "JpegImage.h"
#include "ScopeCompass.h"
#include "ScopeBLE.h"
#include "ScopeLink.h"
#include "ScopeState.h"
#include "ScopeStorage.h"
#include "ScopeUI.h"
#include "SnapshotFetcher.h"
#include "TalkAudio.h"

ScopeState gState;

namespace {

uint32_t lastBatteryMs = 0;
uint32_t lastLedMs = 0;

// Single-cell LiPo, resting voltage -> rough percent. Under load or while charging it reads high;
// it's a gauge, not a fuel meter.
int batteryPercent(float v) {
    if (v < 2.5f) return -1; // nothing on the battery port (running from USB)
    static const float curve[][2] = {{4.20f, 100}, {4.05f, 85}, {3.95f, 70}, {3.85f, 55}, {3.78f, 40}, {3.72f, 25}, {3.65f, 12}, {3.50f, 4}, {3.30f, 0}};
    if (v >= curve[0][0]) return 100;
    for (size_t i = 1; i < sizeof(curve) / sizeof(curve[0]); i++) {
        if (v >= curve[i][0]) {
            const float t = (v - curve[i][0]) / (curve[i - 1][0] - curve[i][0]);
            return (int)roundf(curve[i][1] + t * (curve[i - 1][1] - curve[i][1]));
        }
    }
    return 0;
}

void readBattery(uint32_t now) {
    if (lastBatteryMs && now - lastBatteryMs < Config::kBatteryReadIntervalMs) return;
    lastBatteryMs = now;
    uint32_t mv = 0;
    for (int i = 0; i < 8; i++) mv += analogReadMilliVolts(Config::kBatteryADC);
    gState.batteryVolts = (mv / 8.0f) * 2.0f / 1000.0f; // 100k/100k divider
    gState.batteryPercent = batteryPercent(gState.batteryVolts);
}

// One dim WS2812: green = phone linked, blue = Wi-Fi only, amber = no Wi-Fi, red = recent presence
// alert. Kept very dim so it doesn't light up the scope at night.
void updateLed(uint32_t now) {
    if (now - lastLedMs < 500) return;
    lastLedMs = now;
    bool alert = false;
    for (int i = 0; i < gState.fleetCount; i++) {
        const uint32_t t = gState.fleet[i].presence.lastAlertMs;
        if (t && now - t < 10000) alert = true;
    }
    if (alert) rgbLedWrite(Config::kRGBLed, (now / 500) % 2 ? 24 : 0, 0, 0);
    else if (gState.appLinked(now, Config::kAppLinkTimeoutMs)) rgbLedWrite(Config::kRGBLed, 0, 4, 0);
    else if (gState.wifiConnected) rgbLedWrite(Config::kRGBLed, 0, 0, 4);
    else rgbLedWrite(Config::kRGBLed, 4, 2, 0);
}

} // namespace

void saveMicSetting(bool on) {
    Preferences prefs;
    prefs.begin("scope", false);
    prefs.putBool("mic", on);
    prefs.end();
}

void saveMicGain(int db) {
    Preferences prefs;
    prefs.begin("scope", false);
    prefs.putInt("gain", db);
    prefs.end();
}

static void loadMicSetting() {
    Preferences prefs;
    prefs.begin("scope", true);
    gState.micStreamEnabled = prefs.getBool("mic", Config::kMicStreamDefault);
    gState.micGainDb = constrain(prefs.getInt("gain", Config::kMicGainDb), 0, 42) / 6 * 6;
    prefs.end();
}

// ---- Power off (deep sleep; BOOT wakes) ----
// There's no power switch on the board. "Off" = everything that draws current shut down, then the
// ESP32-S3 in deep sleep with BOOT (GPIO0) as the wake button. Not zero -- the battery divider and
// LDO still draw a little -- but a fraction of a mA (estimated, not measured). USB still charges.
namespace {
volatile bool powerOffRequested = false;
uint32_t bootPressedSinceMs = 0;
}

void requestPowerOff() { powerOffRequested = true; }

static void powerOff(const char *why) {
    Serial.printf("[power] off (%s) -- press BOOT to wake\n", why);
    gState.poweringOff = true;
    gTalk.stopTalk();
    gUI.showPowerOff();
    delay(800);
    while (digitalRead(Config::kBootKey) == LOW) delay(10); // released, or it would wake at once
    delay(50);

    gTalk.shutdown();
    gCompass.suspend();
    gUI.sleepHardware();
    rgbLedWrite(Config::kRGBLed, 0, 0, 0);
    WiFi.disconnect(true);
    WiFi.mode(WIFI_OFF);

    // Keep the speaker amp shut down through sleep (its pin would otherwise float).
    digitalWrite(Config::kAmpEnable, HIGH);
    gpio_hold_en((gpio_num_t)Config::kAmpEnable);
    gpio_deep_sleep_hold_en();

    rtc_gpio_pullup_en((gpio_num_t)Config::kBootKey);
    rtc_gpio_pulldown_dis((gpio_num_t)Config::kBootKey);
    esp_sleep_enable_ext0_wakeup((gpio_num_t)Config::kBootKey, 0); // BOOT pressed = LOW
    Serial.flush();
    esp_deep_sleep_start();
}

static void pollPowerButton(uint32_t now) {
    if (powerOffRequested) powerOff("Power off button");
    if (digitalRead(Config::kBootKey) == LOW) {
        if (!bootPressedSinceMs) bootPressedSinceMs = now;
        if (now - bootPressedSinceMs >= 3000) powerOff("BOOT held 3 s");
    } else {
        bootPressedSinceMs = 0;
    }
}

void setup() {
    Serial.begin(115200);
    delay(200);
    Serial.println("\n[boot] Peregrine Scope Display");
    // Coming back from power-off: release the amp pin's sleep hold so it can be driven again.
    gpio_hold_dis((gpio_num_t)Config::kAmpEnable);
    gpio_deep_sleep_hold_dis();
    if (esp_sleep_get_wakeup_cause() == ESP_SLEEP_WAKEUP_EXT0) Serial.println("[boot] woken by BOOT");
    pinMode(Config::kBootKey, INPUT_PULLUP);
    // BOOT still held from the wake press: don't let it count toward the 3 s power-off hold.
    while (digitalRead(Config::kBootKey) == LOW) delay(10);

    Wire.begin(Config::kI2CSDA, Config::kI2CSCL, Config::kI2CHz);
    analogReadResolution(12);
    rgbLedWrite(Config::kRGBLed, 0, 0, 4);

    loadAlignment();
    loadMicSetting();
    // SD card (optional): bird-card cache + the last target list / trip history, so both show even
    // if the phone is out of reach after a reboot. Then whatever was still waiting for the phone.
    gStore.begin();
    gStore.loadTargetList();
    gStore.loadHistory();
    gLink.beginOutbox();
    jpegInit();
    gUI.begin();
    Serial.println("[boot] display + touch ready");

    if (!gTalk.begin()) Serial.println("[boot] audio unavailable");
    if (Config::kCompassEnabled) gCompass.begin();
    gLink.begin();
    gBLE.begin();
    gSnapshots.begin();
    readBattery(millis());
    Serial.printf("[boot] battery %.2f V (%d%%)\n", gState.batteryVolts, gState.batteryPercent);
    Serial.println("[boot] ready");
}

void loop() {
    const uint32_t now = millis();
    static uint32_t lastLoopMs = 0;
    if (lastLoopMs && now - lastLoopMs > gState.loopMaxMs) gState.loopMaxMs = now - lastLoopMs;
    lastLoopMs = now;
    // Each step gets a fresh millis(): a step can stamp times (a packet's arrival, a tap) later than
    // a `now` read at the top, and `later - earlier` must never be computed the other way round.
    gLink.poll(millis());
    gBLE.poll(gState.appLinked(millis(), Config::kAppLinkTimeoutMs), gState.wifiConnected, gState.myIP);
    gCompass.poll(millis());
    gStore.poll(millis());
    readBattery(millis());
    updateLed(millis());
    pollPowerButton(millis());
    gUI.update(millis());
    delay(2);
}
