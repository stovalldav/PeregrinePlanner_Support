#include "C4001Reader.h"
#include <Arduino.h>
#include <cstdlib>
#include <cstring>

void C4001Reader::begin(HardwareSerial &serial, int rxPin, int txPin, uint32_t baud) {
    serial_ = &serial;
    serial_->begin(baud, SERIAL_8N1, rxPin, txPin);
    // Real init sequence, confirmed 2026-09-22 against DFRobot's own DFRobot_C4001 library source
    // (setSensorMode() in DFRobot_C4001.cpp) -- "sensorStart" alone (the old code here) starts
    // continuous output, but never explicitly selects presence/"exist" mode or commits it, so the
    // module keeps whatever mode and config it already had. Mirrors the vendor library's own
    // sequence and delays exactly: stop, select exist mode, save, start.
    stopSensor();
    serial_->print("setRunApp 1\r\n"); // speed/distance mode ("setRunApp 0" is presence-only, no range)
    delay(100);
    serial_->print("saveConfig\r\n");
    delay(500);
    serial_->print("sensorStart\r\n");
    delay(200);
}

// Collects replies for up to `ms`; true once a line contains `needle`.
bool C4001Reader::readUntil(const char *needle, uint32_t ms) {
    char buf[96];
    size_t len = 0;
    const uint32_t start = millis();
    while (millis() - start < ms) {
        while (serial_->available()) {
            char ch = (char)serial_->read();
            if (ch == '\n' || ch == '\r') {
                if (len == 0) continue;
                buf[len] = '\0';
                len = 0;
                if (strstr(buf, needle) != nullptr) return true;
            } else if (len < sizeof(buf) - 1) {
                buf[len++] = ch;
            }
        }
        delay(5);
    }
    return false;
}

// The module ignores a single "sensorStop" while it's streaming -- seen on node 3 2026-10-20: the
// following "sensorStart" answered "sensor started already", so it had never stopped, and the
// mode/range commands sent in between didn't take. DFRobot's own sensorStop() resends every 400 ms
// until the module echoes "sensorStop" back; mirrored here, bounded at ~7 s instead of forever.
// Confirmed on node 3: acknowledged on attempt 1-2 at every boot after this change.
bool C4001Reader::stopSensor() {
    for (int attempt = 1; attempt <= 15; attempt++) {
        serial_->print("sensorStop\r\n");
        if (readUntil("sensorStop", attempt == 1 ? 1000 : 400)) {
            readUntil("Done", 300);
            delay(100);
            while (serial_->available()) serial_->read();
            return true;
        }
    }
    Serial0.println("[c4001] sensorStop never acknowledged -- mode/range settings may not apply");
    return false;
}

bool C4001Reader::setMaxRangeCm(uint16_t cm) {
    if (!serial_) return false;
    if (cm < 30) cm = 30;
    if (cm > 2500) cm = 2500;
    maxRangeCm_ = cm; // also enforced in parseReportLine(), as for the C4002
    stopSensor();
    serial_->printf("setRange 0.3 %.1f\r\n", cm / 100.0f);
    delay(200);
    serial_->print("saveConfig\r\n");
    delay(500);
    serial_->print("sensorStart\r\n");
    delay(200);
    lineLen_ = 0;
    Serial0.printf("[c4001] range 0.3-%.1f m sent\n", cm / 100.0f);
    return true;
}

bool C4001Reader::poll() {
    if (!serial_) return false;
    bool gotReport = false;
    while (serial_->available()) {
        char c = (char)serial_->read();
        charsProcessed_++;
        if (c == '\n' || c == '\r') {
            if (lineLen_ > 0) {
                lineBuf_[lineLen_] = '\0';
                if (parseReportLine(lineBuf_)) {
                    linesParsed_++;
                    lastReportMs_ = millis();
                    gotReport = true;
                } else {
                    linesUnparsed_++;
                    // TEMPORARY bring-up diagnostic -- dump the real raw line (escaped) and its hex
                    // bytes so the actual wire format can be read off the console instead of guessed
                    // at. Remove once parseReportLine() is confirmed against real captures.
                    Serial0.print("[c4001-raw] text: \"");
                    for (size_t i = 0; i < lineLen_; i++) {
                        char c = lineBuf_[i];
                        if (c >= 32 && c < 127) Serial0.print(c);
                        else Serial0.printf("\\x%02X", (unsigned char)c);
                    }
                    Serial0.print("\"  hex:");
                    for (size_t i = 0; i < lineLen_; i++) {
                        Serial0.printf(" %02X", (unsigned char)lineBuf_[i]);
                    }
                    Serial0.println();
                }
                lineLen_ = 0;
            }
        } else if (lineLen_ < kLineBufSize - 1) {
            lineBuf_[lineLen_++] = c;
        } else {
            // Line too long for the buffer (garbage, or a format wildly different from what's
            // assumed) -- drop it and resync on the next newline rather than overflow.
            lineLen_ = 0;
            linesUnparsed_++;
        }
    }
    return gotReport;
}

bool C4001Reader::parseReportLine(const char *line) {
    // Speed/distance mode, confirmed 2026-09-22 directly against DFRobot's own DFRobot_C4001
    // library source (anaysisData()'s "$DFDMD" branch in DFRobot_C4001.cpp) -- not a guess.
    // Switched here from this file's earlier exist/presence-only mode ("$DFHPD", setRunApp 0)
    // specifically because that mode never reports a distance at all; this one does, at the cost
    // of a slightly less direct presence signal (inferred from target count, not a dedicated flag).
    //
    // Sentence: "$DFDMD,par1,par2,par3,par4,par5,par6,par7*". Per the vendor library's own field
    // use: par1 = target count (int), par3 = range in meters, par4 = speed, par5 = energy -- par2,
    // par6, par7 are read by nothing in the vendor library either and are ignored here too. The
    // vendor library multiplies the raw range by 100 to store centimeters, mirrored below.
    if (strncmp(line, "$DFDMD,", 7) != 0) return false;

    const char *p = line + 7; // just after "$DFDMD,"
    const char *fields[7] = {nullptr};
    int fieldIndex = 0;
    fields[0] = p;
    while (*p && fieldIndex < 6) {
        if (*p == ',') {
            fieldIndex++;
            fields[fieldIndex] = p + 1;
        }
        p++;
    }
    // Need at least par1 (index 0) and par3 (index 2) present to trust this sentence.
    if (fieldIndex < 2) return false;

    int targetCount = atoi(fields[0]);
    float rangeM = atof(fields[2]);
    presence_ = targetCount > 0;
    distanceCm_ = presence_ ? rangeM * 100.0f : 0.0f;
    if (presence_ && maxRangeCm_ > 0 && distanceCm_ > maxRangeCm_) {
        presence_ = false;
        distanceCm_ = 0.0f;
    }
    speedMps_ = (presence_ && fieldIndex >= 3) ? (float)atof(fields[3]) : 0.0f;
    return true;
}
