# Peregrine Camping Security Node Firmware

A 2x INMP441 mic pair, OV5640 camera, DFRobot C4001 (SEN0609) **or** C4002 (SEN0691) mmWave presence sensor, and NULLLAB
NS4168 speaker, on a GOOUUU ESP32-S3-CAM V1.5 board. See `CAMPING_SECURITY_NODE_PLAN.md` (repo
root) for the full design this implements, including the real-hardware pin-budget derivation.

**Status: compile-verified only, as of 2026-09-18. Nothing flashed to real hardware yet** — this
tree was built from the plan doc before the physical board/parts arrived. Per this project's own
hardware-debugging rule (real-device evidence only, no guessing ahead of data), treat every design
decision below as a hypothesis to confirm on first bring-up, not a settled fact — the two flagged
"UNVERIFIED" items below (camera D-line order, C4001 wire protocol) are the most likely to need a
real fix, not just confirmation.

## What's the same as the sibling firmware, and what's new

The I2S capture, onset gate, and DOA cross-correlation pipeline (`I2SCapture.*`, `OnsetDetector.*`,
`DOAEstimator.*`, `RingBuffer.h`), the camera/photo-serving HTTP pattern, video recording, live
MJPEG preview, and the Wi-Fi/BLE/roster plumbing (`UDPStreamer.*`, `WiFiConfigStore.*`,
`BLEAdvertiser.*`, `NodeRoster.*`) are all copied from `../PeregrineMicArrayCam/` and adapted, not
reimplemented from scratch — see that tree's own files for the original real-hardware history
behind each piece.

**Genuinely new here:**
- **`C4001Reader.h/.cpp`** — the C4001 presence sensor (9600-baud `$DF…` text sentences).
  Wire protocol confirmed on real hardware 2026-09-22 — see the file's own header comment.
- **`C4002Reader.h/.cpp`** — the C4002 presence sensor (added 2026-09-26): 115200-baud binary
  frames, protocol taken from DFRobot's own `DFRobot_C4002` library. Confirmed on real hardware
  2026-09-30 (two nodes). `PresenceSensor.h` is the shared interface; `loop()` doesn't care which
  one is fitted. `PresenceConfigStore.h` keeps the app-set range/hold time in NVS.
- **`AudioOutput.h/.cpp`** — the NS4168 speaker's I2S TX path. The first audio *output* peripheral
  in this codebase (every other I2S bus in any Peregrine firmware is a capture/RX path). Serves a
  synthesized alarm tone (bounded to `Config::kAlarmAutoStopMs` since `kSoundAlarm` has no
  corresponding stop packet) and "speak through the node" phone→device playback
  (`kPlaybackAudioFrame`, the first reverse-direction audio packet in the wire protocol).
- **`PhotoServer.h/.cpp`** — diverged from the sibling firmware's SD-only version: probes for an SD
  card once at boot (`videoRecorder.beginSD()`) and picks a backend transparently. SD present →
  byte-identical behavior to the sibling firmware (real video recording works). No card → a small
  in-PSRAM photo ring (`Config::kRamPhotoRingCapacity`), lost on reboot, stills only.
- **`NodeMode.h`** — Birding / Camping Security / Home Security, set at runtime via `kSetNodeMode`
  (no on-device persistence, same convention as every other runtime toggle in this codebase).
- **`MQTTConfigStore.h/.cpp` + `HomeAssistantMQTT.h/.cpp`** — Home Security mode's Home Assistant
  integration, via `PubSubClient` (new dependency: `arduino-cli lib install PubSubClient`). MQTT
  discovery for `binary_sensor` (presence), `button` (Sound Alarm), and `switch` (camera on/off) --
  all real, zero-YAML entities. The `camera` entity is deliberately **not** MQTT-discovered (see
  `HomeAssistantMQTT.h`'s header comment for why that's not actually possible as originally scoped)
  -- stays a one-time manual YAML `generic` platform entry pointing at `GET /snapshot`, same as this
  project's existing Feeder Cam Mode (`HOME_ASSISTANT.md`). Config is NVS-backed with no staged/
  commit/rollback dance (unlike `WiFiConfigStore`) since a bad MQTT config can never strand the node
  off the network the way a bad Wi-Fi config could.

**Not present here at all** (see `Config.h`'s header comment for the GPIO derivation): no GPS/PPS
(confirmed deliberate — this board's camera claims the FORIOT board's own top-bus pin trio, so
there's no second mic pair option and no spare pins for a GPS module either), no 4-mic/stereo path,
no feeder-cam mode (Home Security mode's MQTT integration is the intended replacement for that use
case on this variant, once built).

## Presence sensor: C4001 or C4002

Both go on the same UART pins — **GPIO14 ← sensor TX, GPIO21 → sensor RX** — and only one is
fitted per node. One firmware build serves both: with `Config::kPresenceSensorType = kAuto` (the
default) the node probes for a C4002 at boot and falls back to the C4001 if nothing answers. Set it
to `kC4001` or `kC4002` to skip detection.

| | C4001 (SEN0609) | C4002 (SEN0691) |
|---|---|---|
| VCC | 3.3V | **5V pin** (needs 3.6–5.5V — not 3V3) |
| Baud | 9600 | 115200 |
| Range | 25 m (~82 ft) | 11 m (~36 ft) |

**Before connecting a C4002's TX to GPIO14:** DFRobot doesn't publish its UART logic level. Their
own ESP32 wiring table connects it directly, but measure its TX pin with a multimeter first — it
should idle around 3.3V. If it's near 5V, add a divider (e.g. 10k/20k) on that line.

The boot log names the sensor it found — `[boot] presence sensor: C4002 (auto-detected)` — and the
2-second status line shows `[presence-link] C4002  chars: …  reports parsed: …`. `chars` climbing
with `reports parsed` stuck at 0 means bytes are arriving but not parsing; `chars` at 0 means nothing
is arriving (power, or TX/RX swapped). The app's node page shows "C4002 sensor" once connected.

**No sensor, or one that stops reporting:** both sensors report continuously even with nobody
around, so after `Config::kPresenceSensorSilenceMs` (10 s) with no report the node logs
`[presence] no C4001 reports for 10s -- sensor missing, unpowered, or unplugged`, flags it to the app
(the Camera Console shows "Presence sensor offline" in amber, and an armed node sends a one-time
notification), and marks Home Assistant's Presence entity **unavailable** rather than "clear".
Everything else on the node keeps working. It clears on its own when reports resume. (With no
sensor at all, auto-detect falls back to "C4001", so that's the name the message uses.)

### Detection range, hold time, and the live movement readout (2026-09-30)

- **Range** — anything farther than this is ignored. Set it to the far edge of the area you want
  watched: 24 GHz radar goes through interior walls, so on the full range a node sees people moving
  in the next room. Starts at `Config::kC4002MaxRangeCm` (default 1100 = the C4002's full 11 m) and
  is then set from the app (the node's Camera Console page → **Detection range**). **The node
  enforces it itself**: a C4002 was seen acknowledging a 460 cm range and still reporting targets at
  580–660 cm, so readings past the range are dropped in firmware too.
- **Hold time** (C4002 only, "Clear after" in the app) — how long the sensor keeps reporting a target
  after it loses it. Starts at `Config::kC4002TargetDisappearDelayS` (5 s; the module's own default
  was 15 s). While the sensor is only running this timer out, the node reports **Clearing** instead
  of "standing still", and those reports don't fire an alert, photo, or siren.
- Both are saved on the node (NVS) the moment the app changes them, so they survive a power cut with
  no phone around; the `Config.h` values only apply until the first change.
- **Movement** — about once a second while someone's there, the node sends distance, speed, and
  approaching / moving away (`kPresenceUpdate`). Both sensors measure movement **along the beam
  only**: someone walking straight across in front reads as still / "moving across". The C4002
  reports which way; the C4001 only a speed (DFRobot doesn't document its sign — the node logs the
  signed value as `[presence-link] C4001 raw speed …` so it can be checked on a real walk-up).
- The C4001 range command (`setRange`, from DFRobot's library) **hasn't been run on a real C4001
  yet**; the C4002's has.
- Chasing ghost detections: every C4002 status change is logged as `[c4002-diag]` with the raw
  distance, energy (0–99), range gates, and hold countdown — a fixed object that keeps triggering
  shows up as the same distance every time.

## Optional compass: BNO055 (added 2026-09-28)

Gives this GPS-less node a live heading and full 3-D orientation (tilt/vertical detection), in
place of a Fixed Pin heading that goes wrong if the node is bumped. In the app use Heading Source
**Compass** plus a pinned position.

| BNO055 | ESP32 |
|---|---|
| SDA | **GPIO20** (spare native-USB D+) |
| SCL | **GPIO48** |
| VIN | 3.3V |
| GND | GND |

**GPIO48 also drives the board's onboard RGB LED (WS2812).** I2C traffic makes it flash random
colours, which gives away a hidden node at night. Cut the LED's data trace, or remove the LED,
first. With the compass wired, the board has **no spare GPIO left**. Set
`Config::kCompassEnabled = true`. The boot log shows `checkpoint 5a2`, and every second the
`[compass] heading … calibration …` line. The node tries I2C address 0x28 and then 0x29 (both GY-BNO055
boards built so far answered at **0x29**); if neither answers it logs a scan of the whole bus, and
"nothing on the bus" means power, ground, or SDA/SCL wiring. Do a slow figure-8 with the node until
the magnetometer calibration reads 3/3 before trusting the heading.

## Camera orientation

`Config::kCameraVFlip` and `Config::kCameraHMirror` (both `true` by default) rotate the image 180°
for the portrait enclosure layout with the camera at the top. If your image comes out upside down,
set both to `false`; if it's mirrored (text reads backwards), change only `kCameraHMirror`. Applied
at every camera start, including after the app turns the camera off and on.

## Flashing

Same `arduino-cli`/Arduino IDE workflow as the sibling firmware:
`esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,PartitionScheme=huge_app` (Partition Scheme **must**
be >=3MB, e.g. "Huge APP" — the default 1.2MB scheme is too small). Edit `Config.h`'s WiFi
candidates / `kNetworkRole` / `kFleetId` for your own fleet before flashing, same as every other
node in this project (see `../PeregrineMicArrayCam/Config.local.h`'s convention — copy `Config.h`
to a gitignored `Config.local.h` for your real per-node secrets, never commit real credentials to
the tracked `Config.h`).
