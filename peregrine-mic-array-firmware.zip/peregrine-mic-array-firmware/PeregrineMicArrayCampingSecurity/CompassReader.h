// Copied from ../PeregrineMicArrayCam/CompassReader.h (keep the two in sync) -- added to the
// camping-security node 2026-09-28 (optional BNO055 on GPIO20/48, see Config.h).
// CompassReader.h — Bosch BNO055 absolute-orientation sensor over I2C
// (COMPASS_HEADING_HARDWARE_PLAN.md). Gives a stationary node a live, automatic heading,
// independent of GPS -- NOT a GPS replacement (no position, no disciplined UTC clock for TDOA; see
// the plan doc's own framing). Wraps Adafruit's BNO055 library, which does the sensor fusion
// on-chip and hands back a finished Euler heading directly -- no AHRS filter math needed on this
// MCU, the real reason this part was chosen over the cheaper MPU9250 (see the plan doc's
// "Recommended part" section for that trade-off written out in full).
//
// **Real, honest risks, not glossed over (see the plan doc's "Real, honest risks" section too):**
// - No I2C infrastructure existed anywhere in this codebase before this file -- this is new
//   plumbing, not a small addition to something already proven on real hardware.
// - Fusion IMUs need a brief calibration gesture (a slow figure-8 motion) after power-up before
//   the heading is trustworthy; `magCalibration()` exposes the sensor's own 0-3 confidence for the
//   magnetometer specifically (the component that actually drives heading) so this is at least
//   visible on the Serial console rather than silently trusted from cold.
// - Magnetic interference (motors, speakers, large ferrous hardware, a battery pack mounted too
//   close) distorts real readings -- a placement/enclosure concern this class can't detect or
//   correct, only report a low calibration confidence for.
#pragma once

#include <cstdint>

// Forward-declared rather than #including <Adafruit_BNO055.h> here -- keeps this header (and
// everything that includes it, e.g. the .ino) free of the Adafruit library's own dependency chain
// (Adafruit_Sensor, Adafruit_BusIO, Wire) when all a caller needs is this class's own small
// interface. Heap-allocated once in begin(); see CompassReader.cpp.
class Adafruit_BNO055;

class CompassReader {
public:
    // sda/scl: this node's Config::kCompassSDAPin/kCompassSCLPin. Returns false if the sensor
    // never answers on the bus (wrong wiring, wrong I2C address, or genuinely not installed) --
    // callers should treat that the same as "no compass," not retry forever.
    bool begin(int sda, int scl);

    // Call every loop() iteration -- internally rate-limited to
    // Config::kCompassReportIntervalMs (a stationary node's heading doesn't need telemetry-rate
    // updates, same reasoning as kGPSReportIntervalMs). Returns true exactly on an iteration that
    // produced a fresh reading; headingDeg()/magCalibration() only reflect that fresh value after
    // a true return, same "true on trigger" shape as OnsetDetector::processBlock.
    bool poll(uint32_t nowMs);

    // [0, 360), clockwise from magnetic north, no declination correction -- matches
    // NetworkProtocol.h's CompassHeadingPacket exactly (that wire format predates this sensor and
    // was designed to this same convention already).
    float headingDeg() const { return headingDeg_; }

    // BNO055's own fusion confidence for the magnetometer, 0 (uncalibrated) to 3 (fully
    // calibrated). Not part of the wire packet (see header comment above) -- Serial-logged only,
    // for field bring-up and troubleshooting a node that seems to report a wrong/jumpy heading.
    uint8_t magCalibration() const { return magCalibration_; }

    // NODE_ORIENTATION_3D_PLAN.md (2026-09-27): the raw physical vectors the app builds the node's
    // full 3-D orientation from, in the BNO055's own sensor axes -- gravity (m/s^2, the
    // accelerometer's reaction reading) and the fused/compensated magnetic field (uT). Sent as
    // vectors rather than Euler angles (gimbal-lock on a vertical node) or the quaternion (its
    // world-frame convention isn't documented in the Adafruit library). Fresh after a true poll().
    const float *gravity() const { return gravity_; }
    const float *magnetic() const { return magnetic_; }
    // sys<<6 | gyro<<4 | accel<<2 | mag, each 0-3 -- the whole calibration status in one byte.
    uint8_t packedCalibration() const { return packedCalibration_; }

    bool isInitialized() const { return initialized_; }

    ~CompassReader();

private:
    Adafruit_BNO055 *bno_ = nullptr;
    bool initialized_ = false;
    uint32_t lastReportMs_ = 0;
    float headingDeg_ = 0.0f;
    uint8_t magCalibration_ = 0;
    float gravity_[3] = {0, 0, 0};
    float magnetic_[3] = {0, 0, 0};
    uint8_t packedCalibration_ = 0;
};
