// HomeAssistantMQTT.h — CAMPING_SECURITY_NODE_PLAN.md's "Home Assistant integration," Home
// Security mode only. Uses Home Assistant's MQTT discovery convention (publish a small JSON config
// payload once per entity to `homeassistant/<component>/<object_id>/config`; HA auto-creates the
// entity, no YAML/custom integration needed) via `PubSubClient`.
//
// **Real correction vs. the plan's original framing, made while implementing this (2026-09-18):**
// the plan described the `camera` entity as "the node's existing GET /photos endpoint, referenced
// directly by URL... no new device-side camera-over-MQTT code." That's not actually buildable as a
// discovered MQTT entity -- HA's MQTT `camera` platform only supports a `topic` field (the device
// must publish raw JPEG bytes to it), never a `url`/`still_image_url` field; that capability
// belongs exclusively to the YAML-only `generic` camera platform, which has no MQTT-discovery path
// at all. Publishing real JPEG bytes over MQTT on a trigger would be genuinely new device-side
// code contending with the single shared camera frame buffer (stills/video/live-stream already
// share) -- exactly the cost the plan's own "no new device-side camera-over-MQTT code" language
// was trying to avoid. **Resolution: camera setup stays the one-time YAML `generic` platform
// pointing at `GET /snapshot`, same pattern this project already ships for Feeder Cam Mode (see
// `HOME_ASSISTANT.md`) -- not a discovered entity.** `binary_sensor` (presence), `button` (sound
// alarm), and `switch` (camera on/off) below ARE real, correct, zero-YAML MQTT discovery -- those
// three platforms all genuinely support this. `CAMPING_SECURITY_NODE_PLAN.md` updated to match.
//
// Only meaningful in `NodeMode::kHomeSecurity` -- `poll()` no-ops entirely (no connection attempt
// at all) when either the mode isn't Home Security or `MQTTConfigStore::isConfigured()` is false,
// so a node that never sets this up (Birding/Camping Security use, or Home Security before the app
// config screen is ever visited) costs nothing.
#pragma once

#include <cstdint>
#include <WiFiClient.h>
#include <PubSubClient.h>
#include <WString.h>
#include "MQTTConfigStore.h"

class HomeAssistantMQTT {
public:
    // `deviceIdHex` -- 12 lowercase hex chars (this node's 6-byte eFuse deviceId), used to build
    // unique_id/topic segments so multiple nodes sharing one broker/topicPrefix never collide.
    void begin(MQTTConfigStore &cfg, const char *deviceIdHex);

    // Call every loop() iteration -- see the class doc comment for when this is a no-op. Handles
    // connect/reconnect with a backoff, (re)publishes discovery once per successful connect
    // (HA drops its knowledge of an entity if the node's been gone long enough -- this covers both
    // a fresh HA restart and a node reconnecting after a real outage), and drains PubSubClient's
    // own loop() otherwise.
    void poll(bool nodeModeIsHomeSecurity);

    // Explicit disconnect -- called when the node leaves Home Security mode, so a Birding/Camping
    // Security node doesn't keep a dangling broker connection (and its "presence" entity showing
    // stale data in HA) open for no reason.
    void stop();

    // Not `const` -- PubSubClient::connected() itself isn't const-qualified (it can perform a
    // liveness probe internally), so this can't be either.
    bool isConnected();

    // Retained (HA keeps the last value even across a broker restart) so a fresh HA doesn't show a
    // blank/unknown state for something that's actually still true.
    void publishPresence(bool detected);
    void publishCameraState(bool enabled);
    void publishPresenceCaptureState(bool enabled);
    // Presence sensor health (added 2026-09-26). The presence binary_sensor's availability needs
    // BOTH the node's own status topic AND this one to be "online", so a silent/missing sensor
    // shows as "unavailable" in HA instead of a misleading "clear". Remembered and re-published on
    // every (re)connect.
    void publishPresenceSensorAvailable(bool available);

    // One-shot consume flags, same pattern as UDPStreamer's consume*Request() -- this class stays a
    // pure transport/protocol layer, the .ino (which already owns the camera/alarm state) is what
    // actually acts on a command arriving from HA.
    bool consumeSoundAlarmRequest();
    bool consumeSetCameraEnabledRequest(bool &enabled);
    bool consumeSetPresenceCaptureRequest(bool &enabled);

private:
    void handleMessage(const char *topicStr, const uint8_t *payload, unsigned int length);
    void publishDiscovery();
    void attemptReconnect(uint32_t nowMs);

    String topic(const char *suffix) const;              // "<prefix>/<deviceIdHex>/<suffix>"
    String discoveryTopic(const char *component, const char *objectId) const;
    String deviceBlockJson() const;                       // shared "device": {...} HA groups entities by

    MQTTConfigStore *cfg_ = nullptr;
    String deviceIdHex_;
    WiFiClient wifiClient_;
    PubSubClient client_;
    bool discoveryPublished_ = false;
    bool presenceSensorAvailable_ = true;
    uint32_t lastReconnectAttemptMs_ = 0;

    bool soundAlarmRequested_ = false;
    bool cameraEnabledRequested_ = false;
    bool cameraEnabledRequestedValue_ = false;
    bool presenceCaptureRequested_ = false;
    bool presenceCaptureRequestedValue_ = false;

    // PubSubClient's callback is a plain C function pointer, not a capturing closure -- this
    // trampoline pattern (a static instance pointer + a static forwarding function) is the same
    // shape this codebase already reached for in PPSReader.h when a similar C-API constraint ruled
    // out a normal member function (see that file's own doc comment on the IRAM_ATTR/static-member
    // issue it hit).
    static HomeAssistantMQTT *instance_;
    static void staticCallback(char *topicStr, uint8_t *payload, unsigned int length);
};
