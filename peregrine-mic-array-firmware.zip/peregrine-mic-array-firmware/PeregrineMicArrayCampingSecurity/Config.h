// Config.h — pins, WiFi credentials, and tunable constants for the Peregrine Camping Security
// camera node (GOOUUU ESP32-S3-CAM V1.5, OV5640, N16R8). See CAMPING_SECURITY_NODE_PLAN.md (repo
// root) for the full design this implements, and README.md here for wiring.
//
// This is a 2-mic single-bus camera node, same class as ../PeregrineMicArrayCam's kMicCount==2
// variant, but on a DIFFERENT physical board (GOOUUU, not FORIOT) with two genuinely new
// peripherals that board has no equivalent of: a DFRobot C4001 mmWave presence sensor (UART) and
// an NS4168 I2S speaker (alarm tone + "speak through the node" playback). No GPS, no PPS, no SD
// card requirement (see kSDCmdPin/kSDClkPin/kSDDataPin below — used opportunistically when a card
// is present, RAM-only fallback otherwise, never a hard requirement).
//
// **GPIO budget is genuinely tight on this board — see CAMPING_SECURITY_NODE_PLAN.md's GPIO
// section for the full derivation.** Only 7 pins are free-and-clean after camera (GPIO4-13,15-18),
// nonexistent-on-chip (22-25), not-broken-out (33/34), flash/PSRAM (26-32, 35-37), onboard SD
// (38-40), UART console (43/44), and strapping (0/3/45/46) are all excluded: GPIO 1, 2, 14, 21, 41,
// 42, 47. Mics (3) + C4001 UART (2) + speaker I2S TX (3) need 8 -- GPIO19 (one of the two native-USB
// pins) is deliberately reclaimed for the 8th, forfeiting that port's OTG function permanently
// (this board has a separate UART-bridge USB-C port for flashing, so nothing needed is lost).
//
// **Unlike ../PeregrineMicArrayCam, this board's camera claims the SAME GPIO4-13,15-18 range the
// FORIOT board's camera does** -- confirmed by both board-pinout sources checked while scoping this
// (community reference + Espressif's own chip-level GPIO facts). That range is NOT available for
// mics here either way, same as on FORIOT -- the difference is what happens to GPIO14/21/47 (the
// FORIOT board's remapped top-bus trio): on THIS board they're free-and-clean camera-independent
// pins, so they're repurposed for C4001 (14/21) and the speaker's WS line (47) instead of a second
// mic bus -- this variant only ever has one mic pair, there is no "top bus" concept at all.
#pragma once

#include <cstddef>
#include <cstdint>

namespace Config {

// ---- I2S pins: mics (I2S_NUM_0, single bus -- this variant has no second mic pair) ----
// Same GPIO1/2/42 trio as ../PeregrineMicArrayCam's kBottomWS/kBottomBCLK/kBottomBusDIN -- both
// boards happen to leave this exact trio free, so I2SCapture.cpp needs zero pin remapping between
// the two board types.
constexpr int kMicWS   = 1;
constexpr int kMicBCLK = 2;
constexpr int kMicDIN  = 42;

// ---- I2S pins: speaker output (I2S_NUM_1, TX -- see AudioOutput.h) ----
// GPIO19 is reclaimed from the board's native-USB/OTG port (D-) -- see header comment above.
constexpr int kSpeakerBCLK = 41;
constexpr int kSpeakerWS   = 47;
constexpr int kSpeakerDIN  = 19; // "DIN" from the NS4168's perspective; this is the ESP32's DATA OUT pin

// ---- Presence sensor: DFRobot C4001 (SEN0609, 25m) OR C4002 (SEN0691, 11m), UART ----
// Either sensor goes on the same two pins (the kC4001* names predate C4002 support and are kept so
// an existing Config.local.h doesn't break). **Power differs:** the C4001 runs from 3.3V; the
// C4002's VCC needs 3.6-5.5V, so wire its VCC to the board's 5V pin, not 3V3. DFRobot's own ESP32
// wiring table connects the C4002's RX/TX straight to ESP32 pins, but DFRobot doesn't publish its
// UART logic level -- measure its TX pin (should idle at ~3.3V, not 5V) before connecting it.
constexpr int kC4001RXPin = 14; // ESP32 <- sensor TX
constexpr int kC4001TXPin = 21; // ESP32 -> sensor RX
constexpr uint32_t kC4001Baud = 9600;
constexpr uint32_t kC4002Baud = 115200; // the C4002's factory default (vendor library examples)
// Detection range and hold time (added 2026-09-30, after a real false-presence capture on node 1:
// strong walking-pace targets 11-29 ft out, each followed by 15s of "static presence" that was only
// the sensor's own hold timer). kC4002MaxRangeCm: the farthest distance it reports, 0-1100 -- set it
// to the far edge of the area you want watched, so movement beyond it (24GHz goes through interior
// walls) is ignored. kC4002TargetDisappearDelayS: how long the sensor keeps reporting a target after
// it stops detecting it; shorter clears sooner. Both are sent to the sensor at every boot.
constexpr uint16_t kC4002MaxRangeCm = 1100; // EDIT per node (15 ft = 460)
constexpr uint16_t kC4002TargetDisappearDelayS = 5;

// Which presence sensor is fitted. kAuto (default) probes for a C4002 at boot -- it answers a
// binary set-report-period command with a checksum-valid reply -- and falls back to the C4001 if
// nothing answers, so one build works on every security node. Force one if detection misbehaves.
enum class PresenceSensorType : uint8_t { kAuto, kC4001, kC4002 };
constexpr PresenceSensorType kPresenceSensorType = PresenceSensorType::kAuto;
// Both sensors report continuously even with nobody there (C4002 once a second as configured, the
// C4001 streams), so this long without a single parsed report means the sensor is missing,
// unpowered, or unplugged -- the node flags it to the app and Home Assistant instead of silently
// looking like a quiet night. Recovers on its own if reports resume.
constexpr uint32_t kPresenceSensorSilenceMs = 10000;
// Live presence readout to the app (kPresenceUpdate: distance, speed, approaching/away) -- at most
// this often while someone's there, plus once when they leave. Independent of kMotionRetriggerMs,
// which only paces the alert/photo.
constexpr uint32_t kPresenceUpdateIntervalMs = 1000;

// ---- Optional compass: Bosch BNO055 over I2C (added 2026-09-28) ----
// Gives this GPS-less node a live heading (and full 3-D orientation -- NODE_ORIENTATION_3D_PLAN.md)
// instead of a Fixed Pin heading that goes quietly wrong if the node is bumped. Pair it with the
// app's Compass heading source + a pinned position (the node still has no GPS).
//
// **Pins: SDA = GPIO20, SCL = GPIO48** -- the last two usable GPIOs on this board. 20 is the spare
// native-USB D+ pin (D- / GPIO19 is already the speaker's DIN, so that port is already forfeited).
// **48 also drives the board's onboard WS2812 RGB LED**: I2C traffic on it makes the LED flash
// random colours -- harmless electrically, but a visible giveaway on a security camera at night.
// Cut the LED's data trace (or remove the LED) before enabling this on a node that must stay dark.
// With the compass wired, this board has NO spare GPIO left. The BNO055 runs from 3.3V; Adafruit's
// breakout already carries the I2C pull-ups.
constexpr bool kCompassEnabled = false; // EDIT to true once the BNO055 is wired
constexpr int kCompassSDAPin = 20;
constexpr int kCompassSCLPin = 48;
constexpr uint32_t kCompassReportIntervalMs = 1000;

// ---- Audio ----
constexpr uint32_t kSampleRateHz = 44100;
// INMP441 outputs 24-bit samples left-justified in a 32-bit I2S slot.
constexpr int kI2SBitsPerSample = 32;

// Capacity of the streaming-audio FIFO (audioRing in the .ino) -- see
// ../PeregrineMicArrayCam/Config.h's identical constant for the real-hardware finding (a slow
// esp_camera_fb_get() call starving loop()) that sized this at 2s of headroom rather than the
// original 200ms.
constexpr uint32_t kAudioRingCapacitySamples = kSampleRateHz * 2;

// ---- Mic spacing (only meaningful if a second mic pair is ever added later -- kept for
// DOAEstimator.h's shared kMaxLagSamples derivation, though this variant only ever calls
// estimateSingleBus(), which doesn't use direction at all beyond L/R timing within the one pair) ----
constexpr float kMicSpacingMeters = 0.055f; // measured 55 mm on the as-built security node (2026-09-28) -- EDIT if yours differs
constexpr float kSpeedOfSoundMps = 343.0f;
constexpr int kMaxLagSamples = (int)((kMicSpacingMeters / kSpeedOfSoundMps) * (float)kSampleRateHz * 1.5f) + 1;

// ---- Onset gate (identical to the sibling firmwares) ----
constexpr float kOnsetFastEnvelopeAlpha = 0.6f;
constexpr float kOnsetFloorDownAlpha = 0.01f;
constexpr float kOnsetFloorUpAlpha = 0.0001f;
constexpr float kOnsetTriggerRatio = 4.0f;
constexpr uint32_t kOnsetMinHoldMs = 5;
constexpr uint32_t kOnsetMinIntervalMs = 175;

// ---- Outlier rejection ----
constexpr float kOutlierRejectRatio = 6.0f;

// ---- DOA analysis window ----
constexpr int kDOAWindowSamples = 1024; // ~23ms at 44.1kHz

// ---- GPS ----
// No GPS on this variant -- confirmed deliberate (CAMPING_SECURITY_NODE_PLAN.md). Kept as a flag
// (not simply omitted) because BLEAdvertiser.cpp -- a shared module, kept byte-identical across
// every firmware tree -- reads it when building its scan-response capability flags.
constexpr bool kGPSEnabled = false;

// ---- Node identity ----
constexpr uint8_t kNodeType = 1; // 1 = camera + mic array, see NetworkProtocol.h's NodeIdentityPacket
constexpr uint8_t kMicCount = 2; // this variant always has exactly one mic pair -- no top-bus option exists on this board
constexpr uint32_t kNodeIdentityIntervalMs = 5000;

// ---- BLE-GATT Wi-Fi provisioning (CONFIGURABLE_FLEET_PLAN.md) ----
constexpr bool kBleProvisioningEnabled = true;
constexpr bool kBleProvisioningEncrypted = true;

// ---- Network role (see CAMPING_SECURITY_NODE_PLAN.md's "Network connectivity in the field") ----
// kRoleSecondary is the recommended default for a genuinely infrastructure-free deployment: it
// tries kWiFiCandidates first (useful if a known network ever IS in range -- home Wi-Fi before the
// trip, a car-camping site's phone hotspot), then falls back to hosting its own AP
// (pollFailover()'s promote-to-AP path, already confirmed working on the sibling firmwares) if
// nothing on that list is reachable -- the state a backcountry deployment converges to. Only ONE
// node per fleet may be kRolePrimary; if you're deploying a single camping security node with
// nothing else around, kRolePrimary (always hosts, no candidate-list wait) is also reasonable --
// pick per-deployment, this is just the safer multi-node-fleet default.
constexpr uint8_t kRolePrimary = 0;
constexpr uint8_t kRoleSecondary = 1;
constexpr uint8_t kRoleClient = 2;
constexpr uint8_t kNetworkRole = kRoleSecondary; // EDIT per physical node

// ---- Secondary/failover tuning (only meaningful when kNetworkRole == kRoleSecondary) ----
constexpr uint32_t kFailoverTimeoutMs = 30000;
constexpr uint32_t kPrimaryRescanIntervalMs = 60000;
constexpr uint8_t kPrimaryBSSID[6] = {0, 0, 0, 0, 0, 0}; // EDIT: read off the target network's own BSSID

constexpr int kMaxFleetNodes = 5;
constexpr int kMaxAPStations = kMaxFleetNodes;
constexpr int kWiFiChannel = 6;

// ---- Node roster ----
constexpr uint32_t kFleetId = 0x00000000; // EDIT to a value unique to your own fleet of nodes
constexpr uint32_t kNodeAnnounceIntervalMs = 5000;
constexpr uint32_t kRosterStaleTimeoutMs = 20000;
constexpr bool kIsRosterMaster = false; // EDIT: true on exactly one node, only in an all-kRoleClient shared-network setup

// ---- Camera (OV5640) ----
// JPEG straight off the sensor, same reasoning as the sibling firmware's OV3660 config.
constexpr int kCameraJpegQuality = 12; // 0-63, lower = higher quality/larger file
constexpr size_t kCameraFrameBufferCount = 1;
// Image orientation fix for how the board is mounted. Both true = rotate 180° (upside-down image).
// One alone = a mirror (vflip: top/bottom, hmirror: left/right).
constexpr bool kCameraVFlip = true;
constexpr bool kCameraHMirror = true;
constexpr uint32_t kPhotoMinIntervalMs = 5000;
constexpr bool kPhotoAutoModeDefault = false;

// ---- Storage: SD when available, RAM-only fallback otherwise (CAMPING_SECURITY_NODE_PLAN.md,
// revised 2026-09-17 -- see PhotoServer.h for the dual-backend implementation). The onboard SD
// slot's 3 pins are physically wired to it regardless of use (same convention as the sibling
// firmware's kSDCmdPin/kSDClkPin/kSDDataPin, which happen to be the identical GPIO numbers on this
// board too) -- mounting it opportunistically when a card happens to be inserted costs nothing on
// top of the GPIO budget above, and unlocks real video recording + reboot-durable photo storage.
constexpr int kSDCmdPin = 38;
constexpr int kSDClkPin = 39;
constexpr int kSDDataPin = 40;
// Only meaningful in the SD-backed path (matches ../PeregrineMicArrayCam's identical constant).
constexpr uint16_t kMaxStoredPhotos = 1000;
constexpr bool kWipePhotosOnBoot = false;
// Only meaningful in the RAM-only fallback path (no card present) -- see PhotoServer::begin().
// Deliberately much smaller than kMaxStoredPhotos: these live in PSRAM, shared with Wi-Fi/camera/
// audio-output buffers, not on a multi-GB card. 8-16 is CAMPING_SECURITY_NODE_PLAN.md's starting
// estimate, not yet measured against this camera's real per-frame JPEG size.
constexpr uint8_t kRamPhotoRingCapacity = 12;

// ---- Motion/presence sensor: DFRobot C4001 or C4002 (see PresenceSensor.h) ----
// Unlike ../PeregrineMicArrayCam's kMotionSensorEnabled (a PIR that's optional even on that
// variant), a presence sensor is a fixed, always-present part of this variant -- no
// build-without-it option, so there's no enable flag here, only tuning constants.
constexpr uint32_t kMotionRetriggerMs = 5000; // matches kPhotoMinIntervalMs's reasoning

// ---- Video recording (SD path only -- see PhotoServer.h/VideoRecorder.h) ----
constexpr uint32_t kVideoFrameIntervalMs = 167;   // ~6 fps, matches the sibling firmware
constexpr uint32_t kVideoMaxDurationMs = 30000;

// ---- Diagnostics ----
constexpr bool kDiagnosticDisableWiFi = false;

// ---- WiFi STA ----
struct WiFiCredential {
    const char *ssid;
    const char *password;
};

constexpr const char *kWiFiSSID = "PeregrineCampSecurity";
constexpr const char *kWiFiPassword = "birding123";
constexpr bool kUseDerivedApPassword = true;

constexpr WiFiCredential kWiFiCandidates[] = {
    { kWiFiSSID, kWiFiPassword },
    // Add your own STA fallback networks here, most-preferred first -- see
    // WIFI_MULTI_SSID_FALLBACK_PLAN.md. iOS possessive hotspot names use a typographic right single
    // quote (U+2019, ’), not a plain apostrophe.
    // { "MyHomeWiFi", "homepassword123" },
};
constexpr uint32_t kWiFiPerCandidateTimeoutMs = 3000;
constexpr uint32_t kWiFiReconnectGraceMs = 10000;

// ---- Runtime Wi-Fi config recovery (CONFIGURABLE_FLEET_PLAN.md Part A) ----
constexpr uint32_t kConfigRecoveryTimeoutMs = 180000;
constexpr uint32_t kConfigProofHoldMs = 60000;

// ---- UDP ----
constexpr uint16_t kUDPPort = 3333;
constexpr uint32_t kStreamingInactivityTimeoutMs = 10000;

// ---- Audio streaming ----
constexpr int kAudioSamplesPerPacket = 441;

// ---- Photo HTTP server ----
constexpr uint16_t kHTTPPort = 80;
constexpr uint16_t kVideoHTTPPort = 81;

// ---- Live video streaming ----
constexpr uint16_t kLiveStreamHTTPPort = 82;
constexpr uint32_t kLiveStreamFrameIntervalMs = 200;
constexpr uint32_t kLiveStreamMaxDurationMs = 120000;
constexpr size_t kLiveStreamWriteChunkBytes = 1024;
constexpr uint32_t kLiveStreamFrameWatchdogMs = 3000;

// ---- Alarm tone (AudioOutput.h) ----
// A simple two-tone sweep, not a flat beep -- more attention-grabbing, cheap to synthesize (a
// phase accumulator, no sample data stored anywhere). Tune once built and the real NS4168+speaker
// loudness at 3.3V is known (see CAMPING_SECURITY_NODE_PLAN.md's "confirm actual loudness" open item).
constexpr float kAlarmToneLowHz = 1200.0f;
constexpr float kAlarmToneHighHz = 2400.0f;
constexpr uint32_t kAlarmToneSweepMs = 500; // one low->high->low cycle
constexpr float kAlarmToneAmplitude = 0.6f; // fraction of full-scale int16 -- leaves headroom, avoids clipping
// kSoundAlarm has no corresponding "stop" packet on the wire (fire-and-forget, mirrors
// kPhotoCaptureNow's one-shot shape) -- without a bounded cutoff the alarm would play forever once
// triggered if the app never follows up (crash, connection drop), draining a camping battery for
// no reason. Same safety-cutoff philosophy as kVideoMaxDurationMs/kLiveStreamMaxDurationMs.
constexpr uint32_t kAlarmAutoStopMs = 20000; // 20s -- long enough to be a real deterrent, not indefinite

// ---- Home Assistant MQTT integration (CAMPING_SECURITY_NODE_PLAN.md, Home Security mode only) ----
// How often to retry the broker connection while disconnected. PubSubClient::connect() itself
// blocks briefly (its own internal TCP timeout) -- this just bounds how often loop() attempts that
// blocking call, same "don't hammer a failing operation every single iteration" reasoning as
// kPrimaryRescanIntervalMs elsewhere in this codebase.
constexpr uint32_t kMQTTReconnectIntervalMs = 5000;
// HA discovery payloads (device block + entity fields) comfortably exceed PubSubClient's 256-byte
// default -- sized with real headroom, not tuned to the exact byte count, since a topicPrefix or
// broker host longer than expected shouldn't silently truncate a payload HA depends on.
constexpr uint16_t kMQTTBufferSize = 768;

// ---- Node Mode (CAMPING_SECURITY_NODE_PLAN.md) ----
// See NodeMode.h for the enum. Not persisted -- the app re-sends the saved choice on reconnect,
// same convention as kSetPhotoMode/kSetFeederCamMode.
constexpr uint8_t kNodeModeDefault = 0; // 0 = Birding
constexpr bool kAutomaticAlarmDefault = false;
// Off by default -- presence-triggered photo capture used to fire unconditionally in every Node
// Mode; a user has to explicitly turn it on, from the app's Camping Security screen or Home
// Assistant's "Presence Capture" switch, same shape as kAutomaticAlarmDefault above.
constexpr bool kPresenceCaptureDefault = false;

} // namespace Config
