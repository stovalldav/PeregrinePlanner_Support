// MQTTConfigStore.h — NVS-backed Home Assistant MQTT broker config (CAMPING_SECURITY_NODE_PLAN.md's
// "Home Assistant integration"). Deliberately much simpler than WiFiConfigStore's staged/commit/
// rollback dance: a bad or missing MQTT config just means "no Home Assistant integration this
// boot" -- unlike a bad Wi-Fi config, it can never strand the node off the network entirely, so
// there's no recovery-timer/reboot machinery needed here. `set()` applies and persists immediately;
// the caller (HomeAssistantMQTT) just reconnects with whatever's current.
#pragma once

#include <cstdint>
#include <Preferences.h>
#include <WString.h>

class MQTTConfigStore {
public:
    // Opens NVS ("mqtt" namespace) and loads whatever's persisted, if anything. Call once at boot.
    void begin();

    // Empty host = "not configured" -- HomeAssistantMQTT::poll() no-ops entirely in that state, so
    // a node with nothing set here costs zero CPU/network overhead beyond the one empty check.
    bool isConfigured() const { return host_.length() > 0; }

    const char *host() const { return host_.c_str(); }
    uint16_t port() const { return port_; }
    const char *username() const { return username_.c_str(); }
    const char *password() const { return password_.c_str(); }
    // Scopes this node's entities/topics in HA's namespace -- same purpose as Config::kFleetId does
    // for roster aggregation, just for MQTT instead. Defaults to "peregrine" if never set.
    const char *topicPrefix() const { return topicPrefix_.c_str(); }

    // Persists immediately (no staging/commit step -- see header comment).
    void set(const char *host, uint16_t port, const char *username, const char *password, const char *topicPrefix);

    // Wipes the NVS namespace and the in-RAM cache -- "turn off Home Assistant integration."
    void clear();

private:
    Preferences prefs_;
    String host_;
    uint16_t port_ = 1883;
    String username_;
    String password_;
    String topicPrefix_ = "peregrine";
};
