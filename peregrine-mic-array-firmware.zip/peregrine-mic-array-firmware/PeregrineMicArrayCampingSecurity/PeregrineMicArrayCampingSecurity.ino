// PeregrineMicArrayCampingSecurity — GOOUUU ESP32-S3-CAM V1.5 (OV5640) + 2x INMP441 + DFRobot C4001
// mmWave presence sensor + NS4168 speaker, doubling as an unattended camping/home security node.
// See CAMPING_SECURITY_NODE_PLAN.md (repo root) for the full design this implements.
//
// Distinct from ../PeregrineMicArrayCam: different physical board (see Config.h's header comment
// for the GPIO derivation), no GPS/PPS (confirmed deliberate), no second mic pair (this board's
// camera claims the FORIOT board's own top-bus pin trio, repurposed here for the C4001 + speaker
// instead), and two genuinely new subsystems -- C4001Reader (presence) and AudioOutput (alarm tone
// + "speak through the node" playback). Reuses the sibling firmware's proven capture/onset/DOA
// pipeline, camera/photo-serving pattern, and Wi-Fi/BLE/roster plumbing unmodified.
//
// Storage: SD when a card is present, RAM-only ring fallback otherwise -- see PhotoServer.h.
// Video recording only works on the SD path (see VideoRecorder.h); the RAM-only fallback serves
// stills only.

#include <WiFi.h>
#include <esp_camera.h>
#include <esp_random.h> // esp_random() -- boot-time seed for the RAM-only-mode photo-id counter
#include "Config.h"
#include "CameraPins.h"
#include "NetworkProtocol.h"
#include "RingBuffer.h"
#include "I2SCapture.h"
#include "OnsetDetector.h"
#include "DOAEstimator.h"
#include "UDPStreamer.h"
#include "WiFiConfigStore.h"
#include "PhotoServer.h"
#include "VideoRecorder.h"
#include "VideoServer.h"
#include "LiveStreamServer.h"
#include "BLEAdvertiser.h"
#include "RemoteLogger.h"
#include "C4001Reader.h"
#include "C4002Reader.h"
#include "PresenceConfigStore.h"
#include "CompassReader.h"
#include "AudioOutput.h"
#include "NodeMode.h"
#include "MQTTConfigStore.h"
#include "HomeAssistantMQTT.h"

// FIELD_DEBUG_PLAN.md -- see ../PeregrineMicArrayCam/PeregrineMicArrayCam.ino's identical block for
// the full rationale (mirrored verbatim).
HardwareSerial &RealSerial0 = Serial0;
RemoteLogger gRemoteLogger;
#define Serial0 gRemoteLogger

static const int kReadBlockFrames = 256;

I2SBus micBus; // I2S_NUM_0 -- this variant's only mic pair (see Config.h's kMicWS/kMicBCLK/kMicDIN)
UDPStreamer network;
WiFiConfigStore gWiFiConfig;

static void pollConfigRecovery() {
    if (!gWiFiConfig.awaitingProof()) return;

    const uint8_t role = gWiFiConfig.role();
    const bool reachable = (role == Config::kRolePrimary)
        ? (WiFi.softAPgetStationNum() > 0)
        : (WiFi.status() == WL_CONNECTED);

    static uint32_t proofStartMs = 0;
    const uint32_t now = millis();

    if (reachable) {
        if (proofStartMs == 0) proofStartMs = now;
        if (now - proofStartMs >= Config::kConfigProofHoldMs) {
            gWiFiConfig.markProven();
            Serial0.println("[wcfg] committed config proven good -- recovery arm cleared");
        }
        return;
    }
    proofStartMs = 0;
    if (now < Config::kConfigRecoveryTimeoutMs) return;

    if (gWiFiConfig.hasPrevious()) {
        Serial0.printf("[wcfg] recovery: no network %lus after a config change -- reverting to previous\n",
                       (unsigned long)(Config::kConfigRecoveryTimeoutMs / 1000));
        gWiFiConfig.revertToPrevious();
    } else {
        Serial0.println("[wcfg] recovery: no network and no previous config -- resetting to Config.h defaults");
        gWiFiConfig.resetToDefaults();
    }
    delay(200);
    ESP.restart();
}

BLEAdvertiser bleAdvertiser;
OnsetDetector onset;
PhotoServer photoServer;
VideoRecorder videoRecorder;
VideoServer videoServer;
LiveStreamServer liveStream;
C4001Reader c4001;
C4002Reader c4002;
CompassReader compass; // optional BNO055 (Config::kCompassEnabled) -- added 2026-09-28
// Whichever of the two setup() found -- see the detection comment there.
PresenceSensor *presenceSensor = &c4001;

// Detection range / hold time -- app-adjustable via kSetPresenceRange (2026-09-30), saved in NVS.
// What the node reports back to the app's controls: 0 range = not known, 0xFFFF hold = not settable.
PresenceConfigStore presenceConfigStore;
uint16_t gPresenceRangeCm = 0;
uint16_t gPresenceHoldS = 0xFFFF;

void publishPresenceConfig() {
    network.setPresenceConfig(gPresenceRangeCm, gPresenceHoldS,
        presenceSensor->minSupportedRangeCm(), presenceSensor->maxSupportedRangeCm());
}

// From the app. Applied to the sensor now; saved only once the sensor takes it.
void applyPresenceRange(uint16_t cm, uint16_t holdS) {
    if (cm != PresenceConfigStore::kUnset) {
        if (cm < presenceSensor->minSupportedRangeCm()) cm = presenceSensor->minSupportedRangeCm();
        if (cm > presenceSensor->maxSupportedRangeCm()) cm = presenceSensor->maxSupportedRangeCm();
        if (presenceSensor->setMaxRangeCm(cm)) {
            gPresenceRangeCm = cm;
            presenceConfigStore.setMaxRangeCm(cm);
        }
    }
    if (holdS != PresenceConfigStore::kUnset && presenceSensor->supportsHold()) {
        if (holdS > 600) holdS = 600;
        if (presenceSensor->setHoldS(holdS)) {
            gPresenceHoldS = holdS;
            presenceConfigStore.setHoldS(holdS);
        }
    }
    publishPresenceConfig();
    network.sendPresenceConfig();
}
AudioOutput audioOutput;
MQTTConfigStore mqttConfig;
HomeAssistantMQTT homeAssistant;

RingBuffer audioRing(Config::kAudioRingCapacitySamples);
RingBuffer micLeftRing(Config::kDOAWindowSamples * 4);
RingBuffer micRightRing(Config::kDOAWindowSamples * 4);

static int16_t capturedLeft[Config::kDOAWindowSamples];
static int16_t capturedRight[Config::kDOAWindowSamples];
SemaphoreHandle_t doaCaptureRequested;

uint32_t audioSeq = 0;
uint32_t doaSeq = 0;

// Whether SD is actually available this boot -- decided once, see setup(). Drives PhotoServer's
// backend choice and whether video recording is offered at all (CAMPING_SECURITY_NODE_PLAN.md's
// "Storage: SD when available, RAM-only fallback otherwise").
bool gSDAvailable = false;

uint32_t nextPhotoId = 1;
uint32_t nextVideoId = 1;

struct LastDOAResult {
    uint8_t bandId;
    float lowHz;
    float highHz;
    float azimuthDeg;
    float confidence;
};
static LastDOAResult lastDOAResults[Protocol::kMaxDOABands];
static int lastDOAResultCount = 0;

volatile uint32_t micReadOk = 0;
volatile uint32_t micReadFail = 0;
volatile int16_t micLeftPeak = 0;
volatile int16_t micRightPeak = 0;

static void updatePeak(volatile int16_t &peak, const int16_t *block, int count) {
    for (int i = 0; i < count; i++) {
        int32_t magnitude = abs((int32_t)block[i]);
        if (magnitude > peak) peak = (int16_t)(magnitude > INT16_MAX ? INT16_MAX : magnitude);
    }
}

void captureTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!micBus.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            micReadFail++;
            continue;
        }
        micReadOk++;
        updatePeak(micLeftPeak, blockLeft, kReadBlockFrames);
        updatePeak(micRightPeak, blockRight, kReadBlockFrames);

        micLeftRing.pushBlock(blockLeft, kReadBlockFrames);
        micRightRing.pushBlock(blockRight, kReadBlockFrames);
        audioRing.pushBlock(blockLeft, kReadBlockFrames);

        bool triggered = onset.processBlock(blockLeft, kReadBlockFrames, millis(), micros());
        if (triggered) {
            micLeftRing.snapshotRecent(capturedLeft, Config::kDOAWindowSamples);
            micRightRing.snapshotRecent(capturedRight, Config::kDOAWindowSamples);
            xSemaphoreGive(doaCaptureRequested);
        }
    }
}

bool initCamera() {
    camera_config_t config = {};
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = CAM_PIN_D0;
    config.pin_d1 = CAM_PIN_D1;
    config.pin_d2 = CAM_PIN_D2;
    config.pin_d3 = CAM_PIN_D3;
    config.pin_d4 = CAM_PIN_D4;
    config.pin_d5 = CAM_PIN_D5;
    config.pin_d6 = CAM_PIN_D6;
    config.pin_d7 = CAM_PIN_D7;
    config.pin_xclk = CAM_PIN_XCLK;
    config.pin_pclk = CAM_PIN_PCLK;
    config.pin_vsync = CAM_PIN_VSYNC;
    config.pin_href = CAM_PIN_HREF;
    config.pin_sscb_sda = CAM_PIN_SIOD;
    config.pin_sscb_scl = CAM_PIN_SIOC;
    config.pin_pwdn = CAM_PIN_PWDN;
    config.pin_reset = CAM_PIN_RESET;
    config.xclk_freq_hz = kCameraXCLKFreqHz;
    config.pixel_format = PIXFORMAT_JPEG;
    config.frame_size = FRAMESIZE_SVGA; // 800x600
    config.jpeg_quality = Config::kCameraJpegQuality;
    config.fb_count = Config::kCameraFrameBufferCount;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.grab_mode = CAMERA_GRAB_LATEST;

    if (esp_camera_init(&config) != ESP_OK) return false;

    // Mounting orientation: both flags together = 180° rotation (board mounted camera-up in the
    // portrait enclosure). Applied here so it also survives a camera off/on re-init.
    sensor_t *sensor = esp_camera_sensor_get();
    if (sensor) {
        sensor->set_vflip(sensor, Config::kCameraVFlip ? 1 : 0);
        sensor->set_hmirror(sensor, Config::kCameraHMirror ? 1 : 0);
    }
    return true;
}

uint32_t lastPhotoMs = 0;
bool gCameraEnabled = true;
bool gCameraDisablePending = false;

void capturePhotoIfDue(uint32_t nowMs, bool manual) {
    if (!gCameraEnabled) {
        if (manual) Serial0.println("[photo] capture rejected -- camera is currently disabled (kSetCameraEnabled)");
        return;
    }
    const char *source = manual ? "manual" : "auto";
    uint32_t minIntervalMs = network.photoMinIntervalMs();
    if (nowMs - lastPhotoMs < minIntervalMs) {
        if (manual) {
            Serial0.printf("[photo] %s request ignored -- rate-limited (%lums since last capture, min %lums)\n",
                source, (unsigned long)(nowMs - lastPhotoMs), (unsigned long)minIntervalMs);
        }
        return;
    }

    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        Serial0.printf("[photo] %s capture failed -- esp_camera_fb_get() returned null\n", source);
        return;
    }

    uint8_t *copy = (uint8_t *)malloc(fb->len);
    if (!copy) {
        Serial0.printf("[photo] %s capture failed -- malloc(%u) for frame copy failed\n", source, (unsigned)fb->len);
        esp_camera_fb_return(fb);
        return;
    }
    memcpy(copy, fb->buf, fb->len);
    size_t length = fb->len;
    esp_camera_fb_return(fb);

    uint32_t photoId = nextPhotoId++;

    bool savedToSD = false;
    if (gSDAvailable) {
        // SD path: PhotoServer.publish() caches the RAM fast-path copy; write the durable SD copy
        // here, exactly mirroring the sibling firmware's own split responsibility.
        String photoPath = "/photos/" + String(photoId) + ".jpg";
        File photoFile = SD_MMC.open(photoPath, FILE_WRITE);
        if (photoFile) {
            photoFile.write(copy, length);
            photoFile.close();
            savedToSD = true;
        } else {
            Serial0.printf("[photo] SD write failed -- SD_MMC.open() failed for %s (RAM copy still served)\n", photoPath.c_str());
        }
        photoServer.publish(photoId, copy, length);
        if (savedToSD) photoServer.notePhotoStored(photoId, Config::kMaxStoredPhotos);
    } else {
        // RAM-only path: publish() itself IS the store (a capped ring, oldest evicted).
        photoServer.publish(photoId, copy, length);
    }

    network.sendPhotoReady(nowMs, photoId, (uint32_t)length);
    Serial0.printf("[photo] %s capture ok -- id %lu, %u bytes (%s)\n", source, (unsigned long)photoId,
                   (unsigned)length, gSDAvailable ? (savedToSD ? "SD+RAM" : "RAM only (SD write failed)") : "RAM ring");
    lastPhotoMs = nowMs;
}

// Shared by both camera-enable "front doors" (the app's kSetCameraEnabled and Home Assistant's
// switch/camera command, see loop()) so the two can never silently drift out of sync with each
// other's side effects (esp_camera_init()/deinit(), the deferred-disable flag, the MQTT state echo).
void applyCameraEnabled(bool enabled) {
    if (enabled && !gCameraEnabled) {
        gCameraEnabled = initCamera();
        Serial0.printf("[camera] re-enable %s\n",
            gCameraEnabled ? "ok" : "FAILED -- esp_camera_init() error, staying off");
        homeAssistant.publishCameraState(gCameraEnabled);
    } else if (!enabled && gCameraEnabled) {
        gCameraDisablePending = true;
        Serial0.println("[camera] disable requested -- aborting any active recording/stream first");
        homeAssistant.publishCameraState(false);
    }
}

// Off by default -- see NetworkProtocol.h's kSetPresenceCapture comment for why this exists.
bool gPresenceCaptureEnabled = Config::kPresenceCaptureDefault;

// Shared by both Presence Capture "front doors" (the app's kSetPresenceCapture and Home
// Assistant's switch/presence_capture command), same reasoning as applyCameraEnabled above --
// one place decides gPresenceCaptureEnabled and echoes it back to HA, so the two paths can't drift.
void applyPresenceCaptureEnabled(bool enabled) {
    gPresenceCaptureEnabled = enabled;
    Serial0.printf("[mode] presence capture %s\n", enabled ? "ON" : "off");
    homeAssistant.publishPresenceCaptureState(enabled);
}

// ---- Node Mode + Automatic Alarm (CAMPING_SECURITY_NODE_PLAN.md) ----
// Not persisted -- the app re-sends the saved choice on reconnect, same convention as every other
// runtime toggle in this codebase (kSetPhotoMode, kSetFeederCamMode on the sibling firmware, etc.).
NodeMode gNodeMode = static_cast<NodeMode>(Config::kNodeModeDefault);
bool gAutomaticAlarmEnabled = Config::kAutomaticAlarmDefault;

void setup() {
    gRemoteLogger.attach(RealSerial0);
    Serial0.begin(115200, SERIAL_8N1, 44, 43);
    delay(1500);
    Serial0.println("[boot] checkpoint 1: Serial0 ready (TX+RX)");

    Serial0.println("[boot] checkpoint 2: starting camera");
    if (!initCamera()) {
        Serial0.println("[boot] Camera init failed");
    } else {
        Serial0.println("[boot] checkpoint 3: camera ready");
    }

    Serial0.println("[boot] checkpoint 4: starting mic bus (I2S_NUM_0, single pair)");
    if (!micBus.begin(I2S_NUM_0, Config::kMicBCLK, Config::kMicWS, Config::kMicDIN, Config::kSampleRateHz)) {
        Serial0.println("[boot] Mic bus init failed");
    } else {
        Serial0.println("[boot] checkpoint 5: mic bus ready");
    }

    // Presence sensor: C4002 or C4001 on the same pins (PresenceSensor.h). kAuto tries the C4002
    // first because it's the one that can be positively detected -- it acknowledges a binary
    // command with a checksummed reply. The C4001 streams 9600-baud text and never acknowledges
    // anything, so it's the fallback when nothing answers. The probe's binary bytes reach a C4001
    // as line noise at the wrong baud rate; its own stop/mode/save/start init runs right after and
    // is what configures it.
    Serial0.println("[boot] checkpoint 5a: starting presence sensor UART");
    // The app's last range/hold (NVS) win over Config.h's starting values.
    presenceConfigStore.begin();
    const uint16_t storedRangeCm = presenceConfigStore.maxRangeCm();
    const uint16_t storedHoldS = presenceConfigStore.holdS();
    const uint16_t c4002RangeCm = storedRangeCm != PresenceConfigStore::kUnset ? storedRangeCm : Config::kC4002MaxRangeCm;
    const uint16_t c4002HoldS = storedHoldS != PresenceConfigStore::kUnset ? storedHoldS : Config::kC4002TargetDisappearDelayS;
    bool useC4002 = false;
    if (Config::kPresenceSensorType != Config::PresenceSensorType::kC4001) {
        useC4002 = c4002.begin(Serial1, Config::kC4001RXPin, Config::kC4001TXPin, Config::kC4002Baud,
                               c4002RangeCm, c4002HoldS);
        if (!useC4002 && Config::kPresenceSensorType == Config::PresenceSensorType::kC4002) {
            Serial0.println("[boot] C4002 forced in Config.h but it didn't answer -- check 5V power + TX/RX wiring");
            useC4002 = true; // honor the override; the [presence-link] counters will show what's arriving
        }
    }
    if (useC4002) {
        presenceSensor = &c4002;
    } else {
        Serial1.end();
        c4001.begin(Serial1, Config::kC4001RXPin, Config::kC4001TXPin, Config::kC4001Baud);
        presenceSensor = &c4001;
    }
    network.setPresenceSensorCode(presenceSensor == &c4002 ? 2 : 1);
    if (presenceSensor == &c4002) {
        gPresenceRangeCm = c4002RangeCm > 1100 ? 1100 : c4002RangeCm;
        gPresenceHoldS = c4002HoldS;
    } else if (storedRangeCm != PresenceConfigStore::kUnset) {
        // The C4001 keeps its range in its own flash; only re-send if the app has set one.
        c4001.setMaxRangeCm(storedRangeCm);
        gPresenceRangeCm = storedRangeCm;
    }
    publishPresenceConfig();
    Serial0.printf("[boot] presence sensor: %s%s\n", presenceSensor->name(),
        Config::kPresenceSensorType == Config::PresenceSensorType::kAuto ? " (auto-detected)" : " (forced in Config.h)");

    // Optional BNO055 on GPIO20/48 -- see Config.h's compass section (GPIO48 also drives the onboard
    // RGB LED, which will flicker with the I2C traffic unless its trace is cut).
    if (Config::kCompassEnabled) {
        Serial0.println("[boot] checkpoint 5a2: starting BNO055 compass over I2C (SDA 20, SCL 48)");
        if (!compass.begin(Config::kCompassSDAPin, Config::kCompassSCLPin)) {
            Serial0.println("[boot] BNO055 init failed -- heading will be unavailable this boot");
        }
    }

    Serial0.println("[boot] checkpoint 5b: starting speaker I2S TX (alarm + speak-through-the-node)");
    if (!audioOutput.begin(Config::kSpeakerBCLK, Config::kSpeakerWS, Config::kSpeakerDIN, Config::kSampleRateHz)) {
        Serial0.println("[boot] Speaker I2S init failed -- alarm/speak-through will not work");
    }
    network.setAudioOutput(&audioOutput);

    // Storage: probe for an SD card ONCE via VideoRecorder's own SD_MMC bring-up (same call the
    // sibling firmware uses), decide the backend for this whole boot -- see PhotoServer.h/Config.h's
    // header comments. PhotoServer below shares this same result rather than probing separately.
    Serial0.println("[boot] checkpoint 5c: probing for an SD card (SD_MMC, 1-bit mode)");
    gSDAvailable = videoRecorder.beginSD();
    photoServer.setStorageBackend(gSDAvailable); // must happen before initRetentionState() below
    if (!gSDAvailable) {
        Serial0.println("[boot] no SD card detected -- using RAM-only photo ring (stills only, no video, lost on reboot)");
        nextPhotoId = (esp_random() & 0x00FFFFFFu) | 1u; // nothing to resume across reboot in this mode
    } else {
        Serial0.printf("[boot] checkpoint 5d: SD card ready, %llu/%llu MB used\n",
            SD_MMC.usedBytes() / (1024ULL * 1024ULL), SD_MMC.totalBytes() / (1024ULL * 1024ULL));
        SD_MMC.mkdir("/photos");
        if (Config::kWipePhotosOnBoot) {
            uint32_t wiped = photoServer.wipeAllPhotos();
            Serial0.printf("[boot] kWipePhotosOnBoot=true -- cleared %lu photo file(s)\n", (unsigned long)wiped);
        }
        uint32_t highestPhotoId = photoServer.initRetentionState();
        nextPhotoId = highestPhotoId > 0 ? highestPhotoId + 1 : ((esp_random() & 0x00FFFFFFu) | 1u);
        Serial0.printf("[boot] checkpoint 5e: /photos ready (highest stored id %lu), next photo id %lu\n",
            (unsigned long)highestPhotoId, (unsigned long)nextPhotoId);
    }

    {
        WiFiConfigStore::Defaults d;
        d.role = Config::kNetworkRole;
        d.apSsid = Config::kWiFiSSID;
        static char derivedApPw[16];
        {
            uint8_t did[6];
            WiFiConfigStore::deviceIdFromEfuseMac(ESP.getEfuseMac(), did);
            WiFiConfigStore::deriveDefaultApPassword(did, derivedApPw, sizeof(derivedApPw));
        }
        d.apPassword = Config::kUseDerivedApPassword ? derivedApPw : Config::kWiFiPassword;
        d.apChannel = (uint8_t)Config::kWiFiChannel;
        d.isRosterMaster = Config::kIsRosterMaster;
        static WiFiConfigStore::Credential defCands[WiFiConfigStore::kMaxCandidates];
        const int defCount = sizeof(Config::kWiFiCandidates) / sizeof(Config::kWiFiCandidates[0]);
        uint8_t n = 0;
        for (int i = 0; i < defCount && n < WiFiConfigStore::kMaxCandidates; i++) {
            defCands[n].ssid = Config::kWiFiCandidates[i].ssid;
            defCands[n].password = Config::kWiFiCandidates[i].password;
            n++;
        }
        d.candidates = defCands;
        d.candidateCount = n;
        gWiFiConfig.begin(d);
        Serial0.printf("[boot] checkpoint 6: wifi config %s (role=%u, %u candidate(s))\n",
            gWiFiConfig.isCustomised() ? "loaded from NVS" : "using Config.h defaults",
            (unsigned)gWiFiConfig.role(), (unsigned)gWiFiConfig.candidateCount());
        if (!gWiFiConfig.isCustomised() && gWiFiConfig.role() != Config::kRoleClient) {
            Serial0.printf("[boot] AP password (per-chip default): %s  -- change it from the app\n", gWiFiConfig.apPassword());
        }
    }

    if (Config::kDiagnosticDisableWiFi) {
        Serial0.println("[boot] checkpoint 7: kDiagnosticDisableWiFi=true -- skipping WiFi/network entirely");
    } else {
        bool isPrimary = (gWiFiConfig.role() == Config::kRolePrimary);
        Serial0.printf("[boot] checkpoint 7: %s WiFi (%s) -- config %s%s...\n",
            isPrimary ? "hosting" : "joining", isPrimary ? "AP" : "STA",
            gWiFiConfig.isCustomised() ? "from NVS" : "from Config.h defaults",
            gWiFiConfig.awaitingProof() ? " [recovery arm SET -- unproven]" : "");
        if (!network.begin(gWiFiConfig)) {
            Serial0.println(isPrimary
                ? "[boot] AP hosting failed -- check the AP SSID/password (>=8 chars) and kMaxAPStations"
                : "[boot] WiFi join failed/timed out -- check the configured candidate list");
        } else {
            IPAddress myIP = isPrimary ? WiFi.softAPIP() : WiFi.localIP();
            Serial0.printf("[boot] checkpoint 8: WiFi %s, IP %s -- enter this in the app's node Network Address field\n", isPrimary ? "AP up" : "joined", myIP.toString().c_str());
            if (isPrimary) {
                Serial0.printf("[boot] AP BSSID (for a Secondary's kPrimaryBSSID): %s\n", WiFi.softAPmacAddress().c_str());
            }
            photoServer.begin(Config::kHTTPPort);
            Serial0.println("[boot] checkpoint 9: photo HTTP server up");
            videoServer.begin(Config::kVideoHTTPPort);
            Serial0.println("[boot] checkpoint 9b: video HTTP server up");
            liveStream.begin(Config::kLiveStreamHTTPPort);
            Serial0.println("[boot] checkpoint 9c: live stream server up");
        }
        bleAdvertiser.begin();
        if (Config::kBleProvisioningEnabled) {
            bleAdvertiser.enableProvisioning(gWiFiConfig);
        }
        Serial0.println("[boot] checkpoint 9d: BLE advertising ready (event-gated -- silent while a client is registered)");
    }

    // Home Assistant MQTT integration (CAMPING_SECURITY_NODE_PLAN.md, Home Security mode only) --
    // begin() just wires the config store + builds this node's hex device id, it does NOT attempt
    // a broker connection yet (that only happens in loop() when Node Mode == Home Security AND a
    // broker host is actually configured, see HomeAssistantMQTT::poll()'s doc comment).
    mqttConfig.begin();
    {
        uint8_t did[6];
        WiFiConfigStore::deviceIdFromEfuseMac(ESP.getEfuseMac(), did);
        char hex[13];
        snprintf(hex, sizeof(hex), "%02x%02x%02x%02x%02x%02x", did[0], did[1], did[2], did[3], did[4], did[5]);
        homeAssistant.begin(mqttConfig, hex);
    }
    network.setMQTTConfig(&mqttConfig, &homeAssistant);
    Serial0.printf("[boot] checkpoint 9e: Home Assistant MQTT %s\n",
        mqttConfig.isConfigured() ? "configured -- will connect in Home Security mode" : "not configured");

    doaCaptureRequested = xSemaphoreCreateBinary();

    xTaskCreatePinnedToCore(captureTask, "capture", 4096, NULL, 2, NULL, 1);
    Serial0.println("[boot] checkpoint 10: capture task started, entering loop()");
}

void loop() {
    uint32_t now = millis();

    if (!Config::kDiagnosticDisableWiFi) {
        network.poll();
        network.pollFailover();
        network.pollReconnect();
        pollConfigRecovery();

        gRemoteLogger.poll(network);
        bool remoteLoggingEnabled;
        if (network.consumeSetRemoteLoggingRequest(remoteLoggingEnabled)) {
            gRemoteLogger.setEnabled(remoteLoggingEnabled);
        }

        bool cameraEnableRequested;
        if (network.consumeSetCameraEnabledRequest(cameraEnableRequested)) {
            applyCameraEnabled(cameraEnableRequested);
        }

        // Node Mode + Automatic Alarm (CAMPING_SECURITY_NODE_PLAN.md).
        uint8_t nodeModeRequested;
        if (network.consumeSetNodeModeRequest(nodeModeRequested)) {
            gNodeMode = static_cast<NodeMode>(nodeModeRequested);
            Serial0.printf("[mode] node mode set to %u (0=Birding 1=CampingSecurity 2=HomeSecurity)\n",
                (unsigned)nodeModeRequested);
        }
        bool automaticAlarmRequested;
        if (network.consumeSetAutomaticAlarmRequest(automaticAlarmRequested)) {
            gAutomaticAlarmEnabled = automaticAlarmRequested;
            Serial0.printf("[mode] automatic alarm %s\n", gAutomaticAlarmEnabled ? "ON" : "off");
        }
        bool presenceCaptureRequested;
        if (network.consumeSetPresenceCaptureRequest(presenceCaptureRequested)) {
            applyPresenceCaptureEnabled(presenceCaptureRequested);
        }
        uint16_t rangeRequestCm, holdRequestS;
        if (network.consumeSetPresenceRangeRequest(rangeRequestCm, holdRequestS)) {
            applyPresenceRange(rangeRequestCm, holdRequestS);
        }
        if (network.consumeSoundAlarmRequest()) {
            Serial0.println("[alarm] manual kSoundAlarm received -- starting alarm tone");
            audioOutput.startAlarm();
        }
        if (network.consumeStopAlarmRequest()) {
            Serial0.println("[alarm] manual kStopAlarm received -- silencing alarm tone early");
            audioOutput.stopAlarm();
        }

        // Home Assistant MQTT (Home Security mode only -- see HomeAssistantMQTT::poll()'s doc
        // comment for why this is a complete no-op otherwise). Two front doors, one trigger path:
        // an MQTT "Sound Alarm" button press and the app's kSoundAlarm both land in the exact same
        // audioOutput.startAlarm() call, not a second alarm implementation.
        homeAssistant.poll(gNodeMode == NodeMode::kHomeSecurity);
        if (homeAssistant.consumeSoundAlarmRequest()) {
            Serial0.println("[alarm] Home Assistant button press received -- starting alarm tone");
            audioOutput.startAlarm();
        }
        bool haCameraEnableRequested;
        if (homeAssistant.consumeSetCameraEnabledRequest(haCameraEnableRequested)) {
            applyCameraEnabled(haCameraEnableRequested);
        }
        bool haPresenceCaptureRequested;
        if (homeAssistant.consumeSetPresenceCaptureRequest(haPresenceCaptureRequested)) {
            applyPresenceCaptureEnabled(haPresenceCaptureRequested);
        }

        IPAddress currentIP = network.isCurrentlyHosting() ? WiFi.softAPIP() : WiFi.localIP();
        bleAdvertiser.poll(network.isStreaming(), currentIP);
        bleAdvertiser.pollProvisioning();

        photoServer.poll();
        videoServer.poll();
        liveStream.poll(now);
    }

    // Mic capture -> mono reference stream (this variant is always single-bus/2-mic, no
    // stereo/4-mic path exists at all -- see UDPStreamer.h's header comment).
    {
        static int16_t audioAccumulator[Config::kAudioSamplesPerPacket];
        static int audioAccumulatedCount = 0;
        audioAccumulatedCount += audioRing.popAvailable(
            audioAccumulator + audioAccumulatedCount, Config::kAudioSamplesPerPacket - audioAccumulatedCount
        );
        if (audioAccumulatedCount == Config::kAudioSamplesPerPacket) {
            network.sendAudioFrame(audioSeq++, audioAccumulator, audioAccumulatedCount);
            videoRecorder.appendAudio(audioAccumulator, audioAccumulatedCount);
            audioAccumulatedCount = 0;
        }
    }

    // "Speak through the node" playback + alarm tone -- see AudioOutput::poll()'s own doc comment
    // for the enable/disable-on-idle + precedence logic.
    audioOutput.poll();

    // Video recording control -- same shape as the sibling firmware, gated additionally on
    // gSDAvailable (VideoRecorder::start() already checks isSDReady() internally, this just gives
    // a clearer log message for the no-card case specifically).
    bool videoIncludeAudio;
    if (network.consumeVideoStartRequest(videoIncludeAudio)) {
      if (!gCameraEnabled) {
          Serial0.println("[video] record start rejected -- camera is currently disabled (kSetCameraEnabled)");
      } else if (!gSDAvailable) {
          Serial0.println("[video] record start rejected -- no SD card present (RAM-only mode has no video)");
      } else {
        if (liveStream.isStreaming()) {
            Serial0.println("[video] record start rejected -- live stream is currently active (mutually exclusive)");
        } else if (!videoRecorder.start(nextVideoId, videoIncludeAudio, now)) {
            Serial0.printf("[video] record start rejected -- sdReady=%s recording=%s\n",
                videoRecorder.isSDReady() ? "true" : "false", videoRecorder.isRecording() ? "true" : "false");
        } else {
            Serial0.printf("[video] record start ok -- id %lu, audio=%s\n",
                (unsigned long)nextVideoId, videoIncludeAudio ? "true" : "false");
        }
      }
    }
    bool wasRecording = videoRecorder.isRecording();
    if (network.consumeVideoStopRequest() || gCameraDisablePending) {
        videoRecorder.stop(now);
    }
    videoRecorder.poll(now);
    if (wasRecording && !videoRecorder.isRecording()) {
        uint32_t finishedId = videoRecorder.currentVideoId();
        uint16_t frameCount = videoRecorder.frameCount();
        uint32_t audioSampleCount = videoRecorder.audioSampleCount();
        Serial0.printf("[video] session finished -- id %lu, %u frames, %lu audio samples\n",
            (unsigned long)finishedId, frameCount, (unsigned long)audioSampleCount);
        videoServer.publish(finishedId, frameCount, audioSampleCount > 0);
        network.sendVideoReady(now, finishedId, frameCount, (uint16_t)Config::kVideoFrameIntervalMs, audioSampleCount);
        nextVideoId++;
    }

    if (network.consumeVideoStreamStartRequest() && !videoRecorder.isRecording()) {
        if (gCameraEnabled) {
            liveStream.start(now);
        } else {
            Serial0.println("[stream] start rejected -- camera is currently disabled (kSetCameraEnabled)");
        }
    }
    if (network.consumeVideoStreamStopRequest() || gCameraDisablePending) {
        liveStream.stop();
    }

    if (gCameraDisablePending) {
        esp_camera_deinit();
        gCameraEnabled = false;
        gCameraDisablePending = false;
        Serial0.println("[camera] disabled -- esp_camera_deinit() done, freed for presence/audio work");
    }

    // Optional BNO055 -- poll() is internally rate-limited to Config::kCompassReportIntervalMs.
    if (Config::kCompassEnabled && compass.poll(now)) {
        network.sendCompassHeading(now, compass.headingDeg());
        network.sendOrientation(now, compass.gravity(), compass.magnetic(), compass.packedCalibration());
    }

    static uint32_t lastIdentityMs = 0;
    if (now - lastIdentityMs >= Config::kNodeIdentityIntervalMs) {
        lastIdentityMs = now;
        network.sendNodeIdentity();
    }

    static uint32_t lastAnnounceMs = 0;
    if (!network.isActingAsRosterMaster() && now - lastAnnounceMs >= Config::kNodeAnnounceIntervalMs) {
        lastAnnounceMs = now;
        network.sendNodeAnnounce();
    }

    if (xSemaphoreTake(doaCaptureRequested, 0) == pdTRUE) {
        int bandCount = network.activeBandCount();
        if (bandCount == 0) {
            DOAResult result = DOAEstimator::estimateSingleBus(
                capturedLeft, capturedRight, Config::kDOAWindowSamples, 0, 0);
            network.sendDOATelemetry(doaSeq++, now, result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), 0);
            lastDOAResults[0] = {0, 0, 0, result.azimuthDeg, result.confidence};
            lastDOAResultCount = 1;
        } else {
            lastDOAResultCount = bandCount;
            for (int i = 0; i < bandCount; i++) {
                const Protocol::FrequencyBandSlot &band = network.activeBand(i);
                DOAResult result = DOAEstimator::estimateSingleBus(
                    capturedLeft, capturedRight, Config::kDOAWindowSamples, band.lowHz, band.highHz);
                network.sendDOATelemetry(doaSeq++, now, result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), band.bandId);
                lastDOAResults[i] = {band.bandId, band.lowHz, band.highHz, result.azimuthDeg, result.confidence};
            }
        }

        // Onset-gated automatic capture -- Birding-mode behavior, unchanged regardless of Node
        // Mode (a presence-triggered capture below covers the security modes' own trigger design).
        if (network.isPhotoAutoModeEnabled() && !liveStream.isFrameBufferBusy()) {
            capturePhotoIfDue(now, false);
        }
    }

    if (network.consumeManualCaptureRequest() && !liveStream.isFrameBufferBusy()) {
        capturePhotoIfDue(now, true);
    }

    // Presence sensor (C4001 or C4002) -- trigger design per CAMPING_SECURITY_NODE_PLAN.md:
    //   1. Autonomous capture + kMotionTrigger notify fires in EVERY Node Mode, including Birding
    //      ("something wandered into view," not a security event there) -- pure evidence-gathering,
    //      no real downside either way.
    //   2. The alarm only fires automatically in Camping Security mode with Automatic Alarm on.
    //      Home Security's equivalent decision lives in Home Assistant automations instead (see
    //      HomeAssistantMQTT.h) -- the presence binary_sensor below is what those automations key
    //      off of; this node makes no automatic-alarm decision of its own in that mode.
    {
        static bool lastPublishedPresence = false;
        bool gotReport = presenceSensor->poll();

        // Sensor health (added 2026-09-26). Both sensors report continuously even with nobody
        // there, so kPresenceSensorSilenceMs with no parsed report = missing/unpowered/unplugged.
        // Flagged to the app (NodeIdentity's offline bit, sent right away and on every periodic
        // identity) and to HA (presence entity -> unavailable), instead of looking like a quiet
        // night. The timer starts at the first loop(), which is the boot grace period.
        static bool sensorOnline = true;
        static uint32_t lastSensorReportMs = now;
        if (gotReport) {
            lastSensorReportMs = now;
            if (!sensorOnline) {
                sensorOnline = true;
                Serial0.printf("[presence] %s reporting again -- sensor back online\n", presenceSensor->name());
                network.setPresenceSensorOnline(true);
                network.sendNodeIdentity();
                homeAssistant.publishPresenceSensorAvailable(true);
            }
        } else if (sensorOnline && now - lastSensorReportMs >= Config::kPresenceSensorSilenceMs) {
            sensorOnline = false;
            Serial0.printf("[presence] no %s reports for %lus -- sensor missing, unpowered, or unplugged\n",
                presenceSensor->name(), (unsigned long)(Config::kPresenceSensorSilenceMs / 1000));
            network.setPresenceSensorOnline(false);
            network.sendNodeIdentity();
            if (lastPublishedPresence) {
                lastPublishedPresence = false;
                homeAssistant.publishPresence(false);
            }
            homeAssistant.publishPresenceSensorAvailable(false);
        }
        // MQTT presence state -- reflects the sensor's real-time value, deliberately NOT gated by
        // the capture-debounce below (kMotionRetriggerMs exists to stop the CAMERA from spamming,
        // not to rate-limit what HA sees -- an automation reacting a few seconds late to a real
        // presence change would be a real, avoidable regression).
        if (gotReport && presenceSensor->presence() != lastPublishedPresence) {
            lastPublishedPresence = presenceSensor->presence();
            homeAssistant.publishPresence(lastPublishedPresence);
        }

        // Live readout (kPresenceUpdate, 2026-09-30): distance + speed + approaching/away about once a
        // second while someone's there, and one final "gone" update. Sent BEFORE the throttled
        // kMotionTrigger below so the app already holds this reading when that alert lands.
        {
            static bool lastUpdatePresence = false;
            static uint32_t lastPresenceUpdateMs = 0;
            const bool present = presenceSensor->presence();
            if (gotReport && ((present && now - lastPresenceUpdateMs >= Config::kPresenceUpdateIntervalMs) ||
                              present != lastUpdatePresence)) {
                lastPresenceUpdateMs = now;
                lastUpdatePresence = present;
                network.sendPresenceUpdate(now, presenceSensor->distanceCm(), presenceSensor->radialSpeedMps(),
                    (uint8_t)presenceSensor->movement(), (uint8_t)presenceSensor->targetState());
            }
        }

        // Diagnostic (2026-09-30, false-presence investigation): every C4002 target-status change,
        // with the raw fields, so a ghost detection shows WHERE (distance, range gates) and how
        // strong (energy) it is, and how long the sensor's own hold timer keeps it.
        if (gotReport && presenceSensor == &c4002) {
            static uint8_t lastStatus = 0xFF;
            if (c4002.targetStatusRaw() != lastStatus) {
                lastStatus = c4002.targetStatusRaw();
                const C4002Reader::Raw &r = c4002.raw();
                static const char *kStatus[] = {"none", "STATIC", "MOTION"};
                Serial0.printf("[c4002-diag] t=%lus status %s%s%s  exist %ucm e%u gates 0x%08lX hold %us  move %ucm e%u  speed %+.2f\n",
                    (unsigned long)(now / 1000), lastStatus <= 2 ? kStatus[lastStatus] : "?", c4002.isClearing() ? " (clearing)" : "",
                    c4002.beyondRange() ? " (BEYOND RANGE, ignored)" : "",
                    r.existDistCm, r.existEnergy, (unsigned long)r.existGates, r.existCountdownS,
                    r.moveDistCm, r.moveEnergy, c4002.speedMps());
            }
        }

        static uint32_t lastPresenceTriggerMs = 0;
        // Not on a hold-timer-only report: nobody is actually detected then (see C4002Reader).
        bool presenceRisingEdge = gotReport && presenceSensor->presence() &&
            presenceSensor->targetState() != PresenceSensor::TargetState::kClearing;
        if (presenceRisingEdge && now - lastPresenceTriggerMs >= Config::kMotionRetriggerMs) {
            lastPresenceTriggerMs = now;
            Serial0.printf("[presence] %s report -- distance %.1f cm\n", presenceSensor->name(), presenceSensor->distanceCm());
            network.sendMotionTrigger(now, presenceSensor->distanceCm());
            // Real bug found 2026-09-22: this fired unconditionally in every Node Mode, with no way
            // to turn it off -- gPresenceCaptureEnabled (off by default) is the fix, set from the
            // app's Camping Security screen or Home Assistant's "Presence Capture" switch.
            if (gPresenceCaptureEnabled && !liveStream.isFrameBufferBusy()) {
                capturePhotoIfDue(now, true);
            }
            if (gNodeMode == NodeMode::kCampingSecurity && gAutomaticAlarmEnabled) {
                Serial0.println("[alarm] automatic alarm firing (Camping Security mode, Automatic Alarm on)");
                audioOutput.startAlarm();
            }
        }
    }

    static uint32_t lastStatusMs = 0;
    if (now - lastStatusMs >= 2000) {
        lastStatusMs = now;
        Serial0.printf("[status] mic: %lu ok / %lu fail   camera %s   mode %u   storage %s\n",
            (unsigned long)micReadOk, (unsigned long)micReadFail,
            gCameraEnabled ? "on" : "OFF", (unsigned)gNodeMode, gSDAvailable ? "SD" : "RAM-ring");
        if (gNodeMode == NodeMode::kHomeSecurity) {
            Serial0.printf("[mqtt] configured: %s  connected: %s\n",
                mqttConfig.isConfigured() ? "yes" : "no", homeAssistant.isConnected() ? "yes" : "no");
        }
        Serial0.printf("[levels] L: %d  R: %d\n", micLeftPeak, micRightPeak);
        micLeftPeak = 0;
        micRightPeak = 0;
        Serial0.printf("[audio-ring] skipped: %lu samples\n", (unsigned long)audioRing.skippedSamples());
        for (int i = 0; i < lastDOAResultCount; i++) {
            const LastDOAResult &r = lastDOAResults[i];
            if (r.bandId == 0 && r.lowHz == 0 && r.highHz == 0) {
                Serial0.printf("[doa] band 0 (full spectrum)  azimuth: %.1f  confidence: %.2f\n", r.azimuthDeg, r.confidence);
            } else {
                Serial0.printf("[doa] band %u (%.0f-%.0f Hz)  azimuth: %.1f  confidence: %.2f\n",
                    r.bandId, r.lowHz, r.highHz, r.azimuthDeg, r.confidence);
            }
        }
        Serial0.printf(
            "[onset] fast: %.1f  floor: %.1f  threshold: %.1f  outliers_rejected: %lu\n",
            onset.currentFastEnvelope(), onset.currentSlowFloor(), onset.currentThreshold(),
            (unsigned long)onset.outlierRejectedCount()
        );
        Serial0.printf("[presence-link] %s  chars: %lu  reports parsed: %lu  unparsed: %lu  presence: %s  distance: %.1f cm\n",
            presenceSensor->name(),
            (unsigned long)presenceSensor->charsProcessed(), (unsigned long)presenceSensor->reportsParsed(),
            (unsigned long)presenceSensor->reportsUnparsed(),
            presenceSensor->presence() ? "yes" : "no", presenceSensor->distanceCm());
        if (presenceSensor == &c4002 && c4002.presence()) {
            static const char *kDirection[] = {"away", "none", "approaching"};
            Serial0.printf("[presence-link] C4002 %s  speed %.2f m/s  direction %s  light %.1f lux\n",
                c4002.isMoving() ? "motion" : "static", c4002.speedMps(),
                kDirection[(uint8_t)c4002.direction()], c4002.lightLux());
        }
        if (presenceSensor == &c4001 && c4001.presence()) {
            // Signed, as the sensor sent it -- which sign means approaching is still unconfirmed.
            Serial0.printf("[presence-link] C4001 raw speed %+.2f m/s\n", c4001.rawSpeedMps());
        }
    }
}
