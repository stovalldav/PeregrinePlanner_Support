#include "AudioOutput.h"
#include <Arduino.h>
#include <cmath>
#include "Config.h"

bool AudioOutput::begin(int bclk, int ws, int din, uint32_t sampleRateHz) {
    sampleRateHz_ = sampleRateHz;

    i2s_chan_config_t chanCfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_1, I2S_ROLE_MASTER);
    // Init only, deferred enable -- see ensureEnabled()/ensureDisabled(). Idle most of the time on
    // an unattended battery deployment; only the alarm tone or an active playback session should
    // keep this channel's clocks running.
    chanCfg.auto_clear = true; // zero-fill any DMA slot this code doesn't explicitly write, so a
                                // partially-drained buffer never replays stale audio on re-enable
    if (i2s_new_channel(&chanCfg, &txHandle_, NULL) != ESP_OK) {
        return false;
    }

    i2s_std_config_t stdCfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(sampleRateHz_),
        // NS4168 is a standard Philips-format I2S DAC. 16-bit slots -- matches this codebase's
        // int16 PCM convention everywhere else (kAudioFrame, kPlaybackAudioFrame), no resampling or
        // bit-depth conversion needed on either the capture or playback side.
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = (gpio_num_t)bclk,
            .ws = (gpio_num_t)ws,
            .dout = (gpio_num_t)din,
            .din = I2S_GPIO_UNUSED,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };

    if (i2s_channel_init_std_mode(txHandle_, &stdCfg) != ESP_OK) {
        return false;
    }
    return true; // deliberately left disabled -- ensureEnabled() starts it on first real activity
}

void AudioOutput::ensureEnabled() {
    if (channelEnabled_ || txHandle_ == nullptr) return;
    if (i2s_channel_enable(txHandle_) == ESP_OK) {
        channelEnabled_ = true;
    }
}

void AudioOutput::ensureDisabled() {
    if (!channelEnabled_ || txHandle_ == nullptr) return;
    i2s_channel_disable(txHandle_);
    channelEnabled_ = false;
}

void AudioOutput::startAlarm() {
    // Re-triggering while already active restarts the auto-stop window (a second kSoundAlarm
    // effectively extends it) but deliberately does NOT reset alarmElapsedSamples_ -- no reason to
    // click/restart the sweep if it's already mid-cycle.
    alarmStartMs_ = millis();
    if (alarmActive_) return;
    alarmActive_ = true;
    alarmElapsedSamples_ = 0; // a fresh trigger starts the sweep from the low end, not mid-cycle
}

void AudioOutput::stopAlarm() {
    alarmActive_ = false;
}

void AudioOutput::feedPlayback(const int16_t *samples, int count) {
    playbackRing_.pushBlock(samples, count);
    lastPlaybackFeedMs_ = millis();
}

bool AudioOutput::isPlaybackActive() const {
    // "Active" means either genuinely fresh frames are still arriving, or there's buffered audio
    // left to drain from a moment ago -- both must go quiet before playback is considered over (see
    // header comment on kPlaybackIdleTimeoutMs for why no explicit stop signal is needed).
    return (millis() - lastPlaybackFeedMs_) < kPlaybackIdleTimeoutMs;
}

void AudioOutput::writeBlock(const int16_t *monoSamples, int count) {
    // Duplicate mono into interleaved L/R -- see header comment on why (NS4168's CTRL-pin channel
    // selection is tied at build time, not GPIO-driven, so this works regardless of which way).
    static int16_t interleaved[kBlockFrames * 2];
    for (int i = 0; i < count; i++) {
        interleaved[i * 2] = monoSamples[i];
        interleaved[i * 2 + 1] = monoSamples[i];
    }
    size_t bytesWritten = 0;
    // Bounded timeout, same philosophy as I2SCapture's readFrames() -- a stalled/misbehaving DAC
    // shouldn't be able to block loop() indefinitely.
    i2s_channel_write(txHandle_, interleaved, count * 2 * sizeof(int16_t), &bytesWritten, pdMS_TO_TICKS(50));
}

void AudioOutput::poll() {
    if (txHandle_ == nullptr) return;

    // Bounded auto-stop -- see Config::kAlarmAutoStopMs's doc comment for why this exists at all
    // (kSoundAlarm has no corresponding stop packet on the wire).
    if (alarmActive_ && (millis() - alarmStartMs_ >= Config::kAlarmAutoStopMs)) {
        alarmActive_ = false;
    }

    const bool playbackActive = isPlaybackActive();
    if (!alarmActive_ && !playbackActive) {
        ensureDisabled();
        return;
    }
    ensureEnabled();
    if (!channelEnabled_) return;

    static int16_t block[kBlockFrames];

    if (playbackActive) {
        // Speak-through-the-node takes precedence over the alarm tone (see feedPlayback's doc
        // comment) -- drain whatever's buffered; pad any shortfall with silence rather than
        // repeating stale samples (a genuine mid-utterance network gap, not just "nothing to play
        // at all" -- isPlaybackActive() already established a session is still considered live).
        int got = playbackRing_.popAvailable(block, kBlockFrames);
        for (int i = got; i < kBlockFrames; i++) block[i] = 0;
        writeBlock(block, kBlockFrames);
        return;
    }

    // Alarm tone: a low->high->low sine sweep, phase-accumulated so consecutive chunks stay
    // continuous (no audible click at the chunk boundary the way naively resetting phase per-chunk
    // would cause).
    const uint32_t sweepSamples = (Config::kAlarmToneSweepMs * sampleRateHz_) / 1000;
    const float amplitude = Config::kAlarmToneAmplitude * 32767.0f;
    for (int i = 0; i < kBlockFrames; i++) {
        // Triangle sweep position in [0, 1]: 0->1 over the first half of the cycle (low->high),
        // 1->0 over the second half (high->low).
        float t = (float)alarmElapsedSamples_ / (float)sweepSamples; // [0, 1)
        float sweepFrac = (t < 0.5f) ? (t * 2.0f) : (2.0f - t * 2.0f);
        float freqHz = Config::kAlarmToneLowHz + sweepFrac * (Config::kAlarmToneHighHz - Config::kAlarmToneLowHz);

        alarmPhaseRad_ += 2.0f * (float)M_PI * freqHz / (float)sampleRateHz_;
        if (alarmPhaseRad_ > 2.0f * (float)M_PI) alarmPhaseRad_ -= 2.0f * (float)M_PI;

        block[i] = (int16_t)(amplitude * sinf(alarmPhaseRad_));

        alarmElapsedSamples_++;
        if (alarmElapsedSamples_ >= sweepSamples) alarmElapsedSamples_ = 0;
    }
    writeBlock(block, kBlockFrames);
}
