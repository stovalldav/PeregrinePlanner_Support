// AudioOutput.h — NS4168 I2S speaker output (I2S_NUM_1 TX), the first audio OUTPUT peripheral
// anywhere in this codebase (every other I2S bus in either sibling firmware is a capture/RX path).
// Serves two consumers sharing one TX setup, per CAMPING_SECURITY_NODE_PLAN.md:
//   1. An in-firmware synthesized alarm tone (no SD, no stored sample data -- a phase accumulator).
//   2. "Speak through the node" -- phone-sent PCM (kPlaybackAudioFrame) played back live while the
//      app's push-to-talk button is held.
//
// Mono source, stereo I2S wire format: the NS4168's CTRL pin selects which I2S slot (L or R) it
// actually plays, tied to a fixed level on this build rather than driven from a GPIO (see
// CAMPING_SECURITY_NODE_PLAN.md's GPIO table) -- writing the SAME sample into both L and R slots
// means playback is correct regardless of which way CTRL happens to be tied, no dependency on
// knowing that at firmware-build time.
//
// No explicit "stop playback" wire signal exists (see NetworkProtocol.h's kPlaybackAudioFrame
// comment) -- releasing the app's push-to-talk button just means frames stop arriving, and this
// class naturally falls back to silence once the ring buffer runs dry (see poll()'s doc comment).
// A genuine network hiccup mid-utterance produces the same graceful silence, not a stale/looping
// sound -- deliberate, matches the plan's stated design.
#pragma once

#include <cstddef>
#include <cstdint>
#include "driver/i2s_std.h"
#include "RingBuffer.h"

class AudioOutput {
public:
    // 1 second of playback-ring headroom at the fixed 44100 sample rate this codebase uses
    // everywhere (see RingBuffer.h's explicit-capacity constructor -- the ring can't be resized
    // later, so this is fixed at construction rather than deriving from begin()'s sampleRateHz
    // parameter, same "44100 is a fixed fact of this hardware, not a genuine runtime knob" reality
    // every other sample-rate mention in this codebase already accepts).
    AudioOutput() : playbackRing_(44100) {}

    bool begin(int bclk, int ws, int din, uint32_t sampleRateHz);

    // Call every loop() iteration. Writes at most one small fixed-size chunk per call (same
    // "bound the worst-case blocking time" philosophy as the mic capture tasks' kReadBlockFrames),
    // so a slow/stalled I2S write can't starve the rest of loop() any more than one chunk's worth.
    // Enables the TX channel on first real activity (alarm or a fresh playback frame) and disables
    // it again once both go idle -- a battery-relevant real cost on an unattended camping
    // deployment, not just a latency nicety.
    void poll();

    // Starts/stops the synthesized alarm tone. Idempotent -- calling start while already active (or
    // stop while already idle) is a no-op.
    void startAlarm();
    void stopAlarm();
    bool isAlarmActive() const { return alarmActive_; }

    // "Speak through the node" -- called from UDPStreamer's kPlaybackAudioFrame handler with each
    // arriving frame's decoded mono int16 samples. Pushes into the internal jitter/ring buffer;
    // poll() drains it. Takes precedence over the alarm tone if both happen to be requested at once
    // (a human pressing the app's Sound Alarm button and push-to-talk simultaneously is an edge
    // case, not a real use pattern, but "the human's live voice wins" is the more sensible default
    // of the two arbitrary choices).
    void feedPlayback(const int16_t *samples, int count);
    bool isPlaybackActive() const;

private:
    static constexpr int kBlockFrames = 256; // matches the mic capture tasks' own block size
    // How long after the last kPlaybackAudioFrame arrived before playback is considered over (button
    // released, or the phone stopped sending) -- long enough to ride out a brief in-flight gap
    // between UDP packets without an audible chop, short enough that releasing the button doesn't
    // leave a noticeably long tail of silence-padding before the alarm (if also requested) can take
    // back over.
    static constexpr uint32_t kPlaybackIdleTimeoutMs = 400;

    void ensureEnabled();
    void ensureDisabled();
    void writeBlock(const int16_t *monoSamples, int count);

    i2s_chan_handle_t txHandle_ = nullptr;
    bool channelEnabled_ = false;
    uint32_t sampleRateHz_ = 44100;

    bool alarmActive_ = false;
    uint32_t alarmStartMs_ = 0; // for Config::kAlarmAutoStopMs -- see poll()'s doc comment
    float alarmPhaseRad_ = 0.0f; // running phase, radians -- carried across chunks so the sine stays
                                 // continuous (no audible click at chunk boundaries)
    uint32_t alarmElapsedSamples_ = 0; // position within the low->high->low sweep cycle, wraps at
                                        // one full cycle's sample count

    // Playback ring: 1 second of headroom at the configured sample rate -- generous relative to the
    // ~8ms/block draining rate, absorbs real network jitter without needing much RAM (PSRAM-backed
    // via RingBuffer.h, same allocation pattern as every other ring in this codebase).
    RingBuffer playbackRing_;
    uint32_t lastPlaybackFeedMs_ = 0;
};
