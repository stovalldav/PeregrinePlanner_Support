// PhotoServer.h — the "tiny server" half of the confirmed "HTTP pull, node runs a tiny server"
// photo-transfer decision (see CAMERA_NODE_NETWORK_SPEC.md / PhotoReadyPacket's comment in
// NetworkProtocol.h).
//
// **Two storage backends, decided once at boot (CAMPING_SECURITY_NODE_PLAN.md, revised
// 2026-09-17)** -- unlike ../PeregrineMicArrayCam's PhotoServer (SD-only, always required), this
// variant probes for an SD card at boot and picks a backend transparently: the app's HTTP surface
// (`GET /photo/<id>`, `GET /photos`, `DELETE /photo/<id>`, `DELETE /photos`, `GET /snapshot`) is
// IDENTICAL either way -- the app never knows or cares which backend actually served a request.
//
//   - **SD available**: byte-identical behavior to the sibling firmware's PhotoServer -- every
//     capture written to /photos/<id>.jpg, `kMaxStoredPhotos` retention, ids stay monotonic across
//     a reboot, real video recording available (VideoRecorder). Survives a power cycle.
//   - **SD absent** (no card, or the mount failed): a small in-PSRAM ring of `kRamPhotoRingCapacity`
//     JPEGs (Config.h), oldest evicted first. Lost on reboot -- there is no way around that without
//     a card. Video recording is not attempted in this mode (see CAMPING_SECURITY_NODE_PLAN.md's
//     Storage section for why a meaningful clip length doesn't fit a RAM budget).
//
// `begin()` takes the boot-time SD probe result and commits to one backend for the whole session --
// this deliberately does NOT re-probe at runtime (a card inserted mid-session goes unnoticed until
// the next reboot; CAMPING_SECURITY_NODE_PLAN.md's own open item flags this as an accepted,
// documented limitation, not an oversight).
#pragma once

#include <cstdint>
#include <cstddef>
#include <WebServer.h>
#include <WString.h>
#include "Config.h"

class PhotoServer {
public:
    // Must be called BEFORE initRetentionState()/publish() -- typically right after the boot-time
    // SD_MMC probe, well before Wi-Fi/begin() (the HTTP server doesn't need to be up yet to decide
    // which backend this boot uses). Split from begin() specifically so initRetentionState() can
    // run during the same early boot phase the sibling firmware already runs its own SD scan in,
    // rather than waiting on Wi-Fi to come up first. `ramCapacity` only matters when `sdAvailable`
    // is false.
    void setStorageBackend(bool sdAvailable, uint8_t ramCapacity = Config::kRamPhotoRingCapacity);

    // Starts the HTTP server only -- assumes setStorageBackend() already ran.
    void begin(uint16_t port);

    bool sdAvailable() const { return sdAvailable_; }

    // Call every loop() iteration.
    void poll();

    // Publishes a newly captured photo. SD backend: caches it as the fast-path RAM buffer (the
    // caller separately writes the SD copy -- see the .ino's capturePhotoIfDue(), unchanged from
    // the sibling firmware). RAM-only backend: this IS the store -- appends to the ring, evicting
    // the oldest entry if already at ramCapacity. Takes ownership of `data` either way (must be
    // heap/PSRAM-allocated, freed here).
    void publish(uint32_t photoId, uint8_t *data, size_t length);

    // SD backend only: one full /photos scan at boot, same as the sibling firmware's PhotoServer --
    // see that file's doc comment. Returns 0 (and does nothing) on the RAM-only backend, since
    // nothing persists across a reboot to resume from -- nextPhotoId reseeds from esp_random() in
    // that case, same as the sibling firmware's own "empty store" path already does.
    uint32_t initRetentionState();

    // SD backend only -- a no-op on the RAM-only backend (publish() above already handles RAM
    // eviction inline, there's no separate "note it was stored" step needed for a ring).
    void notePhotoStored(uint32_t photoId, uint16_t maxFiles);

    // Either backend: wipes everything. Returns the number removed.
    uint32_t wipeAllPhotos();

private:
    void handlePhotoRequest(); // GET    /photo/{id}
    void handlePhotoDelete();  // DELETE /photo/{id}
    void handlePhotoList();    // GET    /photos
    void handlePhotoClear();   // DELETE /photos  -- wipe the whole store
    void handleSnapshot();     // GET    /snapshot

    static String photoPath(uint32_t id);
    static bool parseIdFromPath(const String &path, uint32_t &outId);

    void scanRetentionState(uint32_t &countOut, uint32_t &lowestOut, uint32_t &highestOut);
    void advanceOldestStoredId();

    // RAM-ring backend helpers.
    void ramPublish(uint32_t photoId, uint8_t *data, size_t length);
    void ramFreeSlot(int index);
    int ramFindSlot(uint32_t photoId) const; // -1 if not present

    WebServer server_;
    bool sdAvailable_ = false;

    // SD-backend fast-path cache + retention tracking -- unchanged from the sibling firmware.
    uint32_t currentPhotoId_ = 0;
    uint8_t *photoData_ = nullptr;
    size_t photoLength_ = 0;
    uint32_t storedCount_ = 0;
    uint32_t oldestStoredId_ = 0; // 0 == store empty / unknown

    // RAM-ring backend. Fixed-size array, not a true circular buffer -- eviction is "oldest
    // insertion order," not "oldest array slot," since an arbitrary slot can be freed early by an
    // explicit phone DELETE (see ramFreeSlot()). kRamPhotoRingCapacity is small (8-16) so a linear
    // scan per operation is cheap and not worth a fancier structure.
    struct RamSlot {
        uint32_t id = 0;    // 0 == slot empty
        uint8_t *data = nullptr;
        size_t length = 0;
        uint32_t insertSeq = 0; // monotonic insertion order, for oldest-first eviction
    };
    static constexpr int kMaxRamSlots = 32; // headroom above Config::kRamPhotoRingCapacity's expected 8-16
    RamSlot ramSlots_[kMaxRamSlots];
    uint8_t ramCapacity_ = Config::kRamPhotoRingCapacity;
    uint32_t ramInsertSeq_ = 0;
};
