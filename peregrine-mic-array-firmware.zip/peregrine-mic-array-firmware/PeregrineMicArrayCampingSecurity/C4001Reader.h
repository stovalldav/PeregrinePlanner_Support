// C4001Reader.h — DFRobot C4001 (SEN0609) mmWave presence sensor, UART.
//
// **Wire protocol CONFIRMED against real hardware 2026-09-22** (device MAC 28:84:85:60:89:28) --
// two earlier guesses here ("Range <cm>", then a different field entirely) were both wrong. The
// real fix was cross-checked directly against DFRobot's own DFRobot_C4001 library source
// (setSensorMode()/anaysisData() in DFRobot_C4001.cpp, github.com/dfrobot/DFRobot_C4001), not
// guessed: the module needs an explicit stop -> select exist mode ("setRunApp 0") -> saveConfig ->
// start sequence before its presence flag is live -- "sensorStart" alone (the original code here)
// leaves the flag reporting a stuck, meaningless value regardless of real activity. Confirmed
// after the fix: sustained real motion produced repeated, correctly-debounced presence transitions
// and camera triggers, matching real mic-level activity at the same time -- not just a plausible
// theory, an observed correlation.
//
// **Now running in speed/distance mode** ("setRunApp 1", "$DFDMD" sentences), switched from the
// exist/presence-only mode above specifically because that mode structurally cannot report a
// distance at all -- confirmed directly from the vendor source. Speed mode's target count (par1)
// stands in for presence() instead of a dedicated flag; distanceCm() comes from par3 (meters,
// converted to cm to match this class's existing unit). Not yet confirmed against a real detection
// in this mode specifically -- the exist-mode presence fix above was verified with a real hand-wave
// test before this switch; this mode's own field mapping should get the same treatment.
//
// begin()/poll()/presence()/distanceCm()'s shape mirrors GPSReader.h/OnsetDetector.h's existing
// "non-blocking poll, latch the last result" convention deliberately, so it plugs into the rest of
// this firmware the same way every other sensor here does.
#pragma once

#include <cstddef>
#include <cmath>
#include <cstdint>
#include <HardwareSerial.h>
#include "PresenceSensor.h"

class C4001Reader : public PresenceSensor {
public:
    void begin(HardwareSerial &serial, int rxPin, int txPin, uint32_t baud);

    // Call every loop() iteration -- non-blocking, drains whatever bytes are currently available
    // and updates the latched presence/distance state. Returns true exactly once per newly parsed
    // report line (mirrors OnsetDetector's own "true on trigger" shape) so the caller can act on
    // transitions instead of polling presence() unconditionally every iteration.
    bool poll() override;

    bool presence() const override { return presence_; }
    float distanceCm() const override { return distanceCm_; }
    const char *name() const override { return "C4001"; }
    uint32_t lastReportMs() const { return lastReportMs_; }

    // $DFDMD par4 is speed in m/s (DFRobot_C4001.cpp: `target.speed = atof(parts[4]) * 100`,
    // getTargetSpeed() -> /100, printed as "m/s" in their mRangeVelocity example). Which SIGN means
    // approaching is undocumented, so movement() stays kUnknown and only the magnitude is sent; the
    // signed value is in the status log (rawSpeedMps) so it can be confirmed against a real walk-up.
    float radialSpeedMps() const override { return presence_ ? fabsf(speedMps_) : 0.0f; }
    TargetState targetState() const override {
        if (!presence_) return TargetState::kNone;
        return fabsf(speedMps_) >= 0.05f ? TargetState::kMoving : TargetState::kPresentUnknown;
    }
    float rawSpeedMps() const { return speedMps_; }

    // "setRange <min m> <max m>" between sensorStop and saveConfig/sensorStart -- DFRobot_C4001.cpp's
    // setDetectThres()/writeCMD() UART path (speed mode; max <= 2500 cm there). The module saves it
    // in its own flash. No reply is parsed (the vendor library doesn't check one either), so this
    // returns true once sent. Blocks ~2s (the vendor's own stop/save delays). Not yet run on a C4001.
    bool setMaxRangeCm(uint16_t cm) override;
    uint16_t minSupportedRangeCm() const override { return 30; }
    uint16_t maxSupportedRangeCm() const override { return 2500; }

    // Bring-up aid, same "chars vs. valid sentences" pattern this project already uses for GPS
    // (see GPSReader.h) -- tells a genuinely silent/disconnected link apart from a link that's
    // receiving bytes it just can't parse (a real possibility given the format above is unverified).
    uint32_t linesParsed() const { return linesParsed_; }
    uint32_t linesUnparsed() const { return linesUnparsed_; }
    uint32_t charsProcessed() const override { return charsProcessed_; }
    uint32_t reportsParsed() const override { return linesParsed_; }
    uint32_t reportsUnparsed() const override { return linesUnparsed_; }

private:
    bool parseReportLine(const char *line);

    HardwareSerial *serial_ = nullptr;
    static constexpr size_t kLineBufSize = 64;
    char lineBuf_[kLineBufSize];
    size_t lineLen_ = 0;

    bool presence_ = false;
    float distanceCm_ = 0.0f;
    float speedMps_ = 0.0f;
    uint16_t maxRangeCm_ = 0; // 0 = no limit applied here
    uint32_t lastReportMs_ = 0;

    uint32_t charsProcessed_ = 0;
    uint32_t linesParsed_ = 0;
    uint32_t linesUnparsed_ = 0;
};
