// UDPStreamer.h — WiFi STA (not SoftAP) + the UDP control/data socket, for camera/GPS nodes that
// join an existing network the phone is already on, rather than hosting their own AP the way the
// front array/rear sensor do. See Config.h's WiFi STA section and
// CAMERA_NODE_NETWORK_SPEC.md's "leave existing hardware on AP mode, add STA support only for new
// nodes" decision.
//
// Everything downstream of `begin()` — the registered-client tracking, control-packet handling,
// audio/DOA sends — is unchanged from ../PeregrineMicArray/UDPStreamer.h: the phone still actively
// connects TO this device's IP:port and sends kHandshakePing/kSessionStart, exactly like the AP
// case, just at a DHCP-assigned address (read off the Serial0 boot log and entered manually into
// the phone app's "Network Address" field for this node) instead of the AP's fixed 192.168.4.1.
#pragma once

#include <cstdint>
#include <WiFiUdp.h>
#include "NetworkProtocol.h"
#include "NodeRoster.h"
#include "Config.h"
#include "WiFiConfigStore.h"
#include "MQTTConfigStore.h"
#include "NodeMode.h"

class AudioOutput; // forward-declared -- only a pointer is needed here, see feedPlayback's call site
class HomeAssistantMQTT; // forward-declared -- only a pointer is needed here, see sendMQTTConfigReport

class UDPStreamer {
public:
    // Brings up Wi-Fi (host AP or join a candidate) from `cfg`'s *effective* config -- NVS
    // overrides where present, Config.h defaults otherwise -- and starts the UDP socket. Blocks
    // (with a per-candidate timeout) until connected; returns false on failure so the caller can
    // decide whether to retry/reboot rather than silently running with no network. The reference
    // is retained: the runtime Wi-Fi paths (pollReconnect/pollFailover) and the kSetWiFiConfig
    // handler all read/mutate it. See CONFIGURABLE_FLEET_PLAN.md Part A.
    bool begin(WiFiConfigStore &cfg);

    void poll();

    // Call every loop() iteration alongside poll() -- only meaningful when Config::kNetworkRole ==
    // kRoleSecondary, a no-op otherwise. See MIC_ARRAY_MASTER_AP_PLAN.md §4's failover state
    // machine, implemented here 2026-08-14.
    void pollFailover();

    // Call every loop() iteration alongside poll() -- only meaningful when Config::kNetworkRole ==
    // kRoleClient, a no-op otherwise. See WIFI_MULTI_SSID_FALLBACK_PLAN.md's Phase 2 (added
    // 2026-08-16): re-attempts the Config::kWiFiCandidates join loop if the STA link has been down
    // for Config::kWiFiReconnectGraceMs, covering runtime drops that begin()'s one-time join can't.
    void pollReconnect();

    // True if this node is CURRENTLY acting as the fleet's AP host -- always true for
    // kRolePrimary, true for kRoleSecondary only while failed-over, false otherwise. Drives
    // roster-mastering/announce-gating decisions that used to be a compile-time
    // `Config::kNetworkRole == kRolePrimary` check (see MIC_ARRAY_MASTER_AP_PLAN.md §5: "kIsMasterNode's
    // aggregation logic... needs to become driven by 'is this node currently hosting the AP'...
    // instead of a fixed compile-time flag").
    bool isCurrentlyHosting() const;

    // Added 2026-08-16 -- broader than isCurrentlyHosting(): true whenever this node should act as
    // the fleet's roster master, whether that's because it's hosting the AP OR because
    // Config::kIsRosterMaster was set true on it for an all-kRoleClient shared-external-network
    // deployment (see that constant's own doc comment in Config.h for the full rationale). The two
    // roster-related call sites (kNodeAnnounce acceptance, self-announce skip) use this instead of
    // the bare isCurrentlyHosting() now; every other use of "am I hosting" stays on that original
    // method unchanged. Defined in the .cpp, not inline here, matching isCurrentlyHosting()'s own
    // existing style (mirrors ../PeregrineMicArray/UDPStreamer.h's identical method, even though
    // this header happens to already #include "Config.h" unlike that one).
    bool isActingAsRosterMaster() const;

    bool isStreaming() const { return streaming_; }

    void sendAudioFrame(uint32_t seq, const int16_t *samples, int count);
    // sendStereoAudioFrame/sendAudioLevels/sendTimedOnset intentionally not present in this tree --
    // this variant has no second mic pair (see Config.h's header comment) and no GPS/PPS clock to
    // timestamp an onset against (CAMPING_SECURITY_NODE_PLAN.md: "No GPS -- confirmed deliberate").
    void sendDOATelemetry(uint32_t seq, uint32_t timestampMs, float azimuthDeg, float confidence, float relativeLevel, uint8_t bandId);

    // Which presence sensor setup() found, reported in NodeIdentity/announce as hasPresenceSensor:
    // 1 = C4001, 2 = C4002, with bit 0x80 set while the sensor has gone silent (NetworkProtocol.h).
    // Call before begin(). Defaults to C4001, online.
    void setPresenceSensorCode(uint8_t code) { presenceSensorCode_ = code; }
    void setPresenceSensorOnline(bool online) { presenceSensorOnline_ = online; }
    uint8_t presenceSensorByte() const {
        return (uint8_t)(presenceSensorCode_ | (presenceSensorOnline_ ? 0 : Protocol::kPresenceSensorOfflineFlag));
    }

    // New for this node type — see NetworkProtocol.h's "Multi-node network additions."
    void sendNodeIdentity();
    // Optional BNO055 (Config::kCompassEnabled, 2026-09-28) -- same shapes as ../PeregrineMicArrayCam.
    void sendCompassHeading(uint32_t timestampMs, float headingDeg);
    void sendOrientation(uint32_t timestampMs, const float *gravity, const float *magnetic, uint8_t calibration);
    void sendPhotoReady(uint32_t timestampMs, uint32_t photoId, uint32_t photoSizeBytes);
    // kMotionTrigger -- rising edge of the C4001 presence sensor (see C4001Reader.h). Reuses this
    // existing sensor-agnostic mechanism rather than a new packet type -- MotionTriggerPacket's
    // own doc comment already documents signalStrength as "a sensor-specific relative figure, not
    // calibrated across sensor types," which the C4001 slots into exactly like a PIR would. No-op
    // unless a phone client is registered (same as every other send here); the photo the trigger
    // also captures still lands on whichever storage backend is active regardless.
    void sendMotionTrigger(uint32_t timestampMs, float signalStrength);
    void sendPresenceUpdate(uint32_t timestampMs, float distanceCm, float speedMps, uint8_t movement, uint8_t targetState);

    // Roster discovery (MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #1) -- broadcasts this node's own
    // identity to the LAN, not to any registered phone client, so unlike every other send*
    // method above this one works regardless of `streaming_`/session state, and regardless of
    // whether a phone is even connected yet. Uses `WiFi.localIP()`/`subnetMask()` to compute the
    // broadcast address (see broadcastAddress() below), which is only meaningful in STA mode --
    // PeregrineMicArrayCam.ino only calls this when NOT the current Primary (see
    // Config::kNetworkRole), since a Primary (AP mode) has no announcement to make anyway: it
    // already knows its own identity, there's nothing to hear from itself.
    void sendNodeAnnounce();

    // Manual/video capture control (MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3) -- this class stays a
    // pure protocol/transport layer, same as everything above: it decodes the phone's request and
    // exposes a one-shot flag, but PeregrineMicArrayCam.ino's loop() (which already owns the
    // camera/VideoRecorder) is what actually acts on it, matching how doaCaptureRequested already
    // works for onset-triggered stills.
    bool isPhotoAutoModeEnabled() const { return photoAutoMode_; }
    // Runtime override of the min gap between captures (kSetPhotoInterval) -- Config::kPhotoMinIntervalMs
    // is only the boot default. capturePhotoIfDue() reads this every call. No persistence: the app
    // re-sends the saved value on reconnect, same as the photo-mode flag above.
    uint32_t photoMinIntervalMs() const { return photoMinIntervalMs_; }
    // Each consume* method returns true (and resets) at most once per request -- a second poll()
    // before the next request sees false, so .ino doesn't need its own separate "already handled
    // this one" bookkeeping.
    bool consumeManualCaptureRequest();
    bool consumeVideoStartRequest(bool &includeAudio);
    bool consumeVideoStopRequest();
    void sendVideoReady(uint32_t timestampMs, uint32_t videoId, uint16_t frameCount, uint16_t frameIntervalMs, uint32_t audioSampleCount);

    // Live MJPEG preview control (field camera-aim validation) -- same one-shot consume pattern.
    bool consumeVideoStreamStartRequest();
    bool consumeVideoStreamStopRequest();

    int activeBandCount() const { return activeBandCount_; }
    const Protocol::FrequencyBandSlot &activeBand(int index) const { return activeBands_[index]; }

    // Added 2026-08-18, FIELD_DEBUG_PLAN.md -- see RemoteLogger.h for the full rationale, and
    // ../PeregrineMicArray/UDPStreamer.h's identical pair for the full doc comments (mirrored, not
    // reinvented).
    void sendLogLine(const char *line);
    bool consumeSetRemoteLoggingRequest(bool &enabled);
    // Runtime camera on/off toggle -- frees the camera's CPU/PSRAM/DMA for presence/audio work.
    // Same fire-and-forget, no-persistence shape as the toggles above.
    bool consumeSetCameraEnabledRequest(bool &enabled);

    // Sends a kWiFiConfigReport (current role/AP/candidate SSIDs -- never passwords) to a specific
    // address. Called from the kGetWiFiConfig handler and right before a commit/reset reboot so the
    // app has an ack. CONFIGURABLE_FLEET_PLAN.md Part A.
    void sendWiFiConfigReport(IPAddress toIP, uint16_t toPort);

    // CAMPING_SECURITY_NODE_PLAN.md additions -- same fire-and-forget, no-persistence shape as
    // every consume* method above.
    bool consumeSetNodeModeRequest(uint8_t &mode);
    bool consumeSetAutomaticAlarmRequest(bool &enabled);
    bool consumeSetPresenceCaptureRequest(bool &enabled);
    // kSetPresenceRange -- 0xFFFF in either = unchanged. Same request-latch shape as above.
    bool consumeSetPresenceRangeRequest(uint16_t &maxRangeCm, uint16_t &holdS);
    // The current range/hold the app should show; sendNodeIdentity() follows every identity with it.
    void setPresenceConfig(uint16_t maxRangeCm, uint16_t holdS, uint16_t minCm, uint16_t maxCm) {
        presenceConfig_ = {Protocol::kVersion, Protocol::kPresenceConfig, maxRangeCm, holdS, minCm, maxCm};
        presenceConfigKnown_ = true;
    }
    void sendPresenceConfig();
    // kSoundAlarm -- manual trigger, mirrors consumeManualCaptureRequest()'s bare-flag shape.
    bool consumeSoundAlarmRequest();
    // kStopAlarm -- same bare-flag shape, the app's early-stop counterpart to kSoundAlarm.
    bool consumeStopAlarmRequest();
    // Must be called once in setup() before any kPlaybackAudioFrame can arrive -- handlePacket's
    // decoder forwards straight into this instance's playback ring rather than exposing a raw
    // consume-buffer method, since audio needs to keep flowing continuously while held, not be
    // polled one packet at a time.
    void setAudioOutput(AudioOutput *output) { audioOutput_ = output; }

    // Must be called once in setup() before kGetMQTTConfig/kSetMQTTConfig can be answered --
    // `mqtt` is only needed for its isConnected() (surfaced in kMQTTConfigReport so the app can
    // show "Connected to Home Assistant" without a separate query).
    void setMQTTConfig(MQTTConfigStore *cfg, HomeAssistantMQTT *mqtt) { mqttCfg_ = cfg; mqtt_ = mqtt; }
    void sendMQTTConfigReport(IPAddress toIP, uint16_t toPort);

private:
    uint8_t presenceSensorCode_ = 1;
    bool presenceSensorOnline_ = true;
    void handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort);
    IPAddress broadcastAddress() const;
    // Shared by begin()'s cold-boot-with-no-Primary path and pollFailover()'s runtime-loss path --
    // both converge to the same "start hosting our own AP" transition.
    void promoteToFailedOver();
    // Shared by begin()'s STA branch and pollReconnect() -- see the .cpp's own doc comment.
    // WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16.
    bool joinBestCandidate();
    // Fills a 6-byte NodeIdentityPacket::deviceId/RosterEntryPacket::deviceId field from
    // ESP.getEfuseMac() -- see NodeIdentityPacket's own doc comment in NetworkProtocol.h for why
    // this specific source, not WiFi.macAddress()/softAPmacAddress(). Shared by sendNodeIdentity()
    // and sendNodeAnnounce(), the two call sites that build a NodeIdentityPacket.
    static void fillDeviceId(uint8_t *out);

    // Runtime Wi-Fi / AP / role config -- NVS-backed, set in begin(). All the Wi-Fi bring-up and
    // recovery paths read the *effective* view through this instead of Config::kWiFi* directly.
    WiFiConfigStore *cfg_ = nullptr;

    WiFiUDP udp_;
    bool streaming_ = false;
    IPAddress clientIP_;
    uint16_t clientPort_ = 0;
    uint32_t lastClientActivityMs_ = 0;
    Protocol::FrequencyBandSlot activeBands_[Protocol::kMaxDOABands] = {};
    int activeBandCount_ = 0;
    // Only ever populated if this node is the current roster master (Config::kNetworkRole ==
    // kRolePrimary) -- see NodeRoster.h's header for why every node still safely owns one of
    // these either way.
    NodeRoster roster_;

    // Secondary/failover state (MIC_ARRAY_MASTER_AP_PLAN.md §4) -- unused/inert unless
    // Config::kNetworkRole == kRoleSecondary.
    bool failedOver_ = false;
    uint32_t lastConnectedMs_ = 0;
    uint32_t lastPrimaryScanMs_ = 0;

    // kSetRemoteLogging request state -- see consumeSetRemoteLoggingRequest()'s own comment.
    bool remoteLoggingRequested_ = false;
    bool remoteLoggingRequestedValue_ = false;

    // kSetCameraEnabled request state -- same shape.
    bool cameraEnabledRequested_ = false;
    bool cameraEnabledRequestedValue_ = false;

    // CAMPING_SECURITY_NODE_PLAN.md additions -- same fire-and-forget request-latch shape.
    bool nodeModeRequested_ = false;
    uint8_t nodeModeRequestedValue_ = Config::kNodeModeDefault;
    bool automaticAlarmRequested_ = false;
    bool automaticAlarmRequestedValue_ = Config::kAutomaticAlarmDefault;
    bool presenceCaptureRequested_ = false;
    bool presenceCaptureRequestedValue_ = Config::kPresenceCaptureDefault;
    bool presenceRangeRequested_ = false;
    uint16_t presenceRangeRequestedCm_ = 0xFFFF;
    uint16_t presenceHoldRequestedS_ = 0xFFFF;
    Protocol::PresenceConfigPacket presenceConfig_ = {};
    bool presenceConfigKnown_ = false;
    bool soundAlarmRequested_ = false;
    bool stopAlarmRequested_ = false;
    // Set once via setAudioOutput() in setup() -- see that method's doc comment.
    AudioOutput *audioOutput_ = nullptr;
    // Set once via setMQTTConfig() in setup() -- see that method's doc comment.
    MQTTConfigStore *mqttCfg_ = nullptr;
    HomeAssistantMQTT *mqtt_ = nullptr;

    bool photoAutoMode_ = Config::kPhotoAutoModeDefault;
    uint32_t photoMinIntervalMs_ = Config::kPhotoMinIntervalMs;
    bool manualCaptureRequested_ = false;
    bool videoStartRequested_ = false;
    bool videoStartIncludeAudio_ = false;
    bool videoStopRequested_ = false;
    bool videoStreamStartRequested_ = false;
    bool videoStreamStopRequested_ = false;
};
