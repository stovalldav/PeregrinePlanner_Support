// NodeMode.h — which job this physical node is doing right now (CAMPING_SECURITY_NODE_PLAN.md).
// The hardware underneath never changes (onset/DOA + camera + C4001 presence sensor + NS4168
// speaker all exist regardless of mode) -- this just picks the behavior profile, matching the wire
// values in NetworkProtocol.h's SetNodeModePacket.
#pragma once

#include <cstdint>

enum class NodeMode : uint8_t {
    // Behaves like ../PeregrineMicArrayCam's ordinary onset-triggered camera node: full
    // participation in Bird Sounds Detection / fleet-wide classification, DOA/location fusion. The
    // C4001 still runs and can still trigger a photo on presence ("something wandered into view"),
    // but alarm/speak controls are hidden app-side and the automatic-alarm decision never applies.
    kBirding = 0,
    // Unattended, away from home, on battery, no local network infrastructure to lean on. C4001
    // presence autonomously captures a photo/burst + notifies the phone; alarm/speak controls
    // available; drops out of fleet-wide classification to save battery for overnight operation.
    // The Automatic Alarm toggle (see Config::kAutomaticAlarmDefault) only does anything in this mode.
    kCampingSecurity = 1,
    // On the home Wi-Fi network, on wall power, phone app not necessarily watching it -- reports to
    // Home Assistant via MQTT instead (CAMPING_SECURITY_NODE_PLAN.md's "Home Assistant integration",
    // not yet built as of this firmware -- this mode value exists now so the app-side picker and the
    // Automatic-Alarm-hides-in-this-mode behavior are already correct once it is). Same autonomous
    // photo+notify behavior on presence as Camping Security; also drops out of fleet-wide
    // classification; the automatic-alarm DECISION moves to Home Assistant automations instead of
    // living on the node, so the on-device Automatic Alarm toggle is a no-op here (see
    // SetAutomaticAlarmPacket's own comment).
    kHomeSecurity = 2,
};

inline bool isValidNodeMode(uint8_t wireValue) {
    return wireValue <= static_cast<uint8_t>(NodeMode::kHomeSecurity);
}
