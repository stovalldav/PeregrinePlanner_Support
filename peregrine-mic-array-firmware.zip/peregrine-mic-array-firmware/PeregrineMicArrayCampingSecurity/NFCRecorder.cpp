#include "NFCRecorder.h"
#include "Config.h"
#include "RemoteLogger.h"
#include <FS.h>
#include <SD_MMC.h>
#include <cmath>
#include <ctime>

NFCRecorder gNFC;

namespace {
constexpr uint32_t kRate = Config::kSampleRateHz;
constexpr uint32_t kPrerollSamples = kRate / 2;      // 0.5 s before
constexpr uint32_t kPostSamples = kRate;              // 1.0 s after
constexpr uint32_t kClipSamples = kPrerollSamples + kPostSamples;
constexpr int kWindow = kRate / 100;                  // 10 ms analysis windows
constexpr int kMinEventWindows = 3;                   // 30 ms
constexpr int kMaxEventWindows = 40;                  // 400 ms -- longer isn't a flight call
constexpr float kMaxThresholdX = 64;

void writeLE32(uint8_t *p, uint32_t v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }
void writeLE16(uint8_t *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
} // namespace

void NFCRecorder::Biquad::bandpass(float centerHz, float q, float sampleRate) {
    // RBJ cookbook band-pass, 0 dB peak gain.
    const float w0 = 2.0f * PI * centerHz / sampleRate;
    const float alpha = sinf(w0) / (2.0f * q);
    const float a0 = 1 + alpha;
    b0 = alpha / a0; b1 = 0; b2 = -alpha / a0;
    a1 = -2 * cosf(w0) / a0; a2 = (1 - alpha) / a0;
}

void NFCRecorder::begin(bool sdAvailable, uint16_t httpPort) {
    sd_ = sdAvailable;
    low_.bandpass(3162, 1.05f, kRate);   // ~2-5 kHz
    high_.bandpass(8124, 1.62f, kRate);  // ~6-11 kHz
    preroll_ = (int16_t *)ps_malloc(kPrerollSamples * sizeof(int16_t));
    for (auto &slot : slots_) slot.samples = (int16_t *)ps_malloc(kClipSamples * sizeof(int16_t));
    if (!sd_ || !preroll_ || !slots_[kSlots - 1].samples) {
        sd_ = false;
        Serial0.println("[nfc] night listening unavailable (needs SD card + PSRAM)");
    }
    server_ = new WebServer(httpPort);
    server_->on("/nfc/nights", HTTP_GET, [this]() { handleNights(); });
    server_->on("/nfc/list", HTTP_GET, [this]() { handleList(); });
    server_->on("/nfc/clip", HTTP_GET, [this]() { handleClip(); });
    server_->on("/nfc/night", HTTP_DELETE, [this]() { handleDeleteNight(); });
    server_->begin();
    Serial0.printf("[nfc] HTTP on :%u\n", httpPort);
}

void NFCRecorder::configure(bool enabled, uint32_t phoneUnix, int32_t tzOffsetS, uint32_t startUnix, uint32_t endUnix,
                            float thresholdX, uint8_t maxPerMinute) {
    configUnix_ = phoneUnix;
    configMillis_ = millis();
    tzOffsetS_ = tzOffsetS;
    startUnix_ = startUnix;
    endUnix_ = endUnix;
    baseThresholdX_ = thresholdX < 2 ? 2 : thresholdX;
    thresholdX_ = baseThresholdX_;
    maxPerMinute_ = maxPerMinute ? maxPerMinute : 20;
    const String folder = nightFolder(startUnix ? startUnix : phoneUnix);
    if (folder != tonightFolder_) { tonightFolder_ = folder; clipsTonight_ = 0; clipsDropped_ = 0; adjustments_ = 0; }
    enabled_ = enabled && sd_;
    Serial0.printf("[nfc] %s, window %lu-%lu, threshold x%.1f, max %u/min\n", enabled_ ? "ON" : "off",
                   (unsigned long)startUnix, (unsigned long)endUnix, baseThresholdX_, maxPerMinute_);
}

uint32_t NFCRecorder::unixNow() const {
    if (!configUnix_) return 0;
    return configUnix_ + (millis() - configMillis_) / 1000;
}

bool NFCRecorder::inWindow() const {
    if (!enabled_) return false;
    const uint32_t now = unixNow();
    if (!startUnix_ || !endUnix_) return true; // no window = all the time
    return now >= startUnix_ && now < endUnix_;
}

// The evening's date: a clip before noon belongs to the night that started the day before.
String NFCRecorder::nightFolder(uint32_t unixS) const {
    time_t local = (time_t)unixS + tzOffsetS_;
    if (gmtime(&local)->tm_hour < 12) local -= 86400;
    struct tm t;
    gmtime_r(&local, &t);
    char buf[16];
    snprintf(buf, sizeof(buf), "%04d%02d%02d", t.tm_year + 1900, t.tm_mon + 1, t.tm_mday);
    return String(buf);
}

void NFCRecorder::processBlock(const int16_t *samples, int count) {
    if (!enabled_ || !inWindow()) return;
    for (int i = 0; i < count; i++) {
        const int16_t s = samples[i];
        preroll_[prerollWrite_] = s;
        prerollWrite_ = (prerollWrite_ + 1) % kPrerollSamples;
        if (prerollFilled_ < kPrerollSamples) prerollFilled_++;

        if (capturing_) {
            capturing_->samples[kPrerollSamples + captured_] = s;
            if (abs((int)s) > eventPeak_) eventPeak_ = abs((int)s);
            if (++captured_ >= kPostSamples) finishClip();
        }

        const float x = s / 32768.0f;
        const float l = low_.step(x), h = high_.step(x);
        sum_[0] += l * l;
        sum_[1] += h * h;
        if (++windowFill_ < kWindow) continue;

        // One 10 ms window: compare each band with its floor.
        windowFill_ = 0;
        bool over = false;
        for (int b = 0; b < 2; b++) {
            const float e = (float)(sum_[b] / kWindow);
            sum_[b] = 0;
            const bool loud = e > floor_[b] * thresholdX_;
            // Floor: falls fast, rises slowly, and not at all during a call.
            if (!loud) floor_[b] = e < floor_[b] ? floor_[b] * 0.8f + e * 0.2f : floor_[b] * 0.995f + e * 0.005f;
            if (floor_[b] < 1e-9f) floor_[b] = 1e-9f;
            overWindows_[b] = loud ? overWindows_[b] + 1 : 0;
            if (loud) over = true;
            if (!capturing_ && overWindows_[b] == 1 && prerollFilled_ >= kPrerollSamples) {
                // Start a clip: claim a free slot, copy the last 0.5 s in.
                for (auto &slot : slots_) {
                    if (slot.ready) continue;
                    capturing_ = &slot;
                    slot.band = b;
                    slot.thresholdX = thresholdX_;
                    slot.unixMs = (uint64_t)unixNow() * 1000ULL + (millis() - configMillis_) % 1000;
                    for (uint32_t k = 0; k < kPrerollSamples; k++) slot.samples[k] = preroll_[(prerollWrite_ + k) % kPrerollSamples];
                    captured_ = 0;
                    eventWindows_ = 0;
                    eventEnded_ = false;
                    eventPeak_ = 0;
                    break;
                }
                if (!capturing_) clipsDropped_++;
            }
        }
        if (capturing_ && !eventEnded_) {
            if (over) eventWindows_++;
            else eventEnded_ = true;
        }
    }
}

void NFCRecorder::finishClip() {
    Slot *slot = capturing_;
    capturing_ = nullptr;
    // A flight call is short and over within the clip; anything else (insects, wind) is dropped.
    if (!eventEnded_ || eventWindows_ < kMinEventWindows || eventWindows_ > kMaxEventWindows) return;
    slot->peak = eventPeak_;
    slot->durationMs = eventWindows_ * 10;
    slot->ready = true; // service() writes it
}

bool NFCRecorder::writeClip(Slot &slot) {
    const uint32_t unixS = (uint32_t)(slot.unixMs / 1000);
    const String folder = "/nfc/" + nightFolder(unixS);
    SD_MMC.mkdir("/nfc");
    SD_MMC.mkdir(folder);
    time_t local = (time_t)unixS + tzOffsetS_;
    struct tm t;
    gmtime_r(&local, &t);
    char name[32];
    snprintf(name, sizeof(name), "%02d%02d%02d_%03u_%c.wav", t.tm_hour, t.tm_min, t.tm_sec,
             (unsigned)(slot.unixMs % 1000), slot.band ? 'H' : 'L');
    File f = SD_MMC.open(folder + "/" + name, FILE_WRITE);
    if (!f) return false;
    uint8_t header[44];
    const uint32_t dataBytes = kClipSamples * 2;
    memcpy(header, "RIFF", 4); writeLE32(header + 4, 36 + dataBytes); memcpy(header + 8, "WAVEfmt ", 8);
    writeLE32(header + 16, 16); writeLE16(header + 20, 1); writeLE16(header + 22, 1);
    writeLE32(header + 24, kRate); writeLE32(header + 28, kRate * 2); writeLE16(header + 32, 2); writeLE16(header + 34, 16);
    memcpy(header + 36, "data", 4); writeLE32(header + 40, dataBytes);
    bool ok = f.write(header, 44) == 44 && f.write((const uint8_t *)slot.samples, dataBytes) == dataBytes;
    f.close();
    if (!ok) return false;
    File index = SD_MMC.open(folder + "/index.csv", FILE_APPEND);
    if (index) {
        index.printf("%llu,%c,%d,%u,%.1f,%s\n", (unsigned long long)slot.unixMs, slot.band ? 'H' : 'L', slot.peak,
                     slot.durationMs, slot.thresholdX, name);
        index.close();
    }
    return true;
}

void NFCRecorder::service(uint32_t nowMs) {
    for (auto &slot : slots_) {
        if (!slot.ready) continue;
        if (writeClip(slot)) {
            clipsTonight_++;
            clipsThisMinute_++;
            clipsThisTenMinutes_++;
        } else {
            clipsDropped_++;
        }
        slot.ready = false;
    }
    // Rate limiter: a chorus of katydids can trigger all night. Too many clips a minute raises the
    // level; a quiet ten minutes lowers it back toward what the phone asked for.
    if (nowMs - minuteStartMs_ >= 60000) {
        if (clipsThisMinute_ > maxPerMinute_ && thresholdX_ < kMaxThresholdX) {
            thresholdX_ = fminf(kMaxThresholdX, thresholdX_ * 1.5f);
            adjustments_++;
            Serial0.printf("[nfc] %u clips in a minute -- threshold raised to x%.1f\n", clipsThisMinute_, thresholdX_);
        }
        minuteStartMs_ = nowMs;
        clipsThisMinute_ = 0;
    }
    if (nowMs - tenMinuteStartMs_ >= 600000) {
        if (clipsThisTenMinutes_ < maxPerMinute_ * 10 / 4 && thresholdX_ > baseThresholdX_) {
            thresholdX_ = fmaxf(baseThresholdX_, thresholdX_ * 0.8f);
        }
        tenMinuteStartMs_ = nowMs;
        clipsThisTenMinutes_ = 0;
    }
}

NFCRecorder::Status NFCRecorder::status() {
    Status s{};
    s.enabled = enabled_;
    s.activeNow = inWindow();
    s.clipsTonight = clipsTonight_;
    s.clipsDropped = clipsDropped_;
    s.sdFreeMB = sd_ ? (uint32_t)((SD_MMC.totalBytes() - SD_MMC.usedBytes()) / (1024 * 1024)) : 0;
    s.thresholdX = thresholdX_;
    s.adjustments = adjustments_;
    return s;
}

// ---- HTTP (http task) ----

void NFCRecorder::pollHttp() {
    if (server_) server_->handleClient();
}

bool NFCRecorder::safePath(const String &p) {
    if (p.length() == 0 || p.length() > 64 || p.indexOf("..") >= 0 || p.startsWith("/")) return false;
    for (size_t i = 0; i < p.length(); i++) {
        const char c = p[i];
        if (!(isalnum((unsigned char)c) || c == '_' || c == '/' || c == '.')) return false;
    }
    return true;
}

// ["20261020","20261021"]
void NFCRecorder::handleNights() {
    String json = "[";
    File dir = SD_MMC.open("/nfc");
    if (dir && dir.isDirectory()) {
        bool first = true;
        for (File e = dir.openNextFile(); e; e = dir.openNextFile()) {
            if (e.isDirectory()) {
                if (!first) json += ",";
                json += "\"" + String(e.name()) + "\"";
                first = false;
            }
            e.close();
        }
    }
    json += "]";
    server_->send(200, "application/json", json);
}

void NFCRecorder::handleList() {
    const String date = server_->arg("date");
    if (!safePath(date)) { server_->send(400, "text/plain", "bad date"); return; }
    File f = SD_MMC.open("/nfc/" + date + "/index.csv");
    if (!f) { server_->send(200, "text/csv", ""); return; }
    server_->streamFile(f, "text/csv");
    f.close();
}

void NFCRecorder::handleClip() {
    const String path = server_->arg("path");
    if (!safePath(path) || !path.endsWith(".wav")) { server_->send(400, "text/plain", "bad path"); return; }
    File f = SD_MMC.open("/nfc/" + path);
    if (!f) { server_->send(404, "text/plain", "no such clip"); return; }
    server_->streamFile(f, "audio/wav");
    f.close();
}

void NFCRecorder::handleDeleteNight() {
    const String date = server_->arg("date");
    if (!safePath(date) || date.indexOf('/') >= 0) { server_->send(400, "text/plain", "bad date"); return; }
    const String folder = "/nfc/" + date;
    File dir = SD_MMC.open(folder);
    int removed = 0;
    if (dir && dir.isDirectory()) {
        for (File e = dir.openNextFile(); e; e = dir.openNextFile()) {
            const String name = folder + "/" + e.name();
            e.close();
            if (SD_MMC.remove(name)) removed++;
        }
        dir.close();
        SD_MMC.rmdir(folder);
    }
    server_->send(200, "text/plain", String(removed));
}
