// NFCRecorder.h -- overnight flight-call recorder (NIGHT_FLIGHT_CALL_PLAN.md).
//
// Migrating thrushes, warblers and sparrows give short calls (~50-400 ms) at night. This listens to
// the left mic in two bands -- 2-5 kHz (thrushes, some sparrows) and 6-11 kHz (warblers, sparrows) --
// against a slow noise floor per band, and when a band jumps well above it for 30-400 ms, saves
// 0.5 s before + 1.0 s after as a WAV on the SD card. Longer sounds (insects singing, wind, rain on
// the case, traffic) don't count. The phone downloads the clips in the morning and classifies them.
//
// Threads: processBlock() runs on the capture task; service() on loop() (all SD writes happen
// there, never on the capture task); the HTTP handlers on the http task.
//
// Files: /nfc/<YYYYMMDD>/<HHMMSS>_<mmm>_<L|H>.wav (local time, from the phone's clock + time zone
// sent with kSetNightListening) and one /nfc/<YYYYMMDD>/index.csv line per clip:
//   unixMs,band,peak,durationMs,thresholdX,file
// The night's folder is named for the evening it started (a 2 am clip is in the previous date's
// folder), so one night = one folder.
#pragma once

#include <Arduino.h>
#include <WebServer.h>

class NFCRecorder {
public:
    struct Status {
        bool enabled;
        bool activeNow;       // inside the night window right now
        uint16_t clipsTonight;
        uint16_t clipsDropped;  // no free buffer, or SD write failed
        uint32_t sdFreeMB;
        float thresholdX;     // current trigger level, x noise floor
        uint16_t adjustments; // how often the rate limiter raised it tonight
    };

    // `sdAvailable`: from the boot-time SD probe. Without SD the recorder stays off.
    void begin(bool sdAvailable, uint16_t httpPort);

    // kSetNightListening: on/off, the phone's clock and time zone, the night window (unix seconds),
    // trigger level (x noise floor) and the most clips a minute before the level is raised.
    void configure(bool enabled, uint32_t phoneUnix, int32_t tzOffsetS, uint32_t startUnix, uint32_t endUnix,
                   float thresholdX, uint8_t maxPerMinute);

    // Capture task: every block of left-channel samples at Config::kSampleRateHz.
    void processBlock(const int16_t *samples, int count);

    // loop(): writes finished clips, runs the rate limiter.
    void service(uint32_t nowMs);

    // http task.
    void pollHttp();

    Status status();
    bool enabled() const { return enabled_; }

private:
    struct Slot {
        int16_t *samples = nullptr;
        volatile bool ready = false; // filled by the capture task, waiting for service()
        uint64_t unixMs = 0;
        uint8_t band = 0;            // 0 = low (2-5 kHz), 1 = high (6-11 kHz)
        int16_t peak = 0;
        uint16_t durationMs = 0;
        float thresholdX = 0;
    };
    struct Biquad {
        float b0, b1, b2, a1, a2;
        float x1 = 0, x2 = 0, y1 = 0, y2 = 0;
        void bandpass(float centerHz, float q, float sampleRate);
        inline float step(float x) {
            const float y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
            x2 = x1; x1 = x; y2 = y1; y1 = y;
            return y;
        }
    };

    uint32_t unixNow() const;
    bool inWindow() const;
    void finishClip();
    bool writeClip(Slot &slot);
    String nightFolder(uint32_t unixS) const;
    static bool safePath(const String &p);

    void handleNights();
    void handleList();
    void handleClip();
    void handleDeleteNight();

    static constexpr int kSlots = 3;
    Slot slots_[kSlots];
    int16_t *preroll_ = nullptr;
    uint32_t prerollWrite_ = 0;
    uint32_t prerollFilled_ = 0;

    Biquad low_, high_;
    double sum_[2] = {0, 0};
    int windowFill_ = 0;
    float floor_[2] = {1e-6f, 1e-6f};
    int overWindows_[2] = {0, 0};

    // Capture in progress
    Slot *capturing_ = nullptr;
    uint32_t captured_ = 0;
    int eventWindows_ = 0;
    bool eventEnded_ = false;
    int16_t eventPeak_ = 0;

    bool sd_ = false;
    volatile bool enabled_ = false;
    uint32_t configUnix_ = 0;
    uint32_t configMillis_ = 0;
    int32_t tzOffsetS_ = 0;
    uint32_t startUnix_ = 0, endUnix_ = 0;
    float baseThresholdX_ = 8;
    volatile float thresholdX_ = 8;
    uint8_t maxPerMinute_ = 20;

    // Rate limiter (loop only)
    uint32_t minuteStartMs_ = 0;
    uint16_t clipsThisMinute_ = 0;
    uint32_t tenMinuteStartMs_ = 0;
    uint16_t clipsThisTenMinutes_ = 0;

    volatile uint16_t clipsTonight_ = 0;
    volatile uint16_t clipsDropped_ = 0;
    uint16_t adjustments_ = 0;
    String tonightFolder_;

    WebServer *server_ = nullptr;
};

extern NFCRecorder gNFC;
