// CameraPins.h — OV5640 DVP/SCCB pin mapping for the GOOUUU ESP32-S3-CAM V1.5 board.
//
// **UNVERIFIED against real hardware — confirm before flashing.** CAMPING_SECURITY_NODE_PLAN.md
// cross-checked two sources for this board (a community pinout reference and the user's own board
// photo) and found they AGREE on which GPIOs the camera claims as a range (GPIO4-13, 15-18 -- the
// same range the FORIOT board's camera also claims) and on D0/D1/D4/SIOD/SIOC/VSYNC/HREF/PCLK/XCLK,
// but DISAGREE on the exact D2/D3 and D5/D6/D7 ordering within that range. The assignment below
// uses the FORIOT board's own already-flashed-and-working ordering as the starting guess (same
// physical pin numbers happen to be available on both boards) -- per this project's own
// hardware-debugging rule (real-device evidence only), treat this as a hypothesis to verify on the
// first real capture, not a confirmed fact. A wrong D-line order shows up immediately as
// garbled/psychedelic-static color, not a silent failure -- fixed by permuting the D0-D7 values
// below, not a rewire. See CAMPING_SECURITY_NODE_PLAN.md's GPIO table for the cross-check detail.
//
// PWDN/RESET tied off (-1, not wired) — GPIO20 (this board's spare pin) is available for either if
// the specific OV5640 breakout needs them wired rather than left at -1.
//
// XCLK source: some OV5640 breakouts (e.g. Adafruit's) have their own onboard crystal and expect
// XCLK left unconnected rather than ESP32-generated via LEDC -- verify which mode the specific
// module plugged into this board's camera FPC connector is in before trusting kCameraXCLKFreqHz
// below actually does anything.
#pragma once

#define CAM_PIN_PWDN    -1
#define CAM_PIN_RESET   -1
#define CAM_PIN_XCLK    15
#define CAM_PIN_SIOD    4
#define CAM_PIN_SIOC    5
#define CAM_PIN_D7      16
#define CAM_PIN_D6      17
#define CAM_PIN_D5      18
#define CAM_PIN_D4      12
#define CAM_PIN_D3      10
#define CAM_PIN_D2      8
#define CAM_PIN_D1      9
#define CAM_PIN_D0      11
#define CAM_PIN_VSYNC   6
#define CAM_PIN_HREF    7
#define CAM_PIN_PCLK    13

constexpr int kCameraXCLKFreqHz = 20000000;
