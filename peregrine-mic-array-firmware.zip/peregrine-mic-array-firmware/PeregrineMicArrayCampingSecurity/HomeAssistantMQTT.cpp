#include "HomeAssistantMQTT.h"
#include <Arduino.h>
#include "Config.h"

HomeAssistantMQTT *HomeAssistantMQTT::instance_ = nullptr;

void HomeAssistantMQTT::begin(MQTTConfigStore &cfg, const char *deviceIdHex) {
    cfg_ = &cfg;
    deviceIdHex_ = deviceIdHex;
    instance_ = this;
    client_.setClient(wifiClient_);
    client_.setBufferSize(Config::kMQTTBufferSize);
    client_.setCallback(staticCallback);
}

String HomeAssistantMQTT::topic(const char *suffix) const {
    return String(cfg_->topicPrefix()) + "/" + deviceIdHex_ + "/" + suffix;
}

String HomeAssistantMQTT::discoveryTopic(const char *component, const char *objectId) const {
    return String("homeassistant/") + component + "/" + deviceIdHex_ + "_" + objectId + "/config";
}

String HomeAssistantMQTT::deviceBlockJson() const {
    return String("{\"identifiers\":[\"peregrine_") + deviceIdHex_
        + "\"],\"name\":\"Peregrine Camping Security " + deviceIdHex_
        + "\",\"manufacturer\":\"Peregrine Planner\",\"model\":\"Camping Security Node\"}";
}

void HomeAssistantMQTT::publishDiscovery() {
    const String availabilityTopic = topic("status");
    const String presenceState = topic("presence/state");
    const String presenceAvailability = topic("presence/availability");
    const String alarmCommand = topic("alarm/set");
    const String cameraCommand = topic("camera/set");
    const String cameraState = topic("camera/state");
    const String presenceCaptureCommand = topic("presence_capture/set");
    const String presenceCaptureState = topic("presence_capture/state");
    const String device = deviceBlockJson();

    // binary_sensor -- presence (C4001), the core "did something happen" signal HA automations key
    // off of. device_class "motion" gives HA's UI the right icon/verb ("detected"/"clear").
    {
        String payload = String("{\"name\":\"Presence\",\"unique_id\":\"") + deviceIdHex_ + "_presence"
            + "\",\"state_topic\":\"" + presenceState
            + "\",\"payload_on\":\"ON\",\"payload_off\":\"OFF\",\"device_class\":\"motion\""
            // Two availability topics, both must be "online" (availability_mode "all"): the node
            // itself, and its presence sensor (silent/missing sensor -> "unavailable", not "clear").
            + ",\"availability\":[{\"topic\":\"" + availabilityTopic + "\"},{\"topic\":\"" + presenceAvailability + "\"}]"
            // (List-form entries default to "online"/"offline" payloads -- no top-level payload keys,
            // which belong to the single availability_topic form this entity no longer uses.)
            + ",\"availability_mode\":\"all\""
            + ",\"device\":" + device + "}";
        client_.publish(discoveryTopic("binary_sensor", "presence").c_str(), payload.c_str(), true);
        client_.publish(presenceAvailability.c_str(), presenceSensorAvailable_ ? "online" : "offline", true);
    }
    // button -- Sound Alarm. One trigger path, two front doors: this MQTT command and the app's
    // existing kSoundAlarm both funnel into the same consumeSoundAlarmRequest() the .ino already
    // polls for the UDP path -- not a second alarm implementation.
    {
        String payload = String("{\"name\":\"Sound Alarm\",\"unique_id\":\"") + deviceIdHex_ + "_alarm"
            + "\",\"command_topic\":\"" + alarmCommand + "\",\"payload_press\":\"PRESS\""
            + ",\"availability_topic\":\"" + availabilityTopic + "\",\"payload_available\":\"online\",\"payload_not_available\":\"offline\""
            + ",\"device\":" + device + "}";
        client_.publish(discoveryTopic("button", "alarm").c_str(), payload.c_str(), true);
    }
    // switch -- camera on/off, straightforward mirror of the app's own kSetCameraEnabled toggle.
    {
        String payload = String("{\"name\":\"Camera\",\"unique_id\":\"") + deviceIdHex_ + "_camera"
            + "\",\"command_topic\":\"" + cameraCommand + "\",\"state_topic\":\"" + cameraState
            + "\",\"payload_on\":\"ON\",\"payload_off\":\"OFF\""
            + ",\"availability_topic\":\"" + availabilityTopic + "\",\"payload_available\":\"online\",\"payload_not_available\":\"offline\""
            + ",\"device\":" + device + "}";
        client_.publish(discoveryTopic("switch", "camera").c_str(), payload.c_str(), true);
    }
    // switch -- Presence Capture. Added 2026-09-22: the C4001 presence trigger used to fire an
    // autonomous photo unconditionally, with no way to turn it off -- this and the app's matching
    // Camping Security screen toggle are the two front doors onto the same gPresenceCaptureEnabled
    // flag (NetworkProtocol.h's kSetPresenceCapture), off by default.
    {
        String payload = String("{\"name\":\"Presence Capture\",\"unique_id\":\"") + deviceIdHex_ + "_presence_capture"
            + "\",\"command_topic\":\"" + presenceCaptureCommand + "\",\"state_topic\":\"" + presenceCaptureState
            + "\",\"payload_on\":\"ON\",\"payload_off\":\"OFF\""
            + ",\"availability_topic\":\"" + availabilityTopic + "\",\"payload_available\":\"online\",\"payload_not_available\":\"offline\""
            + ",\"device\":" + device + "}";
        client_.publish(discoveryTopic("switch", "presence_capture").c_str(), payload.c_str(), true);
    }
    // NOTE: no `camera` entity published here -- see HomeAssistantMQTT.h's header comment for why
    // that's not a real MQTT-discoverable capability the way the plan first assumed. Camera setup
    // stays the existing one-time YAML `generic` platform pointing at GET /snapshot
    // (HOME_ASSISTANT.md), unchanged by this integration.

    discoveryPublished_ = true;
    Serial0.println("[mqtt] discovery published (binary_sensor/presence, button/alarm, switch/camera, switch/presence_capture)");
}

void HomeAssistantMQTT::attemptReconnect(uint32_t nowMs) {
    if (nowMs - lastReconnectAttemptMs_ < Config::kMQTTReconnectIntervalMs) return;
    lastReconnectAttemptMs_ = nowMs;

    client_.setServer(cfg_->host(), cfg_->port());
    String clientId = String("peregrine-") + deviceIdHex_;
    String availabilityTopic = topic("status");

    bool ok;
    if (cfg_->username()[0] != '\0') {
        ok = client_.connect(clientId.c_str(), cfg_->username(), cfg_->password(),
            availabilityTopic.c_str(), /*willQos=*/1, /*willRetain=*/true, "offline");
    } else {
        ok = client_.connect(clientId.c_str(), nullptr, nullptr,
            availabilityTopic.c_str(), /*willQos=*/1, /*willRetain=*/true, "offline");
    }

    if (!ok) {
        Serial0.printf("[mqtt] connect to %s:%u failed (state %d), retrying in %lus\n",
            cfg_->host(), (unsigned)cfg_->port(), client_.state(), (unsigned long)(Config::kMQTTReconnectIntervalMs / 1000));
        return;
    }

    Serial0.printf("[mqtt] connected to %s:%u\n", cfg_->host(), (unsigned)cfg_->port());
    client_.publish(availabilityTopic.c_str(), "online", true);
    client_.subscribe(topic("alarm/set").c_str());
    client_.subscribe(topic("camera/set").c_str());
    client_.subscribe(topic("presence_capture/set").c_str());
    discoveryPublished_ = false; // re-publish on every fresh connect -- cheap, and covers a HA restart
}

void HomeAssistantMQTT::poll(bool nodeModeIsHomeSecurity) {
    if (!nodeModeIsHomeSecurity || cfg_ == nullptr || !cfg_->isConfigured()) {
        if (client_.connected()) stop(); // mode was switched away while connected -- see stop()'s doc comment
        return;
    }

    if (!client_.connected()) {
        attemptReconnect(millis());
        return;
    }

    client_.loop();
    if (!discoveryPublished_) {
        publishDiscovery();
    }
}

void HomeAssistantMQTT::stop() {
    if (!client_.connected()) return;
    // Best-effort clean "offline" -- the retained LWT would eventually cover this anyway if the
    // disconnect were unclean, but publishing it explicitly here means HA reflects the mode switch
    // immediately rather than waiting on the broker's keep-alive timeout to notice the drop.
    client_.publish(topic("status").c_str(), "offline", true);
    client_.disconnect();
    discoveryPublished_ = false;
}

bool HomeAssistantMQTT::isConnected() {
    return client_.connected();
}

void HomeAssistantMQTT::publishPresence(bool detected) {
    if (!client_.connected()) return;
    client_.publish(topic("presence/state").c_str(), detected ? "ON" : "OFF", true);
}

void HomeAssistantMQTT::publishPresenceSensorAvailable(bool available) {
    presenceSensorAvailable_ = available;
    if (!client_.connected()) return; // publishDiscovery() sends the remembered value on connect
    client_.publish(topic("presence/availability").c_str(), available ? "online" : "offline", true);
}

void HomeAssistantMQTT::publishCameraState(bool enabled) {
    if (!client_.connected()) return;
    client_.publish(topic("camera/state").c_str(), enabled ? "ON" : "OFF", true);
}

void HomeAssistantMQTT::publishPresenceCaptureState(bool enabled) {
    if (!client_.connected()) return;
    client_.publish(topic("presence_capture/state").c_str(), enabled ? "ON" : "OFF", true);
}

bool HomeAssistantMQTT::consumeSoundAlarmRequest() {
    bool requested = soundAlarmRequested_;
    soundAlarmRequested_ = false;
    return requested;
}

bool HomeAssistantMQTT::consumeSetCameraEnabledRequest(bool &enabled) {
    if (!cameraEnabledRequested_) return false;
    cameraEnabledRequested_ = false;
    enabled = cameraEnabledRequestedValue_;
    return true;
}

bool HomeAssistantMQTT::consumeSetPresenceCaptureRequest(bool &enabled) {
    if (!presenceCaptureRequested_) return false;
    presenceCaptureRequested_ = false;
    enabled = presenceCaptureRequestedValue_;
    return true;
}

void HomeAssistantMQTT::handleMessage(const char *topicStr, const uint8_t *payload, unsigned int length) {
    String t(topicStr);
    if (t == topic("alarm/set")) {
        soundAlarmRequested_ = true;
        Serial0.println("[mqtt] alarm/set received -- sound alarm requested");
    } else if (t == topic("camera/set")) {
        // Matches "ON"/"OFF" case-sensitively -- the discovery payload's own payload_on/payload_off
        // above define exactly these two strings, so anything else is a malformed/unrelated message.
        if (length == 2 && payload[0] == 'O' && payload[1] == 'N') {
            cameraEnabledRequested_ = true;
            cameraEnabledRequestedValue_ = true;
        } else if (length == 3 && payload[0] == 'O' && payload[1] == 'F' && payload[2] == 'F') {
            cameraEnabledRequested_ = true;
            cameraEnabledRequestedValue_ = false;
        }
    } else if (t == topic("presence_capture/set")) {
        if (length == 2 && payload[0] == 'O' && payload[1] == 'N') {
            presenceCaptureRequested_ = true;
            presenceCaptureRequestedValue_ = true;
        } else if (length == 3 && payload[0] == 'O' && payload[1] == 'F' && payload[2] == 'F') {
            presenceCaptureRequested_ = true;
            presenceCaptureRequestedValue_ = false;
        }
    }
}

void HomeAssistantMQTT::staticCallback(char *topicStr, uint8_t *payload, unsigned int length) {
    if (instance_) instance_->handleMessage(topicStr, payload, length);
}
