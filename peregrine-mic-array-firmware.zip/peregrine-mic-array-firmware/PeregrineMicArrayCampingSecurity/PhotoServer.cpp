#include "PhotoServer.h"
#include <cstdlib>
#include <cctype>
#include <esp_camera.h>
#include <SD_MMC.h>
#include <uri/UriBraces.h>

static const char *kPhotoDir = "/photos";

namespace {
// Holds a FreeRTOS mutex for one scope.
struct ScopedLock {
    SemaphoreHandle_t m;
    explicit ScopedLock(SemaphoreHandle_t mutex) : m(mutex) { if (m) xSemaphoreTake(m, portMAX_DELAY); }
    ~ScopedLock() { if (m) xSemaphoreGive(m); }
};
}

uint8_t *PhotoServer::allocCopy(size_t length) {
    uint8_t *p = (uint8_t *)heap_caps_malloc(length, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    return p ? p : (uint8_t *)malloc(length);
}

void PhotoServer::sendCopy(uint8_t *data, size_t length) {
    server_.send_P(200, "image/jpeg", (const char *)data, length);
    free(data);
}

String PhotoServer::photoPath(uint32_t id) {
    return String(kPhotoDir) + "/" + String(id) + ".jpg";
}

bool PhotoServer::parseIdFromPath(const String &path, uint32_t &outId) {
    int slash = path.lastIndexOf('/');
    int dot = path.lastIndexOf('.');
    if (dot <= slash + 1) return false;
    String s = path.substring(slash + 1, dot);
    if (s.length() == 0 || s.length() > 10) return false;
    for (unsigned i = 0; i < s.length(); i++) {
        if (!isdigit((unsigned char)s[i])) return false;
    }
    outId = (uint32_t)strtoul(s.c_str(), nullptr, 10);
    return true;
}

void PhotoServer::setStorageBackend(bool sdAvailable, uint8_t ramCapacity) {
    if (!lock_) lock_ = xSemaphoreCreateMutex();
    sdAvailable_ = sdAvailable;
    ramCapacity_ = (ramCapacity > kMaxRamSlots) ? kMaxRamSlots : ramCapacity;
}

void PhotoServer::begin(uint16_t port) {
    if (!lock_) lock_ = xSemaphoreCreateMutex();
    if (!snapshotReady_) snapshotReady_ = xSemaphoreCreateBinary();
    server_.begin(port);
    server_.on(UriBraces("/photo/{}"), HTTP_GET, [this]() { handlePhotoRequest(); });
    server_.on(UriBraces("/photo/{}"), HTTP_DELETE, [this]() { handlePhotoDelete(); });
    server_.on("/photos", HTTP_GET, [this]() { handlePhotoList(); });
    server_.on("/photos", HTTP_DELETE, [this]() { handlePhotoClear(); });
    server_.on("/snapshot", HTTP_GET, [this]() { handleSnapshot(); });
    server_.begin();
}

void PhotoServer::poll() {
    server_.handleClient();
}

void PhotoServer::serviceSnapshot(bool cameraAvailable) {
    {
        ScopedLock lock(lock_);
        if (!snapshotWanted_) return;
    }
    uint8_t *copy = nullptr;
    size_t length = 0;
    if (cameraAvailable) {
        camera_fb_t *fb = esp_camera_fb_get();
        if (fb) {
            copy = allocCopy(fb->len);
            if (copy) {
                memcpy(copy, fb->buf, fb->len);
                length = fb->len;
            }
            esp_camera_fb_return(fb);
        }
    }
    ScopedLock lock(lock_);
    if (!snapshotWanted_) { // the handler gave up waiting -- nobody to hand it to
        free(copy);
        return;
    }
    snapshotWanted_ = false;
    snapshotData_ = copy;
    snapshotLength_ = length;
    xSemaphoreGive(snapshotReady_);
}

void PhotoServer::publish(uint32_t photoId, uint8_t *data, size_t length) {
    ScopedLock lock(lock_);
    if (!sdAvailable_) {
        ramPublish(photoId, data, length);
        return;
    }
    // SD backend: same fast-path-cache behavior as the sibling firmware -- the SD copy is written
    // separately by the caller (capturePhotoIfDue).
    if (photoData_) {
        free(photoData_);
    }
    photoData_ = data;
    photoLength_ = length;
    currentPhotoId_ = photoId;
}

int PhotoServer::ramFindSlot(uint32_t photoId) const {
    for (int i = 0; i < kMaxRamSlots; i++) {
        if (ramSlots_[i].id == photoId) return i;
    }
    return -1;
}

void PhotoServer::ramFreeSlot(int index) {
    if (index < 0 || index >= kMaxRamSlots) return;
    if (ramSlots_[index].data) free(ramSlots_[index].data);
    ramSlots_[index] = RamSlot{};
}

void PhotoServer::ramPublish(uint32_t photoId, uint8_t *data, size_t length) {
    // Find an empty slot, or evict the oldest occupied one (by insertion order, not array
    // position -- a phone DELETE can free an arbitrary slot early, see handlePhotoDelete()).
    int freeIndex = -1;
    int oldestIndex = -1;
    uint32_t oldestSeq = 0xFFFFFFFFu;
    int occupiedCount = 0;
    for (int i = 0; i < kMaxRamSlots; i++) {
        if (ramSlots_[i].id == 0) {
            if (freeIndex < 0) freeIndex = i;
            continue;
        }
        occupiedCount++;
        if (ramSlots_[i].insertSeq < oldestSeq) {
            oldestSeq = ramSlots_[i].insertSeq;
            oldestIndex = i;
        }
    }

    int target;
    if (freeIndex >= 0 && occupiedCount < ramCapacity_) {
        target = freeIndex;
    } else if (oldestIndex >= 0) {
        Serial0.printf("[photo] RAM ring full (%u/%u) -- evicting oldest (id %lu)\n",
            (unsigned)occupiedCount, (unsigned)ramCapacity_, (unsigned long)ramSlots_[oldestIndex].id);
        ramFreeSlot(oldestIndex);
        target = oldestIndex;
    } else if (freeIndex >= 0) {
        target = freeIndex; // ramCapacity_ > occupied but no oldest found -- shouldn't happen, defensive
    } else {
        // kMaxRamSlots itself exhausted (ramCapacity_ misconfigured above kMaxRamSlots) -- drop the
        // new photo rather than leak/overflow. Real config bug if this ever fires, not a normal path.
        Serial0.println("[photo] RAM ring: no slot available at all -- dropping capture");
        free(data);
        return;
    }

    ramSlots_[target].id = photoId;
    ramSlots_[target].data = data;
    ramSlots_[target].length = length;
    ramSlots_[target].insertSeq = ramInsertSeq_++;
}

void PhotoServer::handlePhotoRequest() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();

    // Copy the photo under the lock (RAM copy, or read the SD file -- retention eviction runs
    // under the same lock, so it can't delete the file mid-read), then send it unlocked.
    uint8_t *copy = nullptr;
    size_t length = 0;
    {
        ScopedLock lock(lock_);
        const uint8_t *source = nullptr;
        if (!sdAvailable_) {
            int idx = ramFindSlot(requestedId);
            if (idx >= 0) { source = ramSlots_[idx].data; length = ramSlots_[idx].length; }
        } else if (photoData_ && requestedId == currentPhotoId_) {
            source = photoData_; // fast path: the just-captured photo is still in RAM
            length = photoLength_;
        }
        if (source) {
            copy = allocCopy(length);
            if (copy) memcpy(copy, source, length);
        } else if (sdAvailable_) {
            // Anything older: off the SD card (survives buffer overwrite / reboot).
            File file = SD_MMC.open(photoPath(requestedId), FILE_READ);
            if (file) {
                length = file.size();
                copy = length ? allocCopy(length) : nullptr;
                if (copy && file.read(copy, length) != length) { free(copy); copy = nullptr; }
                file.close();
            }
        }
    }
    if (!copy) {
        server_.send(404, "text/plain", "photo not available");
        return;
    }
    sendCopy(copy, length);
}

void PhotoServer::handlePhotoDelete() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();
    ScopedLock lock(lock_);

    if (!sdAvailable_) {
        int idx = ramFindSlot(requestedId);
        if (idx >= 0) ramFreeSlot(idx);
        server_.send(200, "text/plain", "ok");
        return;
    }

    bool existed = SD_MMC.exists(photoPath(requestedId));
    SD_MMC.remove(photoPath(requestedId)); // idempotent -- a missing file is not an error

    if (existed && storedCount_ > 0) storedCount_--;
    if (existed && requestedId == oldestStoredId_) advanceOldestStoredId();

    if (photoData_ && requestedId == currentPhotoId_) {
        free(photoData_);
        photoData_ = nullptr;
        photoLength_ = 0;
        currentPhotoId_ = 0;
    }
    server_.send(200, "text/plain", "ok");
}

void PhotoServer::handlePhotoClear() {
    uint32_t removed = wipeAllPhotos();
    {
        ScopedLock lock(lock_);
        if (sdAvailable_ && photoData_) {
            free(photoData_);
            photoData_ = nullptr;
            photoLength_ = 0;
            currentPhotoId_ = 0;
        }
    }
    Serial0.printf("[photo] store cleared on request -- %lu file(s) removed\n", (unsigned long)removed);
    server_.send(200, "text/plain", String("removed ") + removed);
}

void PhotoServer::handleSnapshot() {
    // On-demand fresh frame (Camera Console tiles, Home Assistant `generic` camera) -- not written
    // to either storage backend, this is a live view poll, not a real capture event. loop() owns
    // the camera, so ask it for a copy (serviceSnapshot) and wait briefly.
    xSemaphoreTake(snapshotReady_, 0); // clear any stale give
    {
        ScopedLock lock(lock_);
        snapshotWanted_ = true;
    }
    uint8_t *copy = nullptr;
    size_t length = 0;
    bool answered = xSemaphoreTake(snapshotReady_, pdMS_TO_TICKS(3000)) == pdTRUE;
    {
        ScopedLock lock(lock_);
        if (answered) {
            copy = snapshotData_;
            length = snapshotLength_;
            snapshotData_ = nullptr;
            snapshotLength_ = 0;
        }
        snapshotWanted_ = false;
    }
    if (!copy) {
        server_.send(503, "text/plain", "camera busy");
        return;
    }
    sendCopy(copy, length);
}

void PhotoServer::handlePhotoList() {
    String body;
    {
        ScopedLock lock(lock_);
        if (!sdAvailable_) {
            for (int i = 0; i < kMaxRamSlots; i++) {
                if (ramSlots_[i].id == 0) continue;
                body += String(ramSlots_[i].id);
                body += ",";
                body += String((uint32_t)ramSlots_[i].length);
                body += "\n";
            }
        } else {
            File dir = SD_MMC.open(kPhotoDir);
            if (dir && dir.isDirectory()) {
                File entry = dir.openNextFile();
                while (entry) {
                    if (!entry.isDirectory()) {
                        uint32_t id;
                        if (parseIdFromPath(entry.path(), id)) {
                            body += String(id);
                            body += ",";
                            body += String((uint32_t)entry.size());
                            body += "\n";
                        }
                    }
                    entry.close();
                    entry = dir.openNextFile();
                }
            }
            if (dir) dir.close();
        }
    }
    server_.send(200, "text/plain", body);
}

void PhotoServer::scanRetentionState(uint32_t &countOut, uint32_t &lowestOut, uint32_t &highestOut) {
    countOut = 0;
    lowestOut = 0;
    highestOut = 0;
    File dir = SD_MMC.open(kPhotoDir);
    if (dir && dir.isDirectory()) {
        File entry = dir.openNextFile();
        while (entry) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id)) {
                    countOut++;
                    if (lowestOut == 0 || id < lowestOut) lowestOut = id;
                    if (id > highestOut) highestOut = id;
                }
            }
            entry.close();
            entry = dir.openNextFile();
        }
    }
    if (dir) dir.close();
}

uint32_t PhotoServer::initRetentionState() {
    ScopedLock lock(lock_);
    if (!sdAvailable_) return 0; // nothing persists across a reboot in RAM-only mode
    uint32_t count, lowest, highest;
    scanRetentionState(count, lowest, highest);
    storedCount_ = count;
    oldestStoredId_ = lowest;
    return highest;
}

void PhotoServer::advanceOldestStoredId() {
    for (uint32_t probe = oldestStoredId_ + 1, n = 0; n < 4096; probe++, n++) {
        if (SD_MMC.exists(photoPath(probe))) {
            oldestStoredId_ = probe;
            return;
        }
    }
    uint32_t count, lowest, highest;
    scanRetentionState(count, lowest, highest);
    storedCount_ = count;
    oldestStoredId_ = lowest;
}

void PhotoServer::notePhotoStored(uint32_t photoId, uint16_t maxFiles) {
    ScopedLock lock(lock_);
    if (!sdAvailable_) return; // ramPublish() already handles RAM-ring eviction inline

    storedCount_++;
    if (oldestStoredId_ == 0) oldestStoredId_ = photoId;

    int guard = 0;
    while (storedCount_ > maxFiles && oldestStoredId_ != 0 && guard++ < 256) {
        SD_MMC.remove(photoPath(oldestStoredId_));
        Serial0.printf("[photo] retention: evicted /photos/%lu.jpg (~%lu stored, max %u)\n",
                       (unsigned long)oldestStoredId_, (unsigned long)storedCount_, (unsigned)maxFiles);
        if (storedCount_ > 0) storedCount_--;
        advanceOldestStoredId();
    }
}

uint32_t PhotoServer::wipeAllPhotos() {
    ScopedLock lock(lock_);
    if (!sdAvailable_) {
        uint32_t removed = 0;
        for (int i = 0; i < kMaxRamSlots; i++) {
            if (ramSlots_[i].id == 0) continue;
            ramFreeSlot(i);
            removed++;
        }
        return removed;
    }

    uint32_t removed = 0;
    for (int pass = 0; pass < 512; pass++) {
        File dir = SD_MMC.open(kPhotoDir);
        if (!dir || !dir.isDirectory()) {
            if (dir) dir.close();
            break;
        }
        String batch[32];
        int n = 0;
        File entry = dir.openNextFile();
        while (entry && n < 32) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id)) batch[n++] = photoPath(id);
            }
            entry.close();
            entry = dir.openNextFile();
        }
        dir.close();
        if (n == 0) break;
        for (int i = 0; i < n; i++) {
            if (SD_MMC.remove(batch[i])) removed++;
        }
    }
    storedCount_ = 0;
    oldestStoredId_ = 0;
    return removed;
}
