#include "MQTTConfigStore.h"

void MQTTConfigStore::begin() {
    prefs_.begin("mqtt", /*readOnly=*/false);
    host_ = prefs_.getString("host", "");
    port_ = prefs_.getUShort("port", 1883);
    username_ = prefs_.getString("user", "");
    password_ = prefs_.getString("pass", "");
    topicPrefix_ = prefs_.getString("prefix", "peregrine");
}

void MQTTConfigStore::set(const char *host, uint16_t port, const char *username, const char *password, const char *topicPrefix) {
    host_ = host ? host : "";
    port_ = port;
    username_ = username ? username : "";
    password_ = password ? password : "";
    topicPrefix_ = (topicPrefix && topicPrefix[0]) ? topicPrefix : "peregrine";

    prefs_.putString("host", host_);
    prefs_.putUShort("port", port_);
    prefs_.putString("user", username_);
    prefs_.putString("pass", password_);
    prefs_.putString("prefix", topicPrefix_);
}

void MQTTConfigStore::clear() {
    prefs_.clear();
    host_ = "";
    port_ = 1883;
    username_ = "";
    password_ = "";
    topicPrefix_ = "peregrine";
}
