#include "ScopeStorage.h"
#include "Config.h"
#include "ScopeState.h"
#include "ScopeProtocol.h"
#include <FS.h>
#include <LittleFS.h>

ScopeStorage gStore;

namespace {

constexpr size_t kReserveBytes = 512 * 1024; // saved state, logs and photos keep working when cards fill up
constexpr size_t kMaxCardBytes = 256 * 900;  // matches ScopeLink's card buffer
constexpr uint32_t kFetchTimeoutMs = 15000;
constexpr uint8_t kMaxTries = 3;

String field(const String &line, int index) {
    int start = 0;
    for (int i = 0; i < index; i++) {
        start = line.indexOf('\t', start);
        if (start < 0) return String();
        start++;
    }
    const int end = line.indexOf('\t', start);
    return end < 0 ? line.substring(start) : line.substring(start, end);
}

String clean(const String &s) { // no tabs/newlines inside a TSV field
    String out = s;
    out.replace('\t', ' ');
    out.replace('\n', ' ');
    out.replace('\r', ' ');
    return out;
}

// "bewick_s_wren" -> "Bewick's Wren"; "black_capped_chickadee" -> "Black Capped Chickadee". The
// file name drops punctuation, so this is only a stand-in until the real name is seen again.
String nameFromKey(const String &key, bool scientific) {
    String out;
    bool wordStart = true;
    for (size_t i = 0; i < key.length(); i++) {
        const char c = key[i];
        if (c == '_') {
            // A lone "s" after a word was a possessive.
            if (!scientific && i + 2 <= key.length() && key[i + 1] == 's' && (i + 2 == key.length() || key[i + 2] == '_')) {
                out += "'s";
                i++;
                continue;
            }
            out += ' ';
            wordStart = true;
            continue;
        }
        out += (wordStart && (!scientific || out.isEmpty())) ? (char)toupper(c) : c;
        wordStart = false;
    }
    return out;
}

// Lowercase letters and digits only, for search.
void squash(const char *in, char *out, size_t cap) {
    size_t n = 0;
    for (; *in && n + 1 < cap; in++) {
        const char c = tolower(*in);
        if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) out[n++] = c;
    }
    out[n] = 0;
}

// ---- Card attributes (size + colors), read from the card text the app builds ----

const char *const kColorNames[ScopeStorage::kColorCount] = {
    "Black", "White", "Gray", "Brown", "Rusty", "Tan", "Red", "Orange", "Pink", "Yellow", "Green", "Olive", "Blue"};

// Field-guide words -> color bit (index into kColorNames).
struct ColorWord { const char *word; uint8_t bit; };
const ColorWord kColorWords[] = {
    {"black", 0}, {"blackish", 0},
    {"white", 1}, {"whitish", 1},
    {"gray", 2}, {"grey", 2}, {"grayish", 2}, {"greyish", 2}, {"slate", 2}, {"slaty", 2},
    {"brown", 3}, {"brownish", 3},
    {"rufous", 4}, {"chestnut", 4}, {"cinnamon", 4}, {"rusty", 4}, {"russet", 4},
    {"buff", 5}, {"buffy", 5}, {"tan", 5},
    {"red", 6}, {"reddish", 6}, {"crimson", 6}, {"scarlet", 6},
    {"orange", 7}, {"orangish", 7},
    {"pink", 8}, {"pinkish", 8}, {"rosy", 8},
    {"yellow", 9}, {"yellowish", 9},
    {"green", 10}, {"greenish", 10},
    {"olive", 11},
    {"blue", 12}, {"bluish", 12},
};

// A field mark about one of these is an accent (wing bars, eye rings, bill...), not the bird's main
// colors -- "white wing bars" shouldn't make a bird match White. Substrings of the lowercased mark.
const char *const kAccentParts[] = {
    "wing bar", "wingbar", "eye", "supercilium", "lores", "leg", "feet", "foot", "bill", "beak",
    "iris", "tip", "edge", "edging", "spot", "rump", "undertail", "vent"};

uint16_t colorsIn(const char *mark) {
    uint16_t mask = 0;
    char word[16];
    size_t n = 0;
    for (const char *p = mark;; p++) {
        const char c = tolower(*p);
        if (c >= 'a' && c <= 'z') {
            if (n + 1 < sizeof(word)) word[n++] = c;
            continue;
        }
        if (n) {
            word[n] = 0;
            for (const ColorWord &w : kColorWords) {
                if (strcmp(word, w.word) == 0) mask |= 1u << w.bit;
            }
            n = 0;
        }
        if (!*p) break;
    }
    return mask;
}

bool isAccent(const char *mark) {
    char lower[96];
    size_t n = 0;
    for (; mark[n] && n + 1 < sizeof(lower); n++) lower[n] = tolower(mark[n]);
    lower[n] = 0;
    // Only at the start of a word: "legs" and "eyebrow" are accents, "elegant" and "event" aren't.
    for (const char *part : kAccentParts) {
        for (const char *at = strstr(lower, part); at; at = strstr(at + 1, part)) {
            if (at == lower || !isalpha((unsigned char)at[-1])) return true;
        }
    }
    return false;
}

// "Size: large songbird (8.3-9.8 inches)" -> 83, 98 (tenths of an inch).
void parseSize(const String &line, uint16_t &lo, uint16_t &hi) {
    lo = hi = 0;
    int at = line.indexOf('(');
    if (at < 0) at = 0;
    while (at < (int)line.length() && !isdigit((unsigned char)line[at])) at++;
    if (at >= (int)line.length()) return;
    char *end;
    const char *start = line.c_str() + at;
    float a = strtof(start, &end);
    float b = a;
    if (*end == '-') b = strtof(end + 1, &end);
    if (b < a) b = a;
    const float scale = strstr(end, "cm") ? 10.0f / 2.54f : 10.0f;
    lo = (uint16_t)lroundf(a * scale);
    hi = (uint16_t)lroundf(b * scale);
}

ScopeStorage::CardAttrs attrsFromText(const String &text) {
    ScopeStorage::CardAttrs a = {};
    a.known = true;
    uint16_t main = 0, accents = 0;
    bool inMarks = false;
    int start = 0;
    while (start <= (int)text.length()) {
        int end = text.indexOf('\n', start);
        if (end < 0) end = text.length();
        const String line = text.substring(start, end);
        start = end + 1;
        if (line.startsWith("Size:")) {
            parseSize(line, a.sizeLo, a.sizeHi);
        } else if (line.startsWith("Field marks:")) {
            inMarks = true;
        } else if (inMarks && line.startsWith("- ")) {
            const char *mark = line.c_str() + 2;
            if (isAccent(mark)) accents |= colorsIn(mark);
            else main |= colorsIn(mark);
        } else {
            inMarks = false;
        }
    }
    a.colors = main ? main : accents; // a bird described only by its accents still gets its colors
    return a;
}

// Bump when the size/color rules change: index.tsv entries written under another version are read
// again from their card at boot.
constexpr int kAttrsVersion = 2;

// Size classes, tenths of an inch: [lo, hi).
struct SizeClass { const char *name; uint16_t lo, hi; };
const SizeClass kSizeClasses[ScopeStorage::kSizeClassCount] = {
    {"Any", 0, 0}, {"Tiny", 0, 50}, {"Small", 50, 70}, {"Medium", 70, 110}, {"Large", 110, 200}, {"Huge", 200, 0xFFFF}};

} // namespace

const char *ScopeStorage::colorName(int bit) {
    return bit >= 0 && bit < kColorCount ? kColorNames[bit] : "";
}

const char *ScopeStorage::sizeClassName(int sizeClass) {
    return sizeClass >= 0 && sizeClass < kSizeClassCount ? kSizeClasses[sizeClass].name : "";
}

void ScopeStorage::begin() {
    loadBuffer_ = (uint8_t *)ps_malloc(kMaxCardBytes);
    queue_ = (QueueItem *)ps_malloc(sizeof(QueueItem) * kMaxQueue);
    index_ = (IndexEntry *)ps_malloc(sizeof(IndexEntry) * kMaxIndex);
    gState.plans.items = (PlanEntry *)ps_calloc(kMaxPlanEntries, sizeof(PlanEntry));
    mounted_ = LittleFS.begin(true, "/littlefs", 5, "spiffs"); // formats on the first boot
    gState.sdPresent = mounted_;
    if (!mounted_) {
        Serial.println("[store] flash storage FAILED to mount -- bird cards come from the phone each time");
        return;
    }
    for (const char *dir : {"/cards", "/cards/sci", "/state", "/log"}) {
        if (!LittleFS.exists(dir)) LittleFS.mkdir(dir);
    }
    // Reload the download queue.
    queueCount_ = 0;
    File q = LittleFS.open("/cards/queue.tsv", FILE_READ);
    while (q && q.available() && queueCount_ < kMaxQueue) {
        const String line = q.readStringUntil('\n');
        const String common = field(line, 0);
        if (common.isEmpty()) continue;
        QueueItem &item = queue_[queueCount_++];
        strlcpy(item.common, common.c_str(), sizeof(item.common));
        strlcpy(item.scientific, field(line, 1).c_str(), sizeof(item.scientific));
        item.tries = 0;
    }
    if (q) q.close();
    refreshStats();
    loadIndex();
    Serial.printf("[store] mounted, %u bird cards stored, %d queued, %lu MB free\n", gState.cardsStored, queueCount_, (unsigned long)gState.sdFreeMB);
}

void ScopeStorage::clearCards() {
    if (!mounted_) return;
    for (const char *folder : {"/cards/sci", "/cards"}) {
        File dir = LittleFS.open(folder);
        for (File f = dir.openNextFile(); f; f = dir.openNextFile()) {
            const bool isDir = f.isDirectory();
            const String path = String(folder) + "/" + f.name();
            f.close();
            if (!isDir) LittleFS.remove(path);
        }
    }
    queueCount_ = 0;
    indexCount_ = 0;
    indexVersion_++;
    fetching_ = false;
    full_ = false;
    gState.cardsFailed = 0;
    refreshStats();
    Serial.println("[store] cards cleared");
}

void ScopeStorage::refreshStats() {
    if (!mounted_) return;
    uint16_t count = 0;
    File dir = LittleFS.open("/cards");
    for (File f = dir.openNextFile(); f; f = dir.openNextFile()) {
        if (String(f.name()).endsWith(".card")) count++;
        f.close();
    }
    gState.cardsStored = count;
    gState.cardsQueued = queueCount_;
    gState.sdFreeMB = (uint32_t)((LittleFS.totalBytes() - LittleFS.usedBytes()) / (1024ULL * 1024ULL));
}

String ScopeStorage::keyFor(const String &common) {
    String key;
    for (size_t i = 0; i < common.length() && key.length() < 60; i++) {
        const char c = tolower(common[i]);
        if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) key += c;
        else if (key.length() && key[key.length() - 1] != '_') key += '_';
    }
    return "/cards/" + key + ".card";
}

// /cards/sci/<genus_species>.txt holds the card file's path, for lookups by scientific name.
String ScopeStorage::aliasFor(const String &scientific) {
    String key = keyFor(scientific);
    key.replace("/cards/", "/cards/sci/");
    key.replace(".card", ".txt");
    return key;
}

bool ScopeStorage::hasCard(const String &common) {
    return mounted_ && LittleFS.exists(keyFor(common));
}

bool ScopeStorage::loadCard(const String &common, const String &scientific, CardResult &out) {
    if (!mounted_ || !loadBuffer_) return false;
    String path = keyFor(common);
    if (!LittleFS.exists(path) && scientific.length()) {
        File alias = LittleFS.open(aliasFor(scientific), FILE_READ);
        if (alias) {
            path = alias.readStringUntil('\n');
            alias.close();
        }
    }
    File f = LittleFS.open(path, FILE_READ);
    if (!f) return false;
    const size_t size = f.size();
    if (size < 8 || size > kMaxCardBytes) { f.close(); return false; }
    const size_t got = f.read(loadBuffer_, size);
    f.close();
    if (got != size) return false;
    uint32_t textLen, jpegLen;
    memcpy(&textLen, loadBuffer_, 4);
    memcpy(&jpegLen, loadBuffer_ + 4, 4);
    if (8 + (size_t)textLen + jpegLen > size) return false;
    out.requestId = 0;
    out.text = String((const char *)(loadBuffer_ + 8), textLen);
    out.jpeg = jpegLen ? loadBuffer_ + 8 + textLen : nullptr;
    out.jpegLen = jpegLen;
    return true;
}

bool ScopeStorage::pickFact(String &common, String &scientific, String &fact, CardResult &out) {
    if (indexCount_ == 0) return false;
    static const char kPrefix[] = "Behavior: ";
    for (int tries = 0; tries < 8; tries++) { // some cards have no such line
        const IndexEntry &entry = index_[esp_random() % indexCount_];
        if (!loadCard(entry.common, entry.scientific, out)) continue;
        const int at = out.text.indexOf(kPrefix);
        if (at < 0) continue;
        const int start = at + sizeof(kPrefix) - 1;
        const int end = out.text.indexOf('\n', start);
        fact = end < 0 ? out.text.substring(start) : out.text.substring(start, end);
        fact.trim();
        if (fact.isEmpty()) continue;
        common = entry.common;
        scientific = entry.scientific;
        return true;
    }
    return false;
}

void ScopeStorage::saveCard(const String &common, const uint8_t *payload, size_t len, const String &scientific) {
    if (!mounted_ || len < 8 || len > kMaxCardBytes) return;
    uint32_t textLen, jpegLen;
    memcpy(&textLen, payload, 4);
    memcpy(&jpegLen, payload + 4, 4);
    const size_t used = 8 + (size_t)textLen + jpegLen;
    if (used > len) return;
    if (LittleFS.totalBytes() - LittleFS.usedBytes() < used + kReserveBytes) {
        // Everything queued would fail the same way. Loading again after clearCards() retries it.
        Serial.printf("[store] flash nearly full, not saving %s; dropping %d queued\n", common.c_str(), queueCount_);
        full_ = true;
        gState.cardsFailed += queueCount_;
        queueCount_ = 0;
        gState.cardsQueued = 0;
        saveQueue();
        return;
    }
    const bool existed = LittleFS.exists(keyFor(common));
    File f = LittleFS.open(keyFor(common), FILE_WRITE);
    if (!f) return;
    const size_t wrote = f.write(payload, used);
    f.close();
    if (wrote != used) { // a partial card would read as damaged forever
        LittleFS.remove(keyFor(common));
        Serial.printf("[store] couldn't save %s\n", common.c_str());
        return;
    }
    if (!existed) gState.cardsStored++;
    const CardAttrs attrs = attrsFromText(String((const char *)payload + 8, textLen));
    upsertIndex(fileKey(common), common, scientific, false, true, &attrs);
    if (scientific.length()) {
        File alias = LittleFS.open(aliasFor(scientific), FILE_WRITE);
        if (alias) {
            alias.print(keyFor(common));
            alias.close();
        }
    }
    Serial.printf("[store] saved card: %s (%u B text, %u B photo)\n", common.c_str(), (unsigned)textLen, (unsigned)jpegLen);
}

void ScopeStorage::enqueueCard(const String &common, const String &scientific) {
    if (!mounted_ || common.isEmpty()) return;
    if (hasCard(common)) {
        // Already stored -- just make sure it can also be found by its scientific name.
        if (scientific.length() && !LittleFS.exists(aliasFor(scientific))) {
            File alias = LittleFS.open(aliasFor(scientific), FILE_WRITE);
            if (alias) { alias.print(keyFor(common)); alias.close(); }
        }
        noteName(common, scientific);
        return;
    }
    if (queueCount_ >= kMaxQueue) return;
    for (int i = 0; i < queueCount_; i++) {
        if (common.equalsIgnoreCase(queue_[i].common)) return;
    }
    QueueItem &item = queue_[queueCount_++];
    strlcpy(item.common, common.c_str(), sizeof(item.common));
    strlcpy(item.scientific, scientific.c_str(), sizeof(item.scientific));
    item.tries = 0;
    gState.cardsQueued = queueCount_;
    File q = LittleFS.open("/cards/queue.tsv", FILE_APPEND);
    if (q) {
        q.printf("%s\t%s\n", clean(common).c_str(), clean(scientific).c_str());
        q.close();
    }
}

void ScopeStorage::saveQueue() {
    if (!mounted_) return;
    File q = LittleFS.open("/cards/queue.tsv", FILE_WRITE);
    if (!q) return;
    for (int i = 0; i < queueCount_; i++) q.printf("%s\t%s\n", queue_[i].common, queue_[i].scientific);
    q.close();
    savedSinceQueueWrite_ = 0;
}

void ScopeStorage::poll(uint32_t nowMs) {
    if (!mounted_) return;
    if (nowMs - lastStatsMs_ > 60000) {
        lastStatsMs_ = nowMs;
        gState.sdFreeMB = (uint32_t)((LittleFS.totalBytes() - LittleFS.usedBytes()) / (1024ULL * 1024ULL));
    }

    // A queued card arrived -> store it, drop it from the queue.
    String common;
    const uint8_t *payload = nullptr;
    size_t len = 0;
    if (gLink.takePrefetchCard(common, payload, len)) {
        String scientific;
        for (int i = 0; i < queueCount_; i++) {
            if (common.equalsIgnoreCase(queue_[i].common)) { scientific = queue_[i].scientific; break; }
        }
        saveCard(common, payload, len, scientific);
        for (int i = 0; i < queueCount_; i++) {
            if (common.equalsIgnoreCase(queue_[i].common)) {
                memmove(&queue_[i], &queue_[i + 1], sizeof(QueueItem) * (queueCount_ - i - 1));
                queueCount_--;
                break;
            }
        }
        gState.cardsQueued = queueCount_;
        fetching_ = false;
        if (++savedSinceQueueWrite_ >= 10 || queueCount_ == 0) saveQueue();
    }

    // A card you tapped replaced our download request: not a failure -- the same card is still
    // first in the queue and is asked for again once yours is in.
    if (fetching_ && gLink.cardPending() && !gLink.prefetchInFlight()) {
        fetching_ = false;
        return;
    }
    if (fetching_ && nowMs - fetchStartMs_ > kFetchTimeoutMs) {
        // No (complete) reply -- try it again later, at the back of the queue; give up after 3 tries.
        fetching_ = false;
        uint16_t got, expected;
        gLink.cardProgress(got, expected);
        Serial.printf("[store] card timed out: %s (%u of %u chunks)\n", fetchingCommon_.c_str(), got, expected);
        gLink.cancelCard();
        for (int i = 0; i < queueCount_; i++) {
            if (!fetchingCommon_.equalsIgnoreCase(queue_[i].common)) continue;
            QueueItem item = queue_[i];
            memmove(&queue_[i], &queue_[i + 1], sizeof(QueueItem) * (queueCount_ - i - 1));
            queueCount_--;
            if (++item.tries < kMaxTries) queue_[queueCount_++] = item;
            else {
                gState.cardsFailed++;
                Serial.printf("[store] gave up on the card for %s\n", item.common);
            }
            break;
        }
        gState.cardsQueued = queueCount_;
        saveQueue();
    }

    // Next download: only with the phone linked, and never over a card you tapped.
    if (fetching_ || queueCount_ == 0 || gLink.cardPending()) return;
    if (!gState.appLinked(millis(), Config::kAppLinkTimeoutMs) || gState.campMode) return;
    const QueueItem &next = queue_[0];
    if (hasCard(next.common)) { // stored meanwhile (e.g. you tapped it)
        memmove(&queue_[0], &queue_[1], sizeof(QueueItem) * (queueCount_ - 1));
        queueCount_--;
        gState.cardsQueued = queueCount_;
        return;
    }
    if (gLink.requestCard(next.common, next.scientific, true)) {
        Serial.printf("[store] downloading card %s (%d queued)\n", next.common, queueCount_);
        fetching_ = true;
        fetchingCommon_ = next.common;
        fetchStartMs_ = nowMs;
    }
}

// ---- Persisted state ----

void ScopeStorage::savePlans() {
    if (!mounted_ || !gState.plans.items) return;
    File f = LittleFS.open("/state/plans.bin", FILE_WRITE);
    if (!f) return;
    const uint32_t header[2] = {0x31504C50 /* "PLP1" */, (uint32_t)gState.plans.count};
    f.write((const uint8_t *)header, sizeof(header));
    f.write((const uint8_t *)gState.plans.items, sizeof(PlanEntry) * gState.plans.count);
    f.close();
}

void ScopeStorage::loadPlans() {
    if (!mounted_ || !gState.plans.items) return;
    File f = LittleFS.open("/state/plans.bin", FILE_READ);
    if (!f) return;
    uint32_t header[2] = {0, 0};
    if (f.read((uint8_t *)header, sizeof(header)) == sizeof(header) && header[0] == 0x31504C50 && header[1] <= kMaxPlanEntries &&
        f.read((uint8_t *)gState.plans.items, sizeof(PlanEntry) * header[1]) == sizeof(PlanEntry) * header[1]) {
        gState.plans.count = header[1];
        gState.plans.valid = true;
        gState.plansVersion++;
    }
    f.close();
}

void ScopeStorage::saveTargetList() {
    if (!mounted_) return;
    const TripTargetList &list = gState.tripTargets;
    File f = LittleFS.open("/state/targets.tsv", FILE_WRITE);
    if (!f) return;
    f.printf("%s\t%s\t%u\t%u\n", clean(list.tripName).c_str(), clean(list.stopName).c_str(), list.total, list.seen);
    for (int i = 0; i < list.count; i++) f.printf("%u\t%s\n", list.items[i].flags, clean(list.items[i].name).c_str());
    f.close();
}

void ScopeStorage::loadTargetList() {
    if (!mounted_) return;
    File f = LittleFS.open("/state/targets.tsv", FILE_READ);
    if (!f) return;
    TripTargetList &list = gState.tripTargets;
    const String header = f.readStringUntil('\n');
    list.tripName = field(header, 0);
    list.stopName = field(header, 1);
    list.total = field(header, 2).toInt();
    list.seen = field(header, 3).toInt();
    list.count = 0;
    while (f.available() && list.count < kMaxTripTargets) {
        const String line = f.readStringUntil('\n');
        if (line.isEmpty()) continue;
        list.items[list.count].flags = field(line, 0).toInt();
        list.items[list.count].name = field(line, 1);
        list.count++;
    }
    f.close();
    list.valid = list.total > 0;
    gState.tripTargetsVersion++;
}

void ScopeStorage::saveHistory() {
    if (!mounted_) return;
    File f = LittleFS.open("/state/history.tsv", FILE_WRITE);
    if (!f) return;
    const TripHistory &h = gState.tripHistory;
    for (int i = 0; i < h.count; i++) f.printf("%u\t%u\t%s\n", h.items[i].kind, h.items[i].flags, clean(h.items[i].name).c_str());
    f.close();
}

void ScopeStorage::loadHistory() {
    if (!mounted_) return;
    File f = LittleFS.open("/state/history.tsv", FILE_READ);
    if (!f) return;
    TripHistory &h = gState.tripHistory;
    h.count = 0;
    while (f.available() && h.count < kMaxHistoryEntries) {
        const String line = f.readStringUntil('\n');
        if (line.isEmpty()) continue;
        h.items[h.count].kind = field(line, 0).toInt();
        h.items[h.count].flags = field(line, 1).toInt();
        h.items[h.count].name = field(line, 2);
        h.count++;
    }
    f.close();
    h.valid = h.count > 0;
    gState.tripHistoryVersion++;
}

void ScopeStorage::logEvent(const char *action, const String &bird) {
    if (!mounted_) return;
    File f = LittleFS.open("/log/checks.tsv", FILE_APPEND);
    if (!f) return;
    f.printf("%lu\t%s\t%s\t%s\n", (unsigned long)gState.unixNow(), action, clean(bird).c_str(), clean(gState.tripTargets.stopName).c_str());
    f.close();
}

void ScopeStorage::logSlow(const char *step, uint32_t ms, const String &detail) {
    if (!mounted_) return;
    File f = LittleFS.open("/log/slow.txt", FILE_APPEND);
    if (!f) return;
    f.printf("%lu up %lus: %s took %lu ms | map tiles queued %u | heap %u %s\n", (unsigned long)gState.unixNow(),
             (unsigned long)(millis() / 1000), step, (unsigned long)ms, gState.mapsQueued, (unsigned)ESP.getFreeHeap(), detail.c_str());
    f.close();
}

void ScopeStorage::printSlowLog() {
    if (!mounted_) return;
    File f = LittleFS.open("/log/slow.txt", FILE_READ);
    if (!f) return;
    const size_t size = f.size();
    if (size > 2000) f.seek(size - 2000); // the last few
    Serial.println("[slow] earlier freezes (/log/slow.txt):");
    while (f.available()) Serial.println("[slow]   " + f.readStringUntil('\n'));
    f.close();
    LittleFS.remove("/log/slow.old");
    LittleFS.rename("/log/slow.txt", "/log/slow.old"); // printed once; the next boot shows only newer ones
}

// ---- Saved-card index ----

String ScopeStorage::fileKey(const String &common) {
    String k = keyFor(common);
    return k.substring(7, k.length() - 5); // strip "/cards/" and ".card"
}

int ScopeStorage::findIndex(const char *file) const {
    for (int i = 0; i < indexCount_; i++) {
        if (strcmp(index_[i].file, file) == 0) return i;
    }
    return -1;
}

void ScopeStorage::upsertIndex(const String &file, const String &common, const String &scientific, bool derived, bool persist,
                               const CardAttrs *attrs) {
    if (!index_ || file.isEmpty()) return;
    String sci = scientific;
    CardAttrs useAttrs = attrs ? *attrs : CardAttrs{};
    int i = findIndex(file.c_str());
    if (i >= 0) {
        IndexEntry &e = index_[i];
        if (derived && !e.derived) return; // never replace a real name with a rebuilt one
        const bool sameName = common.equals(e.common);
        const bool sameAttrs = !attrs || (attrs->known == e.attrs.known && attrs->sizeLo == e.attrs.sizeLo &&
                                          attrs->sizeHi == e.attrs.sizeHi && attrs->colors == e.attrs.colors);
        if (sameName && e.derived == derived && (sci.isEmpty() || sci.equals(e.scientific)) && sameAttrs) return;
        if (sci.isEmpty()) sci = e.scientific;
        if (!attrs) useAttrs = e.attrs;
        // Remove and re-insert below so the list stays sorted.
        memmove(&index_[i], &index_[i + 1], sizeof(IndexEntry) * (indexCount_ - i - 1));
        indexCount_--;
    }
    if (indexCount_ >= kMaxIndex) return;
    IndexEntry e = {};
    strlcpy(e.file, file.c_str(), sizeof(e.file));
    strlcpy(e.common, common.c_str(), sizeof(e.common));
    strlcpy(e.scientific, sci.c_str(), sizeof(e.scientific));
    e.derived = derived;
    e.attrs = useAttrs;
    int at = 0;
    while (at < indexCount_ && strcasecmp(index_[at].common, e.common) < 0) at++;
    memmove(&index_[at + 1], &index_[at], sizeof(IndexEntry) * (indexCount_ - at));
    index_[at] = e;
    indexCount_++;
    indexVersion_++;
    if (persist) appendIndex(e);
}

void ScopeStorage::appendIndex(const IndexEntry &e) {
    File f = LittleFS.open("/cards/index.tsv", FILE_APPEND);
    if (!f) return;
    printEntry(f, e);
    f.close();
}

void ScopeStorage::printEntry(File &f, const IndexEntry &e) {
    f.printf("%s\t%s\t%s\t%d", e.file, e.common, e.scientific, e.derived ? 1 : 0);
    if (e.attrs.known) f.printf("\t%u\t%u\t%u\t%d\n", e.attrs.sizeLo, e.attrs.sizeHi, e.attrs.colors, kAttrsVersion);
    else f.print("\t\t\t\t\n");
}

void ScopeStorage::writeIndex() {
    File f = LittleFS.open("/cards/index.tsv", FILE_WRITE);
    if (!f) return;
    for (int i = 0; i < indexCount_; i++) {
        printEntry(f, index_[i]);
    }
    f.close();
}

// Reads index.tsv (later lines win), then makes sure every card file has an entry -- cards saved
// before the index existed get a name rebuilt from the file name, and their scientific name from
// the /cards/sci/ alias that points at them -- and drops entries whose file is gone. Rewrites the
// file compact.
void ScopeStorage::loadIndex() {
    if (!index_) return;
    indexCount_ = 0;
    File f = LittleFS.open("/cards/index.tsv", FILE_READ);
    while (f && f.available()) {
        const String line = f.readStringUntil('\n');
        const String file = field(line, 0);
        if (file.isEmpty()) continue;
        CardAttrs attrs = {};
        const String sizeLo = field(line, 4);
        if (sizeLo.length() && field(line, 7).toInt() == kAttrsVersion) {
            attrs.known = true;
            attrs.sizeLo = sizeLo.toInt();
            attrs.sizeHi = field(line, 5).toInt();
            attrs.colors = field(line, 6).toInt();
        }
        upsertIndex(file, clean(field(line, 1)), clean(field(line, 2)), field(line, 3) == "1", false, attrs.known ? &attrs : nullptr);
    }
    if (f) f.close();
    const int fromFile = indexCount_;

    // Every stored card, with or without an entry.
    for (int i = 0; i < indexCount_; i++) index_[i].onCard = false;
    File dir = LittleFS.open("/cards");
    for (File c = dir.openNextFile(); c; c = dir.openNextFile()) {
        String name = c.name();
        c.close();
        const int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (!name.endsWith(".card")) continue;
        const String file = name.substring(0, name.length() - 5);
        if (findIndex(file.c_str()) < 0) upsertIndex(file, nameFromKey(file, false), String(), true, false);
        const int i = findIndex(file.c_str()); // entries move as others are inserted -- look it up again
        if (i >= 0) index_[i].onCard = true;
    }
    // Entries whose card file is gone.
    int kept = 0;
    for (int i = 0; i < indexCount_; i++) {
        if (index_[i].onCard) index_[kept++] = index_[i];
    }
    indexCount_ = kept;
    // Scientific names for rebuilt entries, from the aliases ("/cards/sci/poecile_atricapillus.txt"
    // holds "/cards/black_capped_chickadee.card").
    File sci = LittleFS.open("/cards/sci");
    for (File a = sci.openNextFile(); a; a = sci.openNextFile()) {
        String name = a.name();
        String target = a.readStringUntil('\n');
        a.close();
        const int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (!name.endsWith(".txt") || !target.startsWith("/cards/") || !target.endsWith(".card")) continue;
        const String file = target.substring(7, target.length() - 5);
        const int i = findIndex(file.c_str());
        if (i >= 0 && !index_[i].scientific[0]) {
            strlcpy(index_[i].scientific, nameFromKey(name.substring(0, name.length() - 4), true).c_str(), sizeof(index_[i].scientific));
        }
    }
    // Size and colors for cards that don't have them yet (saved before the filter existed): read
    // each card's text once; writeIndex() below keeps the result.
    const uint32_t attrsStart = millis();
    int attrsRead = 0;
    for (int i = 0; i < indexCount_ && loadBuffer_; i++) {
        IndexEntry &e = index_[i];
        if (e.attrs.known) continue;
        File c = LittleFS.open("/cards/" + String(e.file) + ".card", FILE_READ);
        if (!c) continue;
        uint32_t lens[2] = {0, 0};
        if (c.read((uint8_t *)lens, 8) == 8) {
            const size_t textLen = min((size_t)lens[0], (size_t)4096);
            const size_t got = c.read(loadBuffer_, textLen);
            e.attrs = attrsFromText(String((const char *)loadBuffer_, got));
            attrsRead++;
        }
        c.close();
    }
    if (attrsRead) Serial.printf("[store] read size/colors from %d cards in %lu ms\n", attrsRead, (unsigned long)(millis() - attrsStart));
    writeIndex();
    indexVersion_++;
    int derived = 0, sized = 0, colored = 0;
    for (int i = 0; i < indexCount_; i++) {
        derived += index_[i].derived;
        sized += index_[i].attrs.sizeHi > 0;
        colored += index_[i].attrs.colors != 0;
    }
    Serial.printf("[store] card index: %d cards (%d from index.tsv, %d named from their file only, %d with a size, %d with colors)\n",
                  indexCount_, fromFile, derived, sized, colored);
}

void ScopeStorage::noteName(const String &common, const String &scientific) {
    if (!mounted_ || common.isEmpty()) return;
    const String file = fileKey(common);
    const int i = findIndex(file.c_str());
    if (i < 0) return; // not stored
    const IndexEntry &e = index_[i];
    if (!e.derived && (scientific.isEmpty() || e.scientific[0])) return;
    upsertIndex(file, common, scientific.length() ? scientific : String(e.scientific), false, true);
}

int ScopeStorage::searchCards(const String &query, int sizeClass, uint16_t colorMask, int *out, int max) const {
    char q[64], buf[64];
    squash(query.c_str(), q, sizeof(q));
    const bool bySize = sizeClass > 0 && sizeClass < kSizeClassCount;
    int matched = 0;
    for (int i = 0; i < indexCount_; i++) {
        const CardAttrs &a = index_[i].attrs;
        if (bySize && (a.sizeHi == 0 || a.sizeLo >= kSizeClasses[sizeClass].hi || a.sizeHi < kSizeClasses[sizeClass].lo)) continue;
        if ((a.colors & colorMask) != colorMask) continue;
        bool hit = !q[0];
        if (!hit) {
            squash(index_[i].common, buf, sizeof(buf));
            hit = strstr(buf, q) != nullptr;
        }
        if (!hit && index_[i].scientific[0]) {
            squash(index_[i].scientific, buf, sizeof(buf));
            hit = strstr(buf, q) != nullptr;
        }
        if (!hit) continue;
        if (matched < max) out[matched] = i;
        matched++;
    }
    return matched;
}
