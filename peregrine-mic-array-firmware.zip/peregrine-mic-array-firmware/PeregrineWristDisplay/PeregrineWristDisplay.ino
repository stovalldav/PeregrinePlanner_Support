// PeregrineWristDisplay -- the Wrist Display node: a SAINTCON 2024 badge (ESP32-S3, 2.8" touchscreen,
// LiPo) worn on the wrist. See SAINTCON_BADGES_PLAN.md §4 (repo root) and README.md here.
//
// Joins the fleet as a Scope Display (node type 3) with no speaker, mic or compass, and shows what the
// phone relays: a clock with Mark / Saw it / Undo, Heard, Targets, Trip, bird cards kept in flash, copies of
// the inbox photos, Session with the trip picker, and camp alerts.
//
// The stock badge firmware is gone: this firmware owns the whole flash (partitions.csv, README.md).

#include <Arduino.h>
#include <WiFi.h>
#include "Config.h"
#include "ScopeBLE.h"
#include "ScopeLink.h"
#include "JpegImage.h"
#include "ScopeState.h"
#include "ScopeStorage.h"
#include "WristHardware.h"
#include "WristPhotos.h"
#include "WristUI.h"

ScopeState gState;

// ScopeLink applies the app's scope alignment through this; there's no compass to align here.
void saveAlignment(float, uint16_t) {}

void setup() {
    Serial.begin(115200);
    Serial.setTxTimeoutMs(0); // never wait on the USB log, as on the Scope Display. To read a long log, try 10 for that build:
                              // it kept the log running here, but each print can stall 20 x that with nothing reading
    delay(200);
    Serial.println("\n[boot] Peregrine Wrist Display");

    gState.micStreamEnabled = false;
    gHardware.begin();
    jpegInit();
    // Whatever was saved, so the lists show even with the phone out of reach after a reboot.
    gStore.begin();
    gStore.loadTargetList();
    gStore.loadHistory();
    gStore.loadPlans();
    gStore.printSlowLog();
    gPhotos.begin();
    gLink.beginOutbox();
    gUI.begin();
    Serial.println("[boot] display + touch ready");
    gLink.begin();
    gBLE.begin();
    Serial.println("[boot] ready");
}

void loop() {
    const uint32_t now = millis();
    static uint32_t lastLoopMs = 0;
    if (lastLoopMs && now - lastLoopMs > gState.loopMaxMs) gState.loopMaxMs = now - lastLoopMs;
    lastLoopMs = now;
    gLink.poll(millis());
    gBLE.poll(gState.appLinked(millis(), Config::kAppLinkTimeoutMs), gState.wifiConnected, gState.myIP);
    gHardware.poll(millis());
    gStore.poll(millis());
    gPhotos.poll();
    // Bench commands over USB: see WristUI::benchCommand.
    if (Serial.available()) gUI.benchCommand(Serial.read());
    gUI.update(millis());
    delay(2);
}
