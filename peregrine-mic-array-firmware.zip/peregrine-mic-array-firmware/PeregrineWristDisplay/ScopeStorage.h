// ScopeStorage.h -- the badge's flash (LittleFS, about 12.8 MB): bird-card cache, the "load cards for this
// area" download queue, copies of the trip target list / trip history / trip plans so they survive a
// reboot with the phone out of reach, and a plain-text log of every check made on the display.
//
// A near-copy of the Scope Display's SD card storage, without its stop maps (see README.md). The flash
// can't be swapped like a card, so downloads stop while kReserveBytes is still free and clearCards()
// makes room again.
//
// Layout:  /cards/<key>.card    one bird card = the app's card payload as received
//                               (textLen u32, jpegLen u32, text, jpeg)
//          /cards/queue.tsv     cards still to download: "common<TAB>scientific" per line
//          /cards/index.tsv     the real names behind each file, sizes and colors (see the Scope Display's)
//          /state/targets.tsv   last target list      /state/history.tsv   last trip history
//          /state/plans.bin     last trip plans (trips + stops)
//          /log/checks.tsv      unixTime, action, bird, location -- one line per check / new location
#pragma once

#include <Arduino.h>
#include <FS.h>
#include "ScopeLink.h"
#include "ScopeProtocol.h"

class ScopeStorage {
public:
    // Mounts the flash, formatting it the first time. Call after Serial, before the UI needs cards.
    void begin();
    // Runs the card download queue (one card at a time, only while the phone is linked and no card
    // you tapped is loading). Call every loop().
    void poll(uint32_t nowMs);

    bool present() const { return mounted_; }

    // Bird cards
    bool hasCard(const String &common);
    // Loads a stored card; `out.jpeg` points into this class's own buffer until the next load.
    // Tries the common name, then the scientific name (Sound ID and eBird sometimes name a species
    // differently -- a card saved under one is still found by the other).
    bool loadCard(const String &common, const String &scientific, CardResult &out);
    void saveCard(const String &common, const uint8_t *payload, size_t len, const String &scientific = String());
    // Adds a species to the download queue unless it's already stored or queued.
    void enqueueCard(const String &common, const String &scientific);

    // What the Cards filter matches on, read from the card's "Size:" and "Field marks:" lines.
    struct CardAttrs {
        uint16_t sizeLo, sizeHi; // tenths of an inch; 0 = the card gives no size
        uint16_t colors;         // bit per color (colorName()) on the bird's body, not its accents
        bool known;              // read from the card yet
    };
    // Size classes for the filter (0 = any). A bird matches every class its size range touches.
    static constexpr int kSizeClassCount = 6;
    static const char *sizeClassName(int sizeClass);
    static constexpr int kColorCount = 13;
    static const char *colorName(int bit);

    // Saved-card index, for the Birds tab's Cards view. Sorted by common name.
    struct IndexEntry {
        char file[61];       // keyFor() without "/cards/" and ".card"
        char common[49];
        char scientific[49];
        bool derived;        // name rebuilt from the file name (cards saved before the index existed)
        bool onCard;         // loadIndex() only: the card file was found
        CardAttrs attrs;
    };
    int cardCount() const { return indexCount_; }
    const IndexEntry &cardAt(int i) const { return index_[i]; }
    // Bumped whenever the index changes.
    uint32_t indexVersion() const { return indexVersion_; }
    // Up to `max` matches for `query` (any part of the common or scientific name; case, spaces and
    // punctuation ignored -- "bcch" won't match, "capped chick" will), alphabetical, narrowed to
    // `sizeClass` (0 = any) and to birds showing every color in `colorMask`. Returns how many
    // matched in total, which can be more than `max`.
    int searchCards(const String &query, int sizeClass, uint16_t colorMask, int *out, int max) const;
    // A card's real name, seen somewhere else (a detection, a target, the card list): fixes an entry
    // whose name was only rebuilt from its file name.
    void noteName(const String &common, const String &scientific);

    // No stop maps on this node.
    void enqueueMissingMaps() {}
    void mapProgress(int &stored, int &total) const { stored = total = 0; }

    // Deletes every stored card and the download queue. Saved state and photos stay.
    void clearCards();
    // Downloads stopped because the flash is nearly full.
    bool full() const { return full_; }

    // Persisted copies
    void savePlans();
    void loadPlans();
    void saveTargetList();
    void loadTargetList();
    void saveHistory();
    void loadHistory();
    void logEvent(const char *action, const String &bird);
    // A step that held the main loop for seconds -> /log/slow.txt, printed at the next boot, so a
    // freeze can be diagnosed after the fact without the USB cable in (a 76 s one, 2026-10-08).
    void logSlow(const char *step, uint32_t ms, const String &detail = String());
    void printSlowLog();

private:
    static String keyFor(const String &common);
    static String aliasFor(const String &scientific);
    void saveQueue();
    void refreshStats();
    // Index
    void loadIndex();
    void writeIndex();
    void appendIndex(const IndexEntry &e);
    int findIndex(const char *file) const;
    // `attrs` null = keep the entry's current ones.
    void upsertIndex(const String &file, const String &common, const String &scientific, bool derived, bool persist,
                     const CardAttrs *attrs = nullptr);
    static void printEntry(File &f, const IndexEntry &e);
    static String fileKey(const String &common); // keyFor() without the folder / extension
    static constexpr int kMaxIndex = 800;
    IndexEntry *index_ = nullptr; // PSRAM
    int indexCount_ = 0;
    uint32_t indexVersion_ = 0;

    bool mounted_ = false;
    uint8_t *loadBuffer_ = nullptr; // PSRAM, for loadCard()

    // Download queue (also in flash as /cards/queue.tsv)
    // Fixed-size so the whole queue lives in PSRAM (Strings would put every name in internal RAM).
    struct QueueItem { char common[49]; char scientific[49]; uint8_t tries; };
    static constexpr int kMaxQueue = 600;
    QueueItem *queue_ = nullptr; // PSRAM array of kMaxQueue
    int queueCount_ = 0;
    bool fetching_ = false;
    String fetchingCommon_;
    uint32_t fetchStartMs_ = 0;
    uint32_t lastStatsMs_ = 0;
    int savedSinceQueueWrite_ = 0;

    bool full_ = false;
};

extern ScopeStorage gStore;
