# PeregrineWristDisplay -- the Wrist Display node

A SAINTCON 2024 badge worn on the wrist (design: `SAINTCON_BADGES_PLAN.md` §4 at the repo root). It joins
the fleet as a Scope Display (node type 3) that reports no speaker, mic or compass, and shows what the app
relays:

| Tab | What it does |
|---|---|
| **Clock** | The phone's local time and date, in its 12 or 24-hour format, also in the status strip on every tab. Blank after a restart until the phone sends the time; it then keeps running without the phone. **Mark / Saw it / Undo** buttons, resent until the phone answers. |
| **Birds** | Four views. **Heard:** each detection, newest first. **Targets:** the logged trip's checklist. Tap to check off, through the NVS outbox, so checks survive dropouts; long-press adds to the count; **I moved** (tap twice) starts a new location. **Trip:** what you've seen at each location. **Cards:** saved bird cards, with **Find**, **Filter** (size and colors) and **Clear** (tap twice). Tap a bird anywhere for its card, with its photo. |
| **Photos** | **Get** copies the newest inbox photos from the phone, **View** shows them full screen (swipe to move, tap to close), **Clear** (tap twice) deletes the copies. |
| **Session** | Timer, species, last 10 minutes, lifers, recent birds, Wi-Fi, IP and storage. **Trips** starts a planned trip or says "I'm here" at a stop. |

**Fun facts:** while the app isn't running Sound ID (or is out of reach), waking the screen brings up a saved
card's behavior line and photo, at most once every 10 minutes. Tap to close it, or **Card** for the full card. It
goes when the screen sleeps. It never lights a dark screen, and needs saved cards but not the phone. The **Fun facts**
button on the Session tab steps through every 10 minutes, 30 minutes, 1 hour, 2 hours and off, and is saved on the badge.

A camp presence alert takes over the screen with a slow backlight pulse; tap to dismiss. Tap a card to
close it.

**Bird cards:** in the app, this node's settings > **Load bird cards for this area**. The display pulls each
missing card through the app, one at a time, and tapped cards are saved too. Each card with its photo is
about 20 KB (estimated), so roughly 500 fit. Downloads stop while 512 KB is still free, for saved lists, logs
and photos; **Birds > Cards > Clear** makes room. The target list, trip history and trip plans are saved too,
so they show after a reboot with the phone out of reach.

**Photos:** copies of the newest photos in the app's Camera Node Captures and Linked Phone inboxes: at most 12,
each fit to 320x240 and 48 KB or less, kept in flash. Clearing or re-getting never changes the phone's inboxes,
and the app must be open and linked to fetch.

**Wake:** the screen goes dark after 15 s. Raise your wrist (the screen turns to face up), touch it, or get
a new lifer or camp alert to light it. The first touch on a dark screen only wakes it. Turn the badge off
with its slide switch.

**Merlin:** pair once in the iPhone's Settings > Bluetooth (**PPWrist**) and allow notifications. Only one
device may read and clear Merlin's notifications, so with two displays linked the app picks one (a Scope
Display first), and it sends each bird through the app to the other. If the app goes quiet for 10 s every
display goes back to reading them, and each may miss the odd bird.

**Not ported:** Radar and Compass (no compass), Hold to talk and the mic (no audio hardware), Fleet and the
Camp console (too much for this screen). **Stop maps:** a stop's 682 tiles alone would take more than the 12.8 MB,
and the viewer's tile cache needs more than the badge's 2 MB of PSRAM.

## Flash layout and flashing

**Installing this erases the badge, including its stock firmware and anything it stored, and there's no way
back without your own backup.** To keep one first, which takes about 25 minutes:
`esptool.py --port <port> read_flash 0 0x1000000 saintcon2024-badge.bin`.

This firmware owns the whole 16 MB (`partitions.csv`, which Arduino picks up from this folder):

| Region | Contents |
|---|---|
| `0x9000` `nvs`, 20 KB | The check outbox, BLE pairing |
| `0x10000` `app0`, 3 MB | This firmware |
| `0x310000` `spiffs`, about 12.8 MB | LittleFS: `ScopeStorage.h` has the layout, plus `/photos` |
| `0xFF0000` `coredump`, 64 KB | Crash dumps |

The first time, erase the flash, then build and upload:

```
esptool.py --port <port> erase_flash
arduino-cli compile --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=enabled,PartitionScheme=huge_app,CDCOnBoot=cdc,USBMode=hwcdc" PeregrineWristDisplay
arduino-cli upload  --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=enabled,PartitionScheme=huge_app,CDCOnBoot=cdc,USBMode=hwcdc" -p <port> PeregrineWristDisplay
```

Later uploads keep saved cards and settings. The partition scheme only sets the compile's size limit. Other
ESP32-S3 boards can appear with the same port name, so check you have the right one with `esptool.py read_mac`.

## Hardware

Pins are in `Config.h`, from the badge's published repo (compukidmike/Saintcon2024) and confirmed on one badge.

**Charging:** the firmware sets the BQ24296M to 704 mA (about 0.5C for the 1500 mAh cell) and turns off its
watchdog, which would otherwise restore the 2048 mA default. Charging stays off if that doesn't read back.
On USB the top strip shows Charging, Full or USB instead of a percent, because charge current lifts the
battery voltage. The Session tab shows the voltage.
With the slide switch off, the chip runs on its own defaults.

**Libraries:** LVGL 8.4.0 with the `lv_conf.h` from `../PeregrineScopeDisplay`, and TJpg_Decoder 1.1.0, as on the
Scope Display.

**Wi-Fi:** put your networks in a gitignored `Config.local.h`:

```
#define WRIST_EXTRA_WIFI \
    { "MyHomeWiFi", "homepassword123" }, \
    { "My iPhone", "hotspotpassword" },
```

## In the app

Mic Array tab > Fleet > **Add Node**, type **Scope Display**, address = the IP on the Session tab. The node
then shows as "Scope Display (wrist, no speaker)", spoken alerts skip it, and its settings offer bird cards.

`ScopeLink`, `ScopeBLE`, `ScopeStorage`, `JpegImage`, `ScopeState.h` and the protocol headers are copies of the Scope
Display's, with small edits. `TalkAudio.h` is a stub. Port protocol changes across by hand.
