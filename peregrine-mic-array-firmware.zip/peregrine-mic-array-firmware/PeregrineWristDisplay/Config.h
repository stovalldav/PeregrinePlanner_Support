// Config.h -- the Wrist Display node: a SAINTCON 2024 badge (ESP32-S3) as a small Scope Display.
// See SAINTCON_BADGES_PLAN.md §4 (repo root) and README.md here.
//
// Pins from compukidmike/Saintcon2024 (sdkconfig.defaults, schematic), confirmed on this badge
// 2026-10-30 by its boot log and a hardware test.
//
// Secrets: put your Wi-Fi networks in a gitignored Config.local.h as WRIST_EXTRA_WIFI.
#pragma once

#include <cstddef>
#include <cstdint>

#if __has_include("Config.local.h")
#include "Config.local.h"
#endif
#ifndef WRIST_EXTRA_WIFI
#define WRIST_EXTRA_WIFI
#endif

namespace Config {

// ---- Display: ST7789 on an 8-bit i80 bus ----
constexpr int kLcdData[8] = {39, 40, 41, 42, 44, 43, 2, 1};
constexpr int kLcdDC = 16;
constexpr int kLcdCS = 17;
constexpr int kLcdWR = 15;
constexpr int kLcdRST = 7;
constexpr int kBacklight = 6;
constexpr uint32_t kLcdPixelClockHz = 10000000;
constexpr int kScreenWidth = 320; // landscape, the way the stock firmware mounts it
constexpr int kScreenHeight = 240;
constexpr uint8_t kBacklightOn = 160;
constexpr uint32_t kAwakeMs = 15000;

// ---- Touch: GT911 on its own I2C bus ----
constexpr int kTouchSDA = 9;
constexpr int kTouchSCL = 3;
constexpr int kTouchINT = 11;
constexpr int kTouchRST = 12;
constexpr uint8_t kTouchAddress = 0x5D;

// ---- Peripheral I2C, behind a TCA9544A switch ----
constexpr int kI2CSDA = 38;
constexpr int kI2CSCL = 37;
constexpr uint8_t kSwitchAddress = 0x70;
constexpr uint8_t kSwitchEnable = 0x04;
constexpr uint8_t kAccelChannel = 2;
constexpr uint8_t kChargerChannel = 3;
constexpr uint8_t kAccelAddress = 0x4C;
constexpr uint8_t kChargerAddress = 0x6B;

// ---- Charger (BQ24296M) and battery (1500 mAh) ----
constexpr int kChargerPSEL = 48;
constexpr int kChargerOTG = 21;
constexpr int kChargerCE = 14;
// Fast-charge current register value: 512 mA + 3 x 64 mA = 704 mA, about 0.5C. The chip's default is
// 2048 mA (1.4C), too much for a small cell worn on the wrist.
constexpr uint8_t kChargeCurrentSteps = 3;
constexpr int kBatteryADC = 10; // 100k/100k divider -> millivolts x2
constexpr uint32_t kBatteryReadIntervalMs = 5000;

// ---- Photos copied from the app's inboxes, kept in flash ----
constexpr int kMaxPhotos = 12; // the app sends each at 48 KB or less

// ---- Raise to wake ----
constexpr uint32_t kAccelReadIntervalMs = 100;
constexpr float kFaceUpG = 0.7f;   // screen facing you
constexpr float kFaceAwayG = 0.5f; // must have been below this within kRaiseWindowMs
constexpr uint32_t kRaiseWindowMs = 1500;

// ---- Wi-Fi (client of the fleet network: a node's AP, a travel router, or a phone hotspot) ----
struct WiFiCredential {
    const char *ssid;
    const char *password;
};
constexpr const char *kWiFiSSID = "PeregrineMicArray";
constexpr const char *kWiFiPassword = "birding123";
constexpr WiFiCredential kWiFiCandidates[] = {
    WRIST_EXTRA_WIFI
    { kWiFiSSID, kWiFiPassword },
};
constexpr uint32_t kWiFiPerCandidateTimeoutMs = 8000;
constexpr uint32_t kWiFiRetryMs = 15000;

// ---- Fleet protocol ----
constexpr uint16_t kUDPPort = 3333;
constexpr uint32_t kFleetId = 0x00000000;
constexpr uint32_t kIdentityIntervalMs = 5000;
constexpr uint32_t kAppLinkTimeoutMs = 10000;

} // namespace Config
