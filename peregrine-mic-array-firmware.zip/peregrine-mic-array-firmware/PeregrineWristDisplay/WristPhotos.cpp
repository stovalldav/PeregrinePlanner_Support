#include "WristPhotos.h"
#include "Config.h"
#include "ScopeLink.h"
#include "ScopeStorage.h"
#include <LittleFS.h>

WristPhotos gPhotos;

static_assert(Config::kMaxPhotos <= 12, "WristPhotos::kCapacity");

namespace {
constexpr size_t kHeaderBytes = 2 + 1 + 1 + 2 + 2 + 4 + 4 + 1; // through the label's length byte
const char *const kIndexPath = "/photos/index.tsv";
uint16_t readU16(const uint8_t *p) { return p[0] | (p[1] << 8); }
uint32_t readU32(const uint8_t *p) { return p[0] | (p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
String photoPath(int i) { return "/photos/" + String(i) + ".jpg"; }
} // namespace

// index.tsv: one "bytes<TAB>capturedUnix<TAB>label" line per photo, in order, appended after each save.
void WristPhotos::begin() {
    if (!gStore.present()) return;
    if (!LittleFS.exists("/photos")) LittleFS.mkdir("/photos");
    File f = LittleFS.open(kIndexPath, FILE_READ);
    while (f && f.available() && count_ < kCapacity) {
        const String line = f.readStringUntil('\n');
        const int a = line.indexOf('\t'), b = line.indexOf('\t', a + 1);
        if (a <= 0 || b <= a) continue;
        WristPhoto &p = photos_[count_];
        p.len = line.substring(0, a).toInt();
        p.capturedUnix = line.substring(a + 1, b).toInt();
        strlcpy(p.label, line.substring(b + 1).c_str(), sizeof(p.label));
        if (!LittleFS.exists(photoPath(count_))) break; // the save was cut short
        bytes_ += p.len;
        count_++;
    }
    if (f) f.close();
    if (count_) strlcpy(status_, "Saved on the wrist", sizeof(status_));
    version_++;
    Serial.printf("[photos] %d saved, %u KB\n", count_, (unsigned)(bytes_ / 1024));
}

uint8_t *WristPhotos::loadJpeg(int i, size_t &len) const {
    if (i < 0 || i >= count_) return nullptr;
    File f = LittleFS.open(photoPath(i), FILE_READ);
    if (!f) return nullptr;
    len = f.size();
    uint8_t *buf = (uint8_t *)ps_malloc(len);
    if (buf && f.read(buf, len) != len) {
        free(buf);
        buf = nullptr;
    }
    f.close();
    return buf;
}

void WristPhotos::removeAll() {
    for (int i = 0; i < kCapacity; i++) LittleFS.remove(photoPath(i));
    LittleFS.remove(kIndexPath);
    for (int i = 0; i < count_; i++) photos_[i] = WristPhoto();
    count_ = 0;
    bytes_ = 0;
}

void WristPhotos::clear() {
    stopFetch();
    removeAll();
    strlcpy(status_, "Cleared. The phone keeps its photos", sizeof(status_));
    version_++;
}

void WristPhotos::startFetch() {
    clear();
    fetching_ = true;
    nextIndex_ = 0;
    total_ = 0;
    strlcpy(status_, "Asking the phone...", sizeof(status_));
    requestNext();
}

void WristPhotos::stopFetch() {
    if (!fetching_) return;
    gLink.cancelMap();
    finish("Stopped");
}

void WristPhotos::finish(const char *status) {
    fetching_ = false;
    strlcpy(status_, status, sizeof(status_));
    version_++;
}

void WristPhotos::requestNext() {
    if (gLink.requestPhoto((uint8_t)nextIndex_) == 0) finish("The phone isn't linked");
}

// False when this photo can't be kept: no more room, so the fetch is over.
bool WristPhotos::store(const uint8_t *payload, size_t len) {
    const uint8_t labelLen = payload[kHeaderBytes - 1];
    const uint32_t jpegLen = readU32(payload + 12);
    if (kHeaderBytes + labelLen + (size_t)jpegLen > len) return true; // malformed: skip it
    if (jpegLen == 0) return true;                                    // the phone couldn't read this one
    File f = LittleFS.open(photoPath(count_), FILE_WRITE);
    if (!f) return false;
    const size_t wrote = f.write(payload + kHeaderBytes + labelLen, jpegLen);
    f.close();
    if (wrote != jpegLen) {
        LittleFS.remove(photoPath(count_));
        return false;
    }
    WristPhoto &p = photos_[count_++];
    p.len = jpegLen;
    p.capturedUnix = readU32(payload + 8);
    const size_t copyLen = min((size_t)labelLen, sizeof(p.label) - 1);
    memcpy(p.label, payload + kHeaderBytes, copyLen);
    p.label[copyLen] = 0;
    bytes_ += jpegLen;
    File index = LittleFS.open(kIndexPath, FILE_APPEND);
    if (index) {
        index.printf("%u\t%lu\t%s\n", (unsigned)p.len, (unsigned long)p.capturedUnix, p.label);
        index.close();
    }
    return true;
}

void WristPhotos::poll() {
    if (!fetching_) return;
    String id;
    uint8_t style;
    bool prefetch;
    const uint8_t *payload;
    size_t len;
    if (!gLink.takeMap(id, style, prefetch, payload, len)) {
        if (!gLink.mapPending()) finish(count_ ? "The phone stopped answering" : "The phone didn't answer");
        return;
    }
    if (len < kHeaderBytes || payload[0] != 'P' || payload[1] != 'H' || payload[2] != 1) {
        finish("Unexpected reply from the phone");
        return;
    }
    total_ = readU16(payload + 4);
    if (total_ == 0) {
        finish("The phone's inboxes are empty");
        return;
    }
    const bool stored = store(payload, len);
    version_++;
    Serial.printf("[photos] %d held, %u KB\n", count_, (unsigned)(bytes_ / 1024));
    if (!stored) {
        finish("Couldn't save any more");
        return;
    }
    nextIndex_++;
    if (count_ >= Config::kMaxPhotos) finish("That's the most it holds");
    else if (nextIndex_ >= total_) finish("Done");
    else {
        snprintf(status_, sizeof(status_), "Copying %d of %d...", nextIndex_ + 1, min(total_, Config::kMaxPhotos));
        requestNext();
    }
}
