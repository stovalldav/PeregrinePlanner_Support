// TalkAudio.h -- the badge has no speaker or mic. It reports hasSpeaker = 0, so the app doesn't send
// speech; a stray packet is dropped here.
#pragma once

#include <cstdint>

class TalkAudio {
public:
    void queueSpeech(const int16_t *, int) {}
};

inline TalkAudio gTalk;
