// WristUI.h -- the wrist display's LVGL screens: Heard, Targets, Session, plus a text-only bird card and
// the camp alert takeover. Reads gState; runs on the main loop.
#pragma once

#include <Arduino.h>

class WristUI {
public:
    void begin();
    void update(uint32_t now);
    void benchCommand(char c);
};

extern WristUI gUI;
