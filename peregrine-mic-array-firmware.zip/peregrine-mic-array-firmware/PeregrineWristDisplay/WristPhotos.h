// WristPhotos.h -- copies of the app's newest inbox photos, kept in flash under /photos so you can look
// through them on the wrist, and still have them after the slide switch. One at a time over the map
// transfer (ScopeLink::requestPhoto), up to Config::kMaxPhotos. These are only copies: clearing them
// doesn't touch the phone.
#pragma once

#include <Arduino.h>

struct WristPhoto {
    size_t len = 0;
    uint32_t capturedUnix = 0;
    char label[64] = {0};
};

class WristPhotos {
public:
    // Finds what's already saved. Call after gStore.begin().
    void begin();
    // Replaces what's held with the phone's newest.
    void startFetch();
    void stopFetch();
    void clear();
    void poll();

    bool fetching() const { return fetching_; }
    int count() const { return count_; }
    const WristPhoto &at(int i) const { return photos_[i]; }
    // The photo's JPEG in a new PSRAM buffer the caller frees; null if it can't be read.
    uint8_t *loadJpeg(int i, size_t &len) const;
    size_t bytes() const { return bytes_; }
    const char *statusText() const { return status_; }
    // Bumped on every visible change.
    uint32_t version() const { return version_; }

private:
    void requestNext();
    void finish(const char *status);
    bool store(const uint8_t *payload, size_t len);
    void removeAll();

    static constexpr int kCapacity = 12;
    WristPhoto photos_[kCapacity];
    int count_ = 0;
    size_t bytes_ = 0;
    bool fetching_ = false;
    int nextIndex_ = 0;
    int total_ = 0;
    char status_[48] = "Tap Get to copy the newest";
    uint32_t version_ = 0;
};

extern WristPhotos gPhotos;
