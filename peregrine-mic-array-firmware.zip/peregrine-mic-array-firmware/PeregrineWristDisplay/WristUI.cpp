#include "WristUI.h"
#include "Config.h"
#include "JpegImage.h"
#include "ScopeLink.h"
#include "ScopeProtocol.h"
#include "ScopeState.h"
#include "ScopeStorage.h"
#include "WristHardware.h"
#include "WristPhotos.h"
#include <lvgl.h>
#include <time.h>

WristUI gUI;

namespace {

const lv_color_t kBg = lv_color_hex(0x0B0F14);
const lv_color_t kRow = lv_color_hex(0x18202A);
const lv_color_t kText = lv_color_hex(0xF1F5F9);
const lv_color_t kMuted = lv_color_hex(0x94A3B8);
const lv_color_t kAccent = lv_color_hex(0x38BDF8);
const lv_color_t kGood = lv_color_hex(0x4ADE80);
const lv_color_t kAlert = lv_color_hex(0xB91C1C);

constexpr int kStripHeight = 24;
constexpr int kTabHeight = 32;
constexpr uint32_t kConfirmMs = 3000;
constexpr int kMaxCardRows = 60;
enum BirdsView { kViewHeard = 0, kViewTargets, kViewTrip, kViewCards, kViewCount };

lv_obj_t *stripLink, *stripClock, *stripBattery;
lv_obj_t *clockTime, *clockDate, *handsFreeStatus;
lv_obj_t *birdsViews[kViewCount], *birdsSegments[kViewCount];
int birdsView = kViewHeard;
lv_obj_t *heardList;
lv_obj_t *targetsTitle, *targetsMovedLabel, *targetsList;
lv_obj_t *tripList;
lv_obj_t *cardsInfo, *cardsClearLabel, *cardsList;
lv_obj_t *filterOverlay, *filterSizes[ScopeStorage::kSizeClassCount], *filterColors[ScopeStorage::kColorCount];
lv_obj_t *searchOverlay, *searchField;
lv_obj_t *photosStatus, *photosGetLabel, *photosClearLabel;
lv_obj_t *photoOverlay, *photoImage, *photoCaption;
lv_obj_t *sessionTimer, *sessionCounts, *sessionRecent, *sessionLink;
lv_obj_t *pickerOverlay, *pickerList;
lv_obj_t *cardOverlay, *cardImage, *cardLabel;
lv_obj_t *alertOverlay, *alertLabel;

RGBImage photoPixels, cardPixels;
int photoIndex = 0;
uint32_t photosClearArmedMs = 0, cardsClearArmedMs = 0, movedArmedMs = 0; // each needs a second tap in kConfirmMs
uint32_t handsFreeShownMs = 0;

uint32_t shownDetections = 0xFFFFFFFF;
uint32_t shownTargetsHash = 0, shownTripHash = 0;
uint32_t shownPhotosVersion = 0xFFFFFFFF;
uint32_t shownIndexVersion = 0xFFFFFFFF, lastCardsRebuildMs = 0;
uint32_t shownPlansVersion = 0xFFFFFFFF;
uint32_t shownAlertMs = 0, alertStartMs = 0;
uint32_t lastSlowUpdateMs = 0;
uint16_t waitingCardId = 0;

String cardsQuery;
int cardsSizeClass = 0;
uint16_t cardsColorMask = 0;

// ---- Widgets ----

lv_obj_t *makeLabel(lv_obj_t *parent, const lv_font_t *font, lv_color_t color, const char *text) {
    lv_obj_t *l = lv_label_create(parent);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, color, 0);
    lv_label_set_text(l, text);
    return l;
}

void setFlat(lv_obj_t *o, lv_color_t bg) {
    lv_obj_set_style_bg_color(o, bg, 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(o, 0, 0);
    lv_obj_set_style_radius(o, 0, 0);
    lv_obj_set_style_shadow_width(o, 0, 0);
}

lv_obj_t *makeList(lv_obj_t *parent) {
    lv_obj_t *list = lv_obj_create(parent);
    setFlat(list, kBg);
    lv_obj_set_size(list, LV_PCT(100), LV_PCT(100));
    lv_obj_set_style_pad_all(list, 4, 0);
    lv_obj_set_style_pad_row(list, 4, 0);
    lv_obj_set_flex_flow(list, LV_FLEX_FLOW_COLUMN);
    return list;
}

lv_obj_t *makeRow(lv_obj_t *list, const char *text, lv_color_t color, const lv_font_t *font) {
    lv_obj_t *row = lv_btn_create(list);
    setFlat(row, kRow);
    lv_obj_set_style_radius(row, 6, 0);
    lv_obj_set_width(row, LV_PCT(100));
    lv_obj_set_height(row, LV_SIZE_CONTENT);
    lv_obj_set_style_pad_all(row, 8, 0);
    lv_obj_t *label = makeLabel(row, font, color, text);
    lv_obj_set_width(label, LV_PCT(100));
    lv_label_set_long_mode(label, LV_LABEL_LONG_WRAP);
    return row;
}

void addListNote(lv_obj_t *list, const char *text) {
    lv_obj_t *l = makeLabel(list, &lv_font_montserrat_14, kMuted, text);
    lv_obj_set_width(l, LV_PCT(100));
    lv_label_set_long_mode(l, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_pad_all(l, 8, 0);
}

lv_obj_t *makeOverlay(lv_color_t bg, lv_event_cb_t onTap) {
    lv_obj_t *o = lv_obj_create(lv_layer_top());
    setFlat(o, bg);
    lv_obj_set_size(o, Config::kScreenWidth, Config::kScreenHeight);
    lv_obj_set_style_pad_all(o, 10, 0);
    lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(o, LV_OBJ_FLAG_CLICKABLE);
    if (onTap) lv_obj_add_event_cb(o, onTap, LV_EVENT_SHORT_CLICKED, nullptr);
    return o;
}

lv_obj_t *makeButton(lv_obj_t *parent, const char *text, lv_event_cb_t onClick, lv_obj_t **labelOut = nullptr, void *user = nullptr) {
    lv_obj_t *b = lv_btn_create(parent);
    setFlat(b, kRow);
    lv_obj_set_style_radius(b, 6, 0);
    lv_obj_set_height(b, 44);
    lv_obj_set_style_pad_all(b, 4, 0);
    lv_obj_add_event_cb(b, onClick, LV_EVENT_CLICKED, user);
    lv_obj_t *l = makeLabel(b, &lv_font_montserrat_14, kAccent, text);
    lv_obj_center(l);
    if (labelOut) *labelOut = l;
    return b;
}

lv_obj_t *makeButtonRow(lv_obj_t *parent) {
    lv_obj_t *row = lv_obj_create(parent);
    setFlat(row, kBg);
    lv_obj_set_size(row, LV_PCT(100), LV_SIZE_CONTENT);
    lv_obj_set_style_pad_all(row, 0, 0);
    lv_obj_set_style_pad_column(row, 6, 0);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(row, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
    return row;
}

// ---- Bird cards ----

void closeCard() {
    lv_obj_add_flag(cardOverlay, LV_OBJ_FLAG_HIDDEN);
    waitingCardId = 0;
    lv_img_cache_invalidate_src(&cardPixels.dsc);
    lv_img_set_src(cardImage, nullptr);
    lv_obj_add_flag(cardImage, LV_OBJ_FLAG_HIDDEN);
    cardPixels.release(); // only needed while looking
}

void onCardTap(lv_event_t *) { closeCard(); }

void presentCard(const CardResult &card) {
    String text = card.text;
    text.replace("# ", "");
    lv_label_set_text(cardLabel, text.c_str());
    const bool hasPhoto = card.jpeg && card.jpegLen &&
        decodeJpeg(card.jpeg, card.jpegLen, jpegScaleToFit(card.jpeg, card.jpegLen, Config::kScreenWidth - 20, Config::kScreenHeight), cardPixels);
    if (hasPhoto) {
        lv_img_cache_invalidate_src(&cardPixels.dsc);
        lv_img_set_src(cardImage, &cardPixels.dsc);
        lv_obj_clear_flag(cardImage, LV_OBJ_FLAG_HIDDEN);
    }
    lv_obj_scroll_to_y(cardOverlay, 0, LV_ANIM_OFF);
}

// From flash if it's saved, or else from the phone (which also saves it).
void showCard(const String &common, const String &scientific) {
    lv_obj_clear_flag(cardOverlay, LV_OBJ_FLAG_HIDDEN);
    CardResult stored;
    if (gStore.loadCard(common, scientific, stored)) {
        waitingCardId = 0;
        gStore.noteName(common, scientific);
        presentCard(stored);
        return;
    }
    waitingCardId = gLink.requestCard(common, scientific);
    lv_label_set_text_fmt(cardLabel, "%s\n\n%s", common.c_str(), waitingCardId ? "Asking the phone for this card..." : "Not saved here, and the phone isn't linked.");
    lv_obj_scroll_to_y(cardOverlay, 0, LV_ANIM_OFF);
}

void updateCard() {
    CardResult card;
    if (!gLink.takeCard(card) || card.requestId != waitingCardId) return;
    presentCard(card);
    gHardware.wake(millis(), Config::kAwakeMs);
}

// ---- Heard ----

void onHeardRow(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i < gState.detectionCount) showCard(gState.detections[i].common, gState.detections[i].scientific);
}

void rebuildHeard() {
    const int32_t scrollY = lv_obj_get_scroll_y(heardList);
    lv_obj_clean(heardList);
    if (gState.detectionCount == 0) addListNote(heardList, "No birds heard yet");
    for (int i = 0; i < gState.detectionCount; i++) {
        const Detection &d = gState.detections[i];
        String text = d.common;
        if (d.newLifeBird) text += "  * LIFER";
        text += "\n";
        text += d.source == 1 ? String("Merlin") : String(d.confidencePct) + "%  " + d.nodeName;
        if (d.hits > 1) text += "  x" + String(d.hits);
        lv_obj_t *row = makeRow(heardList, text.c_str(), d.newLifeBird ? kGood : kText, &lv_font_montserrat_14);
        lv_obj_add_event_cb(row, onHeardRow, LV_EVENT_CLICKED, (void *)(intptr_t)i);
    }
    lv_obj_scroll_to_y(heardList, scrollY, LV_ANIM_OFF);
}

// ---- Targets ----

void onTargetRow(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    const TripTargetList &list = gState.tripTargets;
    if (i < list.count) gLink.sendTargetToggle(list.items[i].name, !(list.items[i].flags & Protocol::kTripTargetSeen));
}

// Long-press: count + 1, checked off if it wasn't. The app answers by voice.
void onTargetLong(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    const TripTargetList &list = gState.tripTargets;
    if (i < list.count) gLink.sendCountAdd(list.items[i].name, 1);
}

void onMoved(lv_event_t *) {
    const uint32_t now = millis();
    if (!movedArmedMs || now - movedArmedMs > kConfirmMs) {
        movedArmedMs = now;
        lv_label_set_text(targetsMovedLabel, "Sure?");
        return;
    }
    movedArmedMs = 0;
    lv_label_set_text(targetsMovedLabel, "I moved");
    gLink.sendNewLocation();
}

uint32_t hashTargets() {
    const TripTargetList &list = gState.tripTargets;
    uint32_t h = 2166136261u;
    auto mix = [&h](uint8_t b) { h = (h ^ b) * 16777619u; };
    for (int i = 0; i < list.count; i++) {
        mix(list.items[i].flags);
        for (size_t c = 0; c < list.items[i].name.length(); c++) mix(list.items[i].name[c]);
    }
    return h ^ list.count ^ (list.valid ? 0x80000000u : 0);
}

// The app resends the list every 5 s; rebuilding only on a real change keeps your scroll place and taps.
void rebuildTargets() {
    const TripTargetList &list = gState.tripTargets;
    const int32_t scrollY = lv_obj_get_scroll_y(targetsList);
    lv_obj_clean(targetsList);
    if (!list.valid || list.total == 0) addListNote(targetsList, "No trip being logged");
    for (int i = 0; i < list.count; i++) {
        const TripTarget &t = list.items[i];
        if (t.flags & Protocol::kTripTargetHeading) {
            lv_obj_t *l = makeLabel(targetsList, &lv_font_montserrat_12, (t.flags & Protocol::kTripTargetCurrentHeading) ? kAccent : kMuted, t.name.c_str());
            lv_obj_set_width(l, LV_PCT(100));
            continue;
        }
        const bool seen = t.flags & Protocol::kTripTargetSeen;
        String text = String(seen ? LV_SYMBOL_OK " " : "") + t.name;
        lv_obj_t *row = makeRow(targetsList, text.c_str(), seen ? kGood : kText, &lv_font_montserrat_16);
        lv_obj_add_event_cb(row, onTargetRow, LV_EVENT_SHORT_CLICKED, (void *)(intptr_t)i);
        lv_obj_add_event_cb(row, onTargetLong, LV_EVENT_LONG_PRESSED, (void *)(intptr_t)i);
    }
    lv_obj_scroll_to_y(targetsList, scrollY, LV_ANIM_OFF);
    if (list.valid && list.total > 0) lv_label_set_text_fmt(targetsTitle, "%s  %u/%u", list.stopName.isEmpty() ? list.tripName.c_str() : list.stopName.c_str(), list.seen, list.total);
    else lv_label_set_text(targetsTitle, "");
}

// ---- Trip ----

void onTripBird(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i < gState.tripHistory.count) showCard(gState.tripHistory.items[i].name, String());
}

uint32_t hashTrip() {
    const TripHistory &h = gState.tripHistory;
    uint32_t hash = 2166136261u;
    auto mix = [&hash](uint8_t b) { hash = (hash ^ b) * 16777619u; };
    for (int i = 0; i < h.count; i++) {
        mix(h.items[i].kind);
        mix(h.items[i].flags);
        for (size_t c = 0; c < h.items[i].name.length(); c++) mix(h.items[i].name[c]);
    }
    return hash ^ h.count ^ (h.valid ? 0x80000000u : 0);
}

void rebuildTrip() {
    const TripHistory &h = gState.tripHistory;
    const int32_t scrollY = lv_obj_get_scroll_y(tripList);
    lv_obj_clean(tripList);
    if (!h.valid || h.count == 0) addListNote(tripList, "Nothing seen on this trip yet");
    for (int i = 0; h.valid && i < h.count; i++) {
        const HistoryEntry &item = h.items[i];
        if (item.kind == 0) {
            const bool here = item.flags & 0x01;
            String title = item.name;
            if (here) title += "  - you are here";
            lv_obj_t *l = makeLabel(tripList, &lv_font_montserrat_14, here ? kAccent : kText, title.c_str());
            lv_obj_set_width(l, LV_PCT(100));
            lv_label_set_long_mode(l, LV_LABEL_LONG_WRAP);
            continue;
        }
        String text = item.name + "\n";
        text += (item.flags & 0x02) ? "seen" : "";
        if (item.flags & 0x01) text += (item.flags & 0x02) ? ", heard" : "heard";
        lv_obj_t *row = makeRow(tripList, text.c_str(), kText, &lv_font_montserrat_14);
        lv_obj_add_event_cb(row, onTripBird, LV_EVENT_CLICKED, (void *)(intptr_t)i);
    }
    lv_obj_scroll_to_y(tripList, scrollY, LV_ANIM_OFF);
}

// ---- Cards ----

void onCardsRow(lv_event_t *e) {
    const int i = (int)(intptr_t)lv_event_get_user_data(e);
    if (i < gStore.cardCount()) showCard(gStore.cardAt(i).common, gStore.cardAt(i).scientific);
}

void rebuildCards() {
    lastCardsRebuildMs = millis();
    shownIndexVersion = gStore.indexVersion();
    const int32_t scrollY = lv_obj_get_scroll_y(cardsList);
    lv_obj_clean(cardsList);
    static int matches[kMaxCardRows];
    const int total = gStore.searchCards(cardsQuery, cardsSizeClass, cardsColorMask, matches, kMaxCardRows);
    const bool narrowed = cardsQuery.length() || cardsSizeClass || cardsColorMask;
    if (gStore.cardCount() == 0) addListNote(cardsList, "No cards saved. In the app: this node's settings > Load bird cards for this area. Tapped cards are saved too.");
    else if (total == 0) addListNote(cardsList, "No saved cards match");
    for (int k = 0; k < min(total, kMaxCardRows); k++) {
        lv_obj_t *row = makeRow(cardsList, gStore.cardAt(matches[k]).common, kText, &lv_font_montserrat_14);
        lv_obj_add_event_cb(row, onCardsRow, LV_EVENT_CLICKED, (void *)(intptr_t)matches[k]);
    }
    if (total > kMaxCardRows) addListNote(cardsList, "More match: use Find or Filter to narrow it");
    lv_obj_scroll_to_y(cardsList, scrollY, LV_ANIM_OFF);
    if (narrowed) lv_label_set_text_fmt(cardsInfo, "%d of %d", total, gStore.cardCount());
    else lv_label_set_text_fmt(cardsInfo, "%d saved", gStore.cardCount());
}

void onClearCards(lv_event_t *) {
    const uint32_t now = millis();
    if (gStore.cardCount() == 0) return;
    if (!cardsClearArmedMs || now - cardsClearArmedMs > kConfirmMs) {
        cardsClearArmedMs = now;
        lv_label_set_text(cardsClearLabel, "Sure?");
        return;
    }
    cardsClearArmedMs = 0;
    lv_label_set_text(cardsClearLabel, "Clear");
    gStore.clearCards();
    rebuildCards();
}

void showFilterState() {
    for (int i = 0; i < ScopeStorage::kSizeClassCount; i++) lv_obj_set_style_bg_color(filterSizes[i], i == cardsSizeClass ? kAccent : kRow, 0);
    for (int i = 0; i < ScopeStorage::kColorCount; i++) lv_obj_set_style_bg_color(filterColors[i], (cardsColorMask >> i) & 1 ? kAccent : kRow, 0);
}

void onFilterSize(lv_event_t *e) {
    cardsSizeClass = (int)(intptr_t)lv_event_get_user_data(e);
    showFilterState();
}

void onFilterColor(lv_event_t *e) {
    cardsColorMask ^= 1 << (int)(intptr_t)lv_event_get_user_data(e);
    showFilterState();
}

void onFilterOpen(lv_event_t *) {
    showFilterState();
    lv_obj_clear_flag(filterOverlay, LV_OBJ_FLAG_HIDDEN);
}

void onFilterDone(lv_event_t *) {
    lv_obj_add_flag(filterOverlay, LV_OBJ_FLAG_HIDDEN);
    rebuildCards();
}

void onFilterReset(lv_event_t *) {
    cardsSizeClass = 0;
    cardsColorMask = 0;
    cardsQuery = "";
    lv_textarea_set_text(searchField, "");
    showFilterState();
}

void onSearchOpen(lv_event_t *) { lv_obj_clear_flag(searchOverlay, LV_OBJ_FLAG_HIDDEN); }

void onSearchKeyboard(lv_event_t *e) {
    const lv_event_code_t code = lv_event_get_code(e);
    if (code != LV_EVENT_READY && code != LV_EVENT_CANCEL) return;
    if (code == LV_EVENT_READY) cardsQuery = lv_textarea_get_text(searchField);
    lv_obj_add_flag(searchOverlay, LV_OBJ_FLAG_HIDDEN);
    rebuildCards();
}

void buildCardsView(lv_obj_t *view) {
    lv_obj_set_flex_flow(view, LV_FLEX_FLOW_COLUMN);
    lv_obj_t *row = makeButtonRow(view);
    lv_obj_set_style_pad_all(row, 3, 0);
    cardsInfo = makeLabel(row, &lv_font_montserrat_14, kAccent, "");
    lv_obj_set_flex_grow(cardsInfo, 1);
    for (lv_obj_t *b : {makeButton(row, "Find", onSearchOpen), makeButton(row, "Filter", onFilterOpen), makeButton(row, "Clear", onClearCards, &cardsClearLabel)}) {
        lv_obj_set_size(b, 58, 30);
    }
    cardsList = makeList(view);
    lv_obj_set_flex_grow(cardsList, 1);
    lv_obj_set_height(cardsList, 0);

    filterOverlay = makeOverlay(kBg, nullptr);
    lv_obj_set_flex_flow(filterOverlay, LV_FLEX_FLOW_ROW_WRAP);
    lv_obj_set_style_pad_all(filterOverlay, 6, 0);
    lv_obj_set_style_pad_gap(filterOverlay, 4, 0);
    for (int i = 0; i < ScopeStorage::kSizeClassCount; i++) {
        filterSizes[i] = makeButton(filterOverlay, ScopeStorage::sizeClassName(i), onFilterSize, nullptr, (void *)(intptr_t)i);
        lv_obj_set_size(filterSizes[i], LV_SIZE_CONTENT, 32);
        lv_obj_set_style_pad_hor(filterSizes[i], 8, 0);
    }
    for (int i = 0; i < ScopeStorage::kColorCount; i++) {
        filterColors[i] = makeButton(filterOverlay, ScopeStorage::colorName(i), onFilterColor, nullptr, (void *)(intptr_t)i);
        lv_obj_set_size(filterColors[i], LV_SIZE_CONTENT, 32);
        lv_obj_set_style_pad_hor(filterColors[i], 8, 0);
    }
    lv_obj_set_size(makeButton(filterOverlay, "Reset", onFilterReset), 96, 40);
    lv_obj_set_size(makeButton(filterOverlay, "Done", onFilterDone), 96, 40);

    searchOverlay = makeOverlay(kBg, nullptr);
    lv_obj_set_style_pad_all(searchOverlay, 2, 0);
    lv_obj_clear_flag(searchOverlay, LV_OBJ_FLAG_SCROLLABLE);
    searchField = lv_textarea_create(searchOverlay);
    lv_textarea_set_one_line(searchField, true);
    lv_textarea_set_placeholder_text(searchField, "Part of a bird's name");
    lv_obj_set_size(searchField, LV_PCT(100), 38);
    lv_obj_t *keyboard = lv_keyboard_create(searchOverlay);
    lv_obj_set_size(keyboard, LV_PCT(100), Config::kScreenHeight - 44);
    lv_obj_align(keyboard, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_keyboard_set_textarea(keyboard, searchField);
    lv_obj_add_event_cb(keyboard, onSearchKeyboard, LV_EVENT_ALL, nullptr);
}

// ---- Birds tab ----

void setBirdsView(int view) {
    birdsView = view;
    for (int i = 0; i < kViewCount; i++) {
        if (i == view) lv_obj_clear_flag(birdsViews[i], LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(birdsViews[i], LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_style_bg_color(birdsSegments[i], i == view ? kAccent : kRow, 0);
        lv_obj_set_style_text_color(lv_obj_get_child(birdsSegments[i], 0), i == view ? kBg : kAccent, 0);
    }
    if (view == kViewCards) rebuildCards();
}

void onBirdsSegment(lv_event_t *e) { setBirdsView((int)(intptr_t)lv_event_get_user_data(e)); }

void buildBirds(lv_obj_t *tab) {
    lv_obj_set_flex_flow(tab, LV_FLEX_FLOW_COLUMN);
    lv_obj_t *segments = makeButtonRow(tab);
    lv_obj_set_style_pad_all(segments, 3, 0);
    lv_obj_set_style_pad_column(segments, 3, 0);
    static const char *const kNames[kViewCount] = {"Heard", "Targets", "Trip", "Cards"};
    for (int i = 0; i < kViewCount; i++) {
        birdsSegments[i] = makeButton(segments, kNames[i], onBirdsSegment, nullptr, (void *)(intptr_t)i);
        lv_obj_set_height(birdsSegments[i], 26);
        lv_obj_set_flex_grow(birdsSegments[i], 1);
        birdsViews[i] = lv_obj_create(tab);
        setFlat(birdsViews[i], kBg);
        lv_obj_set_width(birdsViews[i], LV_PCT(100));
        lv_obj_set_flex_grow(birdsViews[i], 1);
        lv_obj_set_style_pad_all(birdsViews[i], 0, 0);
        lv_obj_clear_flag(birdsViews[i], LV_OBJ_FLAG_SCROLLABLE);
    }
    heardList = makeList(birdsViews[kViewHeard]);

    lv_obj_set_flex_flow(birdsViews[kViewTargets], LV_FLEX_FLOW_COLUMN);
    lv_obj_t *targetsHead = makeButtonRow(birdsViews[kViewTargets]);
    lv_obj_set_style_pad_all(targetsHead, 3, 0);
    targetsTitle = makeLabel(targetsHead, &lv_font_montserrat_14, kAccent, "");
    lv_label_set_long_mode(targetsTitle, LV_LABEL_LONG_DOT);
    lv_obj_set_flex_grow(targetsTitle, 1);
    lv_obj_set_size(makeButton(targetsHead, "I moved", onMoved, &targetsMovedLabel), 72, 30);
    targetsList = makeList(birdsViews[kViewTargets]);
    lv_obj_set_flex_grow(targetsList, 1);
    lv_obj_set_height(targetsList, 0);

    tripList = makeList(birdsViews[kViewTrip]);
    buildCardsView(birdsViews[kViewCards]);
    setBirdsView(kViewHeard);
}

// ---- Trip picker ----

void onStartTrip(lv_event_t *e) {
    gLink.sendStartTrip((const char *)lv_event_get_user_data(e));
    lv_obj_add_flag(pickerOverlay, LV_OBJ_FLAG_HIDDEN);
}

void onArrive(lv_event_t *e) {
    gLink.sendArriveAt((const char *)lv_event_get_user_data(e));
    lv_obj_add_flag(pickerOverlay, LV_OBJ_FLAG_HIDDEN);
}

void rebuildPicker() {
    shownPlansVersion = gState.plansVersion;
    lv_obj_clean(pickerList);
    if (gState.plans.count == 0) addListNote(pickerList, "No planned trips. Plan a trip with stops in the app; it shows up here while the phone is linked.");
    bool tripActive = false;
    for (int i = 0; i < gState.plans.count; i++) {
        const PlanEntry &e = gState.plans.items[i];
        lv_obj_t *row = makeButtonRow(pickerList);
        lv_obj_t *name = makeLabel(row, &lv_font_montserrat_14, e.kind == 0 ? kText : kMuted, e.name);
        lv_label_set_long_mode(name, LV_LABEL_LONG_WRAP);
        lv_obj_set_flex_grow(name, 1);
        if (e.kind == 0) {
            tripActive = e.flags & Protocol::kPlanTripActive;
            if (tripActive) makeLabel(row, &lv_font_montserrat_12, kAccent, "Logging");
            else lv_obj_set_size(makeButton(row, (e.flags & Protocol::kPlanTripStarted) ? "Log here" : "Start", onStartTrip, nullptr, (void *)e.id), 72, 34);
        } else if (tripActive && (e.flags & Protocol::kPlanStopCurrent)) {
            lv_obj_set_style_text_color(name, kAccent, 0);
            makeLabel(row, &lv_font_montserrat_12, kAccent, "Here");
        } else {
            lv_obj_set_size(makeButton(row, "I'm here", onArrive, nullptr, (void *)e.id), 72, 34);
        }
    }
}

void onPickerOpen(lv_event_t *) {
    rebuildPicker();
    lv_obj_clear_flag(pickerOverlay, LV_OBJ_FLAG_HIDDEN);
}

void onPickerClose(lv_event_t *) { lv_obj_add_flag(pickerOverlay, LV_OBJ_FLAG_HIDDEN); }

// ---- Session and status ----

void updateSession(uint32_t now) {
    const SessionInfo &s = gState.session;
    if (s.valid && s.active) {
        const uint32_t t = s.elapsedS + (now - s.updatedMs) / 1000;
        lv_label_set_text_fmt(sessionTimer, "%lu:%02lu:%02lu", (unsigned long)(t / 3600), (unsigned long)(t / 60 % 60), (unsigned long)(t % 60));
    } else {
        lv_label_set_text(sessionTimer, "No session");
    }
    if (s.valid) {
        lv_label_set_text_fmt(sessionCounts, "%u species   %u in 10 min   %u lifers", s.species, s.detections10min, s.newLifeBirds);
        String recent;
        for (int i = 0; i < s.recentCount; i++) recent += (i ? ", " : "") + s.recent[i];
        lv_label_set_text(sessionRecent, recent.c_str());
    }
    String link = gState.wifiConnected ? gState.ssid + "  " + gState.myIP.toString() : String("Looking for Wi-Fi");
    link += "\n" + String(gState.cardsStored) + " cards, " + String(gState.sdFreeMB) + " MB free";
    if (gState.cardsQueued) link += ", " + String(gState.cardsQueued) + " downloading";
    if (gStore.full()) link += "\nStorage full: Birds > Cards > Clear";
    if (gState.outboxPending) link += "\n" + String(gState.outboxPending) + " checks waiting for the phone";
    if (!gHardware.chargerReady()) link += "\nCharger setup failed: not charging";
    if (gHardware.chargerFault()) link += "\nCharger fault " + String(gHardware.chargerFault(), HEX);
    lv_label_set_text(sessionLink, link.c_str());
}

void updateStrip(uint32_t now) {
    const bool linked = gState.appLinked(now, Config::kAppLinkTimeoutMs);
    lv_label_set_text(stripLink, linked ? LV_SYMBOL_OK " Phone" : gState.wifiConnected ? LV_SYMBOL_WIFI " No phone" : LV_SYMBOL_CLOSE " No Wi-Fi");
    lv_obj_set_style_text_color(stripLink, linked ? kGood : kMuted, 0);
    const int pct = gHardware.batteryPercent();
    String battery = gHardware.charging() ? String(LV_SYMBOL_CHARGE " ") : String();
    battery += pct < 0 ? String("--") : String(pct) + "%";
    lv_label_set_text(stripBattery, battery.c_str());
}

// Merlin belongs to one device at a time: while a Scope Display is linked, it reads and clears them.
void updateMerlinRule() {
    bool scopeLinked = false;
    for (int i = 0; i < gState.fleetCount; i++) {
        const FleetNode &n = gState.fleet[i];
        // A speaker tells a real Scope Display from another wrist display: both report this type.
        if (n.nodeType == Protocol::kNodeTypeScopeDisplay && (n.flags & Protocol::kFleetConnected) && (n.flags & Protocol::kFleetHasSpeaker)) scopeLinked = true;
    }
    gState.ancsSuppressed = scopeLinked;
}

// ---- Clock ----

// Local time from the phone's offset, as the phone shows it. False until the phone has sent the time.
bool formatClock(uint32_t unixTime, char *timeOut, size_t timeLen, char *dateOut, size_t dateLen) {
    if (!gState.clockKnown || !unixTime) return false;
    const time_t local = (time_t)unixTime + gState.phoneUtcOffsetS;
    struct tm t;
    gmtime_r(&local, &t);
    if (gState.phoneClock24Hour) strftime(timeOut, timeLen, "%H:%M", &t);
    else {
        const int hour = t.tm_hour % 12 ? t.tm_hour % 12 : 12;
        snprintf(timeOut, timeLen, "%d:%02d %s", hour, t.tm_min, t.tm_hour < 12 ? "AM" : "PM");
    }
    char weekdayMonth[12];
    strftime(weekdayMonth, sizeof(weekdayMonth), "%a %b", &t); // newlib has no %-d
    snprintf(dateOut, dateLen, "%s %d", weekdayMonth, t.tm_mday);
    return true;
}

void updateClock() {
    char timeText[12], dateText[20];
    if (!formatClock(gState.unixNow(), timeText, sizeof(timeText), dateText, sizeof(dateText))) {
        lv_label_set_text(clockTime, "--:--");
        lv_label_set_text(clockDate, "Waiting for the phone");
        lv_label_set_text(stripClock, "");
        return;
    }
    lv_label_set_text(clockTime, timeText);
    lv_label_set_text(clockDate, dateText);
    lv_label_set_text(stripClock, timeText);
}

// Mark / Saw it / Undo: resent until the app acks, as on the Scope Display.
void onHandsFree(lv_event_t *e) {
    if (!gLink.hasApp()) {
        lv_label_set_text(handsFreeStatus, "No phone");
    } else {
        gLink.sendButton((uint8_t)(intptr_t)lv_event_get_user_data(e));
        lv_label_set_text(handsFreeStatus, "Sending...");
    }
    handsFreeShownMs = millis();
}

void updateHandsFree(uint32_t now) {
    const ScopeLink::ButtonState s = gLink.takeButtonState();
    if (s == ScopeLink::ButtonState::Acked || s == ScopeLink::ButtonState::NoReply) {
        lv_label_set_text(handsFreeStatus, s == ScopeLink::ButtonState::Acked ? "Got it" : "No reply");
        handsFreeShownMs = now;
    } else if (handsFreeShownMs && s == ScopeLink::ButtonState::Idle && now - handsFreeShownMs > 3000) {
        lv_label_set_text(handsFreeStatus, "");
        handsFreeShownMs = 0;
    }
}

// ---- Photos ----

void showPhoto(int index) {
    if (gPhotos.count() == 0) return;
    photoIndex = (index + gPhotos.count()) % gPhotos.count();
    const WristPhoto &p = gPhotos.at(photoIndex);
    size_t len = 0;
    uint8_t *jpeg = gPhotos.loadJpeg(photoIndex, len);
    if (jpeg && decodeJpeg(jpeg, len, jpegScaleToFit(jpeg, len, Config::kScreenWidth, Config::kScreenHeight), photoPixels)) {
        lv_img_cache_invalidate_src(&photoPixels.dsc);
        lv_img_set_src(photoImage, &photoPixels.dsc);
        lv_obj_center(photoImage);
        lv_obj_clear_flag(photoImage, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_add_flag(photoImage, LV_OBJ_FLAG_HIDDEN);
    }
    free(jpeg);
    char timeText[12] = "", dateText[20] = "";
    formatClock(p.capturedUnix, timeText, sizeof(timeText), dateText, sizeof(dateText));
    lv_label_set_text_fmt(photoCaption, "%d/%d  %s\n%s %s", photoIndex + 1, gPhotos.count(), p.label, dateText, timeText);
    lv_obj_clear_flag(photoOverlay, LV_OBJ_FLAG_HIDDEN);
}

void closePhotoViewer() {
    if (lv_obj_has_flag(photoOverlay, LV_OBJ_FLAG_HIDDEN)) return;
    lv_obj_add_flag(photoOverlay, LV_OBJ_FLAG_HIDDEN);
    lv_img_cache_invalidate_src(&photoPixels.dsc);
    lv_img_set_src(photoImage, nullptr);
    photoPixels.release(); // 150 KB of PSRAM, only needed while looking
}

void onPhotoTap(lv_event_t *) { closePhotoViewer(); }

void onPhotoSwipe(lv_event_t *) {
    const lv_dir_t dir = lv_indev_get_gesture_dir(lv_indev_get_act());
    if (dir == LV_DIR_LEFT) showPhoto(photoIndex + 1);
    else if (dir == LV_DIR_RIGHT) showPhoto(photoIndex - 1);
}

void onGetPhotos(lv_event_t *) {
    closePhotoViewer();
    if (gPhotos.fetching()) gPhotos.stopFetch();
    else gPhotos.startFetch();
}

void onViewPhotos(lv_event_t *) { showPhoto(0); }

void onClearPhotos(lv_event_t *) {
    const uint32_t now = millis();
    if (gPhotos.count() == 0 && !gPhotos.fetching()) return;
    if (!photosClearArmedMs || now - photosClearArmedMs > kConfirmMs) {
        photosClearArmedMs = now;
        return;
    }
    photosClearArmedMs = 0;
    closePhotoViewer();
    gPhotos.clear();
}

void updatePhotos(uint32_t now) {
    if (photosClearArmedMs && now - photosClearArmedMs > kConfirmMs) photosClearArmedMs = 0;
    lv_label_set_text(photosGetLabel, gPhotos.fetching() ? "Stop" : "Get");
    lv_label_set_text(photosClearLabel, photosClearArmedMs ? "Sure?" : "Clear");
    lv_label_set_text_fmt(photosStatus, "%d of %d photos on the wrist\n%u KB used\n%s", gPhotos.count(), Config::kMaxPhotos,
                          (unsigned)(gPhotos.bytes() / 1024), gPhotos.statusText());
}

// ---- Camp alert ----

void onAlertTap(lv_event_t *) {
    lv_obj_add_flag(alertOverlay, LV_OBJ_FLAG_HIDDEN);
    gHardware.setAlertPulse(false);
    alertStartMs = 0;
}

void updateAlert(uint32_t now) {
    int newest = -1;
    uint32_t newestMs = shownAlertMs;
    for (int i = 0; i < gState.fleetCount; i++) {
        const uint32_t t = gState.fleet[i].presence.lastAlertMs;
        if (t && (int32_t)(t - newestMs) > 0) {
            newestMs = t;
            newest = i;
        }
    }
    if (newest >= 0) {
        shownAlertMs = newestMs;
        const PresenceInfo &p = gState.fleet[newest].presence;
        lv_label_set_text_fmt(alertLabel, "CAMP ALERT\n\n%s\n%.1f m\n\nTap to dismiss", gState.fleet[newest].name.c_str(), p.distanceCm / 100.0f);
        lv_obj_clear_flag(alertOverlay, LV_OBJ_FLAG_HIDDEN);
        gHardware.setAlertPulse(true);
        alertStartMs = now;
        Serial.printf("[alert] %s\n", gState.fleet[newest].name.c_str());
    }
    if (alertStartMs && now - alertStartMs > 60000) gHardware.setAlertPulse(false); // the screen stays until dismissed
}

} // namespace

void WristUI::begin() {
    lv_obj_t *screen = lv_scr_act();
    setFlat(screen, kBg);
    lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *strip = lv_obj_create(screen);
    setFlat(strip, kBg);
    lv_obj_set_size(strip, Config::kScreenWidth, kStripHeight);
    lv_obj_set_style_pad_hor(strip, 8, 0);
    lv_obj_set_style_pad_ver(strip, 0, 0);
    lv_obj_clear_flag(strip, LV_OBJ_FLAG_SCROLLABLE);
    stripLink = makeLabel(strip, &lv_font_montserrat_14, kMuted, "");
    lv_obj_align(stripLink, LV_ALIGN_LEFT_MID, 0, 0);
    stripClock = makeLabel(strip, &lv_font_montserrat_14, kText, "");
    lv_obj_align(stripClock, LV_ALIGN_CENTER, 0, 0);
    stripBattery = makeLabel(strip, &lv_font_montserrat_14, kText, "");
    lv_obj_align(stripBattery, LV_ALIGN_RIGHT_MID, 0, 0);

    lv_obj_t *tabs = lv_tabview_create(screen, LV_DIR_BOTTOM, kTabHeight);
    lv_obj_set_size(tabs, Config::kScreenWidth, Config::kScreenHeight - kStripHeight);
    lv_obj_set_y(tabs, kStripHeight);
    lv_obj_set_style_bg_color(tabs, kBg, 0);
    // Swiping would move between tabs instead of working the lists and photos.
    lv_obj_clear_flag(lv_tabview_get_content(tabs), LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *buttons = lv_tabview_get_tab_btns(tabs);
    lv_obj_set_style_bg_color(buttons, kRow, 0);
    lv_obj_set_style_text_color(buttons, kMuted, 0);
    lv_obj_set_style_text_font(buttons, &lv_font_montserrat_14, 0);
    lv_obj_set_style_text_color(buttons, kAccent, LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_bg_color(buttons, kRow, LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_border_color(buttons, kAccent, LV_PART_ITEMS | LV_STATE_CHECKED);

    lv_obj_t *tabClock = lv_tabview_add_tab(tabs, "Clock");
    lv_obj_t *tabBirds = lv_tabview_add_tab(tabs, "Birds");
    lv_obj_t *tabPhotos = lv_tabview_add_tab(tabs, "Photos");
    lv_obj_t *tabSession = lv_tabview_add_tab(tabs, "Session");
    for (lv_obj_t *t : {tabClock, tabBirds, tabPhotos, tabSession}) {
        lv_obj_set_style_pad_all(t, 0, 0);
        lv_obj_clear_flag(t, LV_OBJ_FLAG_SCROLLABLE);
    }

    clockTime = makeLabel(tabClock, &lv_font_montserrat_48, kText, "--:--");
    lv_obj_align(clockTime, LV_ALIGN_TOP_MID, 0, 8);
    clockDate = makeLabel(tabClock, &lv_font_montserrat_20, kMuted, "");
    lv_obj_align(clockDate, LV_ALIGN_TOP_MID, 0, 66);
    handsFreeStatus = makeLabel(tabClock, &lv_font_montserrat_14, kGood, "");
    lv_obj_align(handsFreeStatus, LV_ALIGN_TOP_MID, 0, 96);
    lv_obj_t *handsFree = makeButtonRow(tabClock);
    lv_obj_set_style_pad_all(handsFree, 6, 0);
    lv_obj_align(handsFree, LV_ALIGN_BOTTOM_MID, 0, 0);
    static const struct { const char *name; uint8_t command; } kHandsFree[] = {
        {LV_SYMBOL_GPS " Mark", Protocol::kCmdMark}, {LV_SYMBOL_OK " Saw it", Protocol::kCmdConfirmLast}, {LV_SYMBOL_LOOP " Undo", Protocol::kCmdUndoLast}};
    for (const auto &spec : kHandsFree) lv_obj_set_flex_grow(makeButton(handsFree, spec.name, onHandsFree, nullptr, (void *)(intptr_t)spec.command), 1);

    buildBirds(tabBirds);

    lv_obj_set_flex_flow(tabPhotos, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(tabPhotos, 10, 0);
    lv_obj_set_style_pad_row(tabPhotos, 10, 0);
    photosStatus = makeLabel(tabPhotos, &lv_font_montserrat_14, kText, "");
    lv_obj_set_width(photosStatus, LV_PCT(100));
    lv_label_set_long_mode(photosStatus, LV_LABEL_LONG_WRAP);
    lv_obj_set_flex_grow(photosStatus, 1);
    lv_obj_t *photoButtons = makeButtonRow(tabPhotos);
    lv_obj_set_flex_grow(makeButton(photoButtons, "Get", onGetPhotos, &photosGetLabel), 1);
    lv_obj_set_flex_grow(makeButton(photoButtons, "View", onViewPhotos), 1);
    lv_obj_set_flex_grow(makeButton(photoButtons, "Clear", onClearPhotos, &photosClearLabel), 1);

    lv_obj_set_flex_flow(tabSession, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(tabSession, 8, 0);
    lv_obj_set_style_pad_row(tabSession, 4, 0);
    lv_obj_add_flag(tabSession, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *sessionHead = makeButtonRow(tabSession);
    sessionTimer = makeLabel(sessionHead, &lv_font_montserrat_24, kText, "No session");
    lv_obj_set_flex_grow(sessionTimer, 1);
    lv_obj_set_size(makeButton(sessionHead, "Trips", onPickerOpen), 72, 34);
    sessionCounts = makeLabel(tabSession, &lv_font_montserrat_14, kAccent, "");
    sessionRecent = makeLabel(tabSession, &lv_font_montserrat_14, kText, "");
    lv_obj_set_width(sessionRecent, LV_PCT(100));
    lv_label_set_long_mode(sessionRecent, LV_LABEL_LONG_WRAP);
    sessionLink = makeLabel(tabSession, &lv_font_montserrat_12, kMuted, "");
    lv_obj_set_width(sessionLink, LV_PCT(100));
    lv_label_set_long_mode(sessionLink, LV_LABEL_LONG_WRAP);

    pickerOverlay = makeOverlay(kBg, nullptr);
    lv_obj_set_flex_flow(pickerOverlay, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(pickerOverlay, 4, 0);
    lv_obj_clear_flag(pickerOverlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *pickerHead = makeButtonRow(pickerOverlay);
    lv_obj_set_flex_grow(makeLabel(pickerHead, &lv_font_montserrat_16, kText, "Trips"), 1);
    lv_obj_set_size(makeButton(pickerHead, "Close", onPickerClose), 72, 34);
    pickerList = makeList(pickerOverlay);
    lv_obj_set_flex_grow(pickerList, 1);
    lv_obj_set_height(pickerList, 0);

    cardOverlay = makeOverlay(kBg, onCardTap);
    lv_obj_set_flex_flow(cardOverlay, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(cardOverlay, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_START);
    lv_obj_set_style_pad_row(cardOverlay, 8, 0);
    cardImage = lv_img_create(cardOverlay);
    lv_obj_add_flag(cardImage, LV_OBJ_FLAG_HIDDEN);
    cardLabel = makeLabel(cardOverlay, &lv_font_montserrat_14, kText, "");
    lv_obj_set_width(cardLabel, LV_PCT(100));
    lv_label_set_long_mode(cardLabel, LV_LABEL_LONG_WRAP);

    photoOverlay = makeOverlay(lv_color_black(), onPhotoTap);
    lv_obj_set_style_pad_all(photoOverlay, 0, 0);
    lv_obj_clear_flag(photoOverlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(photoOverlay, onPhotoSwipe, LV_EVENT_GESTURE, nullptr);
    photoImage = lv_img_create(photoOverlay);
    photoCaption = makeLabel(photoOverlay, &lv_font_montserrat_12, lv_color_white(), "");
    lv_obj_set_width(photoCaption, LV_PCT(100));
    lv_label_set_long_mode(photoCaption, LV_LABEL_LONG_DOT);
    lv_obj_set_style_bg_color(photoCaption, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(photoCaption, LV_OPA_60, 0);
    lv_obj_set_style_pad_all(photoCaption, 3, 0);
    lv_obj_align(photoCaption, LV_ALIGN_BOTTOM_LEFT, 0, 0);

    alertOverlay = makeOverlay(kAlert, onAlertTap);
    alertLabel = makeLabel(alertOverlay, &lv_font_montserrat_24, lv_color_white(), "");
    lv_obj_set_style_text_align(alertLabel, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_width(alertLabel, LV_PCT(100));
    lv_obj_center(alertLabel);
}

// Over USB: g get photos, v view the first, n next, c close, x clear them, t print the time,
// k print storage, K clear cards, o open the first saved card.
void WristUI::benchCommand(char c) {
    char timeText[12] = "", dateText[20] = "";
    switch (c) {
        case 'g': gPhotos.startFetch(); break;
        case 'v': showPhoto(0); break;
        case 'n': showPhoto(photoIndex + 1); break;
        case 'c': closePhotoViewer(); closeCard(); break;
        case 'x': closePhotoViewer(); gPhotos.clear(); break;
        case 'K': gStore.clearCards(); rebuildCards(); break;
        case 'o':
            if (gStore.cardCount()) showCard(gStore.cardAt(0).common, gStore.cardAt(0).scientific);
            Serial.printf("[card] opened; photo %dx%d\n", cardPixels.width, cardPixels.height);
            break;
        case 't':
            formatClock(gState.unixNow(), timeText, sizeof(timeText), dateText, sizeof(dateText));
            Serial.printf("[clock] known=%d %s | %s\n", gState.clockKnown, timeText, dateText);
            break;
        case 'k':
            Serial.printf("[state] targets valid=%d count=%d | history valid=%d count=%d | plans valid=%d count=%d\n", gState.tripTargets.valid, gState.tripTargets.count, gState.tripHistory.valid,
                          gState.tripHistory.count, gState.plans.valid, gState.plans.count);
            Serial.printf("[store] %u cards, index %d, %d queued, %u failed, %lu MB free, full=%d, heap %u, PSRAM %u KB free\n", gState.cardsStored, gStore.cardCount(), (int)gState.cardsQueued,
                          gState.cardsFailed, (unsigned long)gState.sdFreeMB, gStore.full(), ESP.getFreeHeap(), (unsigned)(ESP.getFreePsram() / 1024));
            break;
        default: return;
    }
    Serial.printf("[photos] %d held, %u KB, status: %s, viewing %d, image %dx%d\n", gPhotos.count(), (unsigned)(gPhotos.bytes() / 1024), gPhotos.statusText(),
                  lv_obj_has_flag(photoOverlay, LV_OBJ_FLAG_HIDDEN) ? -1 : photoIndex + 1, photoPixels.width, photoPixels.height);
}

void WristUI::update(uint32_t now) {
    if (gState.detectionsVersion != shownDetections) {
        // A new lifer is worth lighting the screen for; ordinary birds wait for you to look.
        if (gState.detectionCount > 0 && gState.detections[0].newLifeBird && shownDetections != 0xFFFFFFFF) gHardware.wake(now, Config::kAwakeMs);
        shownDetections = gState.detectionsVersion;
        rebuildHeard();
    }
    const uint32_t targetsHash = hashTargets();
    if (targetsHash != shownTargetsHash) {
        shownTargetsHash = targetsHash;
        rebuildTargets();
    }
    const uint32_t tripHash = hashTrip();
    if (tripHash != shownTripHash) {
        shownTripHash = tripHash;
        rebuildTrip();
    }
    if (birdsView == kViewCards && gStore.indexVersion() != shownIndexVersion && now - lastCardsRebuildMs > 3000) rebuildCards();
    if (gState.plansVersion != shownPlansVersion && !lv_obj_has_flag(pickerOverlay, LV_OBJ_FLAG_HIDDEN)) rebuildPicker();
    updateAlert(now);
    updateCard();
    updateHandsFree(now);
    if (movedArmedMs && now - movedArmedMs > kConfirmMs) {
        movedArmedMs = 0;
        lv_label_set_text(targetsMovedLabel, "I moved");
    }
    if (cardsClearArmedMs && now - cardsClearArmedMs > kConfirmMs) {
        cardsClearArmedMs = 0;
        lv_label_set_text(cardsClearLabel, "Clear");
    }
    if (now - lastSlowUpdateMs >= 1000) {
        lastSlowUpdateMs = now;
        updateStrip(now);
        updateSession(now);
        updateMerlinRule();
        updateClock();
    }
    if (gPhotos.version() != shownPhotosVersion || photosClearArmedMs) {
        shownPhotosVersion = gPhotos.version();
        updatePhotos(now);
    }
    lv_timer_handler();
}
