// WristHardware.h -- the badge's screen, touch, backlight, charger and accelerometer. All of it runs on
// the main loop; only the display's DMA-done callback is an interrupt.
#pragma once

#include <Arduino.h>

class WristHardware {
public:
    // Charger first: it decides whether the battery charges at a safe current.
    void begin();
    // Battery, charger status and raise-to-wake. Call every loop().
    void poll(uint32_t now);

    // Lights the screen for at least `ms` (never shortens a longer wake).
    void wake(uint32_t now, uint32_t ms);
    bool awake() const { return awake_; }
    // Slow pulse for a camp alert, until the next call with false.
    void setAlertPulse(bool on) { alertPulse_ = on; }

    int batteryPercent() const { return batteryPercent_; }
    float batteryVolts() const { return batteryVolts_; }
    bool charging() const { return chargeState_ == 1 || chargeState_ == 2; }
    bool chargeDone() const { return chargeState_ == 3; }
    bool usbLimited() const { return usbLimited_; } // the USB source can't supply all the charger asks for
    bool usbPower() const { return powerGood_; }
    bool chargerReady() const { return chargerReady_; }
    uint8_t chargerFault() const { return chargerFault_; }

    bool touchPoint(int &x, int &y); // called by LVGL's input driver

private:
    void beginCharger();
    void beginDisplay();
    void beginTouch();
    void beginAccel();
    void pollBattery(uint32_t now);
    void pollCharger();
    void pollRaise(uint32_t now);
    void updateBacklight(uint32_t now);
    bool selectChannel(uint8_t channel);
    bool readRegs(uint8_t addr, uint8_t reg, uint8_t *out, size_t len);
    bool writeReg(uint8_t addr, uint8_t reg, uint8_t value);

    uint32_t wakeUntilMs_ = 0;
    bool awake_ = false;
    bool alertPulse_ = false;
    int lastBrightness_ = -1;

    int batteryPercent_ = -1;
    float batteryVolts_ = 0;
    uint8_t chargeState_ = 0; // 0 not charging, 1 pre-charge, 2 fast charge, 3 done
    bool usbLimited_ = false;
    bool powerGood_ = false;
    bool wasOnUsb_ = false;
    bool chargerReady_ = false;
    uint8_t chargerFault_ = 0;
    uint32_t lastBatteryMs_ = 0;

    bool accelReady_ = false;
    uint32_t lastAccelMs_ = 0;
    uint32_t lastFaceAwayMs_ = 0;
    bool faceUp_ = false;
};

extern WristHardware gHardware;
