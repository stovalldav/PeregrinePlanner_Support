#include "WristHardware.h"
#include "Config.h"
#include <Wire.h>
#include <driver/gpio.h>
#include <esp_heap_caps.h>
#include <esp_lcd_panel_io.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_vendor.h>
#include <lvgl.h>

WristHardware gHardware;

namespace {

// BQ24296M registers
constexpr uint8_t kRegPowerOn = 0x01;      // bit5 OTG, bit4 charge enable
constexpr uint8_t kRegChargeCurrent = 0x02; // bits 7:2 = (mA - 512) / 64
constexpr uint8_t kRegTermTimer = 0x05;    // bits 5:4 watchdog (00 = off)
constexpr uint8_t kRegStatus = 0x08;       // bits 5:4 charge state, bit2 power good
constexpr uint8_t kRegFault = 0x09;

constexpr int kDrawLines = 40;
esp_lcd_panel_handle_t panel = nullptr;
lv_disp_draw_buf_t drawBuf;
lv_disp_drv_t dispDrv;
lv_indev_drv_t indevDrv;
bool touchHeldSinceWake = false;

bool IRAM_ATTR onColorDone(esp_lcd_panel_io_handle_t, esp_lcd_panel_io_event_data_t *, void *) {
    lv_disp_flush_ready(&dispDrv);
    return false;
}

void flush(lv_disp_drv_t *, const lv_area_t *a, lv_color_t *px) {
    esp_lcd_panel_draw_bitmap(panel, a->x1, a->y1, a->x2 + 1, a->y2 + 1, px);
}

void readTouch(lv_indev_drv_t *, lv_indev_data_t *data) {
    int x, y;
    if (!gHardware.touchPoint(x, y)) {
        touchHeldSinceWake = false;
        data->state = LV_INDEV_STATE_REL;
        return;
    }
    const uint32_t now = millis();
    // The first touch on a dark screen only lights it, so a blind tap can't check off a bird.
    if (!gHardware.awake()) touchHeldSinceWake = true;
    gHardware.wake(now, Config::kAwakeMs);
    if (touchHeldSinceWake) {
        data->state = LV_INDEV_STATE_REL;
        return;
    }
    data->point.x = x;
    data->point.y = y;
    data->state = LV_INDEV_STATE_PR;
}

// Single-cell LiPo, resting voltage -> rough percent. Only meaningful off USB: charge current lifts the
// voltage by about 12 points, so a re-plug would look like a jump.
int percentFromVolts(float v) {
    if (v < 2.5f) return -1;
    static const float curve[][2] = {{4.20f, 100}, {4.05f, 85}, {3.95f, 70}, {3.85f, 55}, {3.78f, 40}, {3.72f, 25}, {3.65f, 12}, {3.50f, 3}, {3.30f, 0}};
    if (v >= curve[0][0]) return 100;
    for (size_t i = 1; i < sizeof(curve) / sizeof(curve[0]); i++) {
        if (v >= curve[i][0]) {
            const float t = (v - curve[i][0]) / (curve[i - 1][0] - curve[i][0]);
            return (int)roundf(curve[i][1] + t * (curve[i - 1][1] - curve[i][1]));
        }
    }
    return 0;
}

} // namespace

bool WristHardware::selectChannel(uint8_t channel) {
    Wire.beginTransmission(Config::kSwitchAddress);
    Wire.write(Config::kSwitchEnable | channel);
    return Wire.endTransmission() == 0;
}

bool WristHardware::readRegs(uint8_t addr, uint8_t reg, uint8_t *out, size_t len) {
    Wire.beginTransmission(addr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom(addr, (uint8_t)len) != len) return false;
    for (size_t i = 0; i < len; i++) out[i] = Wire.read();
    return true;
}

bool WristHardware::writeReg(uint8_t addr, uint8_t reg, uint8_t value) {
    Wire.beginTransmission(addr);
    Wire.write(reg);
    Wire.write(value);
    return Wire.endTransmission() == 0;
}

// Charging stays off unless the lower current reads back. The watchdog goes off so the chip can't drop
// back to its 2048 mA default on its own; a power cycle still resets it, and this runs again at boot.
void WristHardware::beginCharger() {
    pinMode(Config::kChargerPSEL, OUTPUT);
    digitalWrite(Config::kChargerPSEL, LOW);
    pinMode(Config::kChargerOTG, OUTPUT);
    digitalWrite(Config::kChargerOTG, HIGH);
    pinMode(Config::kChargerCE, OUTPUT);
    digitalWrite(Config::kChargerCE, HIGH);

    uint8_t power = 0, current = 0, timer = 0;
    bool ok = selectChannel(Config::kChargerChannel) && readRegs(Config::kChargerAddress, kRegPowerOn, &power, 1) &&
              readRegs(Config::kChargerAddress, kRegChargeCurrent, &current, 1) && readRegs(Config::kChargerAddress, kRegTermTimer, &timer, 1);
    if (ok) {
        const uint8_t wantCurrent = (Config::kChargeCurrentSteps << 2) | (current & 0x03);
        const uint8_t wantTimer = timer & ~0x30;
        ok = writeReg(Config::kChargerAddress, kRegChargeCurrent, wantCurrent) && writeReg(Config::kChargerAddress, kRegTermTimer, wantTimer);
        uint8_t readCurrent = 0, readTimer = 0;
        ok = ok && readRegs(Config::kChargerAddress, kRegChargeCurrent, &readCurrent, 1) && readRegs(Config::kChargerAddress, kRegTermTimer, &readTimer, 1) &&
             readCurrent == wantCurrent && readTimer == wantTimer;
    }
    if (ok) ok = writeReg(Config::kChargerAddress, kRegPowerOn, (power | 0x10) & ~0xE0); // charge on, OTG off, no reset bits
    if (ok) digitalWrite(Config::kChargerCE, LOW);
    chargerReady_ = ok;
    Serial.printf("[charger] %s\n", ok ? "charging allowed at 704 mA" : "setup FAILED -- charging stays off");
}

void WristHardware::beginDisplay() {
    ledcAttach(Config::kBacklight, 5000, 8);
    ledcWrite(Config::kBacklight, 0);

    esp_lcd_i80_bus_config_t bus = {};
    bus.clk_src = LCD_CLK_SRC_DEFAULT;
    bus.dc_gpio_num = Config::kLcdDC;
    bus.wr_gpio_num = Config::kLcdWR;
    for (int i = 0; i < 8; i++) bus.data_gpio_nums[i] = Config::kLcdData[i];
    bus.bus_width = 8;
    bus.max_transfer_bytes = Config::kScreenWidth * kDrawLines * sizeof(uint16_t);
    bus.dma_burst_size = 64;
    esp_lcd_i80_bus_handle_t busHandle = nullptr;
    ESP_ERROR_CHECK(esp_lcd_new_i80_bus(&bus, &busHandle));

    esp_lcd_panel_io_i80_config_t io = {};
    io.cs_gpio_num = Config::kLcdCS;
    io.pclk_hz = Config::kLcdPixelClockHz;
    io.trans_queue_depth = 10;
    io.dc_levels.dc_data_level = 1;
    io.flags.swap_color_bytes = 1; // 8-bit bus; lv_conf.h leaves LV_COLOR_16_SWAP off
    io.on_color_trans_done = onColorDone;
    io.lcd_cmd_bits = 8;
    io.lcd_param_bits = 8;
    esp_lcd_panel_io_handle_t ioHandle = nullptr;
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_i80(busHandle, &io, &ioHandle));

    esp_lcd_panel_dev_config_t dev = {};
    dev.reset_gpio_num = Config::kLcdRST;
    dev.rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB;
    dev.bits_per_pixel = 16;
    ESP_ERROR_CHECK(esp_lcd_new_panel_st7789(ioHandle, &dev, &panel));
    esp_lcd_panel_reset(panel);
    esp_lcd_panel_init(panel);
    esp_lcd_panel_invert_color(panel, true);
    esp_lcd_panel_swap_xy(panel, true);    // the stock firmware's landscape-flip
    esp_lcd_panel_mirror(panel, true, false);
    esp_lcd_panel_disp_on_off(panel, true);

    lv_init();
    const size_t bytes = Config::kScreenWidth * kDrawLines * sizeof(lv_color_t);
    lv_color_t *buf = (lv_color_t *)heap_caps_malloc(bytes, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
    lv_disp_draw_buf_init(&drawBuf, buf, nullptr, Config::kScreenWidth * kDrawLines);
    lv_disp_drv_init(&dispDrv);
    dispDrv.hor_res = Config::kScreenWidth;
    dispDrv.ver_res = Config::kScreenHeight;
    dispDrv.flush_cb = flush;
    dispDrv.draw_buf = &drawBuf;
    lv_disp_drv_register(&dispDrv);

    lv_indev_drv_init(&indevDrv);
    indevDrv.type = LV_INDEV_TYPE_POINTER;
    indevDrv.read_cb = readTouch;
    lv_indev_drv_register(&indevDrv);
}

void WristHardware::beginTouch() {
    pinMode(Config::kTouchRST, OUTPUT);
    digitalWrite(Config::kTouchRST, HIGH);
    pinMode(Config::kTouchINT, INPUT);
    Wire1.begin(Config::kTouchSDA, Config::kTouchSCL, 400000);
}

bool WristHardware::touchPoint(int &x, int &y) {
    Wire1.beginTransmission(Config::kTouchAddress);
    Wire1.write(0x81);
    Wire1.write(0x4E);
    if (Wire1.endTransmission(false) != 0) return false;
    if (Wire1.requestFrom(Config::kTouchAddress, (uint8_t)6) != 6) return false;
    const uint8_t status = Wire1.read();
    Wire1.read(); // first point's track id
    const uint16_t rawX = Wire1.read() | (Wire1.read() << 8);
    const uint16_t rawY = Wire1.read() | (Wire1.read() << 8);
    static bool lastDown = false;
    if (!(status & 0x80)) return lastDown; // no new report: the last state holds
    Wire1.beginTransmission(Config::kTouchAddress);
    Wire1.write(0x81);
    Wire1.write(0x4E);
    Wire1.write(0);
    Wire1.endTransmission();
    lastDown = (status & 0x0F) > 0;
    if (lastDown) {
        static int lastX = 0, lastY = 0;
        lastX = constrain((int)rawY, 0, Config::kScreenWidth - 1); // portrait panel, landscape-flip
        lastY = constrain(Config::kScreenHeight - (int)rawX, 0, Config::kScreenHeight - 1);
        x = lastX;
        y = lastY;
    }
    return lastDown;
}

void WristHardware::beginAccel() {
    if (!selectChannel(Config::kAccelChannel)) return;
    uint8_t id = 0;
    accelReady_ = readRegs(Config::kAccelAddress, 0x18, &id, 1) && id == 0xA4;
    if (accelReady_) {
        writeReg(Config::kAccelAddress, 0x07, 0x03); // standby
        delay(5);
        writeReg(Config::kAccelAddress, 0x08, 0x10); // 25 Hz, plenty for a raised wrist
        writeReg(Config::kAccelAddress, 0x07, 0x01); // wake
    }
    Serial.printf("[accel] %s\n", accelReady_ ? "ready" : "NOT FOUND -- raise to wake is off");
}

void WristHardware::begin() {
    Wire.begin(Config::kI2CSDA, Config::kI2CSCL, 100000);
    analogReadResolution(12);
    beginCharger();
    beginAccel();
    beginTouch();
    beginDisplay();
    wake(millis(), Config::kAwakeMs);
}

void WristHardware::wake(uint32_t now, uint32_t ms) {
    const uint32_t until = now + ms;
    if (!awake_ || (int32_t)(until - wakeUntilMs_) > 0) wakeUntilMs_ = until;
    awake_ = true;
}

void WristHardware::pollBattery(uint32_t now) {
    if (lastBatteryMs_ && now - lastBatteryMs_ < Config::kBatteryReadIntervalMs) return;
    lastBatteryMs_ = now;
    pollCharger();
    uint32_t mv = 0;
    for (int i = 0; i < 8; i++) mv += analogReadMilliVolts(Config::kBatteryADC);
    batteryVolts_ = (mv / 8.0f) * 2.0f / 1000.0f * Config::kBatteryCalibration;
    const int pct = percentFromVolts(batteryVolts_);
    // Wi-Fi bursts and the backlight pull the voltage around, so on battery it only rises on a real change.
    if (!powerGood_ && (wasOnUsb_ || batteryPercent_ < 0 || pct < batteryPercent_ || pct >= batteryPercent_ + 3)) batteryPercent_ = pct;
    wasOnUsb_ = powerGood_;
}

void WristHardware::pollCharger() {
    uint8_t status = 0, fault = 0;
    if (!selectChannel(Config::kChargerChannel) || !readRegs(Config::kChargerAddress, kRegStatus, &status, 1)) return;
    readRegs(Config::kChargerAddress, kRegFault, &fault, 1); // first read returns the latched fault
    readRegs(Config::kChargerAddress, kRegFault, &fault, 1); // second, what's still wrong
    const uint8_t state = (status >> 4) & 0x03;
    static uint8_t lastStatus = 0xFF;
    if (status != lastStatus) {
        static const char *const kStates[] = {"not charging", "pre-charge", "fast charge", "done"};
        Serial.printf("[charger] %s, power %s (0x%02X)\n", kStates[state], (status & 0x04) ? "good" : "absent", status);
        lastStatus = status;
    }
    chargeState_ = state;
    usbLimited_ = status & 0x08;
    powerGood_ = status & 0x04;
    if (fault != chargerFault_) Serial.printf("[charger] fault 0x%02X\n", fault);
    chargerFault_ = fault;
}

// Raise to wake, by polling: the screen turned to face you (z up) soon after it wasn't. Any-motion alone
// would keep the backlight on all the time you walk.
void WristHardware::pollRaise(uint32_t now) {
    if (!accelReady_ || now - lastAccelMs_ < Config::kAccelReadIntervalMs) return;
    lastAccelMs_ = now;
    uint8_t d[6];
    if (!selectChannel(Config::kAccelChannel) || !readRegs(Config::kAccelAddress, 0x0D, d, 6)) return;
    const float z = (int16_t)(d[4] | d[5] << 8) / 16384.0f;
    if (z < Config::kFaceAwayG) {
        lastFaceAwayMs_ = now;
        faceUp_ = false;
    } else if (z > Config::kFaceUpG && !faceUp_) {
        faceUp_ = true;
        if (lastFaceAwayMs_ && now - lastFaceAwayMs_ < Config::kRaiseWindowMs) wake(now, Config::kAwakeMs);
    }
}

void WristHardware::updateBacklight(uint32_t now) {
    if (alertPulse_) wake(now, 1000);
    if (awake_ && (int32_t)(now - wakeUntilMs_) >= 0) awake_ = false;
    int level = awake_ ? Config::kBacklightOn : 0;
    if (alertPulse_) level = 60 + (int)(195 * (0.5f + 0.5f * sinf(now * 2.0f * PI / 2000.0f)));
    if (level == lastBrightness_) return;
    lastBrightness_ = level;
    ledcWrite(Config::kBacklight, level);
}

void WristHardware::poll(uint32_t now) {
    pollBattery(now);
    pollRaise(now);
    updateBacklight(now);
}
