# Peregrine Mic Array Cam Firmware

A 4x INMP441 mic array (identical DOA capability to `../PeregrineMicArray/`) plus an OV3660 camera
and ATGM336H GPS module, on a FORIOT ESP32-S3-CAM board. See `CAMERA_NODE_NETWORK_SPEC.md` (repo
root) for the full network architecture and pin-budget derivation, and
`MIC_ARRAY_MULTI_UNIT_PLAN.md` for the multi-node app design this plugs into.

**Status: first real physical build, as of 2026-08-10.** Confirmed working on real hardware: both
mic buses (top bus needed a wiring fix — see git history, not a firmware bug), WiFi AP hosting
(Primary role), GPS fix + position reporting, GPS PPS signal arriving, SD card mount, video
recording (frames + WAV land on the SD card), and the live MJPEG preview (connects and streams,
though currently sluggish — open perf question, not yet root-caused). **Still unconfirmed**:
whether manual/onset-triggered still-photo capture is actually working (button felt unresponsive
in the app during testing — undiagnosed whether that's app-side feedback, the firmware's capture
rate limit, or a real capture bug). Per this project's own hardware-debugging rule — real-device
evidence only, no guessing ahead of data — treat anything not explicitly listed as confirmed above
as still unverified.

## What's the same as the sibling firmware, and what's new

The I2S capture, onset gate, and DOA cross-correlation pipeline
(`I2SCapture.*`, `OnsetDetector.*`, `DOAEstimator.*`, `RingBuffer.h`) are copied verbatim from
`../PeregrineMicArray/` — this node's mic array is electrically identical, just on different pins
(see below). Don't hand-edit these here without also updating the sibling copy, same convention as
`NetworkProtocol.h`.

New in this firmware: camera capture (triggered by the same onset gate that triggers a DOA
capture, rate-limited — see `Config::kPhotoMinIntervalMs`), GPS position reporting, periodic node
identity announcement, a configurable network role (`Config::kNetworkRole` — either hosts its own
AP as a fleet's Primary, matching the sibling firmware's own fixed-AP pattern, or joins a network
as a station; see `MIC_ARRAY_MASTER_AP_PLAN.md`), and a tiny HTTP server (`PhotoServer`) the phone
pulls captured photos from.

## Wiring

### I2S mic pins — REMAPPED from the sibling firmware

| Signal | GPIO | Note |
|---|---|---|
| Bus 0 (TL/TR) WS | 14 | |
| Bus 0 (TL/TR) BCLK | 21 | |
| Bus 0 (TL/TR) SD (DIN) | 47 | |
| Bus 1 (BL/BR) WS | 1 | unchanged from sibling firmware |
| Bus 1 (BL/BR) BCLK | 2 | unchanged from sibling firmware |
| Bus 1 (BL/BR) SD (DIN) | 42 | unchanged from sibling firmware |

Bus 0 is remapped because this board's camera claims GPIO4/5/6 for SIOD/SIOC/VSYNC — a confirmed
direct collision with the sibling firmware's original bus-0 pins. Confirmed against the real
board's pinout diagram (not guessed) that GPIO14/21/47 are free.

### 2-mic single-bus variant — `Config::kMicCount = 2`

`CAMERA_NODE_NETWORK_SPEC.md`'s "alternative" config: leave Bus 0 (GPIO14/21/47 above) entirely
unwired and only build Bus 1 (GPIO1/2/42). Frees those 3 pins for something else later (e.g. a
compass over I2C) at the cost of dropping to one mic pair's own left-right bearing instead of two
averaged together.

**Must set `Config::kMicCount = 2` (not just skip the wiring) when doing this.** `kMicCount`
drives `kTopBusEnabled`, which gates bus-0 init, its capture task, and which `DOAEstimator` entry
point runs — leaving `kMicCount = 4` while Bus 0 is physically unwired doesn't just waste those
pins, it corrupts every azimuth/confidence reading with floating-pin noise averaged in from a bus
that isn't actually receiving mic data. With `kMicCount = 2` set correctly, onset detection, DOA,
and the mono audio stream (UDP + video's audio track) all run off Bus 1 alone instead — no other
config changes needed, this one constant is the single source of truth.

**Not yet validated on real hardware** — written and compile-checked
(`arduino-cli compile` clean for both `kMicCount = 4` and `kMicCount = 2`) but not flashed to a
physical 2-mic board yet. Per this project's real-device-evidence rule, treat as a starting point
to verify once that board exists, not a confirmed-working config.

### GPS (ATGM336H) — optional per node, see `Config::kGPSEnabled`

Not every node needs a GPS module installed (e.g. it hasn't arrived yet, or this node is
deliberately built without one) — `Config::kGPSEnabled` (default `false`) gates the entire
feature: UART init, position reporting, and the `NodeIdentityPacket.hasGPS` claim all key off it.
Only wire the module and flip it to `true` once it's actually installed.

| GPS pin | ESP32 GPIO |
|---|---|
| PPS(GPS -> ESP32) | 19 |
| TX (GPS -> ESP32) | 20 |
| RX (ESP32 -> GPS) | 41 |
| VCC | 3.3-5V (module has its own regulator) |
| GND | GND |

**Real-hardware finding, 2026-08-10: do NOT wire GPS's TX to GPIO44**, even though it's normally
this board's debug-console RX (`U0RXD`) and looks free whenever `Serial0` doesn't need it. GPIO44
is also the exact net esptool's stub flasher uses during upload over the dedicated UART/programming
USB-C port — wiring anything else to it (GPS's TX output included) causes real contention that
broke firmware flashing outright on the first physical build, not just a "console can't receive"
tradeoff as originally assumed. GPS's RX line now lands on GPIO20 instead (one of the board's two
native-USB pins, same tradeoff class as `kPPSPin`/GPIO19 below) — `Serial0` stays fully
bidirectional on GPIO43/44 regardless of `kGPSEnabled`.

**If `kGPSEnabled` is true**: GPIO20 is claimed for GPS RX, GPIO41 for GPS TX (ESP32 -> GPS). JTAG
is fully unusable (GPIO41/42 are claimed by GPS TX and bus 1's SD pin respectively) — expected and
accepted, same tradeoff class as the sibling firmware's own SD-pin choice.

**If `kGPSEnabled` is false** (the default): none of the above applies — don't wire the GPS pins
at all.

### Compass (BNO055) — optional, 2-mic variant only, `COMPASS_HEADING_HARDWARE_PLAN.md`

Gives this node a live, automatic heading independent of GPS — **not a GPS replacement** (no
position, no disciplined UTC clock for TDOA; GPS above still does those jobs). `Config::kCompassEnabled`
(default `false`) gates it entirely.

**Only wireable when `Config::kMicCount = 2`** (the single-bus variant above). A 4-mic build has
exactly ONE genuinely free GPIO (48) once camera + both mic buses + GPS + PPS + SD are all
accounted for — not enough for I2C's two wires. A `static_assert` in `Config.h` rejects
`kCompassEnabled = true` with `kMicCount = 4` at compile time rather than letting that combination
silently miswire. This corrects a real error in the original planning doc, which assumed
GPIO22/23/24/25 were free on this board's camera range — those GPIOs don't exist on the ESP32-S3
chip at all (a chip-level numbering gap, not a board-specific omission), so that "free" pin
suggestion was never actually possible.

| Signal | GPIO | Note |
|---|---|---|
| SDA | GPIO14 | Bus 0's WS pin — only free when `kMicCount = 2` leaves Bus 0 unwired. |
| SCL | GPIO47 | Bus 0's SD (DIN) pin — same. |
| VCC | 3.3V | |
| GND | GND | |

GPIO21 (Bus 0's BCLK) is deliberately left out of this pairing: it and GPIO48 carry the optional
C4002 presence sensor's UART (`Config::kPresenceSensorEnabled` — replaced the old optional PIR
2026-09-26; wiring in `HOME_ASSISTANT.md`), so the compass and the C4002 can both be enabled on the
same 2-mic node. With both, a 2-mic node has **no spare GPIO left**.

With a C4002 fitted, its detection range and hold time ("Clear after") are set from the app and
saved on the node, the node ignores anything beyond the range itself, and it sends the live
distance / speed / approaching-or-away readout — same as the camping-security node (see that
firmware's README, "Detection range, hold time, and the live movement readout").

Requires the **Adafruit BNO055** and **Adafruit Unified Sensor** libraries
(`arduino-cli lib install "Adafruit BNO055"` pulls both). The BNO055 does its own on-chip sensor
fusion and hands back a finished `[0, 360)` heading (clockwise from magnetic north, no declination
correction) — see `CompassReader.h`'s header comment for the calibration gesture it needs after
power-up and other real, honest caveats (magnetic interference, drift after being bumped).
**Firmware + wire protocol only, as of 2026-09-19** — the app already decodes and stores this in
`NodeTelemetry.heading`, but its "Compass (Automatic)" Heading Source option still doesn't consume
it yet (a real, separate app-side gap — see `COMPASS_HEADING_HARDWARE_PLAN.md`).

### Camera (OV3660)

`CameraPins.h` uses the common pin convention published for this class of ESP32-S3 OV2640/OV3660
clone board. **Implicitly confirmed correct as of the 2026-08-10 real-hardware bring-up** — video
recording produces real JPEG frames on the SD card, so the camera is genuinely capturing through
these pins, not just initializing. Still open: whether manual/onset-triggered *still*-photo capture
specifically works end-to-end (unconfirmed — see the Status note above), though that's a capture-
trigger question, not a pin-mapping one.

### Reserved — do not use for anything else

GPIO26-37 (octal PSRAM), GPIO38-40 (onboard SD), GPIO0/3/45/46 (strapping pins).

GPIO19/20 (the board's native-USB/OTG pins) are no longer in this reserved-and-unused list — both
are now claimed on a GPS-equipped node: GPIO19 for PPS (`Config::kPPSPin`), GPIO20 for GPS RX
(`Config::kGPSRXPin`). Real tradeoff, confirmed on hardware: using either means giving up that
second USB port's function entirely (same physical net). If `kGPSEnabled`/`kPPSEnabled` are both
false, they're free for other use; don't put anything on GPIO44 regardless (see the GPS section
above — that pin is the flashing port's own RX line, not free real estate).

## Arduino IDE / arduino-cli setup

Board: **ESP32S3 Dev Module** (`esp32:esp32:esp32s3`). Required options, confirmed by a real
compile against this repo's code:
- **Flash Size**: 16MB
- **PSRAM**: OPI PSRAM (this board's N16R8 module has octal PSRAM — plain "QSPI PSRAM" is for a
  different PSRAM chip type and will misbehave)

Libraries: `TinyGPSPlus` (install via Library Manager or `arduino-cli lib install TinyGPSPlus`).
`esp_camera.h`/`WebServer`/`WiFi` ship with the esp32 core, no separate install needed.

### Compile verification

This exact sketch was compile-checked (not just written by pattern-matching) against a real
toolchain during development:

```
arduino-cli compile --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi" .
```

Result: builds clean. Sketch ~1.0MB (76% of 1.3MB app partition), ~76KB static RAM (23% of
320KB). This confirms the code is syntactically correct and every API call (I2S, camera, WiFi,
WebServer, TinyGPSPlus) matches this project's actual installed core version — it does **not**
confirm correct pin assignments, timing, or that the camera/GPS/mic hardware actually works
together on real silicon. That part still needs the real board.

## First-time setup once the board arrives

1. Wire per the tables above. **Verify `CameraPins.h` against your board's actual pinout first** —
   see the caveat above.
2. Edit `Config.h`: set `kNetworkRole` for this physical node (`kRolePrimary` to host this fleet's
   own AP, `kRoleClient` to join one — see that constant's comment and
   `MIC_ARRAY_MASTER_AP_PLAN.md`), `kWiFiSSID`/`kWiFiPassword` to either what this node should
   broadcast (Primary) or what network to join (Client — your fleet's own Primary, or a genuinely
   external network the phone is also on), `kGPSEnabled` to whether this node actually has a GPS
   module installed and wired (leave `false` if it hasn't arrived yet), `kMicCount` to match what
   you actually wired (`4` = both buses, the default; `2` = the single-bus variant above — **must
   match the real wiring, not just your preference**, see that section's warning), and
   `kMicSpacingMeters` to your array's actual measured edge length (same calibration step as the
   sibling firmware).
3. Flash, open the Serial Monitor at 115200 baud over the board's dedicated UART/programming
   USB-C port (not the OTG port).
4. Confirm the boot checkpoints all succeed (camera, both I2S buses, GPS UART if `kGPSEnabled`,
   WiFi up). The boot log prints this node's IP once WiFi is up (its own AP's gateway if Primary,
   its assigned station IP if Client) — enter that into the app's node "Network Address" field
   (`MicArrayNodesView.swift`) for this node.
5. If `kGPSEnabled`, confirm `[gps] fix: yes` appears in the periodic status log (may take a
   couple minutes outdoors for first fix — GPS modules need a clear sky view, expect
   degraded/no fix under heavy canopy). Skipped entirely (no `[gps]` log line at all) when
   `kGPSEnabled` is false.
6. From the app, connect to this node and confirm DOA telemetry (and GPS position, if
   `kGPSEnabled`), and (once a bird call triggers an onset) a photo notification, all arrive.

## Network protocol

Shares `NetworkProtocol.h` with `../PeregrineMicArray/` and `../PeregrineMicArrayRearSensor/` —
kept byte-identical across all three copies since Arduino sketches can't share headers across
folders. This node additionally sends `kNodeIdentity`, `kGPSPosition`, and `kPhotoReady` (all
additive — existing single-front-array/single-rear-sensor deployments never see these). Photo bytes
themselves never travel over UDP — `kPhotoReady` just notifies the phone it can now
`GET http://<this-node's-ip>/photo/<photoId>`.

## Known limitations (by design, not oversights)

- Same left-right-only azimuth constraint as the sibling firmware (two independent, unsynchronized
  I2S buses) — see its README for why.
- One photo buffer at a time (`Config::kCameraFrameBufferCount = 1`) — a new capture overwrites
  whatever hasn't been fetched yet. Rate-limited to one capture per
  `Config::kPhotoMinIntervalMs` (default 5s) so a burst of onsets doesn't thrash this.
- GPS position is reported periodically (`Config::kGPSReportIntervalMs`), not per-DOA-event — a
  stationary node's position doesn't need per-event freshness.
- No compass on a 4-mic build — the confirmed pin budget (see `CAMERA_NODE_NETWORK_SPEC.md`) only
  fits 4-mic + GPS once the camera's pins are accounted for, with exactly one free GPIO left. The
  2-mic variant (`Config::kMicCount = 2`) frees enough pins for the BNO055 compass above.
  `NodeIdentityPacket.hasCompass` reflects `Config::kCompassEnabled` (0 on a 4-mic build, since the
  `static_assert` above rejects enabling it there). `hasMotionSensor` is always 0 now (the PIR is
  gone); the optional C4002 is reported via `hasPresenceSensor` (2, with bit 0x80 while it's silent),
  and `hasSpeaker` is always 0 on this hardware.
