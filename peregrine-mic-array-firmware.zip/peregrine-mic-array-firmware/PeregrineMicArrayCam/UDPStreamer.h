// UDPStreamer.h — WiFi STA (not SoftAP) + the UDP control/data socket, for camera/GPS nodes that
// join an existing network the phone is already on, rather than hosting their own AP the way the
// front array/rear sensor do. See Config.h's WiFi STA section and
// CAMERA_NODE_NETWORK_SPEC.md's "leave existing hardware on AP mode, add STA support only for new
// nodes" decision.
//
// Everything downstream of `begin()` — the registered-client tracking, control-packet handling,
// audio/DOA sends — is unchanged from ../PeregrineMicArray/UDPStreamer.h: the phone still actively
// connects TO this device's IP:port and sends kHandshakePing/kSessionStart, exactly like the AP
// case, just at a DHCP-assigned address (read off the Serial0 boot log and entered manually into
// the phone app's "Network Address" field for this node) instead of the AP's fixed 192.168.4.1.
#pragma once

#include <cstdint>
#include <WiFiUdp.h>
#include "NetworkProtocol.h"
#include "NodeRoster.h"
#include "Config.h"

class UDPStreamer {
public:
    // Joins Config::kWiFiSSID and starts the UDP socket. Blocks (with a timeout — see
    // Config::kWiFiConnectTimeoutMs) until connected; returns false on timeout so the caller can
    // decide whether to retry/reboot rather than silently running with no network.
    bool begin();

    void poll();

    // Call every loop() iteration alongside poll() -- only meaningful when Config::kNetworkRole ==
    // kRoleSecondary, a no-op otherwise. See MIC_ARRAY_MASTER_AP_PLAN.md §4's failover state
    // machine, implemented here 2026-08-14.
    void pollFailover();

    // Call every loop() iteration alongside poll() -- only meaningful when Config::kNetworkRole ==
    // kRoleClient, a no-op otherwise. See WIFI_MULTI_SSID_FALLBACK_PLAN.md's Phase 2 (added
    // 2026-08-16): re-attempts the Config::kWiFiCandidates join loop if the STA link has been down
    // for Config::kWiFiReconnectGraceMs, covering runtime drops that begin()'s one-time join can't.
    void pollReconnect();

    // True if this node is CURRENTLY acting as the fleet's AP host -- always true for
    // kRolePrimary, true for kRoleSecondary only while failed-over, false otherwise. Drives
    // roster-mastering/announce-gating decisions that used to be a compile-time
    // `Config::kNetworkRole == kRolePrimary` check (see MIC_ARRAY_MASTER_AP_PLAN.md §5: "kIsMasterNode's
    // aggregation logic... needs to become driven by 'is this node currently hosting the AP'...
    // instead of a fixed compile-time flag").
    bool isCurrentlyHosting() const;

    // Added 2026-08-16 -- broader than isCurrentlyHosting(): true whenever this node should act as
    // the fleet's roster master, whether that's because it's hosting the AP OR because
    // Config::kIsRosterMaster was set true on it for an all-kRoleClient shared-external-network
    // deployment (see that constant's own doc comment in Config.h for the full rationale). The two
    // roster-related call sites (kNodeAnnounce acceptance, self-announce skip) use this instead of
    // the bare isCurrentlyHosting() now; every other use of "am I hosting" stays on that original
    // method unchanged. Defined in the .cpp, not inline here, matching isCurrentlyHosting()'s own
    // existing style (mirrors ../PeregrineMicArray/UDPStreamer.h's identical method, even though
    // this header happens to already #include "Config.h" unlike that one).
    bool isActingAsRosterMaster() const;

    bool isStreaming() const { return streaming_; }

    void sendAudioFrame(uint32_t seq, const int16_t *samples, int count);
    // 4-mic nodes only (Config::kTopBusEnabled) -- interleaves left/right into one
    // kStereoAudioFrame packet, mutually exclusive with sendAudioFrame (a node sends one or the
    // other, never both -- see .ino's loop()). `countPerChannel` matches
    // Config::kStereoAudioSamplesPerChannel.
    void sendStereoAudioFrame(uint32_t seq, const int16_t *left, const int16_t *right, int countPerChannel);
    // 4-mic nodes only -- see NetworkProtocol.h's AudioLevelsPacket for the real-hardware finding
    // this exists for. usingBottomPair mirrors the .ino's own usingBottomPairForStream state.
    void sendAudioLevels(uint32_t timestampMs, int16_t topLeftPeak, int16_t topRightPeak, int16_t bottomLeftPeak, int16_t bottomRightPeak, bool usingBottomPair);
    void sendDOATelemetry(uint32_t seq, uint32_t timestampMs, float azimuthDeg, float confidence, float relativeLevel, uint8_t bandId);
    // GPS-PPS-disciplined onset timestamp for multi-node TDOA (MULTI_NODE_TDOA_PLAN.md). Caller
    // only invokes this once its PPSReader clock is anchored; utcSecond/utcMicros come from
    // PPSReader::utcForLocalMicros().
    void sendTimedOnset(uint32_t seq, uint32_t utcSecond, uint32_t utcMicros, uint16_t bandId, float peakLevel, float confidence);

    // New for this node type — see NetworkProtocol.h's "Multi-node network additions."
    void sendNodeIdentity();
    // Diagnostic params (satellitesInView through ppsLastIntervalMicros) added 2026-08-14, for
    // in-field GPS troubleshooting -- straight passthrough of GPSReader's/PPSReader's own counters.
    void sendGPSPosition(
        uint32_t timestampMs, double latitude, double longitude, float horizontalAccuracyMeters, bool hasFix,
        uint8_t satellitesInView, uint32_t charsProcessed, uint32_t sentencesValid, uint32_t sentencesInvalid,
        uint32_t ppsEdgeCount, uint32_t ppsLastIntervalMicros
    );
    void sendPhotoReady(uint32_t timestampMs, uint32_t photoId, uint32_t photoSizeBytes);
    // kMotionTrigger -- rising edge of a PIR / occupancy sensor (Config::kMotionSensorEnabled).
    // No-op unless a phone client is registered (same as every other send here); the photo the
    // trigger also captures still lands on the SD store regardless.
    void sendMotionTrigger(uint32_t timestampMs, float signalStrength);

    // Roster discovery (MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #1) -- broadcasts this node's own
    // identity to the LAN, not to any registered phone client, so unlike every other send*
    // method above this one works regardless of `streaming_`/session state, and regardless of
    // whether a phone is even connected yet. Uses `WiFi.localIP()`/`subnetMask()` to compute the
    // broadcast address (see broadcastAddress() below), which is only meaningful in STA mode --
    // PeregrineMicArrayCam.ino only calls this when NOT the current Primary (see
    // Config::kNetworkRole), since a Primary (AP mode) has no announcement to make anyway: it
    // already knows its own identity, there's nothing to hear from itself.
    void sendNodeAnnounce();

    // Manual/video capture control (MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3) -- this class stays a
    // pure protocol/transport layer, same as everything above: it decodes the phone's request and
    // exposes a one-shot flag, but PeregrineMicArrayCam.ino's loop() (which already owns the
    // camera/VideoRecorder) is what actually acts on it, matching how doaCaptureRequested already
    // works for onset-triggered stills.
    bool isPhotoAutoModeEnabled() const { return photoAutoMode_; }
    // Runtime override of the min gap between captures (kSetPhotoInterval) -- Config::kPhotoMinIntervalMs
    // is only the boot default. capturePhotoIfDue() reads this every call. No persistence: the app
    // re-sends the saved value on reconnect, same as the photo-mode flag above.
    uint32_t photoMinIntervalMs() const { return photoMinIntervalMs_; }
    // Each consume* method returns true (and resets) at most once per request -- a second poll()
    // before the next request sees false, so .ino doesn't need its own separate "already handled
    // this one" bookkeeping.
    bool consumeManualCaptureRequest();
    bool consumeVideoStartRequest(bool &includeAudio);
    bool consumeVideoStopRequest();
    void sendVideoReady(uint32_t timestampMs, uint32_t videoId, uint16_t frameCount, uint16_t frameIntervalMs, uint32_t audioSampleCount);

    // Live MJPEG preview control (field camera-aim validation) -- same one-shot consume pattern.
    bool consumeVideoStreamStartRequest();
    bool consumeVideoStreamStopRequest();

    int activeBandCount() const { return activeBandCount_; }
    const Protocol::FrequencyBandSlot &activeBand(int index) const { return activeBands_[index]; }

    // Added 2026-08-18, FIELD_DEBUG_PLAN.md -- see RemoteLogger.h for the full rationale, and
    // ../PeregrineMicArray/UDPStreamer.h's identical pair for the full doc comments (mirrored, not
    // reinvented).
    void sendLogLine(const char *line);
    bool consumeSetRemoteLoggingRequest(bool &enabled);
    // Runtime feeder-cam toggle (HOME_ASSISTANT.md) -- same fire-and-forget, no-persistence shape
    // as consumeSetRemoteLoggingRequest / the photo-mode toggle.
    bool consumeSetFeederCamModeRequest(bool &enabled);

private:
    void handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort);
    IPAddress broadcastAddress() const;
    // Shared by begin()'s cold-boot-with-no-Primary path and pollFailover()'s runtime-loss path --
    // both converge to the same "start hosting our own AP" transition.
    void promoteToFailedOver();
    // Shared by begin()'s STA branch and pollReconnect() -- see the .cpp's own doc comment.
    // WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16.
    bool joinBestCandidate();
    // Fills a 6-byte NodeIdentityPacket::deviceId/RosterEntryPacket::deviceId field from
    // ESP.getEfuseMac() -- see NodeIdentityPacket's own doc comment in NetworkProtocol.h for why
    // this specific source, not WiFi.macAddress()/softAPmacAddress(). Shared by sendNodeIdentity()
    // and sendNodeAnnounce(), the two call sites that build a NodeIdentityPacket.
    static void fillDeviceId(uint8_t *out);

    WiFiUDP udp_;
    bool streaming_ = false;
    IPAddress clientIP_;
    uint16_t clientPort_ = 0;
    uint32_t lastClientActivityMs_ = 0;
    Protocol::FrequencyBandSlot activeBands_[Protocol::kMaxDOABands] = {};
    int activeBandCount_ = 0;
    // Only ever populated if this node is the current roster master (Config::kNetworkRole ==
    // kRolePrimary) -- see NodeRoster.h's header for why every node still safely owns one of
    // these either way.
    NodeRoster roster_;

    // Secondary/failover state (MIC_ARRAY_MASTER_AP_PLAN.md §4) -- unused/inert unless
    // Config::kNetworkRole == kRoleSecondary.
    bool failedOver_ = false;
    uint32_t lastConnectedMs_ = 0;
    uint32_t lastPrimaryScanMs_ = 0;

    // kSetRemoteLogging request state -- see consumeSetRemoteLoggingRequest()'s own comment.
    bool remoteLoggingRequested_ = false;
    bool remoteLoggingRequestedValue_ = false;

    // kSetFeederCamMode request state -- same shape.
    bool feederCamModeRequested_ = false;
    bool feederCamModeRequestedValue_ = false;

    bool photoAutoMode_ = Config::kPhotoAutoModeDefault;
    uint32_t photoMinIntervalMs_ = Config::kPhotoMinIntervalMs;
    bool manualCaptureRequested_ = false;
    bool videoStartRequested_ = false;
    bool videoStartIncludeAudio_ = false;
    bool videoStopRequested_ = false;
    bool videoStreamStartRequested_ = false;
    bool videoStreamStopRequested_ = false;
};
