#include "VideoServer.h"
#include <uri/UriBraces.h>
#include <SD_MMC.h>
#include "VideoRecorder.h"

void VideoServer::begin(uint16_t port) {
    server_.begin(port);
    server_.on(UriBraces("/video/{}/frame/{}"), HTTP_GET, [this]() { handleFrameRequest(); });
    server_.on(UriBraces("/video/{}/audio"), HTTP_GET, [this]() { handleAudioRequest(); });
    server_.begin();
}

void VideoServer::poll() {
    server_.handleClient();
}

void VideoServer::publish(uint32_t videoId, uint16_t frameCount, bool hasAudio) {
    portENTER_CRITICAL(&mux_);
    currentVideoId_ = videoId;
    frameCount_ = frameCount;
    hasAudio_ = hasAudio;
    portEXIT_CRITICAL(&mux_);
}

bool VideoServer::isServable(uint32_t videoId, uint16_t frameIndex, bool wantAudio) {
    portENTER_CRITICAL(&mux_);
    bool ok = videoId == currentVideoId_ && (wantAudio ? hasAudio_ : frameIndex < frameCount_);
    portEXIT_CRITICAL(&mux_);
    return ok;
}

void VideoServer::handleFrameRequest() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();
    uint16_t frameIndex = (uint16_t)server_.pathArg(1).toInt();

    if (!isServable(requestedId, frameIndex, false)) {
        server_.send(404, "text/plain", "frame not available");
        return;
    }

    File file = SD_MMC.open(VideoRecorder::framePath(requestedId, frameIndex), FILE_READ);
    if (!file) {
        server_.send(404, "text/plain", "frame file missing on SD");
        return;
    }
    server_.streamFile(file, "image/jpeg");
    file.close();
}

void VideoServer::handleAudioRequest() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();

    if (!isServable(requestedId, 0, true)) {
        server_.send(404, "text/plain", "audio not available");
        return;
    }

    File file = SD_MMC.open(VideoRecorder::audioPath(requestedId), FILE_READ);
    if (!file) {
        server_.send(404, "text/plain", "audio file missing on SD");
        return;
    }
    server_.streamFile(file, "audio/wav");
    file.close();
}
