// CameraPins.h — OV3660 DVP/SCCB pin mapping for the FORIOT ESP32-S3-CAM board.
//
// **UNVERIFIED against real hardware — confirm before flashing.** The confirmed pinout diagram
// this project has (see CAMERA_NODE_NETWORK_SPEC.md) established which GPIOs the camera claims as
// a RANGE (GPIO4-13, 15-18) — enough to derive the mic/GPS pin conflicts and remapping in Config.h
// with confidence — but not the exact per-signal assignment within that range (which GPIO is XCLK
// vs. D3 vs. HREF, etc.). The mapping below is the common convention published for this class of
// ESP32-S3 OV2640/OV3660 clone board; per this project's own hardware-debugging rule (real-device
// evidence only, no guessing ahead of data — see repo history), treat this as a starting point to
// verify against the actual board silkscreen/schematic once it's in hand, not a confirmed fact.
// PWDN/RESET tied off (-1, not wired) is also a common convention for these compact boards, not
// confirmed here.
#pragma once

#define CAM_PIN_PWDN    -1
#define CAM_PIN_RESET   -1
#define CAM_PIN_XCLK    15
#define CAM_PIN_SIOD    4
#define CAM_PIN_SIOC    5
#define CAM_PIN_D7      16
#define CAM_PIN_D6      17
#define CAM_PIN_D5      18
#define CAM_PIN_D4      12
#define CAM_PIN_D3      10
#define CAM_PIN_D2      8
#define CAM_PIN_D1      9
#define CAM_PIN_D0      11
#define CAM_PIN_VSYNC   6
#define CAM_PIN_HREF    7
#define CAM_PIN_PCLK    13

constexpr int kCameraXCLKFreqHz = 20000000;
