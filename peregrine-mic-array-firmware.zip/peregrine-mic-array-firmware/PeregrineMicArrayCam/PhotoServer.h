// PhotoServer.h — the "tiny server" half of the confirmed "HTTP pull, node runs a tiny server"
// photo-transfer decision (see CAMERA_NODE_NETWORK_SPEC.md / PhotoReadyPacket's comment in
// NetworkProtocol.h).
//
// Two-tier storage (SD-backed photo store, added 2026-08-28): every capture is written to
// /photos/<id>.jpg on the SD card AND kept as the single most-recent in-RAM buffer. Serving
// prefers the RAM buffer for the just-captured photo (fast, no SD read) and falls back to the SD
// file for anything older -- so a photo the phone hasn't fetched yet survives a loop() stall, the
// app switching nodes, or a power cycle, instead of being lost the moment the next capture frees
// the RAM buffer.
//
// Endpoints (all on Config::kHTTPPort):
//   GET    /photo/<id>  -> the JPEG (RAM buffer if it's the current one, else the SD file), 404 if gone
//   GET    /photos      -> text/plain, one "<id>,<bytes>" line per file in /photos/ -- what the phone
//                          reconciles against on (re)connect to pull anything it's missing
//   DELETE /photo/<id>  -> removes the SD file (idempotent); the phone calls this once it has saved
//                          the photo, so the node's store stays bounded
//   GET    /snapshot    -> a fresh single JPEG grabbed on demand (Home Assistant `generic` camera,
//                          HOME_ASSISTANT.md). 503 if the camera's one frame buffer is momentarily
//                          held by the live stream / a capture -- the caller just retries.
//
// Uses `WebServer`'s `UriBraces` pattern matching (`arduino-esp32` core 3.3.11).
#pragma once

#include <cstdint>
#include <cstddef>
#include <WebServer.h>
#include <WString.h>

class PhotoServer {
public:
    void begin(uint16_t port);

    // Call every loop() iteration.
    void poll();

    // Publishes a newly captured photo as the in-RAM fast-path buffer, replacing whatever was
    // previously being served — frees the old buffer. Takes ownership of `data` (must be
    // heap-allocated with `malloc`/`new[]`, freed here with `free`). The SD copy is written
    // separately by the caller (capturePhotoIfDue) -- this class only owns the RAM tier.
    void publish(uint32_t photoId, uint8_t *data, size_t length);

    // Deletes lowest-id (oldest) files in /photos/ until at most `maxFiles` remain -- the
    // retention safety net for when the phone never returns to fetch + DELETE. Call after each new
    // SD write. No-op when the SD card isn't mounted.
    static void pruneToMax(uint16_t maxFiles);

    // Highest numeric id currently in /photos/ (0 if empty / no SD). Used at boot to resume the
    // photoId counter above any pre-reboot file so ids stay monotonic across a power cycle.
    static uint32_t highestStoredPhotoId();

private:
    void handlePhotoRequest(); // GET    /photo/{id}
    void handlePhotoDelete();  // DELETE /photo/{id}
    void handlePhotoList();    // GET    /photos
    void handleSnapshot();     // GET    /snapshot

    static String photoPath(uint32_t id);
    // Parses the numeric id out of a "/photos/<digits>.jpg" path -- false for anything that isn't
    // exactly that shape (a stray non-photo file, a subdirectory).
    static bool parseIdFromPath(const String &path, uint32_t &outId);

    WebServer server_;
    uint32_t currentPhotoId_ = 0;
    uint8_t *photoData_ = nullptr;
    size_t photoLength_ = 0;
};
