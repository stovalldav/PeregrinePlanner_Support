// PhotoServer.h — the "tiny server" half of the confirmed "HTTP pull, node runs a tiny server"
// photo-transfer decision (see CAMERA_NODE_NETWORK_SPEC.md / PhotoReadyPacket's comment in
// NetworkProtocol.h).
//
// Two-tier storage (SD-backed photo store, added 2026-08-28): every capture is written to
// /photos/<id>.jpg on the SD card AND kept as the single most-recent in-RAM buffer. Serving
// prefers the RAM buffer for the just-captured photo (fast, no SD read) and falls back to the SD
// file for anything older -- so a photo the phone hasn't fetched yet survives a loop() stall, the
// app switching nodes, or a power cycle, instead of being lost the moment the next capture frees
// the RAM buffer.
//
// Endpoints (all on Config::kHTTPPort):
//   GET    /photo/<id>  -> the JPEG (RAM buffer if it's the current one, else the SD file), 404 if gone
//   GET    /photos      -> text/plain, one "<id>,<bytes>" line per file in /photos/ -- what the phone
//                          reconciles against on (re)connect to pull anything it's missing
//   DELETE /photo/<id>  -> removes the SD file (idempotent); the phone calls this once it has saved
//                          the photo, so the node's store stays bounded
//   GET    /snapshot    -> a fresh single JPEG grabbed on demand (Home Assistant `generic` camera,
//                          HOME_ASSISTANT.md). 503 if the camera's one frame buffer is momentarily
//                          held by the live stream / a capture -- the caller just retries.
//
// Uses `WebServer`'s `UriBraces` pattern matching (`arduino-esp32` core 3.3.11).
#pragma once

#include <cstdint>
#include <cstddef>
#include <WebServer.h>
#include <WString.h>

class PhotoServer {
public:
    void begin(uint16_t port);

    // Call every loop() iteration.
    void poll();

    // Publishes a newly captured photo as the in-RAM fast-path buffer, replacing whatever was
    // previously being served — frees the old buffer. Takes ownership of `data` (must be
    // heap-allocated with `malloc`/`new[]`, freed here with `free`). The SD copy is written
    // separately by the caller (capturePhotoIfDue) -- this class only owns the RAM tier.
    void publish(uint32_t photoId, uint8_t *data, size_t length);

    // One full /photos scan at boot: seeds the RAM-tracked retention state (file count + lowest
    // id) and returns the highest stored id, so the caller can resume nextPhotoId above any
    // pre-reboot file (ids stay monotonic across a power cycle). Returns 0 for an empty store / no
    // SD. Replaces the old static highestStoredPhotoId().
    uint32_t initRetentionState();

    // Call after each successful SD write of a new capture. Bumps the RAM-tracked count and, if
    // that pushes /photos over `maxFiles`, deletes from the low-id (oldest) end until it fits.
    //
    // Real finding 2026-09-01: the previous per-capture retention pass (pruneToMax) reopened and
    // walked the whole /photos directory via openNextFile() -- twice -- on every capture. With
    // ~1000 unfetched files piled up (the phone had been unable to connect for a long stretch, so
    // nothing was getting fetched+DELETEd), each capture spent seconds in SD directory iteration
    // on the 1-bit SD_MMC bus and loop() was starved so badly the node dropped off the network
    // entirely. This does no directory scan in the common path -- just SD_MMC.remove() + a bounded
    // SD_MMC.exists() probe to step over any gaps the phone's DELETEs left.
    void notePhotoStored(uint32_t photoId, uint16_t maxFiles);

    // One-shot maintenance: delete every /photos/<id>.jpg and reset the tracked state. Returns the
    // number of files removed. Driven by Config::kWipePhotosOnBoot.
    uint32_t wipeAllPhotos();

private:
    void handlePhotoRequest(); // GET    /photo/{id}
    void handlePhotoDelete();  // DELETE /photo/{id}
    void handlePhotoList();    // GET    /photos
    void handleSnapshot();     // GET    /snapshot

    static String photoPath(uint32_t id);
    // Parses the numeric id out of a "/photos/<digits>.jpg" path -- false for anything that isn't
    // exactly that shape (a stray non-photo file, a subdirectory).
    static bool parseIdFromPath(const String &path, uint32_t &outId);

    // The expensive full-directory scan -> (count, lowest id, highest id). Boot only, plus a
    // resync fallback when incremental tracking loses the thread.
    void scanRetentionState(uint32_t &countOut, uint32_t &lowestOut, uint32_t &highestOut);
    // Step oldestStoredId_ forward to the next id that still has a file (bounded; resyncs from a
    // full scan if the gap is too big).
    void advanceOldestStoredId();

    WebServer server_;
    uint32_t currentPhotoId_ = 0;
    uint8_t *photoData_ = nullptr;
    size_t photoLength_ = 0;

    // RAM-tracked retention state -- see notePhotoStored()'s comment for why the directory is no
    // longer scanned per capture. Approximate under concurrent phone DELETEs; self-heals via
    // advanceOldestStoredId()'s resync.
    uint32_t storedCount_ = 0;
    uint32_t oldestStoredId_ = 0; // 0 == store empty / unknown
};
