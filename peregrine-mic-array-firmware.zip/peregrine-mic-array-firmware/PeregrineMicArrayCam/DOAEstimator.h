// DOAEstimator.h — left-right-only direction-of-arrival from two independent I2S masters (top
// pair, bottom pair). See ../PeregrineMicArray/Config.h's header comment for the full
// geometry/history: the ±90° forward-hemisphere limit is inherent to any single 2-mic pair, not
// something a working cross-bus comparison would fix (the two pairs sit on the same front-back
// axis -- confirmed TL directly above BL, only height differs). A working comparison would give
// elevation instead, and either way it's blocked by the same cross-bus clock-sync problem that
// was tried and didn't work reliably on this hardware.
//
// Each bus's own left-right delay is measured independently (top pair, bottom pair) and
// averaged for better noise robustness than a single measurement. The result is reported as an
// azimuth constrained to the forward hemisphere (-90..+90 degrees from center, wrapped into
// [0,360) the same way a full 2D azimuth would be) -- never fabricates a "behind" reading, since
// that's genuinely not measurable with this hardware. This keeps the wire protocol and the phone
// app completely unchanged (both already expect a plain [0,360) azimuthDeg); only what value
// range actually gets produced is different.
//
// `estimate()` (both buses) is the default, hardware-validated path -- used whenever
// Config::kTopBusEnabled is true. `estimateSingleBus()` below is the 2-mic variant (bottom pair
// only, see Config::kMicCount) -- same per-pair math, just without a second pair to average
// against. Callers must pick the one that matches which buses are actually wired; feeding
// estimate() data from an unwired bus corrupts every reading with floating-pin noise instead of
// failing loudly (see Config.h's kMicCount comment).
#pragma once

#include <cstdint>

struct DOAResult {
    float azimuthDeg;  // [0, 360), but only ever in the forward hemisphere: 270..360..90
    float confidence;  // [0, 1]
};

class DOAEstimator {
public:
    // `topLeft`/`topRight` (bus 0) and `bottomLeft`/`bottomRight` (bus 1) are NOT
    // sample-synchronized with each other -- each pair is only ever compared against its own
    // bus-mate, never cross-bus. All four windows must be `windowSamples` long
    // (Config::kDOAWindowSamples).
    //
    // `lowHz`/`highHz`: when both describe a valid band (lowHz > 0 and highHz > lowHz), all four
    // windows are bandpass-filtered to that range before cross-correlation -- set by the phone
    // (see UDPStreamer's kSetFrequencyBand handling) to the typical call-frequency range of
    // whichever species is currently being tracked, so a busy multi-bird soundscape is more
    // likely to isolate that species' onset rather than whichever transient is loudest overall
    // across the full spectrum. When the band is degenerate/unset (the default when no species is
    // tracked), no filtering is applied -- exactly the original full-spectrum behavior. This is a
    // coarse heuristic, not true source separation -- see MIC_ARRAY_MULTI_UNIT_PLAN.md (repo
    // root) and the app's SpeciesFrequencyEstimator.swift for the honest caveats on how
    // approximate the frequency ranges themselves are.
    static DOAResult estimate(
        const int16_t *topLeft, const int16_t *topRight,
        const int16_t *bottomLeft, const int16_t *bottomRight,
        int windowSamples, float lowHz, float highHz
    );

    // Single-bus (2-mic) variant -- used when Config::kTopBusEnabled is false
    // (CAMERA_NODE_NETWORK_SPEC.md's "2-mic single-bus" config, bottom pair only, top pair
    // genuinely left unwired). Same per-pair delay/azimuth math as one half of estimate() above,
    // just without a second pair to average against -- confidence is that one pair's own
    // correlation strength directly, not an average. Deliberately a separate entry point rather
    // than estimate() called with dummy top-pair data, so there's no way to accidentally feed it
    // floating-pin noise from an unwired bus 0.
    static DOAResult estimateSingleBus(
        const int16_t *left, const int16_t *right, int windowSamples, float lowHz, float highHz
    );

private:
    // Normalized cross-correlation over +/-Config::kMaxLagSamples, with parabolic sub-sample
    // interpolation around the integer peak. Returns the estimated delay in samples (positive
    // means `right` lags `left`, i.e. the sound arrived at `left` first) and the peak
    // correlation coefficient (a rough per-pair confidence signal).
    static void pairDelay(const int16_t *left, const int16_t *right, int windowSamples, float &delaySamplesOut, float &peakCorrelationOut);

    // Writes a bandpass-filtered copy of `input` into `output` (both `windowSamples` long) using
    // a standard constant-0dB-peak-gain RBJ ("Audio EQ Cookbook") biquad bandpass, reset fresh for
    // each call -- these are independent captured windows, not a continuous stream, so there's no
    // persistent filter state to carry across calls. Plain copy (no-op) if lowHz/highHz don't
    // describe a valid band.
    static void applyBandpass(const int16_t *input, int16_t *output, int windowSamples, float lowHz, float highHz);

    // Real gap found 2026-08-20 (mirrored from ../PeregrineMicArray): a bandpass filter alone
    // doesn't verify the source is actually narrowband/tonal in the requested range -- it passes
    // through whatever energy exists there regardless of whether that's a coherent call or just
    // broadband noise (wind, rustling) that happens to have some energy overlapping the band. That
    // mismatch was the actual mechanism behind "azimuth attributed to a species that isn't what's
    // really calling": localization was answering "was something loud in this frequency range,"
    // not "is this genuinely a narrowband source concentrated there." `raw²`-summed energy vs.
    // `filtered²`-summed energy: a real narrowband/tonal source retains most of its energy after a
    // bandpass matched to its own frequency; broadband noise loses most of its energy when
    // restricted to a narrow slice. `estimate()`/`estimateSingleBus()` fold this into the returned
    // `confidence` as a multiplier when a real band is requested -- no new classifier calls, no
    // wire-protocol change (confidence already flows through the app's existing
    // minConfidenceForUpdate gate).
    static float energyRetentionRatio(const int16_t *raw, const int16_t *filtered, int windowSamples);
};
