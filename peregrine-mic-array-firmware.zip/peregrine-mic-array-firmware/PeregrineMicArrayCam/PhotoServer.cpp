#include "PhotoServer.h"
#include <cstdlib>
#include <cctype>
#include <esp_camera.h>
#include <SD_MMC.h>
#include <uri/UriBraces.h>

static const char *kPhotoDir = "/photos";

String PhotoServer::photoPath(uint32_t id) {
    return String(kPhotoDir) + "/" + String(id) + ".jpg";
}

bool PhotoServer::parseIdFromPath(const String &path, uint32_t &outId) {
    int slash = path.lastIndexOf('/');
    int dot = path.lastIndexOf('.');
    if (dot <= slash + 1) return false;
    String s = path.substring(slash + 1, dot);
    if (s.length() == 0 || s.length() > 10) return false;
    for (unsigned i = 0; i < s.length(); i++) {
        if (!isdigit((unsigned char)s[i])) return false;
    }
    outId = (uint32_t)strtoul(s.c_str(), nullptr, 10);
    return true;
}

void PhotoServer::begin(uint16_t port) {
    server_.begin(port);
    server_.on(UriBraces("/photo/{}"), HTTP_GET, [this]() { handlePhotoRequest(); });
    server_.on(UriBraces("/photo/{}"), HTTP_DELETE, [this]() { handlePhotoDelete(); });
    server_.on("/photos", HTTP_GET, [this]() { handlePhotoList(); });
    server_.on("/snapshot", HTTP_GET, [this]() { handleSnapshot(); });
    server_.begin();
}

void PhotoServer::poll() {
    server_.handleClient();
}

void PhotoServer::publish(uint32_t photoId, uint8_t *data, size_t length) {
    if (photoData_) {
        free(photoData_);
    }
    photoData_ = data;
    photoLength_ = length;
    currentPhotoId_ = photoId;
}

void PhotoServer::handlePhotoRequest() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();

    // Fast path: the just-captured photo is still in RAM.
    if (photoData_ && requestedId == currentPhotoId_) {
        server_.send_P(200, "image/jpeg", (const char *)photoData_, photoLength_);
        return;
    }

    // Anything older: stream it off the SD card (survives buffer overwrite / reboot).
    File file = SD_MMC.open(photoPath(requestedId), FILE_READ);
    if (!file) {
        server_.send(404, "text/plain", "photo not available");
        return;
    }
    server_.streamFile(file, "image/jpeg");
    file.close();
}

void PhotoServer::handlePhotoDelete() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();
    bool existed = SD_MMC.exists(photoPath(requestedId));
    SD_MMC.remove(photoPath(requestedId)); // idempotent -- a missing file is not an error

    // Keep the RAM-tracked retention state roughly in step with the phone deleting fetched photos.
    if (existed && storedCount_ > 0) storedCount_--;
    if (existed && requestedId == oldestStoredId_) advanceOldestStoredId();

    // If the phone is deleting the one that also happens to be the live RAM buffer, drop that too
    // so a later GET for it correctly 404s rather than re-serving a photo the phone already saved.
    if (photoData_ && requestedId == currentPhotoId_) {
        free(photoData_);
        photoData_ = nullptr;
        photoLength_ = 0;
        currentPhotoId_ = 0;
    }
    server_.send(200, "text/plain", "ok");
}

void PhotoServer::handleSnapshot() {
    // On-demand fresh frame for a Home Assistant `generic` camera (HOME_ASSISTANT.md). The camera
    // has a single frame buffer (Config::kCameraFrameBufferCount == 1); if the live stream or a
    // capture is momentarily holding it, esp_camera_fb_get() returns null -- answer 503 and let
    // the poller retry rather than blocking. Not written to the SD store (that's only for real
    // capture events, not view polls).
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        server_.send(503, "text/plain", "camera busy");
        return;
    }
    server_.send_P(200, "image/jpeg", (const char *)fb->buf, fb->len);
    esp_camera_fb_return(fb);
}

void PhotoServer::handlePhotoList() {
    String body;
    File dir = SD_MMC.open(kPhotoDir);
    if (dir && dir.isDirectory()) {
        File entry = dir.openNextFile();
        while (entry) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id)) {
                    body += String(id);
                    body += ",";
                    body += String((uint32_t)entry.size());
                    body += "\n";
                }
            }
            entry.close();
            entry = dir.openNextFile();
        }
    }
    if (dir) dir.close();
    server_.send(200, "text/plain", body);
}

void PhotoServer::scanRetentionState(uint32_t &countOut, uint32_t &lowestOut, uint32_t &highestOut) {
    countOut = 0;
    lowestOut = 0;
    highestOut = 0;
    File dir = SD_MMC.open(kPhotoDir);
    if (dir && dir.isDirectory()) {
        File entry = dir.openNextFile();
        while (entry) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id)) {
                    countOut++;
                    if (lowestOut == 0 || id < lowestOut) lowestOut = id;
                    if (id > highestOut) highestOut = id;
                }
            }
            entry.close();
            entry = dir.openNextFile();
        }
    }
    if (dir) dir.close();
}

uint32_t PhotoServer::initRetentionState() {
    uint32_t count, lowest, highest;
    scanRetentionState(count, lowest, highest);
    storedCount_ = count;
    oldestStoredId_ = lowest;
    return highest;
}

void PhotoServer::advanceOldestStoredId() {
    // The phone DELETEs photos it has fetched, which can leave gaps in the middle of the id range,
    // so "next oldest" isn't simply oldestStoredId_ + 1. SD_MMC.exists() is a single stat (not a
    // directory walk); probe forward a bounded distance, and fall back to a full rescan if the gap
    // is larger than that (rare -- only after the phone bulk-deletes a big contiguous run).
    for (uint32_t probe = oldestStoredId_ + 1, n = 0; n < 4096; probe++, n++) {
        if (SD_MMC.exists(photoPath(probe))) {
            oldestStoredId_ = probe;
            return;
        }
    }
    uint32_t count, lowest, highest;
    scanRetentionState(count, lowest, highest);
    storedCount_ = count;
    oldestStoredId_ = lowest;
}

void PhotoServer::notePhotoStored(uint32_t photoId, uint16_t maxFiles) {
    storedCount_++;
    if (oldestStoredId_ == 0) oldestStoredId_ = photoId; // store was empty

    int guard = 0;
    while (storedCount_ > maxFiles && oldestStoredId_ != 0 && guard++ < 256) {
        SD_MMC.remove(photoPath(oldestStoredId_));
        Serial0.printf("[photo] retention: evicted /photos/%lu.jpg (~%lu stored, max %u)\n",
                       (unsigned long)oldestStoredId_, (unsigned long)storedCount_, (unsigned)maxFiles);
        if (storedCount_ > 0) storedCount_--;
        advanceOldestStoredId();
    }
}

uint32_t PhotoServer::wipeAllPhotos() {
    // Delete every /photos/<id>.jpg. Collect a batch of names with the directory handle open, then
    // close it before removing -- removing while iterating an open SD_MMC dir handle is unreliable.
    uint32_t removed = 0;
    for (int pass = 0; pass < 512; pass++) {
        File dir = SD_MMC.open(kPhotoDir);
        if (!dir || !dir.isDirectory()) {
            if (dir) dir.close();
            break;
        }
        String batch[32];
        int n = 0;
        File entry = dir.openNextFile();
        while (entry && n < 32) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id)) batch[n++] = photoPath(id);
            }
            entry.close();
            entry = dir.openNextFile();
        }
        dir.close();
        if (n == 0) break;
        for (int i = 0; i < n; i++) {
            if (SD_MMC.remove(batch[i])) removed++;
        }
    }
    storedCount_ = 0;
    oldestStoredId_ = 0;
    return removed;
}
