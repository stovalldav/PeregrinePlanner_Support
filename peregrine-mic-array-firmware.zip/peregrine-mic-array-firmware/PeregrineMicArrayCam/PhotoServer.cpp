#include "PhotoServer.h"
#include <cstdlib>
#include <cctype>
#include <esp_camera.h>
#include <SD_MMC.h>
#include <uri/UriBraces.h>

static const char *kPhotoDir = "/photos";

String PhotoServer::photoPath(uint32_t id) {
    return String(kPhotoDir) + "/" + String(id) + ".jpg";
}

bool PhotoServer::parseIdFromPath(const String &path, uint32_t &outId) {
    int slash = path.lastIndexOf('/');
    int dot = path.lastIndexOf('.');
    if (dot <= slash + 1) return false;
    String s = path.substring(slash + 1, dot);
    if (s.length() == 0 || s.length() > 10) return false;
    for (unsigned i = 0; i < s.length(); i++) {
        if (!isdigit((unsigned char)s[i])) return false;
    }
    outId = (uint32_t)strtoul(s.c_str(), nullptr, 10);
    return true;
}

void PhotoServer::begin(uint16_t port) {
    server_.begin(port);
    server_.on(UriBraces("/photo/{}"), HTTP_GET, [this]() { handlePhotoRequest(); });
    server_.on(UriBraces("/photo/{}"), HTTP_DELETE, [this]() { handlePhotoDelete(); });
    server_.on("/photos", HTTP_GET, [this]() { handlePhotoList(); });
    server_.on("/snapshot", HTTP_GET, [this]() { handleSnapshot(); });
    server_.begin();
}

void PhotoServer::poll() {
    server_.handleClient();
}

void PhotoServer::publish(uint32_t photoId, uint8_t *data, size_t length) {
    if (photoData_) {
        free(photoData_);
    }
    photoData_ = data;
    photoLength_ = length;
    currentPhotoId_ = photoId;
}

void PhotoServer::handlePhotoRequest() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();

    // Fast path: the just-captured photo is still in RAM.
    if (photoData_ && requestedId == currentPhotoId_) {
        server_.send_P(200, "image/jpeg", (const char *)photoData_, photoLength_);
        return;
    }

    // Anything older: stream it off the SD card (survives buffer overwrite / reboot).
    File file = SD_MMC.open(photoPath(requestedId), FILE_READ);
    if (!file) {
        server_.send(404, "text/plain", "photo not available");
        return;
    }
    server_.streamFile(file, "image/jpeg");
    file.close();
}

void PhotoServer::handlePhotoDelete() {
    uint32_t requestedId = (uint32_t)server_.pathArg(0).toInt();
    SD_MMC.remove(photoPath(requestedId)); // idempotent -- a missing file is not an error

    // If the phone is deleting the one that also happens to be the live RAM buffer, drop that too
    // so a later GET for it correctly 404s rather than re-serving a photo the phone already saved.
    if (photoData_ && requestedId == currentPhotoId_) {
        free(photoData_);
        photoData_ = nullptr;
        photoLength_ = 0;
        currentPhotoId_ = 0;
    }
    server_.send(200, "text/plain", "ok");
}

void PhotoServer::handleSnapshot() {
    // On-demand fresh frame for a Home Assistant `generic` camera (HOME_ASSISTANT.md). The camera
    // has a single frame buffer (Config::kCameraFrameBufferCount == 1); if the live stream or a
    // capture is momentarily holding it, esp_camera_fb_get() returns null -- answer 503 and let
    // the poller retry rather than blocking. Not written to the SD store (that's only for real
    // capture events, not view polls).
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        server_.send(503, "text/plain", "camera busy");
        return;
    }
    server_.send_P(200, "image/jpeg", (const char *)fb->buf, fb->len);
    esp_camera_fb_return(fb);
}

void PhotoServer::handlePhotoList() {
    String body;
    File dir = SD_MMC.open(kPhotoDir);
    if (dir && dir.isDirectory()) {
        File entry = dir.openNextFile();
        while (entry) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id)) {
                    body += String(id);
                    body += ",";
                    body += String((uint32_t)entry.size());
                    body += "\n";
                }
            }
            entry.close();
            entry = dir.openNextFile();
        }
    }
    if (dir) dir.close();
    server_.send(200, "text/plain", body);
}

void PhotoServer::pruneToMax(uint16_t maxFiles) {
    // Evictions are rare (called right after each capture, so at most ~1 over the cap), so a
    // simple "scan for the min id, remove it, repeat" is fine -- O(n) per eviction, ~0-1
    // evictions per call. Guards against runaway looping if SD_MMC.remove() ever fails.
    for (int guard = 0; guard < 32; guard++) {
        File dir = SD_MMC.open(kPhotoDir);
        if (!dir || !dir.isDirectory()) {
            if (dir) dir.close();
            return;
        }
        uint32_t count = 0;
        uint32_t minId = 0;
        bool haveMin = false;
        File entry = dir.openNextFile();
        while (entry) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id)) {
                    count++;
                    if (!haveMin || id < minId) {
                        minId = id;
                        haveMin = true;
                    }
                }
            }
            entry.close();
            entry = dir.openNextFile();
        }
        dir.close();

        if (!haveMin || count <= maxFiles) return;
        SD_MMC.remove(photoPath(minId));
        Serial0.printf("[photo] retention: evicted /photos/%lu.jpg (%lu stored > max %u)\n",
                       (unsigned long)minId, (unsigned long)count, (unsigned)maxFiles);
    }
}

uint32_t PhotoServer::highestStoredPhotoId() {
    uint32_t maxId = 0;
    File dir = SD_MMC.open(kPhotoDir);
    if (dir && dir.isDirectory()) {
        File entry = dir.openNextFile();
        while (entry) {
            if (!entry.isDirectory()) {
                uint32_t id;
                if (parseIdFromPath(entry.path(), id) && id > maxId) {
                    maxId = id;
                }
            }
            entry.close();
            entry = dir.openNextFile();
        }
    }
    if (dir) dir.close();
    return maxId;
}
