// C4002Reader.h — DFRobot C4002 (SEN0691) 24GHz mmWave presence sensor, UART. Added 2026-09-26.
//
// **Wire protocol taken from DFRobot's own DFRobot_C4002 library source** (github.com/DFRobot/
// DFRobot_C4002 -- sendPack()/recvPack()/checkSum()/getNoteInfo() in src/DFRobot_C4002.cpp, and
// get_note_info() in python/raspberrypi/DFRobot_C4002.py), not guessed. NOT YET CONFIRMED AGAINST
// REAL HARDWARE -- same treatment the C4001 needed: check the [presence-link] status line and a
// real walk-past before trusting it.
//
// Completely different from the C4001: binary frames, not text sentences, 115200 baud default.
//   Frame:   FA F5 AA A5 | len(u16 LE, WHOLE frame incl. header+checksum) | 0x00 | type(u8)
//            | payload | checksum(u16 LE, plain byte sum of everything before it)
//   Payload: cmd(u8) | respCode(u8) | payloadLen(u16 LE, includes these 4 bytes) | data...
//   type 0x00 write request, 0x02 write response, 0x04 notification. Detection results arrive
//   as notifications with cmd 0x60, only after a report period has been set (the vendor library
//   and examples both say so).
//
// Result data, 18 bytes, PACKED little-endian -- decoded at explicit offsets, mirroring the vendor
// Python driver. Deliberately NOT the vendor Arduino library's approach (memcpy into its
// sDetectResult_t struct): on ESP32 that struct gets natural alignment padding (u8 then u16 then
// u32...), so memcpy would put every field after the first at the wrong offset. The Python driver's
// explicit offsets are the unambiguous reading of the wire format.
//    0 targetStatus  (0 none, 1 static presence, 2 motion)
//    1 light         (u16, x0.1 lux)
//    3 existGateIdx  (u32 bitmask)       7 existCountDown (u16, s)
//    9 existDist     (u16, cm)          11 existEnergy (u8)
//   12 moveDist      (u16, cm)          14 moveSpeed (i16, x0.01 m/s)
//   16 moveEnergy    (u8)               17 moveDirection (0 away, 1 none, 2 approaching)
#pragma once

#include <cstddef>
#include <cmath>
#include <cstdint>
#include <HardwareSerial.h>
#include "PresenceSensor.h"

class C4002Reader : public PresenceSensor {
public:
    enum class Direction : uint8_t { kAway = 0, kNone = 1, kApproaching = 2 };

    // Opens the UART and sets the report period (which is what turns result notifications on).
    // Returns true only if the sensor answered with a checksum-valid success response -- setup()
    // uses that to auto-detect a C4002 vs. a C4001 on the same pins. Blocks up to ~1s.
    // maxRangeCm (0-1100) and disappearDelayS (the sensor's hold time after a target stops being
    // detected) are written best-effort after detection succeeds.
    bool begin(HardwareSerial &serial, int rxPin, int txPin, uint32_t baud,
               uint16_t maxRangeCm = 1100, uint16_t disappearDelayS = 0xFFFF);

    bool poll() override;
    bool presence() const override { return presence_; }
    float distanceCm() const override { return distanceCm_; }
    const char *name() const override { return "C4002"; }
    uint32_t charsProcessed() const override { return charsProcessed_; }
    uint32_t reportsParsed() const override { return reportsParsed_; }
    uint32_t reportsUnparsed() const override { return reportsUnparsed_; }

    // The sensor's own direction field says which way; its speed field's sign isn't relied on.
    Movement movement() const override {
        switch (direction_) {
            case Direction::kApproaching: return Movement::kApproaching;
            case Direction::kAway: return Movement::kAway;
            default: return Movement::kNone;
        }
    }
    TargetState targetState() const override {
        if (targetStatus_ == 2) return TargetState::kMoving;
        if (targetStatus_ == 1) return clearing_ ? TargetState::kClearing : TargetState::kStill;
        return TargetState::kNone;
    }
    // DFRobot set_detect_range (0x86, closest/farthest cm, farthest <= 1100) and
    // set_target_disappear_delay (0x84, seconds). Persisting the values is the caller's job.
    bool setMaxRangeCm(uint16_t cm) override;
    bool setHoldS(uint16_t seconds) override;
    bool supportsHold() const override { return true; }
    uint16_t minSupportedRangeCm() const override { return 0; }
    uint16_t maxSupportedRangeCm() const override { return 1100; }

    // Static presence that is only the hold timer running out (see handleFrame()).
    bool isClearing() const { return clearing_; }
    float radialSpeedMps() const override { return presence_ ? fabsf(speedMps_) : 0.0f; }

    // C4002-only extras, logged in the status line.
    bool isMoving() const { return targetStatus_ == 2; }
    Direction direction() const { return direction_; }
    float speedMps() const { return speedMps_; }
    float lightLux() const { return lightLux_; }

    // Raw result fields, for diagnosing false/ghost detections from the serial log.
    struct Raw {
        uint32_t existGates = 0;      // bitmask of range gates the static-presence target occupies
        uint16_t existCountdownS = 0; // sensor's own hold timer before it drops static presence
        uint16_t existDistCm = 0;
        uint8_t existEnergy = 0;
        uint16_t moveDistCm = 0;
        uint8_t moveEnergy = 0;
    };
    const Raw &raw() const { return raw_; }
    // As the module reported it, before the range limit -- for the diagnostic log.
    uint8_t targetStatusRaw() const { return rawTargetStatus_; }
    bool beyondRange() const { return beyondRange_; }

private:
    static constexpr uint8_t kCmdSetReportPeriod = 0x83;
    static constexpr uint8_t kCmdSetDetectRange = 0x86;
    static constexpr uint8_t kCmdSetDisappearDelay = 0x84;
    static constexpr uint8_t kNoteResult = 0x60;
    static constexpr uint8_t kTypeWriteRequest = 0x00;
    static constexpr uint8_t kTypeWriteResponse = 0x02;
    static constexpr uint8_t kTypeNotification = 0x04;
    static constexpr uint8_t kRespSucceed = 0x01;
    static constexpr size_t kMaxFrame = 64;

    void sendWrite(const uint8_t *payload, uint16_t len);
    bool writeAndAwaitAck(uint8_t cmd, const uint8_t *data, uint16_t dataLen, uint32_t timeoutMs);
    // Feeds one byte to the frame parser; true when a complete, checksum-valid frame is in frame_.
    bool feed(uint8_t b);
    void handleFrame();

    HardwareSerial *serial_ = nullptr;

    uint8_t frame_[kMaxFrame];
    size_t frameLen_ = 0;
    uint16_t expectedLen_ = 0;
    uint8_t lastFrameType_ = 0;
    uint8_t lastFrameCmd_ = 0;
    uint8_t lastFrameResp_ = 0;

    bool presence_ = false;
    float distanceCm_ = 0.0f;
    uint8_t targetStatus_ = 0;
    Direction direction_ = Direction::kNone;
    float speedMps_ = 0.0f;
    float lightLux_ = 0.0f;
    Raw raw_;
    bool clearing_ = false;
    uint8_t rawTargetStatus_ = 0;
    bool beyondRange_ = false;
    uint16_t maxRangeCm_ = 0; // 0 = no limit applied here
    uint16_t disappearDelayS_ = 0; // 0 = unknown (not set / not acknowledged)
    bool gotResult_ = false;

    uint32_t charsProcessed_ = 0;
    uint32_t reportsParsed_ = 0;
    uint32_t reportsUnparsed_ = 0;
};
