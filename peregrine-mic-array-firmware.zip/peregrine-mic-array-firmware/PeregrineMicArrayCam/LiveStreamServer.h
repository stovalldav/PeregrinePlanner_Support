// LiveStreamServer.h — MJPEG-over-HTTP live preview, phone-triggered start/stop, for confirming a
// camera node's aim/focus/exposure while physically setting it up in the field (not smooth video
// -- see Config::kLiveStreamFrameIntervalMs). See MULTI_NODE_APP_ENHANCEMENTS_PLAN.md's "Future
// ideas" #7 for the larger AR-integration idea this is a smaller, immediately-needed slice of.
//
// Deliberately NOT built on the WebServer class PhotoServer/VideoServer use. That class's
// handleClient() runs each request handler inline and blocking -- fine for "fetch one photo," but
// a real MJPEG stream has to keep writing frames until the client disconnects, and doing that
// inside a WebServer handler would starve loop() (mic capture, onset detection, GPS, everything
// else this sketch does) for the entire stream duration. Instead this owns a raw
// WiFiServer/WiFiClient directly.
//
// Real-hardware finding, 2026-08-10: "at most one frame's worth of work per poll() call" (the
// original design here) turned out not to bound loop()-blocking time the way it was meant to --
// a single frame's client_.write() call was measured blocking for up to 744ms on a real WiFi
// link, and during that whole span nothing else in loop() ran at all (confirmed independently via
// audioRing's skipped-sample counter exploding specifically while a stream was active). Each
// frame's JPEG body is now sent in small fixed-size chunks (Config::kLiveStreamWriteChunkBytes)
// across as many poll() calls as it takes, via pendingFrame_/pendingFrameOffset_ below, instead of
// one big blocking write -- bounds any single poll() call's worst case to roughly one chunk's
// write time instead of a whole frame's. See Config.h's comment on kLiveStreamWriteChunkBytes for
// why a fixed size rather than WiFiClient::availableForWrite() (checked first; not overridden by
// this ESP32 core, always returns 0).
#pragma once

#include <cstddef>
#include <cstdint>
#include <WiFiServer.h>
#include <WiFiClient.h>
#include <esp_camera.h>

class LiveStreamServer {
public:
    // Starts listening on `port` -- call once from setup(), after WiFi is up.
    void begin(uint16_t port);

    // Starts a new streaming session -- no-op if already streaming (PeregrineMicArrayCam.ino is
    // responsible for the OTHER half of mutual exclusion: rejecting this while a video-recording
    // session is in progress, see that file's wiring).
    void start(uint32_t nowMs);
    // Idempotent -- safe to call even if nothing is streaming. Also returns the single shared
    // camera frame buffer if a chunked write was still in flight, so a mid-frame stop can't
    // permanently hold onto it (Config::kCameraFrameBufferCount == 1 -- the only buffer stills/
    // video capture have too).
    void stop();
    bool isStreaming() const { return streaming_; }

    // Feeder-cam mode (Config::kFeederCamMode): when true, poll() no longer auto-stops the session
    // at Config::kLiveStreamMaxDurationMs -- the stream stays up indefinitely for Home Assistant /
    // Frigate to pull whenever they reconnect, instead of timing out after the field-setup window.
    void setKeepAlive(bool keepAlive) { keepAlive_ = keepAlive; }
    // True while a chunked frame write is still in flight -- i.e. this class is currently holding
    // the single shared camera_fb_t (Config::kCameraFrameBufferCount == 1). Real-hardware finding,
    // 2026-08-10: a slow link can keep one frame's chunked send going for several seconds, long
    // enough that an onset-triggered still capture arriving mid-frame gets nothing
    // (esp_camera_fb_get() returns null -- there's no second buffer to hand it). The `.ino` checks
    // this before calling capturePhotoIfDue(), same mutual-exclusion pattern already used between
    // video recording and live streaming.
    bool isFrameBufferBusy() const { return pendingFrame_ != nullptr; }

    // Call every loop() iteration, regardless of isStreaming() -- also accepts pending client
    // connections and clears out finished/dropped ones even when not actively streaming, so a
    // stale half-open socket doesn't block the next real viewer. Never loops internally; always
    // returns after doing at most one chunk's worth of work.
    void poll(uint32_t nowMs);

private:
    void sendMultipartHeader();
    void startFrame(uint32_t schedulingDelayMs);
    void continueFrame(); // sends the next chunk of pendingFrame_, finishing it off if this is the last one

    WiFiServer server_;
    WiFiClient client_;
    bool started_ = false;   // begin() succeeded, ready to accept connections
    bool streaming_ = false; // an explicit start()/stop() session is active
    bool keepAlive_ = false; // Config::kFeederCamMode -- disables the kLiveStreamMaxDurationMs cutoff
    bool headerSent_ = false; // sent the multipart HTTP header to the current client yet
    uint32_t sessionStartMs_ = 0;
    uint32_t lastFrameMs_ = 0;

    // In-flight frame write state, non-null only between startFrame() and continueFrame()'s last
    // chunk. Owns fb until it's fully sent (or stop() reclaims it early) -- must always eventually
    // reach esp_camera_fb_return(), the same rule as every other camera_fb_t owner in this sketch.
    camera_fb_t *pendingFrame_ = nullptr;
    size_t pendingFrameOffset_ = 0;
    uint32_t pendingFrameGrabMs_ = 0;
    uint32_t pendingFrameSchedulingDelayMs_ = 0;
    uint32_t pendingFrameWriteStartMs_ = 0;
};
