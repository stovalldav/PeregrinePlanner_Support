#include "LiveStreamServer.h"
#include "Config.h"

void LiveStreamServer::begin(uint16_t port) {
    server_.begin(port);
    started_ = true;
}

void LiveStreamServer::start(uint32_t nowMs) {
    if (!started_ || streaming_) return;
    streaming_ = true;
    headerSent_ = false;
    sessionStartMs_ = nowMs;
    lastFrameMs_ = 0; // forces a frame on the very next poll() rather than waiting a full interval
}

void LiveStreamServer::stop() {
    streaming_ = false;
    headerSent_ = false;
    if (pendingFrame_) {
        // Real-hardware-driven correctness fix: a chunked write can legitimately be mid-flight
        // when the phone leaves the Live Preview screen. Without this, the single shared camera
        // frame buffer (Config::kCameraFrameBufferCount == 1) would never come back, jamming up
        // every other capture path (stills, video) for good.
        esp_camera_fb_return(pendingFrame_);
        pendingFrame_ = nullptr;
        pendingFrameOffset_ = 0;
    }
    if (client_.connected()) client_.stop();
}

void LiveStreamServer::poll(uint32_t nowMs) {
    if (!started_) return;

    if (!client_.connected()) {
        client_ = server_.available(); // an empty WiFiClient if nothing's pending -- harmless
        if (client_) {
            // Discard the viewer's own HTTP request line+headers -- this server always serves the
            // same stream regardless of path, no real request parsing needed. Bounded wait (not
            // unbounded delay()) since a real request arrives near-instantly on a local LAN; this
            // is the one place this class can block loop() for more than one chunk's worth of
            // time, and only briefly, only once per new connection, not per frame.
            uint32_t waitStartMs = millis();
            while (client_.connected() && !client_.available() && millis() - waitStartMs < 200) {
                delay(1);
            }
            while (client_.available()) client_.readStringUntil('\n');
            headerSent_ = false;
        }
    }

    if (!streaming_ || !client_ || !client_.connected()) return;

    // keepAlive_ (Config::kFeederCamMode) keeps the stream up for Home Assistant / Frigate to
    // reconnect to at will; otherwise it's a bounded field-setup preview.
    if (!keepAlive_ && nowMs - sessionStartMs_ >= Config::kLiveStreamMaxDurationMs) {
        stop();
        return;
    }

    if (!headerSent_) {
        sendMultipartHeader();
        headerSent_ = true;
        lastFrameMs_ = 0;
    }

    // Finish an in-flight frame's chunked write before considering starting a new one -- see
    // header comment on why this is chunked across calls at all.
    if (pendingFrame_) {
        continueFrame();
        return;
    }

    if (nowMs - lastFrameMs_ < Config::kLiveStreamFrameIntervalMs) return;
    // Must be computed BEFORE lastFrameMs_ is overwritten below -- an earlier version of this
    // computed it inside the frame-write function instead, measuring lastFrameMs_ against itself
    // (already updated to the current call's own nowMs) and producing a meaningless near-zero
    // value that underflowed as unsigned and printed as ~4.29 billion ms (real bug, fixed
    // 2026-08-10). Real intent: how much later than the intended kLiveStreamFrameIntervalMs
    // cadence this poll() call actually landed -- 0 on the very first frame of a session
    // (lastFrameMs_ reset to 0 by start()/header-send above, not a real previous frame to compare
    // against).
    uint32_t schedulingDelayMs = lastFrameMs_ > 0 ? (nowMs - lastFrameMs_) - Config::kLiveStreamFrameIntervalMs : 0;
    lastFrameMs_ = nowMs;
    startFrame(schedulingDelayMs);
}

void LiveStreamServer::sendMultipartHeader() {
    client_.print(
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n"
        "Connection: close\r\n\r\n"
    );
}

void LiveStreamServer::startFrame(uint32_t schedulingDelayMs) {
    uint32_t grabStartMs = millis();
    camera_fb_t *fb = esp_camera_fb_get();
    uint32_t grabMs = millis() - grabStartMs;
    if (!fb) {
        Serial0.println("[livestream] frame grab failed -- esp_camera_fb_get() returned null");
        return; // skip this frame rather than dropping the connection over one bad grab
    }

    // Small (well under 100 bytes) -- left as direct blocking prints rather than chunked, same
    // reasoning as PhotoServer/VideoServer's own header writes: a write this size essentially
    // always fits in existing socket buffer space even on a poor link, unlike the JPEG body below.
    client_.print("--frame\r\n");
    client_.print("Content-Type: image/jpeg\r\n");
    client_.print("Content-Length: ");
    client_.print(fb->len);
    client_.print("\r\n\r\n");

    pendingFrame_ = fb;
    pendingFrameOffset_ = 0;
    pendingFrameGrabMs_ = grabMs;
    pendingFrameSchedulingDelayMs_ = schedulingDelayMs;
    pendingFrameWriteStartMs_ = millis();
    continueFrame(); // send the first chunk now rather than idling a whole extra poll() call
}

void LiveStreamServer::continueFrame() {
    camera_fb_t *fb = pendingFrame_;

    // Real-hardware finding, 2026-08-10 (third round of this investigation): a stale/half-dead
    // TCP connection -- the phone's WKWebView backgrounded, the view dismissed, a brief WiFi
    // drop, anything that leaves the peer unresponsive without a clean close -- can leave
    // client_.connected() reporting true while writes to it silently stop making progress. One
    // frame was measured stalling for 75+ SECONDS before the underlying TCP stack's own
    // retransmission timeout finally gave up. Everything before and after that single frame was
    // healthy (well under 350ms even for large frames) -- this is a dead-peer-detection problem,
    // not a chronically weak link, so waiting on the OS to notice on its own isn't good enough.
    // Abandon a frame that's taken unreasonably long and force a fresh connection instead of
    // trusting that eventual detection.
    if (millis() - pendingFrameWriteStartMs_ > Config::kLiveStreamFrameWatchdogMs) {
        Serial0.printf("[livestream] frame watchdog -- abandoning stalled connection after %lums\n",
            (unsigned long)(millis() - pendingFrameWriteStartMs_));
        esp_camera_fb_return(fb);
        pendingFrame_ = nullptr;
        pendingFrameOffset_ = 0;
        client_.stop(); // poll() will accept a fresh connection on its next call
        headerSent_ = false;
        return;
    }

    size_t remaining = fb->len - pendingFrameOffset_;
    size_t chunk = remaining < Config::kLiveStreamWriteChunkBytes ? remaining : Config::kLiveStreamWriteChunkBytes;
    // Real bug fixed here: this used to advance pendingFrameOffset_ by the full requested chunk
    // regardless of how many bytes client_.write() actually reported sending -- silently
    // corrupting the JPEG stream on any partial send (exactly what a stalling/dead connection
    // produces) instead of correctly retrying the unsent remainder next call.
    size_t sent = client_.write(fb->buf + pendingFrameOffset_, chunk);
    pendingFrameOffset_ += sent;

    if (pendingFrameOffset_ < fb->len) return; // more to go (or nothing went out this call) -- resume next poll()

    client_.print("\r\n");
    uint32_t totalWriteMs = millis() - pendingFrameWriteStartMs_;
    Serial0.printf("[livestream] frame %u bytes -- sched delay %lums, grab %lums, write %lums\n",
        (unsigned)fb->len, (unsigned long)pendingFrameSchedulingDelayMs_, (unsigned long)pendingFrameGrabMs_, (unsigned long)totalWriteMs);

    esp_camera_fb_return(fb);
    pendingFrame_ = nullptr;
    pendingFrameOffset_ = 0;
}
