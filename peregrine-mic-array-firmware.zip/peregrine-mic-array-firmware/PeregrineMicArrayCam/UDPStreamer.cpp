#include "UDPStreamer.h"
#include <WiFi.h>
#include <cstring>
#include "Config.h"

bool UDPStreamer::begin(WiFiConfigStore &cfg) {
    cfg_ = &cfg;
    // Everything below reads the *effective* Wi-Fi config through cfg_ -- NVS overrides where the
    // app has set them (kSetWiFiConfig), Config.h defaults otherwise (CONFIGURABLE_FLEET_PLAN.md).
    const uint8_t role = cfg_->role();

    if (role == Config::kRolePrimary) {
        // Host our own AP -- see Config::kNetworkRole's comment and MIC_ARRAY_MASTER_AP_PLAN.md.
        // softAP() is synchronous (no connect-timeout loop needed the way STA join has below).
        WiFi.mode(WIFI_AP);
        if (!WiFi.softAP(cfg_->apSsid(), cfg_->apPassword(), cfg_->apChannel(), /*hidden=*/0, Config::kMaxAPStations)) {
            return false;
        }
    } else {
        // kRoleClient or kRoleSecondary -- both start by trying each configured candidate entry
        // in priority order (see WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16).
        WiFi.mode(WIFI_STA);
        if (!joinBestCandidate()) {
            if (role == Config::kRoleSecondary) {
                // Cold boot with no Primary reachable yet -- don't hard-fail the way
                // kRoleClient does below. A Secondary should be maximally resilient: this
                // converges to the exact same "host our own AP" state pollFailover() reaches
                // if an already-working connection is lost later, so SOME network comes up
                // regardless of whether the real Primary happens to be powered on first.
                Serial0.println("[failover] no Primary reachable at boot -- promoting immediately");
                promoteToFailedOver();
                udp_.begin(Config::kUDPPort);
                return true;
            }
            return false; // kRoleClient has no fallback -- unchanged behavior
        }
        lastConnectedMs_ = millis();
    }

    udp_.begin(Config::kUDPPort);
    return true;
}

// Shared by begin()'s STA branch and pollReconnect() (WIFI_MULTI_SSID_FALLBACK_PLAN.md Phase 1/2,
// added 2026-08-16) -- tries each Config::kWiFiCandidates entry in order, each given up to
// Config::kWiFiPerCandidateTimeoutMs, stopping at the first that reaches WL_CONNECTED. Assumes
// WiFi.mode() has already been set to WIFI_STA (or WIFI_AP_STA) by the caller -- this only drives
// the join attempts themselves, not the radio mode. Mirrors
// ../PeregrineMicArray/UDPStreamer.cpp's identical method (including its 2026-08-18
// normalizeApostrophes() fix -- see that file's copy of this function for the full rationale).
static String normalizeApostrophes(const String &s) {
    String out;
    out.reserve(s.length());
    for (size_t i = 0; i < s.length(); ) {
        if (i + 2 < s.length()
            && (uint8_t)s[i] == 0xE2 && (uint8_t)s[i + 1] == 0x80 && (uint8_t)s[i + 2] == 0x99) {
            out += '\''; // U+2019 -> plain ASCII apostrophe, for comparison purposes only
            i += 3;
        } else {
            out += s[i];
            i += 1;
        }
    }
    return out;
}

bool UDPStreamer::joinBestCandidate() {
    if (cfg_ == nullptr) return false;
    const int candidateCount = cfg_->candidateCount();

    int scanCount = WiFi.scanNetworks();

    for (int i = 0; i < candidateCount; i++) {
        const WiFiConfigStore::Credential &candidate = cfg_->candidate(i);
        if (!candidate.enabled) {
            Serial0.printf("[wifi] candidate %d/%d disabled -- skipping\n", i + 1, candidateCount);
            continue;
        }

        String joinSSID = candidate.ssid;
        String normalizedCandidate = normalizeApostrophes(joinSSID);
        for (int s = 0; s < scanCount; s++) {
            if (normalizeApostrophes(WiFi.SSID(s)) == normalizedCandidate) {
                joinSSID = WiFi.SSID(s);
                break;
            }
        }

        Serial0.printf("[wifi] trying candidate %d/%d: %s\n", i + 1, candidateCount, joinSSID.c_str());
        // Real hardware finding, 2026-08-17: calling WiFi.begin() again for the next candidate
        // right after our own per-candidate timeout gives up is NOT enough -- the ESP-IDF driver's
        // previous connection attempt can still be active internally even once WiFi.status() stops
        // being useful to us, and esp_wifi_set_config() then rejects the new credentials outright
        // ("E wifi:sta is connecting, cannot set config"), silently failing every remaining
        // candidate for the rest of this pass. WiFi.disconnect() explicitly aborts any in-flight
        // attempt and returns the driver to idle before the next WiFi.begin() -- harmless to call
        // on the very first candidate too (nothing in-flight yet). Delay is an unmeasured starting
        // point, just long enough for the driver to settle before the next begin().
        WiFi.disconnect(true);
        delay(100);
        WiFi.begin(joinSSID.c_str(), candidate.password.c_str());
        uint32_t startMs = millis();
        while (WiFi.status() != WL_CONNECTED && millis() - startMs <= Config::kWiFiPerCandidateTimeoutMs) {
            delay(250);
        }
        if (WiFi.status() == WL_CONNECTED) {
            Serial0.printf("[wifi] joined %s\n", joinSSID.c_str());
            // Real hardware finding, 2026-08-17 (see
            // ../PeregrineMicArrayRearSensor/UDPStreamer.cpp's identical fix for the full
            // rationale): ESP32 WiFi modem sleep (default-enabled in STA mode) can intermittently
            // miss incoming UDP packets while dozing between beacon intervals -- observed on the
            // rear sensor as a session that worked for a while then permanently stopped receiving.
            // Disabled defensively here too. MUST live here, not in begin() -- pollReconnect()
            // calls this method directly, bypassing begin() entirely; a first real-hardware test
            // with this placed in begin() instead never actually ran it for exactly that reason.
            WiFi.setSleep(false);
            WiFi.scanDelete();
            return true;
        }
    }
    WiFi.scanDelete();
    Serial0.println("[wifi] exhausted every kWiFiCandidates entry -- none reachable");
    return false;
}

// Phase 2 of WIFI_MULTI_SSID_FALLBACK_PLAN.md -- only meaningful for kNetworkRole == kRoleClient
// (kRoleSecondary has its own, more specialized runtime recovery via pollFailover()'s
// promote-to-AP path; kRolePrimary/a failed-over Secondary hosts, nothing to reconnect to). If the
// STA link has been down for Config::kWiFiReconnectGraceMs, re-runs joinBestCandidate() from the
// top -- covers the gap Phase 1 alone left open: a node that joined some candidate at begin() but
// later dropped off it entirely had no runtime recovery path beyond the ESP32 core's own default
// auto-reconnect. Known, accepted cost: this blocks loop() for up to
// candidateCount * kWiFiPerCandidateTimeoutMs while it runs -- see Config::kWiFiReconnectGraceMs's
// comment for why that's fine here (capture tasks are pinned separately, and no UDP traffic is
// possible without a live link anyway).
void UDPStreamer::pollReconnect() {
    if (cfg_ == nullptr || cfg_->role() != Config::kRoleClient) return;
    if (WiFi.status() == WL_CONNECTED) {
        lastConnectedMs_ = millis();
        return;
    }
    if (millis() - lastConnectedMs_ < Config::kWiFiReconnectGraceMs) return;
    Serial0.println("[wifi] STA link down past the grace period -- retrying the candidate list");
    joinBestCandidate();
    // Reset the grace clock regardless of outcome (success or another exhausted pass) -- avoids a
    // tight retry loop hammering every single loop() iteration if nothing is currently reachable,
    // same throttling lesson as MicArrayNodeConnection's own reconnect cooldown (app side).
    lastConnectedMs_ = millis();
}

void UDPStreamer::promoteToFailedOver() {
    Serial0.println("[failover] promoting to WIFI_AP_STA -- hosting our own AP while watching for the real Primary");
    WiFi.mode(WIFI_AP_STA);
    const char *apSsid = cfg_ ? cfg_->apSsid() : Config::kWiFiSSID;
    const char *apPass = cfg_ ? cfg_->apPassword() : Config::kWiFiPassword;
    const uint8_t apChan = cfg_ ? cfg_->apChannel() : (uint8_t)Config::kWiFiChannel;
    WiFi.softAP(apSsid, apPass, apChan, /*hidden=*/0, Config::kMaxAPStations);
    failedOver_ = true;
    lastPrimaryScanMs_ = millis();
}

void UDPStreamer::pollFailover() {
    if (cfg_ == nullptr || cfg_->role() != Config::kRoleSecondary) return;

    if (!failedOver_) {
        if (WiFi.status() == WL_CONNECTED) {
            lastConnectedMs_ = millis();
            return;
        }
        if (millis() - lastConnectedMs_ > Config::kFailoverTimeoutMs) {
            Serial0.println("[failover] lost the Primary's connection -- promoting");
            promoteToFailedOver();
        }
        return;
    }

    // Currently failed-over -- periodically re-scan for the real Primary specifically (BSSID, not
    // just SSID -- see Config::kPrimaryBSSID's comment). WiFi.scanNetworks() blocks, so this is
    // deliberately infrequent (Config::kPrimaryRescanIntervalMs).
    if (millis() - lastPrimaryScanMs_ < Config::kPrimaryRescanIntervalMs) return;
    lastPrimaryScanMs_ = millis();

    int found = WiFi.scanNetworks();
    bool primaryReachable = false;
    for (int i = 0; i < found; i++) {
        uint8_t *bssid = WiFi.BSSID(i);
        if (bssid != nullptr && memcmp(bssid, Config::kPrimaryBSSID, 6) == 0) {
            primaryReachable = true;
            break;
        }
    }
    WiFi.scanDelete();

    if (primaryReachable) {
        Serial0.println("[failover] real Primary reachable again -- stepping down");
        WiFi.softAPdisconnect(true);
        WiFi.mode(WIFI_STA);
        // Reclaim reconnect stays pinned to the AP identity (candidate[0] is this fleet's Primary
        // by the same convention as before), not the whole candidate list.
        if (cfg_ && cfg_->candidateCount() > 0) {
            WiFi.begin(cfg_->candidate(0).ssid.c_str(), cfg_->candidate(0).password.c_str());
        } else if (cfg_) {
            WiFi.begin(cfg_->apSsid(), cfg_->apPassword());
        }
        failedOver_ = false;
        lastConnectedMs_ = millis();
    }
}

bool UDPStreamer::isCurrentlyHosting() const {
    const uint8_t role = cfg_ ? cfg_->role() : (uint8_t)Config::kNetworkRole;
    return role == Config::kRolePrimary
        || (role == Config::kRoleSecondary && failedOver_);
}

bool UDPStreamer::isActingAsRosterMaster() const {
    const bool rmaster = cfg_ ? cfg_->isRosterMaster() : Config::kIsRosterMaster;
    return isCurrentlyHosting() || rmaster;
}

void UDPStreamer::sendWiFiConfigReport(IPAddress toIP, uint16_t toPort) {
    if (cfg_ == nullptr) return;
    // Layout: see NetworkProtocol.h's kWiFiConfigReport comment. Never emits password bytes.
    uint8_t buf[2 + 5 + 1 + 32 + 1 + WiFiConfigStore::kMaxCandidates * (1 + 32) + 1];
    size_t off = 0;
    buf[off++] = Protocol::kVersion;
    buf[off++] = Protocol::kWiFiConfigReport;
    buf[off++] = cfg_->role();
    buf[off++] = cfg_->apChannel();
    buf[off++] = cfg_->isRosterMaster() ? 1 : 0;
    buf[off++] = cfg_->apPasswordIsDefault() ? 1 : 0;
    buf[off++] = cfg_->awaitingProof() ? 1 : 0;

    const char *ssid = cfg_->apSsid();
    size_t sn = strlen(ssid);
    if (sn > 32) sn = 32;
    buf[off++] = (uint8_t)sn;
    memcpy(buf + off, ssid, sn);
    off += sn;

    uint8_t n = cfg_->candidateCount();
    if (n > WiFiConfigStore::kMaxCandidates) n = WiFiConfigStore::kMaxCandidates;
    buf[off++] = n;
    uint8_t disabledMask = 0;
    for (uint8_t i = 0; i < n; i++) {
        const char *cs = cfg_->candidate(i).ssid.c_str();
        size_t cn = strlen(cs);
        if (cn > 32) cn = 32;
        buf[off++] = (uint8_t)cn;
        memcpy(buf + off, cs, cn);
        off += cn;
        if (!cfg_->candidate(i).enabled) disabledMask |= (uint8_t)(1u << i);
    }
    // Trailing disabled-candidate bitmask (bit i set = candidate i is off). Additive: an older app
    // stops after `n` entries and never reads this byte.
    buf[off++] = disabledMask;

    udp_.beginPacket(toIP, toPort);
    udp_.write(buf, off);
    udp_.endPacket();
}

void UDPStreamer::poll() {
    int packetSize = udp_.parsePacket();
    if (packetSize > 0) {
        // 640 not 64: kSetWiFiConfig's candidate-list op carries up to
        // 6 x (SSID<=32 + pass<=63) len-prefixed -- ~586 bytes worst case. Every other inbound
        // control packet is tiny, so this only affects the one path (CONFIGURABLE_FLEET_PLAN.md).
        uint8_t buf[640];
        int len = udp_.read(buf, sizeof(buf));
        if (len > 0) {
            handlePacket(buf, len, udp_.remoteIP(), udp_.remotePort());
        }
    }

    if (streaming_ && (millis() - lastClientActivityMs_) > Config::kStreamingInactivityTimeoutMs) {
        streaming_ = false;
    }
}

void UDPStreamer::handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort) {
    if (len < 2) return;
    uint8_t type = data[1];

    switch (type) {
        case Protocol::kHandshakePing: {
            Protocol::HandshakePongPacket pong;
            pong.version = Protocol::kVersion;
            pong.type = Protocol::kHandshakePong;
            pong.magic0 = Protocol::kPongMagic0;
            pong.magic1 = Protocol::kPongMagic1;
            udp_.beginPacket(remoteIP, remotePort);
            udp_.write((const uint8_t *)&pong, sizeof(pong));
            udp_.endPacket();
            break;
        }
        case Protocol::kSessionStart: {
            clientIP_ = remoteIP;
            clientPort_ = remotePort;
            streaming_ = true;
            lastClientActivityMs_ = millis();
            break;
        }
        case Protocol::kSessionStop: {
            if (remoteIP == clientIP_ && remotePort == clientPort_) {
                streaming_ = false;
            }
            break;
        }
        case Protocol::kSetRemoteLogging: {
            // FIELD_DEBUG_PLAN.md, added 2026-08-18.
            if (len < 3) break;
            remoteLoggingRequested_ = true;
            remoteLoggingRequestedValue_ = (data[2] != 0);
            break;
        }
        case Protocol::kSetFeederCamMode: {
            // Runtime feeder-cam toggle -- HOME_ASSISTANT.md.
            if (len < 3) break;
            feederCamModeRequested_ = true;
            feederCamModeRequestedValue_ = (data[2] != 0);
            break;
        }
        case Protocol::kSetCameraEnabled: {
            // Runtime camera on/off toggle -- frees CPU/PSRAM/DMA for GPS fix + sound capture.
            if (len < 3) break;
            cameraEnabledRequested_ = true;
            cameraEnabledRequestedValue_ = (data[2] != 0);
            break;
        }
        case Protocol::kGetWiFiConfig: {
            sendWiFiConfigReport(remoteIP, remotePort);
            break;
        }
        case Protocol::kSetWiFiConfig: {
            // CONFIGURABLE_FLEET_PLAN.md Part A. Staging ops mutate NVS but not the running radio;
            // only kWiFiOpCommit / kWiFiOpResetDefaults reboot.
            if (cfg_ == nullptr || len < 3) break;
            const uint8_t op = data[2];
            if (op == Protocol::kWiFiOpSetAp) {
                if (len < 4) break;
                uint8_t channel = data[3];
                size_t off = 4;
                if (off >= (size_t)len) break;
                uint8_t ssLen = data[off++];
                if (off + ssLen + 1 > (size_t)len) break;
                char ssid[33] = {0};
                memcpy(ssid, data + off, ssLen > 32 ? 32 : ssLen);
                off += ssLen;
                uint8_t pwLen = data[off++];
                if (off + pwLen > (size_t)len) break;
                char pass[64] = {0};
                memcpy(pass, data + off, pwLen > 63 ? 63 : pwLen);
                cfg_->stageAp(ssid, pass, channel);
                Serial0.printf("[wcfg] staged AP: ssid='%s' channel=%u\n", ssid, (unsigned)channel);
            } else if (op == Protocol::kWiFiOpSetRole) {
                if (len < 5) break;
                cfg_->stageRole(data[3], data[4] != 0);
                Serial0.printf("[wcfg] staged role=%u rosterMaster=%u\n", (unsigned)data[3], (unsigned)(data[4] != 0));
            } else if (op == Protocol::kWiFiOpSetCandidates) {
                if (len < 4) break;
                uint8_t count = data[3];
                size_t off = 4;
                struct { char ssid[33]; char pass[64]; } parsed[WiFiConfigStore::kMaxCandidates] = {};
                uint8_t parsedCount = 0;
                for (uint8_t c = 0; c < count && c < WiFiConfigStore::kMaxCandidates; c++) {
                    if (off >= (size_t)len) break;
                    uint8_t ssLen = data[off++];
                    if (off + ssLen + 1 > (size_t)len) break;
                    memcpy(parsed[parsedCount].ssid, data + off, ssLen > 32 ? 32 : ssLen);
                    off += ssLen;
                    uint8_t pwLen = data[off++];
                    if (off + pwLen > (size_t)len) break;
                    memcpy(parsed[parsedCount].pass, data + off, pwLen > 63 ? 63 : pwLen);
                    off += pwLen;
                    parsedCount++;
                }
                // Trailing disabled-candidate bitmask (see kWiFiConfigReport). Absent => all enabled.
                uint8_t disabledMask = (off < (size_t)len) ? data[off] : 0;
                cfg_->stageCandidatesBegin();
                for (uint8_t c = 0; c < parsedCount; c++) {
                    cfg_->stageCandidateAdd(parsed[c].ssid, parsed[c].pass, !(disabledMask & (uint8_t)(1u << c)));
                }
                Serial0.printf("[wcfg] staged %u candidate(s), disabledMask=0x%02X\n",
                    (unsigned)parsedCount, (unsigned)disabledMask);
            } else if (op == Protocol::kWiFiOpResetDefaults) {
                Serial0.println("[wcfg] reset to Config.h defaults requested -- wiping NVS + rebooting");
                cfg_->resetToDefaults();
                sendWiFiConfigReport(remoteIP, remotePort);
                delay(250);
                ESP.restart();
            } else if (op == Protocol::kWiFiOpCommit) {
                if (cfg_->commit()) {
                    Serial0.println("[wcfg] committed staged config -- rebooting (recovery arm set)");
                } else {
                    Serial0.println("[wcfg] commit FAILED (serialize/NVS error) -- not rebooting");
                    sendWiFiConfigReport(remoteIP, remotePort);
                    break;
                }
                sendWiFiConfigReport(remoteIP, remotePort);
                delay(250);
                ESP.restart();
            }
            break;
        }
        case Protocol::kSetFrequencyBands: {
            if (len < 3) break;
            uint8_t count = data[2];
            if (count > Protocol::kMaxDOABands) count = Protocol::kMaxDOABands;
            if (len < 3 + (int)(count * sizeof(Protocol::FrequencyBandSlot))) break;

            for (uint8_t i = 0; i < count; i++) {
                memcpy(&activeBands_[i], data + 3 + i * sizeof(Protocol::FrequencyBandSlot), sizeof(Protocol::FrequencyBandSlot));
            }
            activeBandCount_ = count;
            break;
        }
        case Protocol::kNodeAnnounce: {
            // Broadcast from a sibling node, not the phone -- only meaningful if THIS node is
            // CURRENTLY the roster master, i.e. isActingAsRosterMaster() -- either hosting the AP
            // (isCurrentlyHosting(), always true for Primary, true for a failed-over Secondary too
            // as of MIC_ARRAY_MASTER_AP_PLAN.md §4/§5, implemented 2026-08-14) OR explicitly
            // designated as roster master via Config::kIsRosterMaster (added 2026-08-16, for an
            // all-kRoleClient shared-external-network deployment where nothing hosts at all --
            // see that constant's own doc comment). Mirrors
            // ../PeregrineMicArray/UDPStreamer.cpp's identical handler. Every other node just
            // ignores it, same as hearing its own announce echoed back (addOrRefresh on our own IP
            // would be harmless either way, but there's no reason to store it).
            //
            // Real Serial logging added 2026-08-12 -- see ../PeregrineMicArray/UDPStreamer.cpp's
            // identical addition for the full rationale (this whole path was silent before, on
            // both accept and every reject reason). Rare event, safe to log unconditionally.
            if (!isActingAsRosterMaster()) {
                Serial0.printf("[roster] kNodeAnnounce from %s ignored -- this node is not currently acting as roster master\n", remoteIP.toString().c_str());
                break;
            }
            if (len < (int)sizeof(Protocol::NodeIdentityPacket)) {
                Serial0.printf("[roster] kNodeAnnounce from %s ignored -- packet too short (%d bytes, need %u)\n", remoteIP.toString().c_str(), len, (unsigned)sizeof(Protocol::NodeIdentityPacket));
                break;
            }
            Protocol::NodeIdentityPacket identity;
            memcpy(&identity, data, sizeof(identity));
            // A different user's node sharing this WiFi network would otherwise get silently
            // aggregated into this roster too -- see NodeIdentityPacket's fleetId comment.
            if (identity.fleetId != Config::kFleetId) {
                Serial0.printf("[roster] kNodeAnnounce from %s ignored -- fleetId mismatch (got 0x%08lX, this fleet is 0x%08lX)\n",
                    remoteIP.toString().c_str(), (unsigned long)identity.fleetId, (unsigned long)Config::kFleetId);
                break;
            }
            roster_.addOrRefresh(remoteIP, identity, millis());
            Serial0.printf("[roster] kNodeAnnounce from %s accepted -- nodeType %u, roster now has %d entries\n",
                remoteIP.toString().c_str(), identity.nodeType, roster_.count());
            break;
        }
        case Protocol::kRosterRequest: {
            // Always answered, even on a non-master node (which just has nothing to report) --
            // the phone doesn't need to know in advance which connected node is master, it can
            // send this to any of them. Not gated on `streaming_`, matching kHandshakePing/Pong's
            // "works standalone, no session needed" precedent.
            roster_.pruneStale(millis());
            Serial0.printf("[roster] kRosterRequest from %s -- replying with %d entries\n", remoteIP.toString().c_str(), roster_.count());
            Protocol::RosterResponsePacket response{};
            response.version = Protocol::kVersion;
            response.type = Protocol::kRosterResponse;
            response.count = (uint8_t)roster_.count();
            for (int i = 0; i < roster_.count(); i++) {
                IPAddress ip = roster_.ip(i);
                const Protocol::NodeIdentityPacket &identity = roster_.identity(i);
                response.entries[i].ipOctet0 = ip[0];
                response.entries[i].ipOctet1 = ip[1];
                response.entries[i].ipOctet2 = ip[2];
                response.entries[i].ipOctet3 = ip[3];
                response.entries[i].nodeType = identity.nodeType;
                response.entries[i].hasGPS = identity.hasGPS;
                response.entries[i].hasCompass = identity.hasCompass;
                response.entries[i].hasMotionSensor = identity.hasMotionSensor;
                response.entries[i].micCount = identity.micCount;
                memcpy(response.entries[i].deviceId, identity.deviceId, 6);
                response.entries[i].hasPresenceSensor = identity.hasPresenceSensor; // were never relayed before 2026-09-26
                response.entries[i].hasSpeaker = identity.hasSpeaker;
            }
            size_t responseSize = sizeof(Protocol::RosterResponsePacket) - sizeof(Protocol::RosterEntryPacket) * (Protocol::kMaxRosterEntries - roster_.count());
            udp_.beginPacket(remoteIP, remotePort);
            udp_.write((const uint8_t *)&response, responseSize);
            udp_.endPacket();
            break;
        }
        case Protocol::kPhotoCaptureNow: {
            manualCaptureRequested_ = true;
            break;
        }
        case Protocol::kSetPresenceRange: {
            if (len < 6) break;
            presenceRangeRequestedCm_ = data[2] | (data[3] << 8);
            presenceHoldRequestedS_ = data[4] | (data[5] << 8);
            presenceRangeRequested_ = true;
            break;
        }
        case Protocol::kSetPresenceCapture: {
            if (len < 3) break;
            presenceCaptureRequested_ = true;
            presenceCaptureRequestedValue_ = (data[2] != 0);
            break;
        }
        case Protocol::kSetPhotoMode: {
            if (len < 3) break;
            photoAutoMode_ = (data[2] == 0);
            break;
        }
        case Protocol::kSetPhotoInterval: {
            if (len < 6) break;
            uint32_t requested = (uint32_t)data[2] | ((uint32_t)data[3] << 8) |
                                 ((uint32_t)data[4] << 16) | ((uint32_t)data[5] << 24);
            // Clamp to a sane band: below ~1s the single frame buffer / HTTP server can't keep up,
            // above 10min is well past any birding use and just risks an accidental "captures off".
            if (requested < 1000) requested = 1000;
            if (requested > 600000) requested = 600000;
            photoMinIntervalMs_ = requested;
            Serial0.printf("[photo] capture interval set to %lu ms\n", (unsigned long)photoMinIntervalMs_);
            break;
        }
        case Protocol::kVideoRecordStart: {
            // Real diagnostic gap found 2026-08-17: the whole video-record path had zero Serial
            // logging anywhere, unlike photo/live-stream -- made a real user-reported "video not
            // being created" symptom undiagnosable from the field. This confirms the command
            // actually arrived over the network at all, distinct from the .ino's own logging of
            // what happened once it got here (accepted/rejected/finished).
            if (len < 3) {
                Serial0.printf("[video] kVideoRecordStart dropped -- packet too short (%u bytes, need >= 3)\n", (unsigned)len);
                break;
            }
            Serial0.println("[video] kVideoRecordStart received");
            videoStartRequested_ = true;
            videoStartIncludeAudio_ = (data[2] != 0);
            break;
        }
        case Protocol::kVideoRecordStop: {
            Serial0.println("[video] kVideoRecordStop received");
            videoStopRequested_ = true;
            break;
        }
        case Protocol::kVideoStreamStart: {
            videoStreamStartRequested_ = true;
            break;
        }
        case Protocol::kVideoStreamStop: {
            videoStreamStopRequested_ = true;
            break;
        }
        default:
            break;
    }
}

IPAddress UDPStreamer::broadcastAddress() const {
    IPAddress local = WiFi.localIP();
    IPAddress mask = WiFi.subnetMask();
    return IPAddress(
        local[0] | (~mask[0] & 0xFF),
        local[1] | (~mask[1] & 0xFF),
        local[2] | (~mask[2] & 0xFF),
        local[3] | (~mask[3] & 0xFF)
    );
}

void UDPStreamer::fillDeviceId(uint8_t *out) {
    uint64_t mac = ESP.getEfuseMac();
    for (int i = 0; i < 6; i++) {
        out[i] = (uint8_t)(mac >> (8 * i));
    }
}

void UDPStreamer::sendNodeAnnounce() {
    // Peer-to-peer, not to the registered phone client -- deliberately not gated on `streaming_`
    // (see .h's doc comment on this method).
    Protocol::NodeIdentityPacket packet{}; // value-init: every field defined, incl. the trailing capability bytes
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kNodeAnnounce;
    packet.nodeType = Config::kNodeType;
    packet.hasGPS = Config::kGPSEnabled ? 1 : 0;
    packet.hasCompass = Config::kCompassEnabled ? 1 : 0; // COMPASS_HEADING_HARDWARE_PLAN.md
    packet.hasMotionSensor = 0; // the optional C4002 is reported via hasPresenceSensor instead (the PIR it replaced is gone)
    packet.micCount = Config::kMicCount;
    packet.fleetId = Config::kFleetId;
    fillDeviceId(packet.deviceId);
    // Real bug fixed 2026-09-26: these two trailing bytes were never set here, so they went out as
    // whatever was on the stack -- the app could mistake an ordinary Cam node for a security node.
    packet.hasPresenceSensor = presenceSensorByte();
    packet.hasSpeaker = 0; // no speaker on this hardware

    IPAddress dest = broadcastAddress();
    udp_.beginPacket(dest, Config::kUDPPort);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
    // Real Serial logging added 2026-08-12, same reasoning as kNodeAnnounce's receive-side
    // logging above -- confirms from the SENDING node's own Serial output that announces are
    // actually going out (and to what computed broadcast address).
    Serial0.printf("[roster] sent kNodeAnnounce to %s (nodeType %u, fleetId 0x%08lX)\n",
        dest.toString().c_str(), Config::kNodeType, (unsigned long)Config::kFleetId);
}

void UDPStreamer::sendAudioFrame(uint32_t seq, const int16_t *samples, int count) {
    if (!streaming_) return;

    Protocol::AudioFrameHeader header;
    header.version = Protocol::kVersion;
    header.type = Protocol::kAudioFrame;
    header.seq = seq;
    header.sampleRate = Config::kSampleRateHz;
    header.encoding = Protocol::kEncodingInt16;
    header.reserved = 0;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&header, sizeof(header));
    udp_.write((const uint8_t *)samples, count * sizeof(int16_t));
    udp_.endPacket();
}

void UDPStreamer::sendStereoAudioFrame(uint32_t seq, const int16_t *left, const int16_t *right, int countPerChannel) {
    if (!streaming_) return;

    Protocol::AudioFrameHeader header;
    header.version = Protocol::kVersion;
    header.type = Protocol::kStereoAudioFrame;
    header.seq = seq;
    header.sampleRate = Config::kSampleRateHz;
    header.encoding = Protocol::kEncodingInt16;
    header.reserved = 2; // channel count, informational -- see NetworkProtocol.h's AudioFrameHeader comment

    // Interleave L/R into one small stack buffer before the single UDP write -- matches
    // sendAudioFrame's one-write-per-packet shape rather than two separate writes per sample,
    // which would double the syscall/framing overhead for no benefit (the interleave itself is
    // cheap, countPerChannel is bounded by Config::kStereoAudioSamplesPerChannel).
    int16_t interleaved[Config::kStereoAudioSamplesPerChannel * 2];
    for (int i = 0; i < countPerChannel; i++) {
        interleaved[i * 2] = left[i];
        interleaved[i * 2 + 1] = right[i];
    }

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&header, sizeof(header));
    udp_.write((const uint8_t *)interleaved, countPerChannel * 2 * sizeof(int16_t));
    udp_.endPacket();
}

void UDPStreamer::sendAudioLevels(uint32_t timestampMs, int16_t topLeftPeak, int16_t topRightPeak, int16_t bottomLeftPeak, int16_t bottomRightPeak, bool usingBottomPair) {
    if (!streaming_) return;

    Protocol::AudioLevelsPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kAudioLevels;
    packet.timestampMs = timestampMs;
    packet.topLeftPeak = topLeftPeak;
    packet.topRightPeak = topRightPeak;
    packet.bottomLeftPeak = bottomLeftPeak;
    packet.bottomRightPeak = bottomRightPeak;
    packet.activePair = usingBottomPair ? 1 : 0;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendDOATelemetry(uint32_t seq, uint32_t timestampMs, float azimuthDeg, float confidence, float relativeLevel, uint8_t bandId) {
    if (!streaming_) return;

    Protocol::DOATelemetryPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kDOATelemetry;
    packet.seq = seq;
    packet.timestampMs = timestampMs;
    packet.azimuthDeg = azimuthDeg;
    packet.confidence = confidence;
    packet.relativeLevel = relativeLevel;
    packet.bandId = bandId;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendTimedOnset(uint32_t seq, uint32_t utcSecond, uint32_t utcMicros, uint16_t bandId, float peakLevel, float confidence) {
    if (!streaming_) return;

    Protocol::TimedOnsetPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kTimedOnset;
    packet.seq = seq;
    packet.utcSecond = utcSecond;
    packet.utcMicros = utcMicros;
    packet.bandId = bandId;
    packet.peakLevel = peakLevel;
    packet.confidence = confidence;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendNodeIdentity() {
    if (!streaming_) return;

    Protocol::NodeIdentityPacket packet{}; // value-init: every field defined, incl. the trailing capability bytes
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kNodeIdentity;
    packet.nodeType = Config::kNodeType;
    packet.hasGPS = Config::kGPSEnabled ? 1 : 0;
    packet.hasCompass = Config::kCompassEnabled ? 1 : 0; // COMPASS_HEADING_HARDWARE_PLAN.md
    packet.hasMotionSensor = 0; // the optional C4002 is reported via hasPresenceSensor instead (the PIR it replaced is gone)
    packet.micCount = Config::kMicCount;
    packet.fleetId = Config::kFleetId; // not used by the phone, just keeping the shared struct fully populated
    fillDeviceId(packet.deviceId);
    // Real bug fixed 2026-09-26: these two trailing bytes were never set here, so they went out as
    // whatever was on the stack -- the app could mistake an ordinary Cam node for a security node.
    packet.hasPresenceSensor = presenceSensorByte();
    packet.hasSpeaker = 0; // no speaker on this hardware

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
    sendPresenceConfig();
}

void UDPStreamer::sendGPSPosition(
    uint32_t timestampMs, double latitude, double longitude, float horizontalAccuracyMeters, bool hasFix,
    uint8_t satellitesInView, uint32_t charsProcessed, uint32_t sentencesValid, uint32_t sentencesInvalid,
    uint32_t ppsEdgeCount, uint32_t ppsLastIntervalMicros
) {
    if (!streaming_) return;

    Protocol::GPSPositionPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kGPSPosition;
    packet.timestampMs = timestampMs;
    packet.latitude = latitude;
    packet.longitude = longitude;
    packet.horizontalAccuracyMeters = horizontalAccuracyMeters;
    packet.hasFix = hasFix ? 1 : 0;
    packet.satellitesInView = satellitesInView;
    packet.charsProcessed = charsProcessed;
    packet.sentencesValid = sentencesValid;
    packet.sentencesInvalid = sentencesInvalid;
    packet.ppsEdgeCount = ppsEdgeCount;
    packet.ppsLastIntervalMicros = ppsLastIntervalMicros;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

// COMPASS_HEADING_HARDWARE_PLAN.md -- see CompassReader.h/NetworkProtocol.h's CompassHeadingPacket
// comment. `headingDeg` is raw magnetometer heading, no declination correction.
void UDPStreamer::sendOrientation(uint32_t timestampMs, const float *gravity, const float *magnetic, uint8_t calibration) {
    if (!streaming_) return;

    Protocol::OrientationPacket packet{};
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kOrientation;
    packet.timestampMs = timestampMs;
    for (int i = 0; i < 3; i++) {
        packet.gravity[i] = gravity[i];
        packet.magnetic[i] = magnetic[i];
    }
    packet.calibration = calibration;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendCompassHeading(uint32_t timestampMs, float headingDeg) {
    if (!streaming_) return;

    Protocol::CompassHeadingPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kCompassHeading;
    packet.timestampMs = timestampMs;
    packet.headingDeg = headingDeg;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendPhotoReady(uint32_t timestampMs, uint32_t photoId, uint32_t photoSizeBytes) {
    if (!streaming_) return;

    Protocol::PhotoReadyPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kPhotoReady;
    packet.timestampMs = timestampMs;
    packet.photoId = photoId;
    packet.photoSizeBytes = photoSizeBytes;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendMotionTrigger(uint32_t timestampMs, float signalStrength) {
    if (!streaming_) return;

    Protocol::MotionTriggerPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kMotionTrigger;
    packet.timestampMs = timestampMs;
    packet.signalStrength = signalStrength;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

// speedMps < 0 = the sensor doesn't report speed -> 0xFFFF on the wire.
void UDPStreamer::sendPresenceUpdate(uint32_t timestampMs, float distanceCm, float speedMps, uint8_t movement, uint8_t targetState) {
    if (!streaming_) return;

    Protocol::PresenceUpdatePacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kPresenceUpdate;
    packet.timestampMs = timestampMs;
    packet.distanceCm = distanceCm;
    packet.speedCmPerSec = speedMps < 0.0f ? 0xFFFF : (uint16_t)fminf(speedMps * 100.0f + 0.5f, 65534.0f);
    packet.movement = movement;
    packet.targetState = targetState;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

// FIELD_DEBUG_PLAN.md, added 2026-08-18 -- mirrors ../PeregrineMicArray/UDPStreamer.cpp's identical
// pair verbatim, see that file's doc comments for the full rationale.
void UDPStreamer::sendLogLine(const char *line) {
    if (clientPort_ == 0) return;

    size_t length = strlen(line);
    if (length > Protocol::kMaxLogLineLength) length = Protocol::kMaxLogLineLength;

    Protocol::LogLineHeader header;
    header.version = Protocol::kVersion;
    header.type = Protocol::kLogLine;
    header.length = (uint8_t)length;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&header, sizeof(header));
    udp_.write((const uint8_t *)line, length);
    udp_.endPacket();
}

bool UDPStreamer::consumeSetRemoteLoggingRequest(bool &enabled) {
    if (!remoteLoggingRequested_) return false;
    remoteLoggingRequested_ = false;
    enabled = remoteLoggingRequestedValue_;
    return true;
}

bool UDPStreamer::consumeSetFeederCamModeRequest(bool &enabled) {
    if (!feederCamModeRequested_) return false;
    feederCamModeRequested_ = false;
    enabled = feederCamModeRequestedValue_;
    return true;
}

bool UDPStreamer::consumeSetPresenceRangeRequest(uint16_t &maxRangeCm, uint16_t &holdS) {
    if (!presenceRangeRequested_) return false;
    presenceRangeRequested_ = false;
    maxRangeCm = presenceRangeRequestedCm_;
    holdS = presenceHoldRequestedS_;
    return true;
}

void UDPStreamer::sendPresenceConfig() {
    if (!streaming_ || !presenceConfigKnown_) return;
    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&presenceConfig_, sizeof(presenceConfig_));
    udp_.endPacket();
}

bool UDPStreamer::consumeSetPresenceCaptureRequest(bool &enabled) {
    if (!presenceCaptureRequested_) return false;
    presenceCaptureRequested_ = false;
    enabled = presenceCaptureRequestedValue_;
    return true;
}

bool UDPStreamer::consumeSetCameraEnabledRequest(bool &enabled) {
    if (!cameraEnabledRequested_) return false;
    cameraEnabledRequested_ = false;
    enabled = cameraEnabledRequestedValue_;
    return true;
}

bool UDPStreamer::consumeManualCaptureRequest() {
    bool requested = manualCaptureRequested_;
    manualCaptureRequested_ = false;
    return requested;
}

bool UDPStreamer::consumeVideoStartRequest(bool &includeAudio) {
    if (!videoStartRequested_) return false;
    videoStartRequested_ = false;
    includeAudio = videoStartIncludeAudio_;
    return true;
}

bool UDPStreamer::consumeVideoStopRequest() {
    bool requested = videoStopRequested_;
    videoStopRequested_ = false;
    return requested;
}

void UDPStreamer::sendVideoReady(uint32_t timestampMs, uint32_t videoId, uint16_t frameCount, uint16_t frameIntervalMs, uint32_t audioSampleCount) {
    // Deliberately NOT gated on `streaming_` -- a video session can run and finish while the phone
    // is backgrounded/the app is elsewhere (see VideoRecordStartPacket's "runs in the background"
    // comment); the phone still needs to learn the clip is ready even if it isn't actively
    // streaming DOA/audio telemetry right now. Requires a registered client address at all,
    // though (kSessionStart must have happened at least once), same as every other send here.
    if (clientPort_ == 0) return;

    Protocol::VideoReadyPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kVideoReady;
    packet.videoId = videoId;
    packet.timestampMs = timestampMs;
    packet.frameCount = frameCount;
    packet.frameIntervalMs = frameIntervalMs;
    packet.audioSampleCount = audioSampleCount;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

bool UDPStreamer::consumeVideoStreamStartRequest() {
    bool requested = videoStreamStartRequested_;
    videoStreamStartRequested_ = false;
    return requested;
}

bool UDPStreamer::consumeVideoStreamStopRequest() {
    bool requested = videoStreamStopRequested_;
    videoStreamStopRequested_ = false;
    return requested;
}
