#include "VideoRecorder.h"
#include <cstdio>
#include <cstring>
#include <esp_camera.h>
#include "Config.h"

bool VideoRecorder::beginSD() {
    sdReady_ = SD_MMC.setPins(Config::kSDClkPin, Config::kSDCmdPin, Config::kSDDataPin) && SD_MMC.begin("/sdcard", true); // true = 1-bit mode
    return sdReady_;
}

bool VideoRecorder::start(uint32_t videoId, bool includeAudio, uint32_t nowMs) {
    if (!sdReady_ || recording_) return false;

    // Real hardware finding, 2026-08-17 (see this class's own header comment on
    // deleteSessionDirectory): clean up an OLD session's files here, at the START of a new
    // recording, not the immediately-previous one -- the phone may still be mid-fetch on the video
    // that JUST finished (frame-by-frame HTTP, can take a while -- see MicArrayVideoFetcher.swift),
    // and deleting out from under an in-flight fetch would corrupt or truncate it. Something two
    // generations back is old enough that the phone has almost certainly already composed and
    // saved or discarded it. `videoId` here is the NEW session's id (starts at 1), so `videoId - 2`
    // only underflows for the first two sessions ever, both harmlessly no-op (nothing to delete).
    if (videoId >= 3) {
        deleteSessionDirectory(videoId - 2);
    }

    videoId_ = videoId;
    includeAudio_ = includeAudio;
    startMs_ = nowMs;
    lastFrameMs_ = 0; // forces captureFrame() on the very next poll() rather than waiting a full interval
    frameCount_ = 0;
    audioSampleCount_ = 0;

    String dir = "/video_" + String(videoId);
    SD_MMC.mkdir(dir);

    if (includeAudio_) {
        audioFile_ = SD_MMC.open(audioPath(videoId), FILE_WRITE);
        if (audioFile_) {
            writePlaceholderWAVHeader();
        } else {
            includeAudio_ = false; // degrade to video-only rather than failing the whole session
        }
    }

    recording_ = true;
    return true;
}

void VideoRecorder::poll(uint32_t nowMs) {
    if (!recording_) return;

    if (nowMs - lastFrameMs_ >= Config::kVideoFrameIntervalMs) {
        captureFrame(nowMs);
        lastFrameMs_ = nowMs;
    }

    if (nowMs - startMs_ >= Config::kVideoMaxDurationMs) {
        finishSession();
    }
}

void VideoRecorder::stop(uint32_t nowMs) {
    if (!recording_) return; // idempotent -- the phone's stop button doesn't track server state
    finishSession();
}

void VideoRecorder::captureFrame(uint32_t nowMs) {
    // Real diagnostic added 2026-08-18, alongside raising kVideoFrameIntervalMs from 500ms to
    // 167ms (~6fps) -- unlike LiveStreamServer (which already had grab/write timing from an
    // earlier real-hardware finding), this path had none, so there was no way to tell whether SD
    // write speed could actually sustain the new, faster requested rate versus silently falling
    // behind it. Logged only when a frame's total time exceeds the interval it's supposed to fit
    // in -- that specific condition means the achieved frame rate is being throttled below what
    // was requested, regardless of what poll()'s scheduling intends. Not logged every frame
    // (would spam at 6fps for a full 30s session) -- this is a "something's wrong" signal, not
    // routine telemetry.
    uint32_t captureStartMs = millis();

    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        // Real diagnostic gap found 2026-08-17: this used to skip silently -- if something else
        // (live-stream's single shared frame buffer, a wedged camera driver) is starving every
        // grab, a whole session could finish with a frameCount_ near zero and nothing in the log
        // to explain why. Not spammy in practice: at most one line per kVideoFrameIntervalMs.
        Serial0.println("[video] frame grab failed -- esp_camera_fb_get() returned null, skipping this frame");
        return; // skip this frame rather than aborting the whole session over one bad grab
    }
    uint32_t grabMs = millis() - captureStartMs;

    uint32_t writeStartMs = millis();
    String path = framePath(videoId_, frameCount_);
    File frameFile = SD_MMC.open(path, FILE_WRITE);
    if (frameFile) {
        frameFile.write(fb->buf, fb->len);
        frameFile.close();
        frameCount_++;
    } else {
        Serial0.printf("[video] frame write failed -- SD_MMC.open() failed for %s\n", path.c_str());
    }
    uint32_t writeMs = millis() - writeStartMs;
    esp_camera_fb_return(fb);

    uint32_t totalMs = millis() - captureStartMs;
    if (totalMs > Config::kVideoFrameIntervalMs) {
        Serial0.printf("[video] frame %u took %ums (grab %ums, write %ums) -- longer than the %ums interval, actual rate is falling behind requested\n",
            frameCount_, totalMs, grabMs, writeMs, (unsigned)Config::kVideoFrameIntervalMs);
    }
}

void VideoRecorder::appendAudio(const int16_t *samples, int count) {
    if (!recording_ || !includeAudio_ || !audioFile_) return;
    audioFile_.write((const uint8_t *)samples, count * sizeof(int16_t));
    audioSampleCount_ += (uint32_t)count;
}

// Enumerates and removes every file in the session's directory, then the (now-empty) directory
// itself -- SD_MMC/FS has no recursive-delete built in, and rmdir() only works on an empty
// directory. Our own video directories are always flat (frame_NNNN.jpg files + one audio.wav, no
// subdirectories), so a single non-recursive pass is sufficient. Static/no instance state touched
// -- safe to call for an id this instance never itself recorded (harmless no-op via SD_MMC.open()
// failing on a directory that doesn't exist), matching the "may not exist yet" case for the first
// two sessions after boot.
void VideoRecorder::deleteSessionDirectory(uint32_t videoId) {
    String dir = "/video_" + String(videoId);
    File d = SD_MMC.open(dir);
    if (!d) return;
    if (!d.isDirectory()) {
        d.close();
        return;
    }
    File entry = d.openNextFile();
    while (entry) {
        String entryPath = entry.path();
        entry.close();
        SD_MMC.remove(entryPath);
        entry = d.openNextFile();
    }
    d.close();
    SD_MMC.rmdir(dir);
}

void VideoRecorder::finishSession() {
    if (includeAudio_ && audioFile_) {
        finalizeWAVHeader();
        audioFile_.close();
    }
    recording_ = false;
}

// Mirrors the app's own WAVFileWriter.swift byte-for-byte (mono, 16-bit PCM) -- see that file for
// the reference layout this matches. Written as a placeholder with a zero data size at start()
// (the final sample count isn't known until the session ends), then patched in finalizeWAVHeader()
// by seeking back to the start of the file -- SD_MMC's File supports seek+overwrite mid-file on
// FAT, this isn't an append-only stream.
void VideoRecorder::writePlaceholderWAVHeader() {
    uint8_t header[44] = {0};
    memcpy(header, "RIFF", 4);
    memcpy(header + 8, "WAVE", 4);
    memcpy(header + 12, "fmt ", 4);
    uint32_t fmtChunkSize = 16;
    memcpy(header + 16, &fmtChunkSize, 4);
    uint16_t audioFormat = 1; // PCM
    memcpy(header + 20, &audioFormat, 2);
    uint16_t numChannels = 1;
    memcpy(header + 22, &numChannels, 2);
    uint32_t sampleRate = Config::kSampleRateHz;
    memcpy(header + 24, &sampleRate, 4);
    uint16_t bitsPerSample = 16;
    uint32_t byteRate = sampleRate * numChannels * (bitsPerSample / 8);
    memcpy(header + 28, &byteRate, 4);
    uint16_t blockAlign = numChannels * (bitsPerSample / 8);
    memcpy(header + 32, &blockAlign, 2);
    memcpy(header + 34, &bitsPerSample, 2);
    memcpy(header + 36, "data", 4);
    // bytes 4 (RIFF size) and 40 (data size) left zero here, patched in finalizeWAVHeader()
    audioFile_.write(header, sizeof(header));
}

void VideoRecorder::finalizeWAVHeader() {
    uint32_t dataSize = audioSampleCount_ * sizeof(int16_t);
    uint32_t riffSize = 36 + dataSize;
    audioFile_.seek(4);
    audioFile_.write((const uint8_t *)&riffSize, 4);
    audioFile_.seek(40);
    audioFile_.write((const uint8_t *)&dataSize, 4);
}

String VideoRecorder::framePath(uint32_t videoId, uint16_t frameIndex) {
    char buf[48];
    snprintf(buf, sizeof(buf), "/video_%lu/frame_%04u.jpg", (unsigned long)videoId, frameIndex);
    return String(buf);
}

String VideoRecorder::audioPath(uint32_t videoId) {
    return "/video_" + String(videoId) + "/audio.wav";
}
