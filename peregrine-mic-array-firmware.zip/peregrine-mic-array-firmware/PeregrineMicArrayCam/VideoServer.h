// VideoServer.h — the "tiny server" half of video pull-transfer, same "HTTP pull, node runs a tiny
// server" decision PhotoServer already applies to stills (see that file's header). Unlike
// PhotoServer (which serves one in-memory buffer), frames/audio here are streamed directly off the
// SD card (VideoRecorder already wrote them there) -- a multi-second clip's frames + audio track
// are too large to hold as a second in-memory copy on top of what's already on SD.
//
// No manifest endpoint -- frameCount/frameIntervalMs/audioSampleCount are already delivered via
// the UDP VideoReadyPacket (NetworkProtocol.h), so the phone derives frame/audio URLs from that
// rather than needing a second HTTP round-trip just to ask "how many frames are there."
#pragma once

#include <cstdint>
#include <WebServer.h>

class VideoServer {
public:
    void begin(uint16_t port);

    // Call every loop() iteration.
    void poll();

    // Makes `videoId`'s already-on-SD frames/audio fetchable -- called once a VideoRecorder
    // session finishes. `hasAudio` distinguishes "no audio track for this clip" from "audio file
    // exists but happens to be silent," matching VideoReadyPacket's audioSampleCount == 0 meaning.
    void publish(uint32_t videoId, uint16_t frameCount, bool hasAudio);

private:
    void handleFrameRequest();
    void handleAudioRequest();

    WebServer server_;
    uint32_t currentVideoId_ = 0;
    uint16_t frameCount_ = 0;
    bool hasAudio_ = false;
};
