// PeregrineMicArrayCam — ESP32-S3-CAM (OV3660) 4x INMP441 + GPS direction-finding + camera node
// for Peregrine Planner's multi-node network. See CAMERA_NODE_NETWORK_SPEC.md (repo root) for the
// full architecture this implements, and README.md here for wiring/board settings.
//
// This is the SAME mic-array capture/onset/DOA pipeline as ../PeregrineMicArray/, byte-for-byte
// copied (I2SCapture.*, OnsetDetector.*, DOAEstimator.*, RingBuffer.h) rather than reimplemented —
// that code is proven on real hardware and this node's mic array is electrically identical, just
// on remapped pins (see Config.h) to clear a collision with the camera's SIOD/SIOC/VSYNC lines.
// What's new here: camera capture (triggered by the same onset gate that triggers a DOA capture,
// rate-limited — see Config::kPhotoMinIntervalMs), GPS position reporting, node-identity
// announcement, and a configurable network role (Config::kNetworkRole — hosts its own AP as a
// fleet's Primary, or joins a network as a station, either that fleet's Primary or a genuinely
// external one; see MIC_ARRAY_MASTER_AP_PLAN.md) with a tiny HTTP server for the phone to pull
// captured photos from.
//
// Also supports CAMERA_NODE_NETWORK_SPEC.md's "2-mic single-bus" wiring variant
// (Config::kMicCount = 2, bus 0/top pair genuinely left unwired) — Config::kTopBusEnabled gates
// bus-0 init, its capture task, and which DOAEstimator entry point runs, so the bottom bus alone
// does onset detection + DOA in that mode instead of being averaged against a floating,
// unwired top bus. See Config.h's kMicCount comment for why that gating matters.
//
// Uses Serial0 (UART), TX-only — see Config.h's header comment for why (GPIO44, normally U0RXD,
// is reused for the GPS UART).

#include <WiFi.h>
#include <esp_camera.h>
#include <esp_random.h> // esp_random() -- boot-time seed for the SD photo-id counter
#include "Config.h"
#include "CameraPins.h"
#include "NetworkProtocol.h"
#include "RingBuffer.h"
#include "I2SCapture.h"
#include "OnsetDetector.h"
#include "DOAEstimator.h"
#include "UDPStreamer.h"
#include "GPSReader.h"
#include "PPSReader.h"
#include "PhotoServer.h"
#include "VideoRecorder.h"
#include "VideoServer.h"
#include "LiveStreamServer.h"
#include "BLEAdvertiser.h"
#include "RemoteLogger.h"

// FIELD_DEBUG_PLAN.md, added 2026-08-18 -- see RemoteLogger.h for the full rationale.
// `RealSerial0` MUST be captured here, before the #define below -- that macro is a pure textual
// substitution, so any later occurrence of the literal token `Serial0` (including trying to
// reference the real global by name) would also get replaced, making the original object
// unreachable by name at all. Verified via a standalone prototype against this exact Arduino core
// before relying on it here, including this exact 4-arg begin() call shape.
HardwareSerial &RealSerial0 = Serial0;
RemoteLogger gRemoteLogger;
#define Serial0 gRemoteLogger

static const int kReadBlockFrames = 256;

I2SBus busTop;    // I2S_NUM_0, independent master -- TL (left-select) / TR (right-select)
I2SBus busBottom; // I2S_NUM_1, independent master -- BL (left-select) / BR (right-select)
UDPStreamer network;
BLEAdvertiser bleAdvertiser; // BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17
OnsetDetector onset;
GPSReader gps;
PPSReader pps;
PhotoServer photoServer;
VideoRecorder videoRecorder;
VideoServer videoServer;
LiveStreamServer liveStream;

// Capacity: Config::kAudioRingCapacitySamples (2s) -- see that constant's own comment for the
// real 2026-08-26 finding (video-recording camera-grab stalls overflowing the previous 200ms
// capacity) that drove the increase.
RingBuffer audioRing(Config::kAudioRingCapacitySamples);
// TR's matching FIFO, added 2026-08-18 for kStereoAudioFrame (Config::kTopBusEnabled/4-mic only)
// -- always fed alongside audioRing (see captureTopTask below), same size, so the two never desync
// in how much backlog each can hold. Unused/harmless overhead in 2-mic single-bus mode.
RingBuffer audioRingRight(Config::kAudioRingCapacitySamples);
// Bottom pair's own matching FIFOs, added 2026-08-20 for automatic top/bottom-pair fallback (see
// usingBottomPair below, kTopBusEnabled/4-mic only) -- fed unconditionally by
// captureBottomTask, same as audioRing/audioRingRight are by captureTopTask, so a fallback has
// Config::kAudioRingCapacitySamples worth of already-buffered bottom-pair audio ready the instant
// it triggers, no cold-start gap. Unused/harmless overhead in 2-mic single-bus mode (there's no
// second pair to fall back to).
RingBuffer audioRingBottomLeft(Config::kAudioRingCapacitySamples);
RingBuffer audioRingBottomRight(Config::kAudioRingCapacitySamples);
RingBuffer topLeftRing(Config::kDOAWindowSamples * 4);
RingBuffer topRightRing(Config::kDOAWindowSamples * 4);
RingBuffer bottomLeftRing(Config::kDOAWindowSamples * 4);
RingBuffer bottomRightRing(Config::kDOAWindowSamples * 4);

static int16_t capturedTopLeft[Config::kDOAWindowSamples];
static int16_t capturedTopRight[Config::kDOAWindowSamples];
static int16_t capturedBottomLeft[Config::kDOAWindowSamples];
static int16_t capturedBottomRight[Config::kDOAWindowSamples];
SemaphoreHandle_t doaCaptureRequested;

uint32_t audioSeq = 0;
uint32_t doaSeq = 0;
uint32_t timedOnsetSeq = 0;

// Onset -> loop() handoff for the GPS-PPS-disciplined TDOA timestamp (MULTI_NODE_TDOA_PLAN.md
// Phase 3). The capture task latches the sub-block crossing micros() here and raises the flag;
// loop() converts it through pps.utcForLocalMicros() and sends a kTimedOnset packet. Plain 32-bit
// volatiles, atomic on the ESP32 -- the doaCaptureRequested semaphore already orders this same
// producer/consumer handoff for the captured audio windows, and a rare torn read here would only
// cost one onset's TDOA timestamp, never corrupt anything.
volatile uint32_t gOnsetCrossingMicros = 0;
volatile bool gOnsetPending = false;

// Which pair is currently authoritative (Config::kTopBusEnabled/4-mic only) -- feeds the streamed
// stereo reference audio AND (as of 2026-08-20) the onset/DOA gate + azimuth math (see
// captureTopTask/captureBottomTask below). See Config::kAudioFallbackSilenceThreshold/
// kAudioFallbackSilenceIntervals for the decision logic, evaluated once per status interval in
// loop(). Volatile: written only by loop(), but now READ by both capture tasks too (to decide
// which one drives onset/DOA this iteration) -- a plain bool read is atomic on this architecture,
// same accepted single-writer/multi-reader risk profile as topLeftPeak/etc. above.
volatile bool usingBottomPair = false;

// Runtime feeder-cam toggle (kSetFeederCamMode, HOME_ASSISTANT.md) -- set from the app, no
// on-device persistence (the app re-sends its saved choice on reconnect, same as the photo-mode
// toggle). feederCamActive() OR's it with the compile-time Config::kFeederCamMode. Only the
// *behavior* (stream auto-start + keep-alive, motion/on-demand capture instead of onset, video
// yields the stream) follows the runtime flag; the compile flag additionally skips starting the
// I2S capture tasks, which can't be undone at runtime.
bool gRuntimeFeederCamMode = false;
static inline bool feederCamActive() { return Config::kFeederCamMode || gRuntimeFeederCamMode; }

uint32_t nextPhotoId = 1;
uint32_t nextVideoId = 1;

struct LastDOAResult {
    uint8_t bandId;
    float lowHz;
    float highHz;
    float azimuthDeg;
    float confidence;
};
static LastDOAResult lastDOAResults[Protocol::kMaxDOABands];
static int lastDOAResultCount = 0;

volatile uint32_t topReadOk = 0;
volatile uint32_t topReadFail = 0;
volatile uint32_t bottomReadOk = 0;
volatile uint32_t bottomReadFail = 0;

// Real-hardware finding 2026-08-18/20 (mirrored from ../PeregrineMicArray, same root-causing
// session): onset only ever processes TL (top-left)/whichever bus is active in 2-mic mode -- there
// was previously NO visibility into whether the other channels actually carry real audio, only
// whether their I2S reads succeed structurally (topReadOk/bottomReadOk, which say nothing about
// signal content -- a dead mic on an otherwise-fine bus reads back clean zeros forever, same as a
// healthy read of true silence). Peak-since-last-report per channel (not a running max since boot
// -- reset after each print, see loop() below). Not mutex-guarded, same accepted risk profile as
// topReadOk/etc. above.
volatile int16_t topLeftPeak = 0;
volatile int16_t topRightPeak = 0;
volatile int16_t bottomLeftPeak = 0;
volatile int16_t bottomRightPeak = 0;

static void updatePeak(volatile int16_t &peak, const int16_t *block, int count) {
    for (int i = 0; i < count; i++) {
        // int32_t, not int16_t: abs(INT16_MIN) is 32768, one past int16_t's own positive range --
        // computing the magnitude in a wider type avoids signed-overflow UB on that specific value.
        int32_t magnitude = abs((int32_t)block[i]);
        if (magnitude > peak) peak = (int16_t)(magnitude > INT16_MAX ? INT16_MAX : magnitude);
    }
}

void captureTopTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!busTop.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            topReadFail++;
            continue;
        }
        topReadOk++;
        updatePeak(topLeftPeak, blockLeft, kReadBlockFrames);
        updatePeak(topRightPeak, blockRight, kReadBlockFrames);

        topLeftRing.pushBlock(blockLeft, kReadBlockFrames);
        topRightRing.pushBlock(blockRight, kReadBlockFrames);
        audioRing.pushBlock(blockLeft, kReadBlockFrames);
        audioRingRight.pushBlock(blockRight, kReadBlockFrames); // TR, for kStereoAudioFrame (see its declaration)

        // Real-hardware fix 2026-08-20: only the currently-authoritative pair drives onset/DOA --
        // `onset` is a single shared detector instance, so letting both capture tasks call
        // processBlock() concurrently would race its internal envelope/floor state. When the top
        // pair is known-dead (usingBottomPair), captureBottomTask below does this instead, and its
        // own results are computed via DOAEstimator::estimateSingleBus() (loop()), not this task's
        // capturedTopLeft/Right snapshot -- see that call site's comment for why a dead pair can't
        // just be included in the normal two-pair average.
        if (!usingBottomPair) {
            bool triggered = onset.processBlock(blockLeft, kReadBlockFrames, millis(), micros());
            if (triggered) {
                topLeftRing.snapshotRecent(capturedTopLeft, Config::kDOAWindowSamples);
                topRightRing.snapshotRecent(capturedTopRight, Config::kDOAWindowSamples);
                gOnsetCrossingMicros = onset.lastCrossingMicros();
                gOnsetPending = true;
                xSemaphoreGive(doaCaptureRequested);
            }
        }
    }
}

void captureBottomTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!busBottom.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            bottomReadFail++;
            continue;
        }
        bottomReadOk++;
        updatePeak(bottomLeftPeak, blockLeft, kReadBlockFrames);
        updatePeak(bottomRightPeak, blockRight, kReadBlockFrames);
        audioRingBottomLeft.pushBlock(blockLeft, kReadBlockFrames);
        audioRingBottomRight.pushBlock(blockRight, kReadBlockFrames);
        bottomLeftRing.pushBlock(blockLeft, kReadBlockFrames);
        bottomRightRing.pushBlock(blockRight, kReadBlockFrames);

        // 2-mic mode (Config::kTopBusEnabled == false): bus 0/captureTopTask doesn't exist, so
        // this bus takes over everything captureTopTask normally does -- feeding audioRing (the
        // mono audio stream/video-audio-track source). Mirrors captureTopTask's own logic above,
        // just on bottom's buffers.
        if (!Config::kTopBusEnabled) {
            audioRing.pushBlock(blockLeft, kReadBlockFrames);
        }

        // Onset/DOA gate, mirroring captureTopTask's own comment above, flipped: this bus drives
        // it whenever there's no top bus to begin with (2-mic mode, unchanged from before), OR
        // (added 2026-08-20) once the top pair has been confirmed dead in 4-mic mode and
        // usingBottomPair has switched.
        if (!Config::kTopBusEnabled || usingBottomPair) {
            bool triggered = onset.processBlock(blockLeft, kReadBlockFrames, millis(), micros());
            if (triggered) {
                bottomLeftRing.snapshotRecent(capturedBottomLeft, Config::kDOAWindowSamples);
                bottomRightRing.snapshotRecent(capturedBottomRight, Config::kDOAWindowSamples);
                gOnsetCrossingMicros = onset.lastCrossingMicros();
                gOnsetPending = true;
                xSemaphoreGive(doaCaptureRequested);
            }
        }
    }
}

bool initCamera() {
    camera_config_t config = {};
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = CAM_PIN_D0;
    config.pin_d1 = CAM_PIN_D1;
    config.pin_d2 = CAM_PIN_D2;
    config.pin_d3 = CAM_PIN_D3;
    config.pin_d4 = CAM_PIN_D4;
    config.pin_d5 = CAM_PIN_D5;
    config.pin_d6 = CAM_PIN_D6;
    config.pin_d7 = CAM_PIN_D7;
    config.pin_xclk = CAM_PIN_XCLK;
    config.pin_pclk = CAM_PIN_PCLK;
    config.pin_vsync = CAM_PIN_VSYNC;
    config.pin_href = CAM_PIN_HREF;
    config.pin_sscb_sda = CAM_PIN_SIOD;
    config.pin_sscb_scl = CAM_PIN_SIOC;
    config.pin_pwdn = CAM_PIN_PWDN;
    config.pin_reset = CAM_PIN_RESET;
    config.xclk_freq_hz = kCameraXCLKFreqHz;
    config.pixel_format = PIXFORMAT_JPEG;
    config.frame_size = FRAMESIZE_SVGA; // 800x600 -- small enough for a fast HTTP transfer over WiFi
    config.jpeg_quality = Config::kCameraJpegQuality;
    config.fb_count = Config::kCameraFrameBufferCount;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.grab_mode = CAMERA_GRAB_LATEST;

    return esp_camera_init(&config) == ESP_OK;
}

// Rate-limited so a burst of onset triggers (e.g. a chattering flock) doesn't thrash the single
// frame buffer / HTTP server with captures faster than the phone could plausibly fetch them.
uint32_t lastPhotoMs = 0;

// `manual` only affects the log line below -- capture behavior is identical either way. Added
// 2026-08-10: real-hardware testing found this whole path was completely silent (no Serial output
// either way), making "did my manual capture request actually do anything" unanswerable from the
// app alone (kPhotoCaptureNow is fire-and-forget on the wire, no ack packet type exists).
void capturePhotoIfDue(uint32_t nowMs, bool manual) {
    const char *source = manual ? "manual" : "auto";
    if (nowMs - lastPhotoMs < Config::kPhotoMinIntervalMs) {
        if (manual) {
            // Only worth logging for manual requests -- automatic (onset-gated) skips are
            // routine and would spam the console during a chattering flock.
            Serial0.printf("[photo] %s request ignored -- rate-limited (%lums since last capture, min %lums)\n",
                source, (unsigned long)(nowMs - lastPhotoMs), (unsigned long)Config::kPhotoMinIntervalMs);
        }
        return;
    }

    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        Serial0.printf("[photo] %s capture failed -- esp_camera_fb_get() returned null\n", source);
        return;
    }

    uint8_t *copy = (uint8_t *)malloc(fb->len);
    if (!copy) {
        Serial0.printf("[photo] %s capture failed -- malloc(%u) for frame copy failed\n", source, (unsigned)fb->len);
        esp_camera_fb_return(fb);
        return;
    }
    memcpy(copy, fb->buf, fb->len);
    size_t length = fb->len;
    esp_camera_fb_return(fb);

    uint32_t photoId = nextPhotoId++;
    photoServer.publish(photoId, copy, length);
    network.sendPhotoReady(nowMs, photoId, (uint32_t)length);

    // SD-backed photo store (2026-08-28): also persist the JPEG to /photos/<id>.jpg so it survives
    // a loop() stall, the app switching which node feeds a screen, or a power cycle -- the RAM
    // buffer PhotoServer holds is only the fast path for an immediate fetch, and the next capture
    // frees it. The phone reconciles GET /photos on (re)connect and DELETEs each once it has it.
    // Degrades to RAM-only (the prior behavior) when the card isn't mounted -- same graceful
    // philosophy as "[boot] SD card mount failed ... stills unaffected".
    bool savedToSD = false;
    if (videoRecorder.isSDReady()) {
        String photoPath = "/photos/" + String(photoId) + ".jpg";
        File photoFile = SD_MMC.open(photoPath, FILE_WRITE);
        if (photoFile) {
            photoFile.write(copy, length);
            photoFile.close();
            savedToSD = true;
            photoServer.notePhotoStored(photoId, Config::kMaxStoredPhotos);
        } else {
            Serial0.printf("[photo] SD write failed -- SD_MMC.open() failed for %s (RAM copy still served)\n", photoPath.c_str());
        }
    }

    Serial0.printf("[photo] %s capture ok -- id %lu, %u bytes (%s)\n", source, (unsigned long)photoId,
                   (unsigned)length, savedToSD ? "SD+RAM" : "RAM only");
    lastPhotoMs = nowMs;
}

void setup() {
    // Real-hardware finding (2026-08-10): GPIO44 is this board's dedicated UART/programming
    // USB-C port's own RX line into the chip -- the same net esptool's stub flasher uses during
    // upload. An earlier design had GPS's TX wire landing there too (RX disabled on Serial0 to
    // "free" it), which looked fine on paper but broke actual flashing outright (two drivers
    // contending for one net during the upload handshake, not just a lost-console-input
    // tradeoff). Fixed by moving GPS's RX pin to GPIO20 instead (see Config::kGPSRXPin) --
    // Serial0 no longer needs to give up GPIO44 for any reason, regardless of kGPSEnabled.
    gRemoteLogger.attach(RealSerial0);
    Serial0.begin(115200, SERIAL_8N1, 44, 43); // normal U0RXD/U0TXD, always fully bidirectional
    delay(1500);
    Serial0.println("[boot] checkpoint 1: Serial0 ready (TX+RX)");

    Serial0.println("[boot] checkpoint 2: starting camera");
    if (!initCamera()) {
        Serial0.println("[boot] Camera init failed");
    } else {
        Serial0.println("[boot] checkpoint 3: camera ready");
    }

    if (Config::kTopBusEnabled) {
        Serial0.println("[boot] checkpoint 4: starting busTop (I2S master)");
        if (!busTop.begin(I2S_NUM_0, Config::kTopBCLK, Config::kTopWS, Config::kTopBusDIN, Config::kSampleRateHz)) {
            Serial0.println("[boot] Top bus init failed");
        } else {
            Serial0.println("[boot] checkpoint 5: busTop ready");
        }
    } else {
        // !kTopBusEnabled -- bus 0 is genuinely left unwired in this variant (see Config.h), not
        // just unused. Deliberately NOT calling busTop.begin() at all -- I2S init doesn't fail just
        // because nothing's physically connected to its pins, so leaving it running would silently
        // capture floating-pin noise that nothing then reads (harmless on its own, but worth
        // skipping entirely rather than leaving a misleading "ready" checkpoint for a bus this
        // config doesn't use).
        //
        // Real bug found 2026-08-17: this used to print a hardcoded "kMicCount=2" regardless of
        // Config::kMicCount's actual value, which masked a real kTopBusEnabled formula bug (fixed
        // the same day in Config.h) as a phantom "node thinks it's a 2-mic array" identity problem
        // instead of what it actually was -- print the real values so this can't mislead again.
        Serial0.printf("[boot] checkpoint 4/5: kMicCount=%u, kTopBusEnabled=%s -- busTop skipped (single-bus config, see Config.h)\n",
            Config::kMicCount, Config::kTopBusEnabled ? "true" : "false");
    }

    Serial0.println("[boot] checkpoint 6: starting busBottom (I2S master, independent clock)");
    if (!busBottom.begin(I2S_NUM_1, Config::kBottomBCLK, Config::kBottomWS, Config::kBottomBusDIN, Config::kSampleRateHz)) {
        Serial0.println("[boot] Bottom bus init failed");
    } else {
        Serial0.println("[boot] checkpoint 7: busBottom ready");
    }

    if (Config::kGPSEnabled) {
        Serial0.println("[boot] checkpoint 8: starting GPS UART");
        gps.begin(Serial1, Config::kGPSRXPin, Config::kGPSTXPin, Config::kGPSBaud, Config::kGPSUARTRxBufferBytes);
    } else {
        Serial0.println("[boot] checkpoint 8: kGPSEnabled=false -- skipping GPS entirely");
    }

    if (Config::kPPSEnabled) {
        Serial0.println("[boot] checkpoint 8a: attaching GPS PPS interrupt");
        pps.begin(Config::kPPSPin);
    }

    // MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3 -- a missing/failed-to-mount SD card only disables
    // video recording, not the rest of this node (mic array, DOA, stills all work without it).
    Serial0.println("[boot] checkpoint 8b: mounting SD card (SD_MMC, 1-bit mode)");
    if (!videoRecorder.beginSD()) {
        Serial0.println("[boot] SD card mount failed -- video recording will be unavailable (stills/mic array unaffected)");
    } else {
        // Real diagnostic gap found 2026-08-17: no visibility into SD card usage anywhere, on a
        // card that (before that same day's cleanup fix) accumulated every video session's frame
        // files/directories forever with nothing ever deleting them. Logged at boot so a slowly
        // filling card is at least visible on the next tethered Serial check, not just inferred.
        Serial0.printf("[boot] checkpoint 8c: SD card ready, %llu/%llu MB used\n",
            SD_MMC.usedBytes() / (1024ULL * 1024ULL), SD_MMC.totalBytes() / (1024ULL * 1024ULL));

        // SD-backed photo store (2026-08-28) -- see capturePhotoIfDue(). Resume the photoId
        // counter above any file already in /photos/ so ids stay monotonic across a power cycle
        // (nextPhotoId is a plain global that otherwise resets to 1 every boot). If /photos/ is
        // empty, seed from a random 24-bit base so a fresh boot after the phone fully
        // fetched+deleted an earlier set still can't reuse those ids.
        SD_MMC.mkdir("/photos");
        if (Config::kWipePhotosOnBoot) {
            Serial0.println("[boot] kWipePhotosOnBoot=true -- clearing /photos (one-shot maintenance; set it back to false and reflash)");
            uint32_t wiped = photoServer.wipeAllPhotos();
            Serial0.printf("[boot] cleared %lu photo file(s) from /photos\n", (unsigned long)wiped);
        }
        uint32_t highestPhotoId = photoServer.initRetentionState();
        nextPhotoId = highestPhotoId > 0 ? highestPhotoId + 1 : ((esp_random() & 0x00FFFFFFu) | 1u);
        Serial0.printf("[boot] checkpoint 8d: /photos ready (highest stored id %lu), next photo id %lu\n",
            (unsigned long)highestPhotoId, (unsigned long)nextPhotoId);
    }

    if (Config::kDiagnosticDisableWiFi) {
        Serial0.println("[boot] checkpoint 9: kDiagnosticDisableWiFi=true -- skipping WiFi/network entirely");
    } else {
        // See Config::kNetworkRole / MIC_ARRAY_MASTER_AP_PLAN.md -- Primary hosts its own AP,
        // everyone else joins a network as a station (either this fleet's Primary, or a genuinely
        // external network -- network.begin() itself doesn't distinguish between those two STA
        // cases, only Config::kWiFiSSID/kWiFiPassword's value does).
        bool isPrimary = (Config::kNetworkRole == Config::kRolePrimary);
        Serial0.printf("[boot] checkpoint 9: %s WiFi (%s)...\n", isPrimary ? "hosting" : "joining", isPrimary ? "AP" : "STA");
        if (!network.begin()) {
            Serial0.println(isPrimary
                ? "[boot] AP hosting failed -- check Config::kWiFiSSID/kWiFiPassword (>=8 chars) and kMaxAPStations"
                : "[boot] WiFi join failed/timed out -- check Config::kWiFiSSID/kWiFiPassword");
        } else {
            IPAddress myIP = isPrimary ? WiFi.softAPIP() : WiFi.localIP();
            Serial0.printf("[boot] checkpoint 10: WiFi %s, IP %s -- enter this in the app's node Network Address field\n", isPrimary ? "AP up" : "joined", myIP.toString().c_str());
            if (isPrimary) {
                // For any Secondary node's Config::kPrimaryBSSID (MIC_ARRAY_MASTER_AP_PLAN.md §4)
                // -- read this and hardcode it into the Secondary's own Config.h before relying on
                // failover in the field.
                Serial0.printf("[boot] AP BSSID (for a Secondary's kPrimaryBSSID): %s\n", WiFi.softAPmacAddress().c_str());
            }
            photoServer.begin(Config::kHTTPPort);
            Serial0.println("[boot] checkpoint 11: photo HTTP server up");
            videoServer.begin(Config::kVideoHTTPPort);
            Serial0.println("[boot] checkpoint 11b: video HTTP server up");
            liveStream.begin(Config::kLiveStreamHTTPPort);
            liveStream.setKeepAlive(Config::kFeederCamMode); // stays up for Home Assistant / Frigate, no timeout
            Serial0.printf("[boot] checkpoint 11c: live stream server up%s\n",
                Config::kFeederCamMode ? " (feeder-cam mode -- auto-start + keep-alive)" : "");
        }
        // BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17 -- skipped alongside WiFi under
        // kDiagnosticDisableWiFi since the whole point of that flag is testing for zero radio
        // activity at all; BLE is a second, separate radio that would reintroduce exactly the kind
        // of interference that diagnostic mode exists to rule out.
        bleAdvertiser.begin();
        Serial0.println("[boot] checkpoint 11d: BLE advertising ready (event-gated -- silent while a client is registered)");
    }

    doaCaptureRequested = xSemaphoreCreateBinary();

    if (Config::kMotionSensorEnabled) {
        // PIR / occupancy sensor OUT -> a photo + kMotionTrigger on the rising edge (loop()).
        // PULLDOWN so a disconnected pin reads as "no motion" rather than floating.
        pinMode(Config::kMotionSensorPin, INPUT_PULLDOWN);
        Serial0.printf("[boot] checkpoint 11e: motion sensor enabled on GPIO%d\n", Config::kMotionSensorPin);
    }

    if (Config::kFeederCamMode) {
        // Bird-feeder / Home Assistant camera mode: this node is a plain network camera, not a mic
        // array. Skip the audio capture tasks entirely (loop() also skips all onset/DOA/audio-frame
        // work) -- frees the CPU/power the array pipeline used. Stills are motion- or on-demand-
        // triggered here, not onset-triggered.
        Serial0.println("[boot] checkpoint 12: feeder-cam mode -- mic-array pipeline skipped, entering loop()");
    } else {
        // captureTopTask is only started when there's an actual top bus to read -- starting it
        // against an unwired busTop (never begin()'d above) would just spin reporting readFrames()
        // failures forever, and more importantly its onset-detection duty has already moved to
        // captureBottomTask for this mode (see that task's own comment above).
        if (Config::kTopBusEnabled) {
            xTaskCreatePinnedToCore(captureTopTask, "captureTop", 4096, NULL, 2, NULL, 0);
        }
        xTaskCreatePinnedToCore(captureBottomTask, "captureBottom", 4096, NULL, 2, NULL, 1);
        Serial0.println("[boot] checkpoint 12: capture tasks started, entering loop()");
    }
}

void loop() {
    uint32_t now = millis();

    if (!Config::kDiagnosticDisableWiFi) {
        network.poll();
        network.pollFailover(); // no-op unless Config::kNetworkRole == kRoleSecondary
        network.pollReconnect(); // no-op unless Config::kNetworkRole == kRoleClient -- WIFI_MULTI_SSID_FALLBACK_PLAN.md Phase 2

        // FIELD_DEBUG_PLAN.md, added 2026-08-18 -- see ../PeregrineMicArray/PeregrineMicArray.ino's
        // identical block for the full rationale.
        gRemoteLogger.poll(network);
        bool remoteLoggingEnabled;
        if (network.consumeSetRemoteLoggingRequest(remoteLoggingEnabled)) {
            gRemoteLogger.setEnabled(remoteLoggingEnabled);
        }

        // Runtime feeder-cam toggle (kSetFeederCamMode, HOME_ASSISTANT.md).
        bool feederCamRequested;
        if (network.consumeSetFeederCamModeRequest(feederCamRequested)) {
            bool wasActive = feederCamActive();
            gRuntimeFeederCamMode = feederCamRequested;
            bool nowActive = feederCamActive();
            liveStream.setKeepAlive(nowActive); // keeps the stream up for HA; compile flag also forces true
            if (wasActive && !nowActive) {
                liveStream.stop(); // revert to a timed field-preview / off
            }
            Serial0.printf("[feeder] runtime feeder-cam mode %s (effective: %s)\n",
                feederCamRequested ? "on" : "off", nowActive ? "on" : "off");
        }

        // BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17 -- event-gated: only ever advertising while
        // network.isStreaming() is false (no registered phone client), so BLE is silent for the
        // entire duration of an established session. WiFi.softAPIP() vs WiFi.localIP() mirrors the
        // exact same isCurrentlyHosting() branch setup() already uses for its own boot-log IP print.
        IPAddress currentIP = network.isCurrentlyHosting() ? WiFi.softAPIP() : WiFi.localIP();
        bleAdvertiser.poll(network.isStreaming(), currentIP);

        photoServer.poll();
        videoServer.poll();
        liveStream.poll(now);
    }
    if (Config::kGPSEnabled) {
        gps.poll();
        // MULTI_NODE_TDOA_PLAN.md Phase 1: anchor a UTC second to the most recent PPS edge whenever
        // a fresh GPS time has been parsed. utcSecondOfDay() clears the "fresh" flag.
        if (Config::kPPSEnabled && gps.timeFresh() && gps.timeValid()) {
            pps.bindUtcSecond(gps.utcSecondOfDay());
        }
    }

    // Stereo (Config::kTopBusEnabled/4-mic) and mono (2-mic single-bus) are mutually exclusive --
    // this node sends one or the other, never both (see NetworkProtocol.h's AudioFrameHeader
    // comment). Both drain the exact same audioRing (TL) the mono path always has; stereo
    // additionally drains audioRingRight (TR), fed in lockstep by captureTopTask every block.
    // Video's own audio track stays mono (TL/left) either way -- no change to VideoRecorder's
    // format assumptions needed for this feature.
    // Skipped entirely in Config::kFeederCamMode -- the capture tasks that feed these rings aren't
    // started (setup()), so there's nothing to drain and no phone client expecting audio frames.
    if (!Config::kFeederCamMode && Config::kTopBusEnabled) {
        static int16_t stereoLeftAccum[Config::kStereoAudioSamplesPerChannel];
        static int16_t stereoRightAccum[Config::kStereoAudioSamplesPerChannel];
        static int stereoAccumCount = 0;
        // Real-hardware finding 2026-08-18/20 -- top pair confirmed completely silent on the
        // sibling front-array node (see Config::kAudioFallbackSilenceThreshold's comment).
        // usingBottomPair (updated once per status interval below) picks which pair's
        // already-buffered rings to drain here -- video's audio track (below, via stereoLeftAccum)
        // benefits automatically, no separate change needed. A torn packet mixing both pairs'
        // samples is possible on the exact iteration a fallback triggers mid-accumulation, a rare
        // (once per ~10s streak minimum) and harmless cosmetic glitch, not worth adding
        // cross-iteration state to prevent.
        RingBuffer &leftSource = usingBottomPair ? audioRingBottomLeft : audioRing;
        RingBuffer &rightSource = usingBottomPair ? audioRingBottomRight : audioRingRight;
        int remaining = Config::kStereoAudioSamplesPerChannel - stereoAccumCount;
        int gotLeft = leftSource.popAvailable(stereoLeftAccum + stereoAccumCount, remaining);
        int gotRight = rightSource.popAvailable(stereoRightAccum + stereoAccumCount, remaining);
        // The selected pair's two rings are pushed together every single block (same call site,
        // same count), so gotLeft should always equal gotRight -- min() is a defensive guard, not
        // an expected path, against the two ever silently drifting apart rather than corrupting
        // the L/R interleave with mismatched channel data.
        int got = (gotLeft < gotRight) ? gotLeft : gotRight;
        stereoAccumCount += got;
        if (stereoAccumCount == Config::kStereoAudioSamplesPerChannel) {
            network.sendStereoAudioFrame(audioSeq++, stereoLeftAccum, stereoRightAccum, stereoAccumCount);
            // Same already-decimated left-channel block the UDP stream just sent -- not a second
            // consumer of audioRing, just feeding the same data to a second destination when a
            // video session with audio is in progress. No-ops internally otherwise (see
            // VideoRecorder::appendAudio).
            videoRecorder.appendAudio(stereoLeftAccum, stereoAccumCount);
            stereoAccumCount = 0;
        }
    } else if (!Config::kFeederCamMode) {
        static int16_t audioAccumulator[Config::kAudioSamplesPerPacket];
        static int audioAccumulatedCount = 0;
        audioAccumulatedCount += audioRing.popAvailable(
            audioAccumulator + audioAccumulatedCount, Config::kAudioSamplesPerPacket - audioAccumulatedCount
        );
        if (audioAccumulatedCount == Config::kAudioSamplesPerPacket) {
            network.sendAudioFrame(audioSeq++, audioAccumulator, audioAccumulatedCount);
            // Same already-decimated block the UDP stream just sent -- not a second consumer of
            // audioRing, just feeding the same data to a second destination when a video session with
            // audio is in progress. No-ops internally otherwise (see VideoRecorder::appendAudio).
            videoRecorder.appendAudio(audioAccumulator, audioAccumulatedCount);
            audioAccumulatedCount = 0;
        }
    }

    // Video recording control (MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3) -- phone-triggered
    // start/stop, runs independently of whatever else this loop is doing once started. Rejects a
    // start request while a live stream is active (see the live-stream block below) -- the two
    // are kept mutually exclusive, one deliberate camera consumer at a time, not for thread-safety
    // (everything here runs on one task) but to keep the on-node behavior simple and predictable.
    bool videoIncludeAudio;
    // Real diagnostic gap found 2026-08-17: this whole block used to make its accept/reject
    // decision silently -- a start request arriving while a live stream was active (the mutual-
    // exclusion case explained above) just vanished, no different in the Serial log from the
    // request never having arrived at all. Logged explicitly now so "video not being created" is
    // diagnosable from the field instead of guessed at.
    if (network.consumeVideoStartRequest(videoIncludeAudio)) {
        if (liveStream.isStreaming() && feederCamActive()) {
            // Feeder-cam mode holds the stream up by default -- yield it for this recording;
            // loop()'s auto-start block below brings it back once the session ends.
            Serial0.println("[video] feeder-cam stream yielding to a record request");
            liveStream.stop();
        }
        if (liveStream.isStreaming()) {
            Serial0.println("[video] record start rejected -- live stream is currently active (mutually exclusive, see comment above)");
        } else if (!videoRecorder.start(nextVideoId, videoIncludeAudio, now)) {
            Serial0.printf("[video] record start rejected -- sdReady=%s recording=%s\n",
                videoRecorder.isSDReady() ? "true" : "false", videoRecorder.isRecording() ? "true" : "false");
        } else {
            Serial0.printf("[video] record start ok -- id %lu, audio=%s\n",
                (unsigned long)nextVideoId, videoIncludeAudio ? "true" : "false");
        }
    }
    bool wasRecording = videoRecorder.isRecording();
    if (network.consumeVideoStopRequest()) {
        videoRecorder.stop(now);
    }
    videoRecorder.poll(now); // may also auto-finish the session (Config::kVideoMaxDurationMs safety cutoff)
    if (wasRecording && !videoRecorder.isRecording()) {
        // Session just ended, either way above -- detected by transition rather than a return
        // value from poll()/stop() individually, so neither path can silently lose this signal
        // (see VideoRecorder::poll's doc comment for why).
        uint32_t finishedId = videoRecorder.currentVideoId();
        uint16_t frameCount = videoRecorder.frameCount();
        uint32_t audioSampleCount = videoRecorder.audioSampleCount();
        Serial0.printf("[video] session finished -- id %lu, %u frames, %lu audio samples\n",
            (unsigned long)finishedId, frameCount, (unsigned long)audioSampleCount);
        videoServer.publish(finishedId, frameCount, audioSampleCount > 0);
        network.sendVideoReady(now, finishedId, frameCount, (uint16_t)Config::kVideoFrameIntervalMs, audioSampleCount);
        nextVideoId++;
    }

    // Live preview control (field camera-aim validation, LiveStreamServer.h) -- same mutual
    // exclusion the other direction: rejects a start request while a video-recording session is
    // in progress. liveStream.poll() (called unconditionally above, alongside photoServer/
    // videoServer) does the actual per-frame work; this block only handles start/stop requests.
    if (network.consumeVideoStreamStartRequest() && !videoRecorder.isRecording()) {
        liveStream.start(now);
    }
    if (network.consumeVideoStreamStopRequest()) {
        liveStream.stop();
    }
    // Feeder-cam mode: keep the MJPEG stream running with no app involvement, so Home Assistant /
    // Frigate can connect to /stream whenever they like (HOME_ASSISTANT.md). start() is a no-op
    // while already streaming; combined with setKeepAlive() it never times out. Yields while a
    // recording session is in progress (re-armed here once that finishes). Follows feederCamActive()
    // so the app's runtime toggle works, not just the compile-time flag.
    if (feederCamActive() && !liveStream.isStreaming() && !videoRecorder.isRecording()) {
        liveStream.start(now);
    }

    if (Config::kGPSEnabled) {
        static uint32_t lastGPSReportMs = 0;
        if (now - lastGPSReportMs >= Config::kGPSReportIntervalMs) {
            lastGPSReportMs = now;
            network.sendGPSPosition(
                now, gps.latitude(), gps.longitude(), gps.horizontalAccuracyMeters(), gps.hasFix(),
                (uint8_t)gps.satellitesInView(), gps.charsProcessed(), gps.sentencesWithValidChecksum(),
                gps.sentencesWithInvalidChecksum(), pps.edgeCount(), pps.lastIntervalMicros()
            );
        }
    }

    static uint32_t lastIdentityMs = 0;
    if (now - lastIdentityMs >= Config::kNodeIdentityIntervalMs) {
        lastIdentityMs = now;
        network.sendNodeIdentity();
    }

    // Peer-to-peer roster discovery (MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #1) -- unlike
    // sendNodeIdentity() above, this isn't gated on a phone session existing at all, since it's a
    // LAN broadcast to sibling nodes, not a send to a registered client. Skipped entirely whenever
    // THIS node is CURRENTLY acting as roster master (isActingAsRosterMaster() -- hosting the AP,
    // always true for Primary/a failed-over Secondary, OR explicitly designated via
    // Config::kIsRosterMaster as of 2026-08-16 for an all-kRoleClient shared-network setup) --
    // a master node already knows its own identity (nothing to announce to itself), and
    // sendNodeAnnounce()'s broadcast-address computation relies on WiFi.localIP()/subnetMask(),
    // only meaningful while genuinely STA-joined to something, which a failed-over Secondary isn't
    // (it only does periodic scans while failed-over, not a persistent STA join).
    static uint32_t lastAnnounceMs = 0;
    if (!network.isActingAsRosterMaster() && now - lastAnnounceMs >= Config::kNodeAnnounceIntervalMs) {
        lastAnnounceMs = now;
        network.sendNodeAnnounce();
    }

    if (xSemaphoreTake(doaCaptureRequested, 0) == pdTRUE) {
        // Bottom's DOA-window snapshot is taken here, slightly after the actual onset instant,
        // ONLY when top is the pair that triggered (its own snapshot happened precisely at trigger
        // time, inside captureTopTask). In every other case -- structural 2-mic mode, or (added
        // 2026-08-20) 4-mic mode once usingBottomPair has switched after the top pair was
        // confirmed dead -- captureBottomTask already snapshotted bottom's own window at the true
        // trigger instant itself (it's the bus doing onset detection in both those cases); redoing
        // it here would overwrite that precise capture with a slightly-later, less accurate one.
        if (Config::kTopBusEnabled && !usingBottomPair) {
            bottomLeftRing.snapshotRecent(capturedBottomLeft, Config::kDOAWindowSamples);
            bottomRightRing.snapshotRecent(capturedBottomRight, Config::kDOAWindowSamples);
        }

        // Real-hardware finding 2026-08-18/20: DOAEstimator::estimate()'s cross-pair average is
        // NOT graceful about a known-dead pair -- see ../PeregrineMicArray's matching comment.
        // Once usingBottomPair has switched (top pair confirmed dead in 4-mic mode), use
        // estimateSingleBus() on the bottom pair alone, same path structural 2-mic mode already
        // used, rather than blending in a pair already known to be silent.
        bool useSingleBus = !Config::kTopBusEnabled || usingBottomPair;

        int bandCount = network.activeBandCount();
        if (bandCount == 0) {
            DOAResult result = useSingleBus
                ? DOAEstimator::estimateSingleBus(
                      capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples, 0, 0)
                : DOAEstimator::estimate(
                      capturedTopLeft, capturedTopRight, capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples,
                      0, 0);
            network.sendDOATelemetry(doaSeq++, now, result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), 0);
            lastDOAResults[0] = {0, 0, 0, result.azimuthDeg, result.confidence};
            lastDOAResultCount = 1;
        } else {
            lastDOAResultCount = bandCount;
            for (int i = 0; i < bandCount; i++) {
                const Protocol::FrequencyBandSlot &band = network.activeBand(i);
                DOAResult result = useSingleBus
                    ? DOAEstimator::estimateSingleBus(
                          capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples, band.lowHz, band.highHz)
                    : DOAEstimator::estimate(
                          capturedTopLeft, capturedTopRight, capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples,
                          band.lowHz, band.highHz);
                network.sendDOATelemetry(doaSeq++, now, result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), band.bandId);
                lastDOAResults[i] = {band.bandId, band.lowHz, band.highHz, result.azimuthDeg, result.confidence};
            }
        }

        // GPS-PPS-disciplined onset timestamp for multi-node TDOA (MULTI_NODE_TDOA_PLAN.md
        // Phase 3). Sent alongside the DOA telemetry above, for the same event -- the capture task
        // latched the sub-block crossing micros() in gOnsetCrossingMicros. Skipped silently when
        // the clock isn't anchored (no PPS edge + parsed GPS time yet): this node just doesn't
        // participate in TDOA this session, bearing-only still works.
        if (gOnsetPending) {
            gOnsetPending = false;
            PPSReader::UtcMicros t = pps.utcForLocalMicros(gOnsetCrossingMicros);
            if (t.valid) {
                float conf = (lastDOAResultCount > 0) ? lastDOAResults[0].confidence : 0.0f;
                network.sendTimedOnset(timedOnsetSeq++, t.second, t.micros, 0, onset.lastRelativeLevel(), conf);
            }
        }

        // Onset-gated automatic capture -- only fires in automatic mode now (see
        // MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3's "user should have an option to do automatic or
        // manually trigger" ask). Manual capture below works regardless of this mode; manual mode
        // doesn't mean captures are blocked, it means the node stops deciding on its own.
        // `!liveStream.isFrameBufferBusy()` guard added 2026-08-10 -- real-hardware finding, see
        // that method's doc comment: without it, an onset firing while a live-stream frame is
        // still mid-send silently fails (esp_camera_fb_get() returns null, single shared buffer
        // already held), logged as "auto capture failed" rather than actually capturing anything.
        // ...and not in feeder-cam mode -- there, stills are motion-/on-demand-triggered instead
        // (the always-on stream would fail most onset grabs on the shared buffer anyway).
        if (network.isPhotoAutoModeEnabled() && !feederCamActive() && !liveStream.isFrameBufferBusy()) {
            capturePhotoIfDue(now, false);
        }
    }

    // Manual capture (kPhotoCaptureNow) -- deliberately checked outside the onset-gated block
    // above, since a manual request has nothing to do with whether an onset just fired. Still
    // respects capturePhotoIfDue's own Config::kPhotoMinIntervalMs rate limit internally, so a
    // rapid double-tap in the app can't thrash the single frame buffer any more than automatic
    // mode already couldn't. Same live-stream guard as the automatic path above, same reason.
    if (network.consumeManualCaptureRequest() && !liveStream.isFrameBufferBusy()) {
        capturePhotoIfDue(now, true);
    }

    // PIR / occupancy sensor (Config::kMotionSensorEnabled) -- a photo + kMotionTrigger on the
    // rising edge. The point of a bird-feeder cam: a silent visitor never trips the sound-based
    // onset capture. Rate-limited (kMotionRetriggerMs) -- a PIR holds its output HIGH for a dwell
    // period and re-asserts on continued presence, which at a busy feeder is otherwise a capture
    // every loop. The captured photo lands on the SD store regardless of whether a phone is
    // connected; sendMotionTrigger() no-ops if none is (the app already decodes kMotionTrigger).
    if (Config::kMotionSensorEnabled) {
        static bool lastMotionHigh = false;
        static uint32_t lastMotionTriggerMs = 0;
        bool motionHigh = digitalRead(Config::kMotionSensorPin) == HIGH;
        if (motionHigh && !lastMotionHigh && now - lastMotionTriggerMs >= Config::kMotionRetriggerMs) {
            lastMotionTriggerMs = now;
            Serial0.println("[motion] rising edge -- capturing photo + kMotionTrigger");
            network.sendMotionTrigger(now, 1.0f);
            if (!liveStream.isFrameBufferBusy()) {
                capturePhotoIfDue(now, true);
            }
        }
        lastMotionHigh = motionHigh;
    }

    static uint32_t lastStatusMs = 0;
    if (now - lastStatusMs >= 2000) {
        lastStatusMs = now;

      if (Config::kFeederCamMode) {
        // No mic-array pipeline in feeder-cam mode -- the [status]/[levels]/[audio-ring]/[doa]/
        // [onset] lines below would all print stale zeros. GPS/PPS (further down) still apply.
        Serial0.printf("[status] feeder-cam -- stream %s%s\n",
            liveStream.isStreaming() ? "up" : "idle",
            videoRecorder.isRecording() ? ", recording" : "");
      } else {
        // 2-mic mode never starts captureTopTask, so topReadOk/topReadFail would otherwise print a
        // permanently-zero line every 2s that looks like a stuck/failed bus rather than a bus this
        // config simply doesn't have -- omitted entirely in that case instead.
        if (Config::kTopBusEnabled) {
            Serial0.printf(
                "[status] top: %lu ok / %lu fail   bottom: %lu ok / %lu fail\n",
                (unsigned long)topReadOk, (unsigned long)topReadFail,
                (unsigned long)bottomReadOk, (unsigned long)bottomReadFail
            );
        } else {
            Serial0.printf(
                "[status] bottom (single-bus, 2-mic mode): %lu ok / %lu fail\n",
                (unsigned long)bottomReadOk, (unsigned long)bottomReadFail
            );
        }
        // Real-hardware diagnostic added 2026-08-20 -- see topLeftPeak's own declaration comment.
        // Peak absolute sample value seen since the last report, per channel -- make noise near
        // the array and watch which numbers actually move. Same omit-the-nonexistent-bus reasoning
        // as the [status] line above -- TL/TR would otherwise print a permanently-zero, misleading
        // pair on a 2-mic node that never starts captureTopTask at all.
        if (Config::kTopBusEnabled) {
            Serial0.printf(
                "[levels] TL: %d  TR: %d  BL: %d  BR: %d\n",
                topLeftPeak, topRightPeak, bottomLeftPeak, bottomRightPeak
            );

            // Automatic top/bottom-pair fallback + phone-visible level telemetry, kTopBusEnabled
            // (4-mic) only -- see Config::kAudioFallbackSilenceThreshold's comment for the
            // real-hardware finding this exists for. 2-mic mode has only one pair to begin with,
            // nothing to fall back to.
            int16_t topPairPeak = (topLeftPeak > topRightPeak) ? topLeftPeak : topRightPeak;
            int16_t bottomPairPeak = (bottomLeftPeak > bottomRightPeak) ? bottomLeftPeak : bottomRightPeak;

            static int topSilentStreak = 0;
            static int bottomSilentStreak = 0;
            topSilentStreak = (topPairPeak < Config::kAudioFallbackSilenceThreshold) ? topSilentStreak + 1 : 0;
            bottomSilentStreak = (bottomPairPeak < Config::kAudioFallbackSilenceThreshold) ? bottomSilentStreak + 1 : 0;

            if (!usingBottomPair
                && topSilentStreak >= Config::kAudioFallbackSilenceIntervals
                && bottomSilentStreak < Config::kAudioFallbackSilenceIntervals) {
                usingBottomPair = true;
                Serial0.println("[audio-fallback] top pair silent, bottom pair alive -- streaming reference audio + onset/DOA now from bottom pair instead");
            } else if (usingBottomPair
                && bottomSilentStreak >= Config::kAudioFallbackSilenceIntervals
                && topSilentStreak < Config::kAudioFallbackSilenceIntervals) {
                usingBottomPair = false;
                Serial0.println("[audio-fallback] bottom pair silent, top pair alive -- streaming reference audio + onset/DOA back on top pair");
            }

            network.sendAudioLevels(now, topLeftPeak, topRightPeak, bottomLeftPeak, bottomRightPeak, usingBottomPair);
        } else {
            Serial0.printf("[levels] BL: %d  BR: %d\n", bottomLeftPeak, bottomRightPeak);
        }
        topLeftPeak = 0;
        topRightPeak = 0;
        bottomLeftPeak = 0;
        bottomRightPeak = 0;
        Serial0.printf("[audio-ring] skipped: %lu samples\n", (unsigned long)audioRing.skippedSamples());
        for (int i = 0; i < lastDOAResultCount; i++) {
            const LastDOAResult &r = lastDOAResults[i];
            if (r.bandId == 0 && r.lowHz == 0 && r.highHz == 0) {
                Serial0.printf("[doa] band 0 (full spectrum)  azimuth: %.1f  confidence: %.2f  level: %.1f\n", r.azimuthDeg, r.confidence, onset.lastRelativeLevel());
            } else {
                Serial0.printf("[doa] band %u (%.0f-%.0f Hz)  azimuth: %.1f  confidence: %.2f  level: %.1f\n",
                    r.bandId, r.lowHz, r.highHz, r.azimuthDeg, r.confidence, onset.lastRelativeLevel());
            }
        }
        Serial0.printf(
            "[onset] fast: %.1f  floor: %.1f  threshold: %.1f  outliers_rejected: %lu\n",
            onset.currentFastEnvelope(), onset.currentSlowFloor(), onset.currentThreshold(),
            (unsigned long)onset.outlierRejectedCount()
        );
      } // end !kFeederCamMode mic-array status

        if (Config::kGPSEnabled) {
            Serial0.printf("[gps] fix: %s  lat: %.6f  lon: %.6f\n", gps.hasFix() ? "yes" : "no", gps.latitude(), gps.longitude());
            // Real-hardware finding, 2026-08-12: "fix: no" alone can't tell a genuinely
            // still-cold-starting module apart from one that's never received a single valid
            // byte at all (wiring/baud problem) -- see GPSReader.h's doc comment on how to read
            // these three numbers together.
            Serial0.printf("[gps-link] chars: %lu  valid sentences: %lu  invalid: %lu  satellites: %d  max poll gap: %lu ms\n",
                (unsigned long)gps.charsProcessed(), (unsigned long)gps.sentencesWithValidChecksum(),
                (unsigned long)gps.sentencesWithInvalidChecksum(), gps.satellitesInView(),
                (unsigned long)gps.maxPollGapMs());
        }
        if (Config::kPPSEnabled) {
            // Real-hardware validation line -- lastIntervalMicros() should read very close to
            // 1,000,000 on a correctly wired/working signal; nothing yet consumes this timing
            // (see PPSReader.h/Config::kPPSEnabled's comments), this just confirms the signal
            // itself is arriving before anything is built on top of it.
            Serial0.printf("[pps] edges: %lu  interval us: last %lu  min %lu  max %lu  meanAbsDev %lu  (n=%lu)\n",
                (unsigned long)pps.edgeCount(), (unsigned long)pps.lastIntervalMicros(),
                (unsigned long)pps.minIntervalMicros(), (unsigned long)pps.maxIntervalMicros(),
                (unsigned long)pps.meanAbsDevMicros(), (unsigned long)pps.intervalSampleCount());
            // MULTI_NODE_TDOA_PLAN.md Phase 1: the disciplined local->UTC clock. Once anchored,
            // `utc` should track real wall-clock time; a constant whole-second offset is harmless
            // for relative TDOA (see PPSReader::bindUtcSecond's comment).
            PPSReader::UtcMicros nowUtc = pps.utcForLocalMicros(micros());
            if (nowUtc.valid) {
                Serial0.printf("[clock] utc: %lu.%06lu  anchorAge: %lu ms\n",
                    (unsigned long)nowUtc.second, (unsigned long)nowUtc.micros,
                    (unsigned long)pps.anchorAgeMillis());
            } else {
                Serial0.println("[clock] utc: not anchored (need a PPS edge + a parsed GPS time)");
            }
        }
    }
}
