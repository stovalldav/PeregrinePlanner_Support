# Using a camera node as a bird-feeder cam (Home Assistant / Frigate)

**Not the camping security node's own Home Assistant integration** — that's a separate, real MQTT-
discovery integration (presence/alarm/camera-switch entities, zero YAML) documented in
`CAMPING_SECURITY_NODE_PLAN.md`'s "Home Assistant integration" section and built in
`firmware/PeregrineMicArrayCampingSecurity/HomeAssistantMQTT.h`. This doc's YAML `generic` camera
pattern (below) is what that integration's own camera entity reuses too, since HA's MQTT camera
platform has no URL-based mode — see `HomeAssistantMQTT.h`'s header comment for why.

A `PeregrineMicArrayCam` node joined to your home Wi-Fi is a plain HTTP camera on the LAN. With
`Config::kFeederCamMode` it becomes one Home Assistant, Frigate, a browser, or VLC can use
directly — no Peregrine Planner app involvement, and it keeps working while you're away (from
outside your network, reach it through Home Assistant's remote access / Nabu Casa, or a VPN such
as Tailscale/WireGuard — **do not** port-forward these endpoints, there is no authentication on
them).

## Endpoints (once the node has an IP on your network)

| URL | What it is |
|---|---|
| `http://<node-ip>:82/stream` | MJPEG stream (`multipart/x-mixed-replace`). Modest FPS — a preview, not a 30fps feed. |
| `http://<node-ip>:80/snapshot` | One fresh JPEG, grabbed on demand. `503` if the camera's single frame buffer is momentarily busy — the caller just retries. |
| `http://<node-ip>:80/photos` | `text/plain`, one `<id>,<bytes>` line per still on the SD card (used by the app, not usually HA). |
| `http://<node-ip>:80/photo/<id>` | A stored still (`GET`), or delete it (`DELETE`). |

The node's IP is printed on its serial boot log (`checkpoint 10: WiFi joined, IP ...`) and is in
your router's client list. Give it a DHCP reservation so it doesn't move.

## Toggling feeder-cam mode

**From the app (no reflash):** in the Peregrine Planner app, open **Mic Array → Additional Mic
Array Nodes → (your camera node) → Camera Controls**, and turn on **Feeder Cam Mode**. (For the
Primary array, the same toggle is in **Settings → Mic Array → Camera**.) The toggle is per node,
persists in the app, and is re-sent to the node on every reconnect (the firmware doesn't store it).
When it's on, the app shows the stream + snapshot URLs with a copy button, ready to paste into
Home Assistant. This runtime toggle does everything below **except** stopping the I2S capture
tasks — those keep running (a modest load next to camera + Wi-Fi).

**Compile-time (`Config::kFeederCamMode = true`)** is only for a *dedicated* feeder node where you
also want the leanest build — it additionally skips starting the mic-array capture tasks. Set it in
`Config.h` (or `Config.local.h`, then `cp Config.local.h Config.h` before flashing) alongside:

```cpp
constexpr uint8_t  kMicCount           = 2;      // 2-mic build -- frees GPIO14/21/47
constexpr bool     kFeederCamMode      = true;   // + skips the capture tasks (lean dedicated build)
constexpr bool     kPresenceSensorEnabled = true; // optional C4002 mmWave -- see below
```

Feeder-cam mode (runtime or compile-time) does three things:
1. The MJPEG stream auto-starts at boot and never times out; `loop()` restarts it if it ever drops.
2. The mic-array / onset / DOA pipeline is skipped entirely (capture tasks not started) — the node
   is a camera now, so that CPU/power is freed.
3. Still capture becomes **presence-triggered** (optional C4002, with Presence Capture on) or **on-demand**
   (`/snapshot`, the app's manual capture) instead of sound-triggered. GPS and video recording
   still work; a record request from the app makes the stream yield for that recording's duration.

Every still that is captured (presence or manual) is still written to the SD card and pulled into
"Camera Node Captures" the next time the Peregrine Planner app connects on the LAN — the two
workflows coexist.

## Optional: C4002 mmWave presence sensor (replaced the PIR, 2026-09-26)

A silent bird at the feeder never makes a sound the mic array could trigger on, so for a feeder
cam a presence sensor is worth wiring. This used to be an optional PIR; it's now a DFRobot
**C4002 (SEN0691)** mmWave sensor, which also gives a distance and still sees a visitor that's
sitting still. Only on a 2-mic (or camera-only) build — it uses the top bus's GPIO21.

- C4002 `TX` → **GPIO21**, C4002 `RX` → **GPIO48**.
- C4002 `VIN` → **5V** (it needs 3.6–5.5V, not 3V3), `GND` → GND.
- DFRobot doesn't publish the C4002's UART logic level — measure its TX pin before wiring it to
  GPIO21 (should idle around 3.3V; if it's near 5V, add a 10k/20k divider on that line).
- Set `Config::kPresenceSensorEnabled = true`. Boot log: `[boot] checkpoint 11e: C4002 presence
  sensor on GPIO21/48 -- found`; every 2s: `[presence-link] C4002  chars: … reports parsed: …`.
- Each detection sends `kMotionTrigger` with the distance (the app shows it in feet and can alert
  on it) and, **only if Presence Capture is on** (the node's page in the app; off by default),
  captures a still (→ SD store). Rate-limited by `Config::kMotionRetriggerMs` (default 5s).
- If the sensor sends nothing for 10s the node flags it offline to the app instead of looking
  like "nobody around"; it clears on its own when reports resume.

## Home Assistant

### As an MJPEG camera (live view)

`configuration.yaml`:

```yaml
camera:
  - platform: mjpeg
    name: Bird Feeder Cam
    mjpeg_url: http://10.0.1.199:82/stream
    still_image_url: http://10.0.1.199:80/snapshot
```

### As a still-polling camera (lower load, no always-on stream)

If you'd rather not keep the stream up, leave `kFeederCamMode` off (or accept the occasional
`503`) and poll `/snapshot`:

```yaml
camera:
  - platform: generic
    name: Bird Feeder Snapshot
    still_image_url: http://10.0.1.199:80/snapshot
    framerate: 0.2   # every 5s
```

### Frigate (recording + on-box bird detection + notifications)

Point Frigate at the MJPEG stream; all the heavy lifting (decode, object detection, clip
recording, remote viewing) runs on your Home Assistant machine, nothing extra on the ESP32:

```yaml
cameras:
  bird_feeder:
    ffmpeg:
      inputs:
        - path: http://10.0.1.199:82/stream
          input_args: -re -stream_loop -1 -f mjpeg
          roles: [detect]
    detect:
      width: 640
      height: 480
      fps: 5
    objects:
      track: [bird]
```

Then use Frigate's own events / MQTT for phone notifications and its UI (local or via HA remote
access) for viewing while you're away.

## Notes

- **No authentication.** Keep these nodes on a trusted LAN or a dedicated IoT VLAN. Reach them
  remotely only through HA's remote access or a VPN — never a router port-forward.
- **Power:** a feeder node needs permanent USB power. Intermittent streaming is fine; a
  continuous high-FPS pull will run the board warm.
- **One viewer at a time** on the MJPEG stream, realistically. Frigate holds it; point HA's camera
  card at Frigate's restream rather than a second direct connection.
- The GPS module is optional and irrelevant to feeder use — set `Config::kGPSEnabled = false` on a
  feeder node if it doesn't have one.
