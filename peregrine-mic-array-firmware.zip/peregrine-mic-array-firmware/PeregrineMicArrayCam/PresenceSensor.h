// PresenceSensor.h — copied from ../PeregrineMicArrayCampingSecurity/ (keep the two in sync). That
// node supports both the C4001 and C4002; this Cam firmware only ever uses the C4002 (C4002Reader),
// replacing the old optional PIR (2026-09-26). Kept as the same interface so C4002Reader.h/.cpp are
// byte-identical copies of the security node's.
#pragma once

#include <cstdint>

class PresenceSensor {
public:
    virtual ~PresenceSensor() = default;

    // Non-blocking; drains available UART bytes. True exactly once per newly parsed report.
    virtual bool poll() = 0;

    virtual bool presence() const = 0;
    // 0 when no target.
    virtual float distanceCm() const = 0;

    // Movement, for the app's live presence readout (kPresenceUpdate, added 2026-09-30). Values are
    // the wire values of PresenceUpdatePacket (NetworkProtocol.h). Radial only: both sensors measure
    // range rate along the beam, so someone walking straight across the field reads as not moving.
    enum class Movement : uint8_t { kUnknown = 0, kNone = 1, kApproaching = 2, kAway = 3 };
    // kClearing: the sensor is only running out its hold timer -- the target is no longer detected.
    enum class TargetState : uint8_t { kNone = 0, kStill = 1, kMoving = 2, kPresentUnknown = 3, kClearing = 4 };
    virtual Movement movement() const { return Movement::kUnknown; }
    virtual TargetState targetState() const { return presence() ? TargetState::kPresentUnknown : TargetState::kNone; }
    // Speed along the beam, m/s, always >= 0; negative = the sensor doesn't report one.
    virtual float radialSpeedMps() const { return -1.0f; }

    // Runtime detection range / hold time (added 2026-09-30, set from the app via kSetPresenceRange).
    // Both block briefly while the sensor acknowledges -- call only on a user change, never per loop.
    virtual bool setMaxRangeCm(uint16_t cm) = 0;
    virtual bool setHoldS(uint16_t) { return false; }
    virtual bool supportsHold() const { return false; }
    virtual uint16_t minSupportedRangeCm() const = 0;
    virtual uint16_t maxSupportedRangeCm() const = 0;

    // Short name for logs ("C4001" / "C4002").
    virtual const char *name() const = 0;

    // Bring-up counters -- a silent link (chars == 0) vs. bytes that don't parse (unparsed > 0).
    virtual uint32_t charsProcessed() const = 0;
    virtual uint32_t reportsParsed() const = 0;
    virtual uint32_t reportsUnparsed() const = 0;
};
