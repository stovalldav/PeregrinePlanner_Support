#include "C4002Reader.h"
#include <Arduino.h>
#include <cstring>

bool C4002Reader::begin(HardwareSerial &serial, int rxPin, int txPin, uint32_t baud,
                        uint16_t maxRangeCm, uint16_t disappearDelayS) {
    serial_ = &serial;
    serial_->begin(baud, SERIAL_8N1, rxPin, txPin);
    delay(10);
    while (serial_->available()) serial_->read();

    // Report period, units of 0.1s -- 10 = one result notification per second, the vendor
    // getAllResults example's own value. Also the detection probe: only a real C4002 answers this
    // with a checksum-valid write response (a C4001 on these pins talks 9600-baud text instead).
    const uint8_t period = 10;
    bool acked = false;
    for (int attempt = 0; attempt < 3 && !acked; attempt++) {
        acked = writeAndAwaitAck(kCmdSetReportPeriod, &period, 1, 300);
    }
    if (!acked) return false;

    // Best-effort -- the module keeps its previous setting if either isn't acknowledged.
    setMaxRangeCm(maxRangeCm);
    if (disappearDelayS != 0xFFFF) setHoldS(disappearDelayS);
    return true;
}

bool C4002Reader::setMaxRangeCm(uint16_t cm) {
    if (cm > 1100) cm = 1100;
    maxRangeCm_ = cm; // enforced in handleFrame() whether or not the module honors the command
    const uint8_t range[4] = {0x00, 0x00, (uint8_t)(cm & 0xFF), (uint8_t)(cm >> 8)};
    const bool acked = writeAndAwaitAck(kCmdSetDetectRange, range, sizeof(range), 300);
    Serial0.printf("[c4002] range 0-%u cm %s\n", cm, acked ? "set" : "NOT acknowledged");
    return acked;
}

bool C4002Reader::setHoldS(uint16_t seconds) {
    const uint8_t bytes[2] = {(uint8_t)(seconds & 0xFF), (uint8_t)(seconds >> 8)};
    const bool acked = writeAndAwaitAck(kCmdSetDisappearDelay, bytes, sizeof(bytes), 300);
    if (acked) disappearDelayS_ = seconds;
    Serial0.printf("[c4002] hold %us %s\n", seconds, acked ? "set" : "NOT acknowledged");
    return acked;
}

void C4002Reader::sendWrite(const uint8_t *payload, uint16_t len) {
    uint8_t buf[kMaxFrame];
    uint16_t total = len + 10; // 4 header + 2 length + 1 reserved + 1 type + 2 checksum
    if (total > sizeof(buf)) return;
    size_t n = 0;
    buf[n++] = 0xFA; buf[n++] = 0xF5; buf[n++] = 0xAA; buf[n++] = 0xA5;
    buf[n++] = total & 0xFF;
    buf[n++] = total >> 8;
    buf[n++] = 0x00;
    buf[n++] = kTypeWriteRequest;
    memcpy(&buf[n], payload, len);
    n += len;
    uint16_t sum = 0;
    for (size_t i = 0; i < n; i++) sum += buf[i];
    buf[n++] = sum & 0xFF;
    buf[n++] = sum >> 8;
    serial_->write(buf, n);
}

bool C4002Reader::writeAndAwaitAck(uint8_t cmd, const uint8_t *data, uint16_t dataLen, uint32_t timeoutMs) {
    uint8_t payload[kMaxFrame];
    uint16_t payloadLen = 4 + dataLen; // cmd, respCode, len(u16), data -- len counts all of it
    if (payloadLen + 10 > kMaxFrame) return false;
    payload[0] = cmd;
    payload[1] = 0x00; // eReadAndWriteReq
    payload[2] = payloadLen & 0xFF;
    payload[3] = payloadLen >> 8;
    memcpy(&payload[4], data, dataLen);
    lastFrameType_ = 0xFF;
    sendWrite(payload, payloadLen);

    uint32_t start = millis();
    while (millis() - start < timeoutMs) {
        while (serial_->available()) {
            charsProcessed_++;
            if (feed((uint8_t)serial_->read())) {
                handleFrame();
                if (lastFrameType_ == kTypeWriteResponse && lastFrameCmd_ == cmd) {
                    return lastFrameResp_ == kRespSucceed;
                }
            }
        }
        delay(1);
    }
    return false;
}

bool C4002Reader::feed(uint8_t b) {
    static const uint8_t kHeader[4] = {0xFA, 0xF5, 0xAA, 0xA5};
    if (frameLen_ < 4) {
        if (b == kHeader[frameLen_]) {
            frame_[frameLen_++] = b;
        } else {
            frameLen_ = (b == kHeader[0]) ? 1 : 0;
            if (frameLen_) frame_[0] = b;
        }
        return false;
    }

    frame_[frameLen_++] = b;
    if (frameLen_ == 6) {
        expectedLen_ = frame_[4] | (frame_[5] << 8);
        if (expectedLen_ < 12 || expectedLen_ > kMaxFrame) { // implausible length -- resync
            reportsUnparsed_++;
            frameLen_ = 0;
        }
        return false;
    }
    if (frameLen_ < 6 || frameLen_ < expectedLen_) return false;

    frameLen_ = 0; // frame_ keeps the bytes for handleFrame()
    uint16_t sum = 0;
    for (size_t i = 0; i < (size_t)expectedLen_ - 2; i++) sum += frame_[i];
    uint16_t claimed = frame_[expectedLen_ - 2] | (frame_[expectedLen_ - 1] << 8);
    if (sum != claimed) {
        reportsUnparsed_++;
        return false;
    }
    return true;
}

void C4002Reader::handleFrame() {
    lastFrameType_ = frame_[7];
    lastFrameCmd_ = frame_[8];
    lastFrameResp_ = frame_[9];
    if (lastFrameType_ != kTypeNotification || lastFrameCmd_ != kNoteResult) return;
    // Mirrors the vendor getNoteInfo(): only a success-coded result notification is used.
    if (lastFrameResp_ != kRespSucceed) { reportsUnparsed_++; return; }

    const uint16_t payloadLen = frame_[10] | (frame_[11] << 8);
    if (payloadLen < 4 + 18 || 12 + 18 > expectedLen_ - 2) { reportsUnparsed_++; return; }

    const uint8_t *d = &frame_[12];
    rawTargetStatus_ = d[0];
    targetStatus_ = d[0];
    lightLux_ = (d[1] | (d[2] << 8)) * 0.1f;
    const uint16_t existDistCm = d[9] | (d[10] << 8);
    const uint16_t moveDistCm = d[12] | (d[13] << 8);
    speedMps_ = (int16_t)(d[14] | (d[15] << 8)) * 0.01f;
    direction_ = d[17] <= 2 ? (Direction)d[17] : Direction::kNone;
    raw_.existGates = (uint32_t)d[3] | ((uint32_t)d[4] << 8) | ((uint32_t)d[5] << 16) | ((uint32_t)d[6] << 24);
    raw_.existCountdownS = d[7] | (d[8] << 8);
    raw_.existDistCm = existDistCm;
    raw_.existEnergy = d[11];
    raw_.moveDistCm = moveDistCm;
    raw_.moveEnergy = d[16];

    // Range limit, enforced here: a 2026-09-30 capture on node 1 had the module ACK a 460cm range
    // and still report targets at 580-660cm. Anything beyond maxRangeCm_ counts as no target.
    const uint16_t reportedCm = targetStatus_ == 2 ? moveDistCm : (targetStatus_ == 1 ? existDistCm : 0);
    beyondRange_ = targetStatus_ != 0 && maxRangeCm_ > 0 && reportedCm > maxRangeCm_;
    if (beyondRange_) targetStatus_ = 0;

    // Hold-timer-only presence (2026-09-30 field capture: after every movement burst the sensor
    // reported ~15s of "static presence", often with existDist 0, with nobody there). While a target
    // is actually detected the countdown sits at the full hold time; it only counts down once the
    // target is gone. So: static AND (no distance, or countdown below the hold time we set).
    clearing_ = targetStatus_ == 1 &&
        (existDistCm == 0 || (disappearDelayS_ > 0 && raw_.existCountdownS < disappearDelayS_));

    // 1 = static presence, 2 = motion. Distance from whichever target the sensor says is there.
    presence_ = targetStatus_ == 1 || targetStatus_ == 2;
    if (targetStatus_ == 2) distanceCm_ = moveDistCm;
    else if (targetStatus_ == 1) distanceCm_ = existDistCm;
    else distanceCm_ = 0.0f;
    gotResult_ = true;
}

bool C4002Reader::poll() {
    if (!serial_) return false;
    bool gotReport = false;
    while (serial_->available()) {
        charsProcessed_++;
        if (feed((uint8_t)serial_->read())) {
            handleFrame();
            if (gotResult_) {
                gotResult_ = false;
                reportsParsed_++;
                gotReport = true;
            }
        }
    }
    return gotReport;
}
