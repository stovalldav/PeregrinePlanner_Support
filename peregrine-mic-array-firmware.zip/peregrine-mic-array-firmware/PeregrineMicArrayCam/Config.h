// Config.h — pins, WiFi credentials, and tunable constants for the Peregrine Mic Array CAMERA
// node (FORIOT ESP32-S3-CAM, OV3660, N16R8). See CAMERA_NODE_NETWORK_SPEC.md (repo root) for the
// full pin-budget derivation this table comes from, and README.md here for wiring.
//
// **This board's camera claims GPIO4/5/6 for SIOD/SIOC/VSYNC** — a direct collision with
// ../PeregrineMicArray/Config.h's bus-0 pins (kTopWS=4/kTopBCLK=5/kTopBusDIN=6), confirmed against
// the real board's pinout diagram, not guessed. Bus 0 is remapped below to GPIO14/21/47 to clear
// the conflict; bus 1 is untouched since it never conflicted with anything camera-related.
//
// **GPS does NOT use GPIO44 -- real-hardware finding, 2026-08-10.** An earlier revision of this
// board's wiring put the GPS module's TX line on GPIO44 (this board's dedicated UART/programming
// USB-C port's own RX line, U0RXD) with `Serial0`'s RX disabled to "free" it. That looked fine on
// paper but broke actual firmware flashing outright -- GPIO44 is the exact net esptool's stub
// flasher uses during upload, and having the GPS module's TX output also drive it caused real
// contention, not just a lost-console-input tradeoff. Fixed by moving the GPS RX line to GPIO20
// instead (one of the two native-USB pins already sacrificed for PPS below) -- `Serial0` stays
// fully bidirectional on GPIO43/44 always, regardless of `kGPSEnabled`. JTAG is still unusable
// (GPIO41/42 are claimed by GPS TX and bus-1's SD pin respectively) — expected and accepted, same
// tradeoff class as bus 1's original SD-pin choice in the sibling firmware. Don't reintroduce
// GPIO44 for anything GPS-related.
//
// GPIO26-37 (octal PSRAM), GPIO38-40 (onboard SD), GPIO19-20 (native USB/OTG), and GPIO0/3/45/46
// (strapping) are never touched below — confirmed reserved by this board's own layout, not
// available regardless of what this firmware needs.
#pragma once

#include <cstddef>
#include <cstdint>

namespace Config {

// ---- I2S pins ----
// Bus 0 (I2S_NUM_0, independent master): TL (L-select) / TR (R-select), top pair.
// REMAPPED off the camera's GPIO4/5/6 (SIOD/SIOC/VSYNC) — see header comment.
// Only wired/used when kTopBusEnabled is true (see kMicCount below) -- the 2-mic single-bus
// variant (CAMERA_NODE_NETWORK_SPEC.md's "alternative" config) leaves these 3 pins unwired
// entirely, freeing them for something else (e.g. a compass over I2C).
constexpr int kTopWS   = 14;
constexpr int kTopBCLK = 21;
constexpr int kTopBusDIN = 47;

// Bus 1 (I2S_NUM_1, independent master -- its own separate clock, not synchronized to bus 0):
// BL (L-select) / BR (R-select), bottom pair. Unchanged from ../PeregrineMicArray/Config.h — no
// conflict with the camera or GPS pins on this board. Always wired/used regardless of kMicCount
// -- the 2-mic variant is "bottom bus only", not "top bus only".
constexpr int kBottomWS   = 1;
constexpr int kBottomBCLK = 2;
constexpr int kBottomBusDIN = 42;

// ---- Audio ----
constexpr uint32_t kSampleRateHz = 44100;
// INMP441 outputs 24-bit samples left-justified in a 32-bit I2S slot.
constexpr int kI2SBitsPerSample = 32;

// Capacity of the streaming-audio FIFOs (audioRing/audioRingRight/audioRingBottomLeft/
// audioRingBottomRight in the .ino) -- NOT the separate short DOA lookback rings
// (topLeftRing/etc., sized off kDOAWindowSamples instead, unaffected by this).
//
// Real-hardware finding, 2026-08-26: a live capture during video recording showed
// `[audio-ring] skipped` climbing extremely fast (>40% of all captured samples lost over ~35s) --
// traced to `esp_camera_fb_get()` itself (not the SD write, which was consistently fast) taking up
// to ~260ms per frame under real lighting, well past the previous 200ms (kSampleRateHz/5) capacity
// -- loop() blocks on that single call, so the ring can't be drained again until it returns. Raised
// to 2 full seconds of headroom, generous on purpose (same reasoning as kGPSUARTRxBufferBytes'
// ~4.5s headroom) -- absorbs several consecutive slow frames, not just one. Doesn't fix a
// SUSTAINED grab time worse than this buffer's fill rate forever (no buffer size can), but that
// wasn't the observed pattern -- grab times varied per frame, not a permanent floor above target.
// Paired with switching RingBuffer's own allocation to PSRAM (RingBuffer.h) specifically so this
// increase doesn't eat into this board's tight ~250KB internal-SRAM budget -- see that file's own
// comment. A few hundred ms of added streaming/video-audio-track latency during a real stall is an
// accepted, deliberate tradeoff against a permanent, silent gap spliced into that same audio.
constexpr uint32_t kAudioRingCapacitySamples = kSampleRateHz * 2;

// ---- Mic spacing ----
// Set this to your array's *actual* measured edge length (TL-to-TR distance, which should equal
// TL-to-BL) in meters, same as the sibling firmware — kMaxLagSamples below is derived from this at
// compile time.
constexpr float kMicSpacingMeters = 0.07f; // EDIT to your actual measured spacing

constexpr float kSpeedOfSoundMps = 343.0f;
constexpr int kMaxLagSamples = (int)((kMicSpacingMeters / kSpeedOfSoundMps) * (float)kSampleRateHz * 1.5f) + 1;

// ---- Onset gate (identical to the sibling firmware — see its Config.h for the real-hardware
// rationale behind each of these) ----
constexpr float kOnsetFastEnvelopeAlpha = 0.6f;
constexpr float kOnsetFloorDownAlpha = 0.01f;
constexpr float kOnsetFloorUpAlpha = 0.0001f;
constexpr float kOnsetTriggerRatio = 4.0f;
constexpr uint32_t kOnsetMinHoldMs = 5;
constexpr uint32_t kOnsetMinIntervalMs = 175;

// ---- Outlier rejection (see ../PeregrineMicArray/Config.h — same interim mitigation) ----
constexpr float kOutlierRejectRatio = 6.0f;

// ---- DOA analysis window ----
constexpr int kDOAWindowSamples = 1024; // ~23ms at 44.1kHz

// ---- GPS (ATGM336H, UART) ----
// EDIT per physical node -- not every node necessarily has the GPS module installed/wired (e.g.
// the module hasn't arrived yet, or this node is deliberately built without one). Defaults to
// false: only flip to true once the module is actually soldered in and you've confirmed which
// GPIOs it's wired to below. Gates GPS entirely -- no UART init, no position reporting, no
// NodeIdentityPacket.hasGPS claim.
constexpr bool kGPSEnabled = false; // EDIT to true once this node's GPS module is installed
// kGPSRXPin is NOT GPIO44 -- see header comment for why (real flashing-conflict finding,
// 2026-08-10). GPIO20 is one of the two native-USB pins, same tradeoff class as kPPSPin below.
constexpr int kGPSTXPin = 41; // ESP32 -> GPS RX
constexpr int kGPSRXPin = 20; // ESP32 <- GPS TX
constexpr uint32_t kGPSBaud = 9600; // ATGM336H default
// Real-hardware finding 2026-08-18, from a live GPS-freeze investigation on a physically 2-mic
// Cam node ("C2"): the default ESP32 Arduino core UART RX ring buffer is only 256 bytes, well
// under a second of headroom at this module's observed near-saturated ~450-460 B/s sustained send
// rate. Any loop() stall longer than that -- WiFi scan/reconnect's documented blocking calls
// (UDPStreamer.cpp), or specifically in 2-mic single-bus mode (see kMicCount above) the
// audio/onset work sharing loop()'s own core -- can silently drop bytes with zero visibility,
// which is the leading theory for a real, repeated field symptom: charsProcessed() kept climbing
// steadily for many minutes while sentencesWithValidChecksum()/WithInvalidChecksum() both froze
// forever, recovering only on reboot. Sized generously (~4.5s of headroom at the observed rate)
// -- ESP32-S3 RAM isn't tight here. Paired with GPSReader::maxPollGapMs() (new, same
// investigation) to directly measure whether loop() actually stalls that long in the field,
// rather than just inferring it from code structure.
constexpr uint32_t kGPSUARTRxBufferBytes = 2048;
// How often to send a GPSPositionPacket once a fix exists — position doesn't change mid-session,
// no need to stream it at telemetry rates.
constexpr uint32_t kGPSReportIntervalMs = 3000;

// ---- GPS PPS (pulse-per-second precision time base) ----
// Repurposes this board's SECOND USB-C port -- the ESP32-S3's native USB peripheral, wired to
// GPIO19/20 (D-/D+), confirmed unused anywhere in this project (no USB Host/Device code at all)
// and previously listed as fully unavailable in CAMERA_NODE_NETWORK_SPEC.md's pin budget. Using
// either pin as plain GPIO means giving up that port's USB function permanently -- these pins are
// physically wired via PCB trace to that connector's D-/D+ lines, so an external PPS signal on the
// same net as a live USB connection would conflict. Only do this if you're certain you'll never
// plug anything into that second port again. GPIO20 (D+) is left unwired/spare below -- only one
// pin is needed for PPS, and there's no current use for a second free pin.
//
// Only meaningful if kGPSEnabled is also true -- PPS is a signal from the same GPS module, not
// separate hardware. **Not yet consumed by any synchronized-capture feature** (cross-bus
// elevation / multi-node TDOA remain unimplemented, explicitly future work, see
// MIC_ARRAY_MASTER_AP_PLAN.md-adjacent discussion) -- PPSReader only captures and reports edge
// timing for now, so real-hardware bring-up can confirm the signal itself arrives correctly
// (pulses ~1,000,000 microseconds apart) before anything is built on top of it.
constexpr bool kPPSEnabled = false; // EDIT to true once wired -- see the port tradeoff above
constexpr int kPPSPin = 19; // GPIO19 (D-) of the board's second/native-USB port

// ---- Node identity ----
// Sent once after boot and then periodically (see kNodeIdentityIntervalMs) so the phone can
// reconcile this node against the user's declared configuration without out-of-band setup.
constexpr uint8_t kNodeType = 1; // 1 = camera + mic array, see NetworkProtocol.h's NodeIdentityPacket
// kMicCount (NOT kNodeType above -- that always stays 1 on this firmware regardless of mic count):
// 4 = full array, both I2S buses wired (kTopWS/kTopBCLK/kTopBusDIN + kBottomWS/kBottomBCLK/
// kBottomBusDIN all physically connected). 2 = CAMERA_NODE_NETWORK_SPEC.md's "2-mic single-bus"
// alternative -- bus 0 (top pair) genuinely left unwired, bus 1 (bottom pair) only. No other
// value is supported. This single constant is the source of truth for kTopBusEnabled below, which
// is what actually gates bus-0 init/capture/onset/DOA in the .ino and DOAEstimator -- setting this
// to 2 without also leaving GPIO14/21/47 unwired is harmless (those pins just go unused), but
// setting it to 4 while bus 0 is physically unwired will corrupt every DOA reading (floating-pin
// noise gets averaged into the azimuth/confidence the same as a real signal would) -- this value
// must match what's actually wired, not just what you'd prefer to report.
// Real bug found 2026-08-18: this was left at 4 on a physically 2-mic-wired unit (10.0.1.199,
// confirmed by the user) -- exactly the corruption scenario this constant's own comment above
// warns about. Boot log showed "starting busTop / busTop ready" (the 4-mic path) instead of
// "busTop skipped" -- top bus was reading floating GPIO14/21/47 as if real mics were connected,
// which explains "sound not working": the continuous mono reference stream this firmware sends
// (TL's channel) lives on the TOP bus, so with it unwired the reference audio itself was garbage/
// silence regardless of what the (correctly wired) bottom pair was picking up.
constexpr uint8_t kMicCount = 4; // EDIT to 2 for the 2-mic + GPS variant -- see README's wiring table
constexpr bool kTopBusEnabled = (kMicCount == 4);
constexpr uint32_t kNodeIdentityIntervalMs = 5000;

// ---- Network role (host-your-own-AP or join-a-network model, see MIC_ARRAY_MASTER_AP_PLAN.md) ----
// kRolePrimary: this node hosts its own WiFi AP -- kWiFiSSID/kWiFiPassword below become what IT
// broadcasts. Every other node in the fleet, and the phone, join it directly -- no external router
// needed, works at a genuinely remote site. Also automatically the roster master (see below):
// there's no separate flag for that anymore, it's simply whichever node is currently the one
// hosting. Exactly one node per fleet should be Primary.
// kRoleClient: this node joins a network as a station instead -- kWiFiSSID/kWiFiPassword become
// whatever network you're pointing it at, which can be either your fleet's own Primary (set to the
// EXACT SAME value as that node's own kWiFiSSID/kWiFiPassword, same convention already used by
// PeregrineMicArrayRearSensor joining the front array's fixed AP) OR a genuinely external network
// (a home/field router, the original MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #1 model) -- this
// firmware doesn't distinguish between those two cases, only you do, by what you set these
// credentials to.
// kRoleSecondary: **implemented 2026-08-14** (MIC_ARRAY_MASTER_AP_PLAN.md §4). Behaves exactly
// like kRoleClient while the Primary is reachable -- this real unit's already-validated Secondary/
// Client-equivalent behavior is unchanged, confirmed by the failover code path being a pure no-op
// whenever WiFi.status() == WL_CONNECTED (see UDPStreamer::pollFailover()). Only new: if the STA
// connection is lost for longer than kFailoverTimeoutMs (including never connecting at all on a
// cold boot -- see UDPStreamer::begin()), this node promotes itself to WIFI_AP_STA, hosting the
// SAME kWiFiSSID/kWiFiPassword the Primary does, so existing Clients and the phone reconnect with
// zero reconfiguration -- then periodically re-scans (kPrimaryRescanIntervalMs) for the real
// Primary's specific BSSID (kPrimaryBSSID below, NOT just "an AP with this SSID", since both
// broadcast the same one once failed-over) to know when to step back down.
//
// **Only kRoleSecondary can ever fall back to hosting an AP** -- a plain kRoleClient that
// exhausts every kWiFiCandidates entry just has no network at all until pollReconnect() retries
// (see WIFI_MULTI_SSID_FALLBACK_PLAN.md's Phase 2); it never stands up a softAP. If you want "try
// the phone's Personal Hotspot / home router, and if it's not around, host our own AP so the fleet
// still has somewhere to go," that's kRoleSecondary, repurposed to back up an EXTERNAL network
// instead of this fleet's own Primary -- see WIFI_MULTI_SSID_FALLBACK_PLAN.md's "Configuration
// recipe: hotspot backup with an AP fallback" section for the full, easy-to-get-wrong setup:
// kWiFiCandidates below must NOT default to kWiFiSSID/kWiFiPassword in that mode -- they need to
// be different values, the hotspot to try vs. this node's own distinct fallback broadcast
// identity -- and kPrimaryBSSID below needs to be the hotspot's actual BSSID, not a fleet Primary's.
constexpr uint8_t kRolePrimary = 0;
constexpr uint8_t kRoleSecondary = 1;
constexpr uint8_t kRoleClient = 2;
constexpr uint8_t kNetworkRole = kRoleClient; // EDIT per physical node

// ---- Secondary/failover tuning (only meaningful when kNetworkRole == kRoleSecondary) ----
// How long to tolerate losing the Primary's STA connection before promoting this node to host its
// own AP. **No real-hardware-measured value exists** (flagged open in MIC_ARRAY_MASTER_AP_PLAN.md
// §7) -- 30s chosen as a starting point: comfortably longer than an ordinary WiFi hiccup/
// reassociation (typically a few seconds), short enough that a genuine Primary failure doesn't
// leave the fleet dark for long. Tune once real multi-node hardware exists to test failover
// against.
constexpr uint32_t kFailoverTimeoutMs = 30000;
// How often a failed-over Secondary re-scans for the real Primary. WiFi.scanNetworks() is a
// BLOCKING call on this single-radio chip -- every scan is a real, if brief, disruption to
// whatever this node is doing while failed-over (currently-connected Clients' traffic, and
// potentially this node's own mic capture if the WiFi/BT shared core gets starved during the scan,
// unmeasured). Deliberately infrequent to bound how often that disruption happens, traded off
// against how quickly the fleet reunifies once the real Primary comes back -- same "unmeasured
// starting point" caveat as kFailoverTimeoutMs.
constexpr uint32_t kPrimaryRescanIntervalMs = 60000;
// The BSSID (WiFi MAC address) of whatever this node is failing OVER FOR -- NOT its own STA MAC,
// and not something this node can discover on its own once both it and that network broadcast the
// identical SSID/password. In the original design this is the fleet's own Primary: read this off
// the Primary's own boot log (its AP-hosting checkpoint now prints WiFi.softAPmacAddress()
// specifically for this) once, and hardcode it here -- same "confirmed against the real unit"
// per-node manual-field convention as kMicSpacingMeters. In the "hotspot backup with an AP
// fallback" configuration (WIFI_MULTI_SSID_FALLBACK_PLAN.md) this is instead the phone's own
// Personal Hotspot BSSID (or a home router's) -- same field, same purpose, different network. All
// zeros (the default) means "not configured": this node will still fail over (promote to hosting
// its own AP) correctly either way, but can never confirm the real target's return, so it stays
// failed-over until manually rebooted. Set this before relying on failover in the field.
constexpr uint8_t kPrimaryBSSID[6] = {0, 0, 0, 0, 0, 0}; // EDIT: read off the target network's own BSSID

// Up to this many total physical nodes in one fleet, counting the Primary itself -- sizes the
// Primary's AP station slots (see kMaxAPStations) and the roster's own kMaxRosterEntries headroom
// (NetworkProtocol.h, already generous at 8). **Planning number, not a validated-stable one** --
// see MIC_ARRAY_MASTER_AP_PLAN.md's open questions on real station-count stability.
constexpr int kMaxFleetNodes = 5;
// The Primary's AP needs to accept up to (kMaxFleetNodes - 1) sibling nodes plus the phone, which
// --  since kMaxFleetNodes already counts the Primary itself -- comes out to exactly
// kMaxFleetNodes stations total.
constexpr int kMaxAPStations = kMaxFleetNodes;
// AP channel -- only meaningful when kNetworkRole == kRolePrimary. Matches the front array's own
// fixed channel choice (../PeregrineMicArray/Config.h's kWiFiChannel); no coordination is actually
// needed between the two (a phone/node only ever joins one of these networks at a time), just no
// reason to invent a different convention.
constexpr int kWiFiChannel = 6;

// ---- Node roster (multi-node discovery, see MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #1) ----
// The current Primary (kNetworkRole == kRolePrimary, see above) aggregates every other node's
// periodic kNodeAnnounce broadcast into a roster the phone can pull with a single kRosterRequest,
// instead of the user typing in every node's IP by hand. Every other node still compiles and runs
// identically either way -- they just never populate a roster, so they always reply to
// kRosterRequest with count=0.
// Scopes roster aggregation to YOUR OWN nodes only -- set the exact same value on every node you
// personally own, and something different from any other fleet whose nodes might ever join the
// same WiFi network as yours (a shared venue WiFi, a portable hotspot on a joint outing). Without
// this, a master node aggregates ANY kNodeAnnounce it hears on its network, including a different
// user's nodes if you happen to be on the same WiFi -- see NetworkProtocol.h's NodeIdentityPacket
// comment. There's no registry to check uniqueness against; pick any nonzero value unlikely to
// collide (mash the keyboard, or use the current unix time when you set up this fleet) --
// **leaving this at the default risks exactly the collision this field exists to prevent** if two
// people both forget to change it.
constexpr uint32_t kFleetId = 0x00000000; // EDIT to a value unique to your own fleet of nodes
constexpr uint32_t kNodeAnnounceIntervalMs = 5000; // matches kNodeIdentityIntervalMs's cadence
// A sibling not re-announced within this window is dropped from the roster -- distinguishes "still
// out there, just between announces" from "powered off / out of range" without a separate
// keepalive mechanism.
constexpr uint32_t kRosterStaleTimeoutMs = 20000;

// Added 2026-08-16 -- see ../PeregrineMicArray/Config.h's own copy of this constant for the full
// rationale (mirrored here verbatim): true on exactly one node lets it keep acting as roster
// master even in an all-kRoleClient shared-external-network deployment (a home router, or the
// phone's own Personal Hotspot), where isCurrentlyHosting() is unconditionally false for every
// node. Leave false when using kRolePrimary/kRoleSecondary AP-hosting setups.
constexpr bool kIsRosterMaster = false; // EDIT: true on exactly one node, only in an all-kRoleClient shared-network setup

// ---- Camera (OV3660) ----
// JPEG straight off the sensor — smallest transfer size over the phone's HTTP GET, and this
// firmware has no use for raw frames (no on-device vision, just capture-on-trigger + serve).
constexpr int kCameraJpegQuality = 12; // 0-63, lower = higher quality/larger file
constexpr size_t kCameraFrameBufferCount = 1; // single buffer: capture-on-demand, not streaming video
// Minimum gap between photo captures, triggered off the same onset gate as DOA capture -- a burst
// of onsets (e.g. a chattering flock) shouldn't thrash the single frame buffer/HTTP server faster
// than the phone could plausibly fetch each one.
constexpr uint32_t kPhotoMinIntervalMs = 5000;
// Whether the onset gate fires the camera at all (see kSetPhotoMode/PhotoModePacket) -- the
// runtime-toggleable default. Manual capture (kPhotoCaptureNow) always works regardless of this.
constexpr bool kPhotoAutoModeDefault = true;

// Max still photos kept on the SD card at once (SD-backed photo store, added 2026-08-28). Every
// capture is now written to /photos/<id>.jpg as well as the single in-RAM PhotoServer buffer, so
// it survives a loop() stall, the app switching which node feeds a screen, or a power cycle. The
// phone reconciles GET /photos on (re)connect, pulls anything it's missing, and DELETEs each as it
// goes. This cap is the safety net for "the phone never comes back": once /photos exceeds it,
// capturePhotoIfDue() evicts the lowest-id (oldest) files. ~50KB per JPEG, so 1000 is ~50MB --
// negligible on any real card.
constexpr uint16_t kMaxStoredPhotos = 1000;

// ---- Bird-feeder / Home Assistant camera mode (2026-08-28) ----
// Turns a node into a plain network camera you can point Home Assistant / Frigate at directly,
// with no Peregrine Planner app involvement -- see HOME_ASSISTANT.md.
//   * The MJPEG stream (kLiveStreamHTTPPort, /stream) auto-starts at boot and stays up: the
//     kLiveStreamMaxDurationMs field-setup timeout is disabled, and loop() re-starts it if it
//     ever stops. HA/Frigate can't send the kVideoStreamStart control packet the app uses, so
//     without this the stream would never turn on for them.
//   * The mic-array / onset / DOA pipeline is skipped entirely (capture tasks not started, no
//     audio-frame or DOA-telemetry work in loop()) -- this is a camera now, not a mic array, and
//     that frees the CPU/power the array pipeline was using. Still-photo capture in this mode is
//     motion-triggered (kMotionSensorEnabled) or on-demand (GET /snapshot, the app's manual
//     capture), not onset-triggered. GPS, video recording, and the SD photo store all still work.
//   * A video-record request (from the app) makes the stream yield for the recording's duration,
//     then loop() brings the stream back -- rather than the request being rejected.
constexpr bool kFeederCamMode = false;

// PIR / occupancy sensor -> capture a photo + emit kMotionTrigger on the rising edge. Independent
// of kFeederCamMode (useful on any camera node), but especially the point of a feeder cam: a
// silent bird at the feeder never trips the sound-based onset capture. Wire the sensor's OUT to
// kMotionSensorPin (most PIR modules drive it HIGH on motion; INPUT_PULLDOWN so a disconnected
// pin reads as "no motion").
constexpr bool kMotionSensorEnabled = false;
// GPIO21 is the top-bus BCLK -- genuinely free on a 2-mic (kMicCount==2) / kFeederCamMode build
// where the top bus is never wired or driven. Do NOT enable kMotionSensorEnabled on a 4-mic node
// without first moving this to an actually-free pin.
constexpr int kMotionSensorPin = 21;
// Minimum gap between motion-triggered captures/packets -- a PIR holds its output HIGH for its
// own dwell time and re-triggers on continued presence, which at a busy feeder would otherwise
// be a capture every frame. Matches kPhotoMinIntervalMs.
constexpr uint32_t kMotionRetriggerMs = 5000;

// ---- Video recording (MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3) ----
// Phone-triggered start/stop, not onset-gated like stills -- see VideoRecordStartPacket's comment
// in NetworkProtocol.h. This hardware has no video encoder, so "video" here is really a JPEG still
// sequence + a WAV audio track, composed into an actual video file on the phone afterward
// (MicArrayVideoFetcher) -- see the plan doc for why that split, not on-node encoding.
// **Frame rate/duration below are conservative, unvalidated defaults** -- SD write speed and
// JPEG-capture timing at this frame interval have not been measured on real hardware (per this
// project's own "real-device evidence only" rule, treat these as a starting point to tune once a
// board exists to test against, not confirmed-good values).
// Raised from 500ms (~2fps) to 167ms (~6fps) 2026-08-18 per user request -- composed video looked
// choppy at 2fps (inherent to that low a frame rate, not a bug). **Still unvalidated on real
// hardware at this new rate** -- same caveat as before, now with a real, specific risk worth
// flagging: at the same kVideoMaxDurationMs below, a full-length session now captures ~3x as many
// frames (up to ~180 instead of ~60), meaning ~3x the per-session SD writes, ~3x the phone's
// frame-by-frame HTTP fetch count, and ~3x compose time -- exactly the class of "extremely long to
// generate" symptom this project already spent a whole investigation root-causing once (see
// project_fleet_reliability_features memory). VideoRecorder::captureFrame() below got matching
// timing diagnostics specifically so the next real test can show directly whether SD write speed
// actually keeps up at this rate, rather than assuming it does.
constexpr uint32_t kVideoFrameIntervalMs = 167;   // ~6 fps
constexpr uint32_t kVideoMaxDurationMs = 30000;   // safety cutoff if the phone never sends kVideoRecordStop
                                                    // (e.g. it's backgrounded or the connection drops)
// SD_MMC (1-bit mode) pins -- **unverified against real hardware**, same caveat as CameraPins.h's
// own header: this matches the common convention for this class of ESP32-S3-CAM board's onboard
// SD slot, and lines up with CAMERA_NODE_NETWORK_SPEC.md's pin-budget table already marking
// GPIO38-40 as claimed by "onboard SD" -- but that table only established the pins were reserved
// for this purpose, not confirmed the exact CLK/CMD/D0 assignment. Verify against the actual board
// silkscreen/schematic before flashing, not just trust this.
constexpr int kSDCmdPin = 38;
constexpr int kSDClkPin = 39;
constexpr int kSDDataPin = 40;

// ---- Diagnostics ----
// Same purpose as the sibling firmware's flag — skip WiFi/network entirely to test whether the
// radio couples electrical noise into the I2S lines.
constexpr bool kDiagnosticDisableWiFi = false;

// ---- WiFi STA ----
// Unlike the front array/rear sensor (which run their own fixed SoftAP), this node joins an
// EXISTING network the phone is also on — per the confirmed "leave existing hardware on AP mode,
// add STA support only for new nodes" decision. EDIT these to match your actual home/field network.
//
// One STA candidate network -- see WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16 for
// kWiFiCandidates below.
struct WiFiCredential {
    const char *ssid;
    const char *password;
};

constexpr const char *kWiFiSSID = "PeregrineMicArray";
constexpr const char *kWiFiPassword = "birding123";

// ---- WiFi multi-SSID fallback (see WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16) ----
// Only meaningful when STA-joining (kNetworkRole == kRoleClient, or kRoleSecondary's initial boot
// join -- NOT its pollFailover() reclaim reconnect, which deliberately stays pinned to
// kWiFiSSID/kWiFiPassword above since that path is about rejoining THIS node's own fleet Primary
// specifically, not picking among arbitrary external networks). UDPStreamer::begin() tries each
// candidate in order, giving each up to kWiFiPerCandidateTimeoutMs, and stops at the first one
// that connects. Defaults to a single entry matching kWiFiSSID/kWiFiPassword above, so an existing
// single-network deployment needs zero changes here to keep working exactly as before.
//
// **If this node is the "hotspot backup with an AP fallback" node** (kNetworkRole ==
// kRoleSecondary above, repurposed per WIFI_MULTI_SSID_FALLBACK_PLAN.md's configuration recipe):
// replace the default entry below entirely -- point this list at the actual hotspot/router to
// join, and leave kWiFiSSID/kWiFiPassword above as this node's own distinct fallback broadcast
// identity instead. Leaving this defaulted to kWiFiSSID/kWiFiPassword in that mode means you're
// trying to join your own not-yet-hosted fallback network, which will just never connect.
//
// **If some OTHER node in your fleet is configured as that hotspot-backup node**: add ITS
// kWiFiSSID/kWiFiPassword (its fallback identity, not the hotspot's) as an entry here too, so this
// node has somewhere to land if that one is ever actually hosting instead of relaying to the
// hotspot.
constexpr WiFiCredential kWiFiCandidates[] = {
    { kWiFiSSID, kWiFiPassword },
    // Real bug found 2026-08-18: this used a plain ASCII apostrophe (0x27) -- iOS auto-generates
    // possessive hotspot names with the typographic right single quote (U+2019) instead, confirmed
    // against the user's own iPhone. See ../PeregrineMicArray/Config.h's matching comment for the
    // full account (found and fixed there first).
    // Add your own STA fallback networks here. iOS possessive hotspot names use a typographic
    // right single quote (U+2019, ’), not a plain apostrophe -- copy the SSID exactly as shown.
    // Add more, most-preferred first, e.g.:
    // { "MyHomeWiFi", "homepassword123" },
    // { "My iPhone", "hotspotpassword" },
};
constexpr uint32_t kWiFiPerCandidateTimeoutMs = 3000; // lowered 8000->3000 (2026-08-28) after a
    // real-hardware capture caught loop() frozen 6.3s (`[gps-link] max poll gap: 6326 ms`, audio
    // ring overflow, phone unable to fetch/command) -- pollReconnect() walks this whole list in
    // loop(), and two of the three default candidates (the front-array AP, a phone hotspot) are
    // usually absent, each costing a full timeout before the real network is tried. Worst-case
    // stall is candidateCount * this value, so also trim kWiFiCandidates in Config.local.h to just
    // the network the node actually uses. Real fix is an async (event-driven) reconnect that never
    // blocks loop() -- deferred; this is the cheap mitigation.

// Phase 2 (WIFI_MULTI_SSID_FALLBACK_PLAN.md) -- only meaningful for kNetworkRole == kRoleClient
// (kRoleSecondary has its own, more specialized runtime recovery via pollFailover()'s
// promote-to-AP path; kRolePrimary/a failed-over Secondary hosts, nothing to reconnect to). If the
// STA link has been down this long, UDPStreamer::pollReconnect() re-attempts the full
// kWiFiCandidates join loop from the top. Real known cost, not hidden: that retry blocks loop()
// for up to candidateCount * kWiFiPerCandidateTimeoutMs while it runs -- accepted because audio
// capture lives on its own pinned FreeRTOS tasks (captureTopTask/captureBottomTask), not in
// loop(), and no UDP traffic can happen without a live link anyway during that stall.
constexpr uint32_t kWiFiReconnectGraceMs = 10000; // unmeasured starting point

// ---- UDP ----
// Same port as every other node — this device's own IP is what distinguishes it, set in the
// phone app's "Network Address" field for this node (see MicArrayNodesView.swift) once you read
// this node's assigned IP off the Serial0 boot log.
constexpr uint16_t kUDPPort = 3333;
constexpr uint32_t kStreamingInactivityTimeoutMs = 10000;

// ---- Audio streaming ----
constexpr int kAudioSamplesPerPacket = 441;
// Stereo (kStereoAudioFrame, kTopBusEnabled/4-mic only) interleaves 2 channels into the same
// 12-byte header, so this is deliberately smaller than kAudioSamplesPerPacket above -- at 441
// samples/channel the interleaved payload would be 12 + 441*2*2 = 1776 bytes, over the ~1472-byte
// practical UDP-over-WiFi MTU (risking IP fragmentation, the mono path's whole reason for using
// 441 in the first place). 360 samples/channel keeps it at 12 + 360*2*2 = 1452 bytes, ~8.16ms/
// ~122 packets/sec -- fragmentation-free with the same headroom philosophy as kAudioSamplesPerPacket.
constexpr int kStereoAudioSamplesPerChannel = 360;

// ---- Automatic top/bottom-pair audio fallback (kTopBusEnabled/4-mic only) ----
// Real-hardware finding 2026-08-18/20, on the sibling front-array node: the top pair (TL/TR) was
// found completely silent (peak level exactly 0 for a full ~2h08m field session AND a 30s
// real-hardware clip capture) while the bottom pair's I2S reads succeeded the whole time -- with
// no fallback, this meant the streamed reference audio (and therefore Bird Sounds Detection
// entirely) went silent even though a perfectly good second pair of mics was sitting right there,
// unused, on the same node. See usingBottomPairForStream's declaration for how these two
// constants gate the switch.
// Below this peak amplitude, a pair is considered "silent" for fallback purposes -- matches this
// project's documented healthy background-noise floor (~15-110 in earlier real-hardware onset
// tuning), comfortably above normal quiet-room electrical noise so a genuinely working pair never
// falsely trips this.
constexpr int16_t kAudioFallbackSilenceThreshold = 50;
// How many consecutive 2s status-report intervals (~10s total) a pair must stay below the
// threshold before triggering a fallback -- avoids switching on a single quiet moment between bird
// calls. Symmetric: the same streak length is required to switch back once a previously-silent
// pair recovers.
constexpr int kAudioFallbackSilenceIntervals = 5;

// ---- Photo HTTP server ----
constexpr uint16_t kHTTPPort = 80;
// Separate WebServer instance/port for video frame/audio serving (VideoServer) -- a single port
// can only be bound by one WebServer instance, so this can't share kHTTPPort with PhotoServer.
constexpr uint16_t kVideoHTTPPort = 81;

// ---- Live video streaming (field camera-aim validation; see MULTI_NODE_APP_ENHANCEMENTS_PLAN.md
// #7's original framing -- this is the smaller, immediately-needed slice of that idea) ----
// MJPEG over a raw HTTP multipart stream, phone-triggered start/stop, meant for confirming a
// camera is aimed/focused/working while physically setting up a node in the field -- not smooth
// video. Deliberately its OWN port and its OWN raw WiFiServer, NOT built on the WebServer class
// PhotoServer/VideoServer use -- see LiveStreamServer.h's header for why (that class's
// handleClient() runs a request handler inline and blocking, and a real MJPEG stream needs to
// keep writing frames until the client disconnects, which would starve loop() -- mic capture,
// onset detection, GPS -- for the whole stream duration).
constexpr uint16_t kLiveStreamHTTPPort = 82;
// ~5fps target -- enough to confirm framing/focus, not meant to be smooth. Real achievable rate
// is bandwidth-limited in practice (see kLiveStreamWriteChunkBytes below) -- confirmed on real
// hardware, 2026-08-10: a single ~24KB frame's client_.write() call was measured blocking for up
// to 744ms on a real WiFi link, well past this interval.
constexpr uint32_t kLiveStreamFrameIntervalMs = 200;
// Safety cutoff if the phone never sends kVideoStreamStop (view screen backgrounded, connection
// drops) -- same reasoning as kVideoMaxDurationMs.
constexpr uint32_t kLiveStreamMaxDurationMs = 120000;
// Real-hardware finding, 2026-08-10: LiveStreamServer originally wrote a whole JPEG frame
// (~20-50KB) in one client_.write() call per poll() -- fine on paper ("at most one frame's worth
// of work per call"), but on real hardware that one call was measured blocking for up to 744ms,
// during which NOTHING else in loop() ran (confirmed independently: audioRing's skipped-sample
// counter exploded specifically while live-streaming was active, on the order of the full sample
// rate -- i.e. essentially all audio capture was lost for the stream's duration). Checked
// WiFiClient (esp32 core 3.3.11) for availableForWrite() first, to chunk adaptively to whatever
// the link can actually accept without blocking -- it isn't overridden, always returns the
// Print:: base class's 0, not usable here. Fixed instead with a small FIXED chunk size, sent
// across as many poll() calls as it takes -- bounds any single call's worst-case block to roughly
// this many bytes' worth of write time instead of a whole frame's, regardless of whether the
// underlying slowness turns out to be WiFi-stack/CPU contention or a genuinely weak RF link.
// Total wall-clock time to send one frame is unchanged; what changes is how often loop() gets
// control back to drain audio/service GPS/etc. while a frame is still in flight.
constexpr size_t kLiveStreamWriteChunkBytes = 1024;
// Real-hardware finding, 2026-08-10 (third round): chunking alone didn't fix the worst stalls --
// a real-world test showed mostly-healthy frame writes (well under 350ms even for 40-50KB frames)
// punctuated by rare, extreme stalls, one measured at 75+ seconds for a single ~26KB frame. That
// bimodal pattern (fine / catastrophically stuck, not uniformly slow) is the signature of a
// stale/half-dead TCP connection -- client_.connected() still reports true, but the peer has
// stopped acking (backgrounded WKWebView, dismissed view, a brief WiFi drop) -- not a weak RF
// link, which would show uniformly degraded throughput instead. The OS TCP stack's own
// retransmission timeout eventually notices on its own, but "eventually" measured in the tens of
// seconds is too slow -- this bounds how long LiveStreamServer will wait on one frame before
// giving up on the connection and forcing a fresh one.
constexpr uint32_t kLiveStreamFrameWatchdogMs = 3000;

} // namespace Config
