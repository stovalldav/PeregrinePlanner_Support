// VideoRecorder.h — phone-triggered start/stop capture session: a JPEG frame sequence + optional
// WAV audio track written to the SD card, served to the phone afterward for it to compose into an
// actual playable video (see NetworkProtocol.h's VideoRecordStartPacket/VideoReadyPacket and
// MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #3). Runs entirely on the node once started -- no further
// phone involvement needed until it fetches the result, matching the "runs in the background,
// doesn't interrupt app usage" requirement.
#pragma once

#include <cstdint>
#include <SD_MMC.h>
#include <WString.h>

class VideoRecorder {
public:
    // Mounts the SD card (1-bit SD_MMC mode, Config::kSDCmdPin/kSDClkPin/kSDDataPin) -- call once
    // at boot. Returns false if no card is present/mount failed; every other method safely no-ops
    // when the card isn't mounted, so a missing SD card degrades this feature only, not the rest
    // of the node's operation (mic array + stills still work without it).
    bool beginSD();
    bool isSDReady() const { return sdReady_; }

    bool isRecording() const { return recording_; }
    uint32_t currentVideoId() const { return videoId_; }
    uint16_t frameCount() const { return frameCount_; }
    uint32_t audioSampleCount() const { return audioSampleCount_; }

    // Starts a new session -- `videoId` is caller-assigned (a monotonic counter, same pattern as
    // PhotoServer's photoId). Fails if the SD card isn't ready or a session is already in progress
    // (one at a time, matching this node's single-frame-buffer camera design elsewhere).
    bool start(uint32_t videoId, bool includeAudio, uint32_t nowMs);

    // Call every loop() iteration. Captures a new frame once Config::kVideoFrameIntervalMs has
    // elapsed since the last one, and auto-stops at Config::kVideoMaxDurationMs. Doesn't itself
    // signal "a session just finished" -- the caller detects that by noticing isRecording() went
    // from true to false across a poll()/stop() call (a plain return-value signal would be lost
    // whenever an explicit stop() call, not this auto-cutoff, is what actually ended the session).
    void poll(uint32_t nowMs);

    // Explicit stop (phone's kVideoRecordStop). Idempotent -- calling it when nothing's recording
    // is a harmless no-op, since the phone's stop button doesn't track server-side state itself.
    void stop(uint32_t nowMs);

    // Appends one block of PCM samples to the current session's WAV file -- called from the same
    // place UDPStreamer::sendAudioFrame's block already flows (PeregrineMicArrayCam.ino's loop()),
    // not a second consumer of the audio ring buffer. No-ops if not recording or audio wasn't
    // requested for this session.
    void appendAudio(const int16_t *samples, int count);

    static String framePath(uint32_t videoId, uint16_t frameIndex);
    static String audioPath(uint32_t videoId);

private:
    void captureFrame(uint32_t nowMs);
    void finishSession();
    void writePlaceholderWAVHeader();
    void finalizeWAVHeader();
    // Real hardware finding, 2026-08-17: nothing ever deleted a finished session's frame files/
    // directory from the SD card -- every capture accumulated forever, degrading FAT filesystem
    // open/write performance over repeated use and eventually risking genuinely running out of
    // space. Called from start() to delete an OLD session (see that method's own comment for why
    // two generations back, not the immediately-previous one).
    static void deleteSessionDirectory(uint32_t videoId);

    bool sdReady_ = false;
    bool recording_ = false;
    bool includeAudio_ = false;
    uint32_t videoId_ = 0;
    uint32_t startMs_ = 0;
    uint32_t lastFrameMs_ = 0;
    uint16_t frameCount_ = 0;
    uint32_t audioSampleCount_ = 0;
    File audioFile_;
};
