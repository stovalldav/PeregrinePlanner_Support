// PresenceConfigStore.h -- the presence sensor's detection range and hold time, as last set from the
// app (kSetPresenceRange, added 2026-09-30). Kept in NVS so the node comes back with the user's
// range after a power cut, with no phone connected -- a security node is often running alone or
// feeding Home Assistant. Config.h's values are only the starting point until the app changes them.
// Identical copy in ../PeregrineMicArrayCam/ (keep the two in sync).
#pragma once

#include <Preferences.h>

class PresenceConfigStore {
public:
    static constexpr uint16_t kUnset = 0xFFFF;

    void begin() { prefs_.begin("presence", false); }

    // kUnset when the app has never set it.
    uint16_t maxRangeCm() { return prefs_.getUShort("range", kUnset); }
    uint16_t holdS() { return prefs_.getUShort("hold", kUnset); }

    void setMaxRangeCm(uint16_t cm) { prefs_.putUShort("range", cm); }
    void setHoldS(uint16_t seconds) { prefs_.putUShort("hold", seconds); }

private:
    Preferences prefs_;
};
