#include "BLEAdvertiser.h"
#include <BLEDevice.h>
#include <BLEAdvertising.h>
#include <cstring>
#include "Config.h"

namespace {
// Mirrors UDPStreamer::fillDeviceId()'s exact source (ESP.getEfuseMac(), NOT a WiFi-derived MAC --
// see NodeIdentityPacket's own doc comment in NetworkProtocol.h for why) so the SAME physical node
// reports the SAME deviceId over BLE as it does over the UDP wire protocol -- lets the phone match
// a BLE-discovered node against an already-declared one via the identical deviceId both paths use.
void fillDeviceId(uint8_t *out) {
    uint64_t mac = ESP.getEfuseMac();
    for (int i = 0; i < 6; i++) {
        out[i] = (uint8_t)(mac >> (8 * i));
    }
}
} // namespace

void BLEAdvertiser::begin() {
    fillDeviceId(deviceId_);
    BLEDevice::init("PPCam");
}

void BLEAdvertiser::poll(bool hasClient, IPAddress currentIP) {
    if (hasClient) {
        if (advertising_) stopAdvertising();
        return;
    }
    if (!advertising_) {
        startAdvertising(currentIP);
        return;
    }
    // Already advertising -- refresh the payload if our IP changed since we started (DHCP
    // renewal mid-boot, before any client has registered).
    if (currentIP != lastAdvertisedIP_) {
        startAdvertising(currentIP);
    }
}

void BLEAdvertiser::startAdvertising(IPAddress ip) {
    lastAdvertisedIP_ = ip;

    // Manufacturer-data payload, 14 bytes -- see BLE_NODE_DISCOVERY_PLAN.md's byte layout. Raw
    // bytes, not a struct -- BLEAdvertisementData::setManufacturerData() takes an arbitrary byte
    // string, and this must match byte-for-byte what MicArrayBLEScanner (app side) decodes.
    uint8_t payload[14];
    payload[0] = 'P';
    payload[1] = 'P'; // magic marker, identifies this as a Peregrine Planner node during scanning
    memcpy(&payload[2], deviceId_, 6);
    payload[8] = Config::kNodeType;
    uint8_t flags = 0;
    if (Config::kGPSEnabled) flags |= 0x01;
    payload[9] = flags;
    payload[10] = ip[0];
    payload[11] = ip[1];
    payload[12] = ip[2];
    payload[13] = ip[3];

    // BLEAdvertisementData::setManufacturerData() takes an Arduino String, not std::string -- and
    // critically NOT the null-terminated-cstring constructor (payload bytes routinely include 0x00,
    // e.g. any IP octet that's actually 0, or flags==0 -- that constructor would silently truncate
    // the payload at the first such byte). The explicit-length constructor below copies exactly
    // sizeof(payload) bytes regardless of content.
    BLEAdvertisementData advData;
    advData.setManufacturerData(String((const char *)payload, sizeof(payload)));

    BLEAdvertising *advertising = BLEDevice::getAdvertising();
    advertising->stop(); // safe even if not currently running -- avoids a duplicate-start warning
    advertising->setAdvertisementData(advData);
    advertising->setScanResponse(false);
    advertising->start();
    advertising_ = true;
}

void BLEAdvertiser::stopAdvertising() {
    BLEDevice::getAdvertising()->stop();
    advertising_ = false;
}
