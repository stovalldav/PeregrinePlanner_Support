#include "BLEAdvertiser.h"
#include <BLEDevice.h>
#include <BLEAdvertising.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <cstring>
#include "Config.h"
#include "NetworkProtocol.h"

// --- GATT provisioning UUIDs (CONFIGURABLE_FLEET_PLAN.md) -- must match MicArrayBLEProvisioner ---
static const char *kProvServiceUUID = "4F2A0000-9B5E-4C71-8D3A-1E7C0F6B2A11";
static const char *kProvWriteUUID   = "4F2A0001-9B5E-4C71-8D3A-1E7C0F6B2A11"; // phone -> device, [op][body], mirrors kSetWiFiConfig data[2..]
static const char *kProvReportUUID  = "4F2A0002-9B5E-4C71-8D3A-1E7C0F6B2A11"; // device -> phone, full kWiFiConfigReport bytes, read + notify

namespace {
void fillDeviceId(uint8_t *out) {
    uint64_t mac = ESP.getEfuseMac();
    for (int i = 0; i < 6; i++) {
        out[i] = (uint8_t)(mac >> (8 * i));
    }
}
} // namespace

// Copies the written op bytes into the advertiser's pending buffer; pollProvisioning() acts on it.
class BLEProvWriteCallback : public BLECharacteristicCallbacks {
public:
    explicit BLEProvWriteCallback(BLEAdvertiser *owner) : owner_(owner) {}
    void onWrite(BLECharacteristic *ch) override {
        String v = ch->getValue();
        int n = (int)v.length();
        if (n <= 0 || n > (int)sizeof(owner_->opBuf_)) return;
        memcpy(owner_->opBuf_, v.c_str(), n);
        owner_->opLen_ = n;
        owner_->opPending_ = true;
    }
private:
    BLEAdvertiser *owner_;
};

void BLEAdvertiser::begin() {
    fillDeviceId(deviceId_);
    BLEDevice::init("PPCam");
}

void BLEAdvertiser::enableProvisioning(WiFiConfigStore &cfg) {
    cfg_ = &cfg;

    if (Config::kBleProvisioningEncrypted) {
        // Secure Connections, "just works" (no MITM, no bonding store) -- iOS shows a system
        // pairing prompt and the link is then encrypted, so the password bytes written to the
        // characteristic below aren't sniffable at close range. No BOND flag -> no NVS bond-slot
        // dependency; the phone re-pairs each provisioning session, which is fine for a rare op.
        BLESecurity *sec = new BLESecurity();
        sec->setAuthenticationMode(ESP_LE_AUTH_REQ_SC_ONLY);
        sec->setCapability(ESP_IO_CAP_NONE);
        sec->setInitEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);
    }

    server_ = BLEDevice::createServer();
    BLEService *svc = server_->createService(BLEUUID(kProvServiceUUID));

    uint32_t writePerms = BLECharacteristic::PROPERTY_WRITE;
    writeChar_ = svc->createCharacteristic(BLEUUID(kProvWriteUUID), writePerms);
    if (Config::kBleProvisioningEncrypted) {
        writeChar_->setAccessPermissions(ESP_GATT_PERM_WRITE_ENCRYPTED);
    }
    writeChar_->setCallbacks(new BLEProvWriteCallback(this));

    reportChar_ = svc->createCharacteristic(
        BLEUUID(kProvReportUUID),
        BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
    if (Config::kBleProvisioningEncrypted) {
        reportChar_->setAccessPermissions(ESP_GATT_PERM_READ_ENCRYPTED);
    }
    reportChar_->addDescriptor(new BLE2902());

    svc->start();
    refreshReportCharacteristic();
    provisioning_ = true;
    Serial0.printf("[ble] GATT provisioning enabled (encrypted=%s)\n",
                   Config::kBleProvisioningEncrypted ? "yes" : "no");
}

// Builds the same bytes UDPStreamer::sendWiFiConfigReport() sends and pushes them into the report
// characteristic (readable, and notified to a subscribed phone).
void BLEAdvertiser::refreshReportCharacteristic() {
    if (reportChar_ == nullptr || cfg_ == nullptr) return;
    uint8_t buf[2 + 5 + 1 + 32 + 1 + WiFiConfigStore::kMaxCandidates * (1 + 32) + 1];
    size_t off = 0;
    buf[off++] = Protocol::kVersion;
    buf[off++] = Protocol::kWiFiConfigReport;
    buf[off++] = cfg_->role();
    buf[off++] = cfg_->apChannel();
    buf[off++] = cfg_->isRosterMaster() ? 1 : 0;
    buf[off++] = cfg_->apPasswordIsDefault() ? 1 : 0;
    buf[off++] = cfg_->awaitingProof() ? 1 : 0;
    const char *ssid = cfg_->apSsid();
    size_t sn = strlen(ssid);
    if (sn > 32) sn = 32;
    buf[off++] = (uint8_t)sn;
    memcpy(buf + off, ssid, sn);
    off += sn;
    uint8_t n = cfg_->candidateCount();
    if (n > WiFiConfigStore::kMaxCandidates) n = WiFiConfigStore::kMaxCandidates;
    buf[off++] = n;
    uint8_t disabledMask = 0;
    for (uint8_t i = 0; i < n; i++) {
        const char *cs = cfg_->candidate(i).ssid.c_str();
        size_t cn = strlen(cs);
        if (cn > 32) cn = 32;
        buf[off++] = (uint8_t)cn;
        memcpy(buf + off, cs, cn);
        off += cn;
        if (!cfg_->candidate(i).enabled) disabledMask |= (uint8_t)(1u << i);
    }
    buf[off++] = disabledMask; // trailing disabled-candidate bitmask (see kWiFiConfigReport)
    reportChar_->setValue(buf, off);
    reportChar_->notify();
}

void BLEAdvertiser::pollProvisioning() {
    if (!provisioning_ || !opPending_ || cfg_ == nullptr) return;
    opPending_ = false;
    const int len = opLen_;
    if (len < 1) return;
    const uint8_t *data = opBuf_;
    const uint8_t op = data[0]; // payload is [op][body], mirroring kSetWiFiConfig's data[2..]

    if (op == Protocol::kWiFiOpSetAp) {
        if (len < 2) return;
        uint8_t channel = data[1];
        size_t o = 2;
        if (o >= (size_t)len) return;
        uint8_t ssLen = data[o++];
        if (o + ssLen + 1 > (size_t)len) return;
        char ssid[33] = {0};
        memcpy(ssid, data + o, ssLen > 32 ? 32 : ssLen);
        o += ssLen;
        uint8_t pwLen = data[o++];
        if (o + pwLen > (size_t)len) return;
        char pass[64] = {0};
        memcpy(pass, data + o, pwLen > 63 ? 63 : pwLen);
        cfg_->stageAp(ssid, pass, channel);
        Serial0.printf("[ble] staged AP: ssid='%s' channel=%u\n", ssid, (unsigned)channel);
    } else if (op == Protocol::kWiFiOpSetRole) {
        if (len < 3) return;
        cfg_->stageRole(data[1], data[2] != 0);
        Serial0.printf("[ble] staged role=%u rosterMaster=%u\n", (unsigned)data[1], (unsigned)(data[2] != 0));
    } else if (op == Protocol::kWiFiOpSetCandidates) {
        if (len < 2) return;
        uint8_t count = data[1];
        size_t o = 2;
        struct { char ssid[33]; char pass[64]; } parsed[WiFiConfigStore::kMaxCandidates] = {};
        uint8_t parsedCount = 0;
        for (uint8_t c = 0; c < count && c < WiFiConfigStore::kMaxCandidates; c++) {
            if (o >= (size_t)len) break;
            uint8_t ssLen = data[o++];
            if (o + ssLen + 1 > (size_t)len) break;
            memcpy(parsed[parsedCount].ssid, data + o, ssLen > 32 ? 32 : ssLen);
            o += ssLen;
            uint8_t pwLen = data[o++];
            if (o + pwLen > (size_t)len) break;
            memcpy(parsed[parsedCount].pass, data + o, pwLen > 63 ? 63 : pwLen);
            o += pwLen;
            parsedCount++;
        }
        uint8_t disabledMask = (o < (size_t)len) ? data[o] : 0; // trailing bitmask; absent => all enabled
        cfg_->stageCandidatesBegin();
        for (uint8_t c = 0; c < parsedCount; c++) {
            cfg_->stageCandidateAdd(parsed[c].ssid, parsed[c].pass, !(disabledMask & (uint8_t)(1u << c)));
        }
        Serial0.printf("[ble] staged %u candidate(s), disabledMask=0x%02X\n",
            (unsigned)parsedCount, (unsigned)disabledMask);
    } else if (op == Protocol::kWiFiOpResetDefaults) {
        Serial0.println("[ble] reset to Config.h defaults -- wiping NVS + rebooting");
        cfg_->resetToDefaults();
        refreshReportCharacteristic();
        delay(300);
        ESP.restart();
    } else if (op == Protocol::kWiFiOpCommit) {
        if (cfg_->commit()) {
            Serial0.println("[ble] committed staged config -- rebooting (recovery arm set)");
        } else {
            Serial0.println("[ble] commit FAILED -- not rebooting");
        }
        refreshReportCharacteristic();
        delay(300);
        ESP.restart();
    }
    refreshReportCharacteristic();
}

void BLEAdvertiser::poll(bool hasClient, IPAddress currentIP) {
    if (hasClient) {
        if (advertising_) stopAdvertising();
        return;
    }
    if (!advertising_) {
        startAdvertising(currentIP);
        return;
    }
    if (currentIP != lastAdvertisedIP_) {
        startAdvertising(currentIP);
    }
}

void BLEAdvertiser::startAdvertising(IPAddress ip) {
    lastAdvertisedIP_ = ip;

    uint8_t payload[14];
    payload[0] = 'P';
    payload[1] = 'P';
    memcpy(&payload[2], deviceId_, 6);
    payload[8] = Config::kNodeType;
    uint8_t flags = 0;
    if (Config::kGPSEnabled) flags |= 0x01;
    if (provisioning_) flags |= 0x02; // CONFIGURABLE_FLEET_PLAN.md -- "BLE provisioning available"
    payload[9] = flags;
    payload[10] = ip[0];
    payload[11] = ip[1];
    payload[12] = ip[2];
    payload[13] = ip[3];

    BLEAdvertisementData advData;
    advData.setManufacturerData(String((const char *)payload, sizeof(payload)));

    BLEAdvertising *advertising = BLEDevice::getAdvertising();
    advertising->stop();
    advertising->setAdvertisementData(advData);

    if (provisioning_) {
        // The 128-bit service UUID won't fit in the main packet alongside the 14-byte mfg payload
        // (31-byte limit) -- put it in the scan response, which iOS merges into the same
        // advertisementData dict the app already reads.
        BLEAdvertisementData scanResp;
        scanResp.setCompleteServices(BLEUUID(kProvServiceUUID));
        advertising->setScanResponseData(scanResp);
        advertising->setScanResponse(true);
    } else {
        advertising->setScanResponse(false);
    }

    advertising->start();
    advertising_ = true;
}

void BLEAdvertiser::stopAdvertising() {
    BLEDevice::getAdvertising()->stop();
    advertising_ = false;
}
