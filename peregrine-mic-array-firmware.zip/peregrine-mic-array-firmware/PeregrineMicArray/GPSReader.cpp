#include "GPSReader.h"

#include <Arduino.h>  // millis()

// Cap on bytes drained from the UART per poll() call. A miswired / wrong-baud / noise-flooded link
// can supply bytes as fast as we read them; an unbounded `while (available())` then never returns
// and loop() hangs -- the node stops servicing the network and the app can only ever see it as
// "configured but not connected" (real finding 2026-09-01, immediately after a GPS rewire on the
// 2-mic Cam node -- poll() is documented "non-blocking" but wasn't). ~1s of real 9600-baud NMEA;
// loop() runs many times a second so a healthy module never reaches this. A bad link now degrades
// to "no/garbled data" (visible via charsProcessed()/passedChecksum()) instead of a wedged loop().
static constexpr int kMaxBytesPerPoll = 1024;

void GPSReader::begin(HardwareSerial &serial, int rxPin, int txPin, uint32_t baud, uint32_t rxBufferSize) {
    serial_ = &serial;
    // Must come before begin() -- see the .h doc comment and Config::kGPSUARTRxBufferBytes.
    serial_->setRxBufferSize(rxBufferSize);
    serial_->begin(baud, SERIAL_8N1, rxPin, txPin);
}

void GPSReader::poll() {
    if (!serial_) return;
    uint32_t nowMs = millis();
    if (lastPollMs_ != 0) {
        uint32_t gap = nowMs - lastPollMs_;
        if (gap > maxPollGapMs_) maxPollGapMs_ = gap;
    }
    lastPollMs_ = nowMs;

    for (int budget = kMaxBytesPerPoll; budget > 0 && serial_->available() > 0; --budget) {
        parser_.encode(serial_->read());
    }

    if (parser_.location.isValid() && parser_.location.isUpdated()) {
        hasFix_ = true;
        latitude_ = parser_.location.lat();
        longitude_ = parser_.location.lng();
    }
    // HDOP is a unitless dilution-of-precision figure, not a meters figure — TinyGPSPlus doesn't
    // convert it, and the ATGM336H's datasheet accuracy (~2.5m open-sky) is a better honest default
    // than a made-up conversion. horizontalAccuracyMeters_ stays 0 ("unknown," per the wire
    // packet's own documented convention) rather than fabricate a number this module doesn't
    // actually report.
}

uint32_t GPSReader::charsProcessed() const { return parser_.charsProcessed(); }
uint32_t GPSReader::sentencesWithValidChecksum() const { return parser_.passedChecksum(); }
uint32_t GPSReader::sentencesWithInvalidChecksum() const { return parser_.failedChecksum(); }
int GPSReader::satellitesInView() {
    return parser_.satellites.isValid() ? parser_.satellites.value() : 0;
}

bool GPSReader::timeValid() const {
    return parser_.time.isValid() && parser_.date.isValid();
}

uint32_t GPSReader::utcSecondOfDay() {
    return (uint32_t)parser_.time.hour() * 3600u
         + (uint32_t)parser_.time.minute() * 60u
         + (uint32_t)parser_.time.second();
}

bool GPSReader::timeFresh() const {
    return parser_.time.isUpdated();
}
