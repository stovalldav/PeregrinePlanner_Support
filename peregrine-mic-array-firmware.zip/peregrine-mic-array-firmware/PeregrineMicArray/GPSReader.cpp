#include "GPSReader.h"

#include <Arduino.h>  // millis()

void GPSReader::begin(HardwareSerial &serial, int rxPin, int txPin, uint32_t baud, uint32_t rxBufferSize) {
    serial_ = &serial;
    // Must come before begin() -- see the .h doc comment and Config::kGPSUARTRxBufferBytes.
    serial_->setRxBufferSize(rxBufferSize);
    serial_->begin(baud, SERIAL_8N1, rxPin, txPin);
}

void GPSReader::poll() {
    if (!serial_) return;
    uint32_t nowMs = millis();
    if (lastPollMs_ != 0) {
        uint32_t gap = nowMs - lastPollMs_;
        if (gap > maxPollGapMs_) maxPollGapMs_ = gap;
    }
    lastPollMs_ = nowMs;

    while (serial_->available() > 0) {
        parser_.encode(serial_->read());
    }

    if (parser_.location.isValid() && parser_.location.isUpdated()) {
        hasFix_ = true;
        latitude_ = parser_.location.lat();
        longitude_ = parser_.location.lng();
    }
    // HDOP is a unitless dilution-of-precision figure, not a meters figure — TinyGPSPlus doesn't
    // convert it, and the ATGM336H's datasheet accuracy (~2.5m open-sky) is a better honest default
    // than a made-up conversion. horizontalAccuracyMeters_ stays 0 ("unknown," per the wire
    // packet's own documented convention) rather than fabricate a number this module doesn't
    // actually report.
}

uint32_t GPSReader::charsProcessed() const { return parser_.charsProcessed(); }
uint32_t GPSReader::sentencesWithValidChecksum() const { return parser_.passedChecksum(); }
uint32_t GPSReader::sentencesWithInvalidChecksum() const { return parser_.failedChecksum(); }
int GPSReader::satellitesInView() {
    return parser_.satellites.isValid() ? parser_.satellites.value() : 0;
}
