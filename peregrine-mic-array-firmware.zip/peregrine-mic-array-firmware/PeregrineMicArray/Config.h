// Config.h — pins, WiFi credentials, and tunable constants for the Peregrine Mic Array.
//
// Physical layout (see README.md for the full wiring diagram): a square of 4 mics --
// TL (top-left), TR (top-right), BL (bottom-left), BR (bottom-right) -- with the TOP pair (TL/TR)
// on I2S bus 0 and the BOTTOM pair (BL/BR) on I2S bus 1.
//
// **Architecture note, real and deliberate, not a hypothetical**: this firmware previously tried
// true sample-synchronized 4-channel capture (bus 0 as I2S master, bus 1 as I2S slave reading the
// same clock, via several different pin-sharing/loopback/clock-config strategies). None of them
// worked reliably on real hardware despite exhausting the documented ESP-IDF configuration space
// for I2S slave mode. Both buses are now independent I2S masters, each with their own separate
// BCLK/WS pins -- a much simpler, standard, well-proven pattern, at a real and accepted cost:
// **azimuth is left-right only (roughly ±90° from center), not full 360°.** Measuring front-back
// position would require comparing a top mic's timing against a bottom mic's timing, which is
// only meaningful if both buses share a synchronized clock -- exactly the capability that wasn't
// achievable here. See DOAEstimator.h for how this constraint is reflected honestly in the output
// (never fabricates a "behind" reading).
//
// **Mark the TOP edge of the enclosure "FRONT."** Every azimuth reading (and the app's
// on-screen arrow) is relative to this physical mark, never true north (no magnetometer here).
//
// GPIO choices below avoid ESP32-S3 strapping pins (0, 3, 45, 46) and the native-USB pins
// (19, 20 on most S3 dev boards) — adjust to match your actual board/wiring if different.
#pragma once

#include <cstdint>

namespace Config {

// ---- I2S pins (matches the actual build) ----
// Bus 0 (I2S_NUM_0, independent master): TL (L-select) / TR (R-select), top pair.
constexpr int kTopWS   = 4;
constexpr int kTopBCLK = 5;
constexpr int kTopBusDIN = 6;

// Bus 1 (I2S_NUM_1, independent master -- its own separate clock, not synchronized to bus 0):
// BL (L-select) / BR (R-select), bottom pair. Requires rewiring these mics' WS/SCK away from
// GPIO4/GPIO5 (bus 0's pins) to these new, dedicated pins.
constexpr int kBottomWS   = 1;
constexpr int kBottomBCLK = 2;
// GPIO1/GPIO2/GPIO42 are safe here: none are strapping pins, none are used for flash/PSRAM,
// none are the native-USB pair. GPIO1's only other role on the S3 is ADC1_CH0, GPIO2 is a plain
// GPIO, and GPIO42 doubles as MTMS (JTAG) but that's inert unless JTAG debugging is enabled.
constexpr int kBottomBusDIN = 42;

// ---- Audio ----
constexpr uint32_t kSampleRateHz = 44100;
// INMP441 outputs 24-bit samples left-justified in a 32-bit I2S slot.
constexpr int kI2SBitsPerSample = 32;

// ---- Mic spacing ----
// Set this to your array's *actual* measured edge length (TL-to-TR distance, which should equal
// TL-to-BL) in meters -- the hardware's already built, so this firmware adapts to your real
// spacing rather than assuming a specific value. kMaxLagSamples below is derived from this at
// compile time, not hardcoded, so changing this one number keeps the cross-correlation search
// window correctly sized automatically.
constexpr float kMicSpacingMeters = 0.07f; // EDIT to your actual measured spacing

constexpr float kSpeedOfSoundMps = 343.0f;
// Theoretical max inter-mic delay for this spacing, plus a 50% safety margin (mounting isn't
// perfectly precise, and a slightly-too-wide search window costs a little CPU, not correctness --
// a too-narrow one would silently clip real delays and bias the angle estimate).
constexpr int kMaxLagSamples = (int)((kMicSpacingMeters / kSpeedOfSoundMps) * (float)kSampleRateHz * 1.5f) + 1;

// ---- Diagnostics ----
// Set true to skip WiFi entirely (no SoftAP, no radio activity at all) -- a cheap way to test
// whether the actively-transmitting WiFi radio is coupling electrical noise into the I2S signal
// lines on breadboard-prototyped hardware, a real and common issue for exactly this kind of
// setup. Real-device data showed the "ambient" RMS level swinging wildly (~1700 to ~31000 out of
// a 32767 max) block-to-block, only ~6ms apart -- genuine acoustic room noise doesn't normally
// vary that fast that much; electrical interference is a strong suspect. Flip back to false once
// you've compared results with WiFi on vs. off.
constexpr bool kDiagnosticDisableWiFi = false;

// ---- WiFi SoftAP ----
// Fixed SSID/password — the phone app hardcodes both the expectation of this network and the
// gateway IP below, so change these consistently in both places if you customize them.
constexpr const char *kWiFiSSID = "PeregrineMicArray";
constexpr const char *kWiFiPassword = "birding123"; // >=8 chars required for WPA2
constexpr int kWiFiChannel = 6;
// ESP32 WiFi.softAP() always uses 192.168.4.1 as its own gateway address by default — the app
// connects there directly, no mDNS/Bonjour discovery needed.

// ---- UDP ----
constexpr uint16_t kUDPPort = 3333;
// If no start/keepalive packet arrives from the registered client within this window, stop
// streaming server-side rather than sending audio into the void.
constexpr uint32_t kStreamingInactivityTimeoutMs = 10000;

// ---- Audio streaming ----
// 10ms per packet at 44.1kHz — no UDP fragmentation, ~100 packets/sec, ~706kbps.
constexpr int kAudioSamplesPerPacket = 441;

// ---- Onset gate ----
constexpr float kOnsetFastEnvelopeAlpha = 0.6f;   // ~5ms time constant at this loop rate
// Asymmetric floor tracking: adapts DOWN toward real quiet periods fast, but UP far more slowly,
// so a sustained (non-transient) loud condition can't drag the floor up to meet it and lock out
// detection entirely -- confirmed as a real failure mode on real hardware: a genuinely symmetric
// floor (same alpha both directions, an earlier version of this file) climbed in lockstep with a
// steady ~19000 baseline until the trigger threshold exceeded what any real 16-bit sample could
// produce, permanently disabling onset detection after about 20-25 seconds of runtime.
constexpr float kOnsetFloorDownAlpha = 0.01f;  // ~1.5s time constant -- catches real quiet periods
constexpr float kOnsetFloorUpAlpha = 0.0001f;  // ~150s time constant -- 100x slower to rise
constexpr float kOnsetTriggerRatio = 4.0f;         // fast envelope must exceed floor * this ratio
constexpr uint32_t kOnsetMinHoldMs = 5;
constexpr uint32_t kOnsetMinIntervalMs = 175;       // rate-limit DOA events

// ---- Outlier rejection (interim software mitigation, not a substitute for the real fix) ----
// Real hardware (bare INMP441 modules, no decoupling caps, daisy-chained GND) showed isolated
// single-block RMS spikes up to ~31000 out of a 32767 max, uncorrelated with acoustic events or
// WiFi state -- consistent with occasional corrupted/flipped bits on the I2S data line rather
// than real sound (a genuine acoustic transient's RMS rises and sustains over several consecutive
// blocks; a bit-flip on one block does not). This clamps a block's RMS back down to a short causal
// baseline if it spikes further above that baseline than any real onset plausibly would in one
// block. Once the array is rewired with a star ground and decoupling caps (see README), this
// should rarely if ever fire in practice -- `OnsetDetector::outlierRejectedCount()` is exposed so
// you can confirm that on real hardware rather than guessing.
constexpr float kOutlierRejectRatio = 6.0f; // reject if a block is >6x the last 2 accepted blocks

// ---- DOA analysis window ----
constexpr int kDOAWindowSamples = 1024; // ~23ms at 44.1kHz

} // namespace Config
