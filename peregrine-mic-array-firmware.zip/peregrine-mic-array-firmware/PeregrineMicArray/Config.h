// Config.h — pins, WiFi credentials, and tunable constants for the Peregrine Mic Array.
//
// Physical layout (see README.md for the full wiring diagram): 4 mics as two horizontal L-R pairs
// stacked vertically -- TL (top-left)/TR (top-right) physically higher, BL (bottom-left)/BR
// (bottom-right) physically lower, TL directly above BL and TR directly above BR (confirmed
// against the real build: no front-back/depth offset between the two pairs, only height differs).
// The TOP pair is on I2S bus 0, the BOTTOM pair is on I2S bus 1.
//
// **Architecture note, real and deliberate, not a hypothetical**: this firmware previously tried
// true sample-synchronized 4-channel capture (bus 0 as I2S master, bus 1 as I2S slave reading the
// same clock, via several different pin-sharing/loopback/clock-config strategies). None of them
// worked reliably on real hardware despite exhausting the documented ESP-IDF configuration space
// for I2S slave mode. A final attempt (CONFIGURABLE_FLEET_PLAN.md Part C, kBottomBusClockSlave) --
// bus-1 BCLK/WS jumpered from bus 0 on a physically reworked board -- was built and measured on
// 2026-09-09: the ESP32-S3 I2S slave RX still does not hold lock (inter-bus offset drifts ±128
// samples clap-to-clap). **Single-clock-domain 4-mic capture is confirmed NOT possible on this
// hardware. Do not re-attempt.** Both buses are independent I2S masters, each with their own
// separate BCLK/WS pins -- a much simpler, standard, well-proven pattern, at a real and accepted
// cost: **azimuth is left-right only (roughly ±90° from center, the "forward hemisphere"), not
// full 360°.** That ±90° limit is inherent to cross-correlating a SINGLE 2-mic pair -- one pair
// alone can't distinguish a source in front of its own axis from one mirrored behind it, since
// both produce the same time delay, regardless of clock sync. Comparing the TOP pair's timing
// against the BOTTOM pair's (cross-bus) would NOT resolve that ambiguity either -- given the two
// pairs sit on the same front-back axis (confirmed: TL is directly above BL, no depth offset), a
// mirror-image source produces the same result on both. The one thing a working cross-bus
// comparison WOULD have measured, given the real vertical separation between the pairs, is
// elevation (how high/low the source is) -- and that is now off the table for good on this board.
// See DOAEstimator.h for how the ±90° constraint is reflected honestly in the output (never
// fabricates a "behind" reading), and ../PeregrineMicArrayRearSensor/ for how the forward-hemisphere
// ambiguity is actually resolved in this project (a separate mic with genuine front-back offset,
// not a cross-bus trick).
//
// **Mark the direction the mics are physically facing/pointing as "FRONT."** This is unrelated to
// the TOP/BOTTOM pair naming above (that's about height, this is about which way the array
// listens) -- every azimuth reading (and the app's on-screen arrow) is relative to this physical
// mark, never true north (no magnetometer here).
//
// GPIO choices below avoid ESP32-S3 strapping pins (0, 3, 45, 46) and the native-USB pins
// (19, 20 on most S3 dev boards) — adjust to match your actual board/wiring if different.
#pragma once

#include <cstdint>

namespace Config {

// ---- I2S pins (matches the actual build) ----
// Bus 0 (I2S_NUM_0, independent master): TL (L-select) / TR (R-select), top pair.
constexpr int kTopWS   = 4;
constexpr int kTopBCLK = 5;
constexpr int kTopBusDIN = 6;

// Bus 1 (I2S_NUM_1, independent master -- its own separate clock, not synchronized to bus 0):
// BL (L-select) / BR (R-select), bottom pair. Requires rewiring these mics' WS/SCK away from
// GPIO4/GPIO5 (bus 0's pins) to these new, dedicated pins.
constexpr int kBottomWS   = 1;
constexpr int kBottomBCLK = 2;
// GPIO1/GPIO2/GPIO42 are safe here: none are strapping pins, none are used for flash/PSRAM,
// none are the native-USB pair. GPIO1's only other role on the S3 is ADC1_CH0, GPIO2 is a plain
// GPIO, and GPIO42 doubles as MTMS (JTAG) but that's inert unless JTAG debugging is enabled.
constexpr int kBottomBusDIN = 42;

// ---- Audio ----
constexpr uint32_t kSampleRateHz = 44100;
// INMP441 outputs 24-bit samples left-justified in a 32-bit I2S slot.
constexpr int kI2SBitsPerSample = 32;

// ---- Mic spacing ----
// Set this to your array's *actual* measured edge length (TL-to-TR distance, which should equal
// TL-to-BL) in meters -- the hardware's already built, so this firmware adapts to your real
// spacing rather than assuming a specific value. kMaxLagSamples below is derived from this at
// compile time, not hardcoded, so changing this one number keeps the cross-correlation search
// window correctly sized automatically.
constexpr float kMicSpacingMeters = 0.07f; // EDIT to your actual measured spacing

constexpr float kSpeedOfSoundMps = 343.0f;
// Theoretical max inter-mic delay for this spacing, plus a 50% safety margin (mounting isn't
// perfectly precise, and a slightly-too-wide search window costs a little CPU, not correctness --
// a too-narrow one would silently clip real delays and bias the angle estimate).
constexpr int kMaxLagSamples = (int)((kMicSpacingMeters / kSpeedOfSoundMps) * (float)kSampleRateHz * 1.5f) + 1;

// ---- Synchronous 4-mic capture (CONFIGURABLE_FLEET_PLAN.md Part C) -- ABANDONED, DO NOT ENABLE ----
// The intent was: jumper bus 1's BCLK/WS from bus 0, run bus 1 as a clock SLAVE, get all four
// INMP441s on one clock domain (for cross-pair timing -> coarse elevation). This was BUILT and a
// board was physically reworked and TESTED on 2026-09-09. It does not work: the ESP32-S3 I2S slave
// RX never holds lock -- the inter-bus sample offset drifts +/-128 samples (+/-2.9 ms) clap-to-clap
// at high correlation confidence (field_debug_2026-09-09_14-07-15). Enable-order and disable/
// re-enable relock strategies made no difference. This matches the earlier, independent finding in
// this file's own header comment above. **Leave this false. Do not re-attempt on this hardware.**
// The slave code path (kBottomBusClockSlave branch in the .ino, I2SBus::enable/relock, the
// [interbus] diagnostic) is kept only as a record of what was tried.
constexpr bool kBottomBusClockSlave = false;
// Was: the fixed integer-sample offset between the two RX DMA FIFOs, to be measured once per board.
// Moot -- there is no fixed offset (see above). Unused while kBottomBusClockSlave is false.
constexpr int32_t kInterBusSampleOffset = 0;

// ---- Diagnostics ----
// Set true to skip WiFi entirely (no SoftAP, no radio activity at all) -- a cheap way to test
// whether the actively-transmitting WiFi radio is coupling electrical noise into the I2S signal
// lines on breadboard-prototyped hardware, a real and common issue for exactly this kind of
// setup. Real-device data showed the "ambient" RMS level swinging wildly (~1700 to ~31000 out of
// a 32767 max) block-to-block, only ~6ms apart -- genuine acoustic room noise doesn't normally
// vary that fast that much; electrical interference is a strong suspect. Flip back to false once
// you've compared results with WiFi on vs. off.
constexpr bool kDiagnosticDisableWiFi = false;

// ---- Node identity ----
// Sent once after boot and then periodically (see kNodeIdentityIntervalMs) so the phone can
// reconcile this node against the user's declared configuration without out-of-band setup. Added
// 2026-08-12 alongside the network-role system below -- see FLEET_NETWORK_PARTICIPATION_PLAN.md
// (repo root) for why.
constexpr uint8_t kNodeType = 0; // 0 = mic-only array, see NetworkProtocol.h's NodeIdentityPacket

// ---- BLE-GATT Wi-Fi provisioning (CONFIGURABLE_FLEET_PLAN.md) ----
// When true, BLEAdvertiser also stands up a connectable GATT server so the app can read + change
// this node's Wi-Fi/AP/role config over BLE -- the password never crosses Wi-Fi. Proximity (~10 m)
// is the gate. Set false to keep BLE discovery-only.
constexpr bool kBleProvisioningEnabled = true;
// Require an encrypted BLE link ("just works" pairing -- iOS prompts once per session) before the
// node accepts a config write. Set false only if pairing proves flaky on your hardware (writes are
// still proximity-gated either way).
constexpr bool kBleProvisioningEncrypted = true;
constexpr uint8_t kMicCount = 4;
constexpr uint32_t kNodeIdentityIntervalMs = 5000;

// ---- Network role (host-your-own-AP or join-a-network model) ----
// Added 2026-08-12 -- see FLEET_NETWORK_PARTICIPATION_PLAN.md (repo root) for the full design
// rationale, and ../PeregrineMicArrayCam/Config.h's own copy of this same system (this mirrors it
// directly, not reinvented). **Critical backward-compatibility default: kRolePrimary, with the
// SAME kWiFiSSID/kWiFiPassword this firmware has always used** -- every unit already built and
// deployed keeps working with ZERO reflash-required behavior change unless you deliberately edit
// kNetworkRole below. This firmware was left completely untouched by this project's own
// 2026-08-07 "coexist, not replace" decision for a long time specifically because it was (and
// still is) the most-relied-upon, most heavily field-tested firmware in this whole system --
// treat any change to kNetworkRole's default here as a bug, not an intentional edit.
//
// kRolePrimary (the default, unchanged from before this system existed): hosts its own WiFi AP --
// kWiFiSSID/kWiFiPassword below are what IT broadcasts. Also automatically the roster master --
// no separate flag, it's simply whichever node is currently the one hosting.
// kRoleClient: joins a network as a station instead -- kWiFiSSID/kWiFiPassword become whatever
// network you're pointing it at, typically a camera node's own fleet AP (set to the EXACT SAME
// value as that node's own kWiFiSSID/kWiFiPassword) so this array becomes one more node in that
// fleet instead of hosting its own separate, unreachable-from-the-fleet network.
// kRoleSecondary: **implemented 2026-08-14** (MIC_ARRAY_MASTER_AP_PLAN.md §4), mirrors
// ../PeregrineMicArrayCam/Config.h's own copy of this same failover system verbatim. Behaves
// exactly like kRoleClient while the current Primary is reachable -- a pure no-op whenever
// WiFi.status() == WL_CONNECTED (see UDPStreamer::pollFailover()), so this doesn't touch this
// firmware's own default (kRolePrimary, unchanged) or its already-proven Client-mode behavior
// unless you deliberately set kNetworkRole to kRoleSecondary below. If the STA connection is lost
// for longer than kFailoverTimeoutMs (including never connecting at all on a cold boot), this node
// promotes itself to WIFI_AP_STA, hosting the SAME kWiFiSSID/kWiFiPassword the Primary does, then
// periodically re-scans (kPrimaryRescanIntervalMs) for the real Primary's specific BSSID
// (kPrimaryBSSID below) to know when to step back down.
//
// **Only kRoleSecondary can ever fall back to hosting an AP** -- a plain kRoleClient that
// exhausts every kWiFiCandidates entry just has no network at all until pollReconnect() retries
// (see WIFI_MULTI_SSID_FALLBACK_PLAN.md's Phase 2); it never stands up a softAP. If you want "try
// the phone's Personal Hotspot / home router, and if it's not around, host our own AP so the fleet
// still has somewhere to go," that's kRoleSecondary, repurposed to back up an EXTERNAL network
// instead of this fleet's own Primary -- see WIFI_MULTI_SSID_FALLBACK_PLAN.md's "Configuration
// recipe: hotspot backup with an AP fallback" section for the full, easy-to-get-wrong setup
// (kWiFiCandidates must NOT default to kWiFiSSID/kWiFiPassword in that mode -- they need to be
// different values: the hotspot to try, vs. this node's own distinct fallback broadcast identity).
constexpr uint8_t kRolePrimary = 0;
constexpr uint8_t kRoleSecondary = 1;
constexpr uint8_t kRoleClient = 2;
constexpr uint8_t kNetworkRole = kRoleSecondary; // DO NOT change this default -- see comment above

// ---- Secondary/failover tuning (only meaningful when kNetworkRole == kRoleSecondary) ----
// See ../PeregrineMicArrayCam/Config.h's own copy of these three constants for the full rationale
// -- mirrored here verbatim, same unmeasured-starting-point caveats.
constexpr uint32_t kFailoverTimeoutMs = 30000;
constexpr uint32_t kPrimaryRescanIntervalMs = 60000;
constexpr uint8_t kPrimaryBSSID[6] = {0xBA, 0x8B, 0xFC, 0x99, 0x6C, 0xDE}; // EDIT: read off the Primary's own boot log

// Up to this many total physical nodes in one fleet, counting this one -- sizes this node's own AP
// station slots when acting as Primary (see kMaxAPStations) and the roster's own kMaxRosterEntries
// headroom (NetworkProtocol.h, already generous at 8). Matches PeregrineMicArrayCam's own default.
// Real behavior change from before this system existed: max_connection was previously a hardcoded
// 2 (phone + optional rear sensor only) -- this raises it to accommodate a real mixed fleet
// (additional camera nodes, a second mic-only array, etc. all joining as Clients) when this array
// is Primary. Purely additive/permissive, not a functional regression for any existing 2-device
// setup.
constexpr int kMaxFleetNodes = 5;
constexpr int kMaxAPStations = kMaxFleetNodes;

// ---- Node roster (multi-node discovery) ----
// See ../PeregrineMicArrayCam/Config.h's own copy of this section for the full rationale --
// mirrored here verbatim. Only meaningful when kNetworkRole == kRolePrimary (aggregating) or ==
// kRoleClient (announcing) -- see UDPStreamer.cpp's kNodeAnnounce/kRosterRequest handling.
constexpr uint32_t kFleetId = 0x00000000; // EDIT to a value unique to your own fleet of nodes
constexpr uint32_t kNodeAnnounceIntervalMs = 5000;
constexpr uint32_t kRosterStaleTimeoutMs = 20000;

// Added 2026-08-16 for a real deployment mode this system didn't support before: every node,
// including this one, set to kRoleClient and joined to some EXTERNAL shared network (a home
// router, or the phone's own Personal Hotspot) instead of any node hosting its own AP at all --
// sidesteps a real bug found hosting on camera hardware (untested-until-now kRolePrimary on
// PeregrineMicArrayCam) and also fixes the separate no-internet-while-on-the-mic-array's-own-WiFi
// problem, since a real external network has actual internet access.
//
// The gap this closes: `UDPStreamer::isCurrentlyHosting()` is unconditionally false for every node
// in that all-kRoleClient configuration (nothing hosts), and roster mastering (accepting
// kNodeAnnounce, answering kRosterRequest with a non-empty roster) was ENTIRELY gated on that --
// meaning Auto-Discover would silently find nothing at all, with no node ever aggregating its
// siblings' announces. Setting this true on exactly ONE node (this array or a camera node, doesn't
// matter which) keeps that one acting as roster master even though it isn't hosting anything --
// see UDPStreamer::isActingAsRosterMaster(), the new broader check that replaces the bare
// isCurrentlyHosting() at both roster-related call sites. Leave false on every node using
// kRolePrimary/kRoleSecondary (AP-hosting) setups, where isCurrentlyHosting() already covers this
// correctly on its own -- this flag is additive, not a replacement for that path.
constexpr bool kIsRosterMaster = true; // EDIT: true on exactly one node, only in an all-kRoleClient shared-network setup

// ---- WiFi ----
// Fixed SSID/password when kNetworkRole == kRolePrimary (the default, unchanged from before this
// role system existed) -- the phone app hardcodes both the expectation of this network and the
// gateway IP below, so change these consistently in both places if you customize them. When
// kNetworkRole == kRoleClient instead, these become whatever network you're joining (see that
// constant's comment above).
//
// One STA candidate network -- see WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16 for
// kWiFiCandidates below.
struct WiFiCredential {
    const char *ssid;
    const char *password;
};

constexpr const char *kWiFiSSID = "PeregrineMicArray";
constexpr const char *kWiFiPassword = "birding123"; // >=8 chars required for WPA2
// CONFIGURABLE_FLEET_PLAN.md A5: when true (default) each node uses an 11-char AP password
// derived from its own chip id ("pp-" + 8 hex of deviceId[0..3]) instead of the shared literal
// above -- the app reproduces it from the deviceId it already sees over BLE / kNodeIdentity. Only
// the AP-hosting roles (kRolePrimary/kRoleSecondary) broadcast it. FOR A MULTI-NODE FLEET set one
// shared password from the app instead (a Client's candidate[0] must match the Primary's AP), or
// set this false + a shared kWiFiPassword here. The literal above is the last-resort fallback.
constexpr bool kUseDerivedApPassword = true;
constexpr int kWiFiChannel = 6; // only meaningful when hosting (kRolePrimary)
// ESP32 WiFi.softAP() always uses 192.168.4.1 as its own gateway address by default — the app
// connects there directly, no mDNS/Bonjour discovery needed.

// ---- WiFi multi-SSID fallback (see WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16) ----
// Only meaningful when STA-joining (kNetworkRole == kRoleClient, or kRoleSecondary's initial boot
// join -- NOT its pollFailover() reclaim reconnect, which deliberately stays pinned to
// kWiFiSSID/kWiFiPassword above since that path is about rejoining THIS node's own fleet Primary
// specifically, not picking among arbitrary external networks). UDPStreamer::begin() tries each
// candidate in order, giving each up to kWiFiPerCandidateTimeoutMs, and stops at the first one
// that connects. Defaults to a single entry matching kWiFiSSID/kWiFiPassword above, so an existing
// single-network deployment needs zero changes here to keep working exactly as before.
//
// **If this node is the "hotspot backup with an AP fallback" node** (kNetworkRole ==
// kRoleSecondary above, repurposed per WIFI_MULTI_SSID_FALLBACK_PLAN.md's configuration recipe):
// replace the default entry below entirely -- point this list at the actual hotspot/router to
// join, and leave kWiFiSSID/kWiFiPassword above as this node's own distinct fallback broadcast
// identity instead. Leaving this defaulted to kWiFiSSID/kWiFiPassword in that mode means you're
// trying to join your own not-yet-hosted fallback network, which will just never connect.
//
// **If some OTHER node in your fleet is configured as that hotspot-backup node**: add ITS
// kWiFiSSID/kWiFiPassword (its fallback identity, not the hotspot's) as an entry here too, so this
// node has somewhere to land if that one is ever actually hosting instead of relaying to the
// hotspot.
// This node is the "hotspot backup with an AP fallback" node (kRoleSecondary above, repurposed
// per the recipe two comments up) -- deliberately NOT defaulted to kWiFiSSID/kWiFiPassword, since
// nothing broadcasts that until/unless this node itself fails over.
constexpr WiFiCredential kWiFiCandidates[] = {
    // Real bug found 2026-08-18: this used a plain ASCII apostrophe (0x27). iOS auto-generates
    // possessive device/hotspot names with the typographic right single quote (U+2019, "'") instead
    // -- confirmed against the user's own iPhone (Settings > Personal Hotspot's "Now discoverable
    // as..." text uses the same curly-quote style throughout). SSIDs are raw bytes, not
    // case/lookalike-insensitive text -- a straight apostrophe here means WiFi.begin() searches for
    // a string that plain doesn't exist over the air, producing exactly the WIFI_REASON_NO_AP_FOUND
    // (201) failure seen on real hardware regardless of the "Maximize Compatibility" setting or
    // signal strength. Now the real UTF-8 U+2019 byte sequence (0xE2 0x80 0x99) -- matches what the
    // 802.11 SSID field actually carries.
    { kWiFiSSID, kWiFiPassword },
    // Add your own STA fallback networks here, most-preferred first, e.g.:
    // { "My Phone’s Hotspot", "hotspotpassword" },  // iOS possessive names use U+2019 (’), not '
    // { "MyHomeWiFi", "homepassword123" },
};
constexpr uint32_t kWiFiPerCandidateTimeoutMs = 8000; // unmeasured starting point -- kept shorter
    // than the old single-network kWiFiConnectTimeoutMs (was 20000) since several may need trying
    // in sequence; worst-case total is roughly candidateCount * this value, so keep the list short.

// Phase 2 (WIFI_MULTI_SSID_FALLBACK_PLAN.md) -- only meaningful for kNetworkRole == kRoleClient
// (kRoleSecondary has its own, more specialized runtime recovery via pollFailover()'s
// promote-to-AP path; kRolePrimary/a failed-over Secondary hosts, nothing to reconnect to). If the
// STA link has been down this long, UDPStreamer::pollReconnect() re-attempts the full
// kWiFiCandidates join loop from the top. Real known cost, not hidden: that retry blocks loop()
// for up to candidateCount * kWiFiPerCandidateTimeoutMs while it runs -- accepted because audio
// capture lives on its own pinned FreeRTOS tasks (captureTopTask/captureBottomTask), not in
// loop(), and no UDP traffic can happen without a live link anyway during that stall.
constexpr uint32_t kWiFiReconnectGraceMs = 10000; // unmeasured starting point

// ---- Runtime Wi-Fi config recovery (CONFIGURABLE_FLEET_PLAN.md Part A) ----
// After the app commits a new Wi-Fi/AP/role config (kSetWiFiConfig + kWiFiOpCommit) the node
// reboots with a recovery arm set. If it then cannot reach a network -- STA not connected for a
// client/secondary, or zero stations ever joined for a Primary -- within this window since boot,
// WiFiConfigStore reverts to the previous known-good config (then, on a second failure, to the
// Config.h defaults below + a recovery AP). Prevents a bad pushed config bricking a headless node.
constexpr uint32_t kConfigRecoveryTimeoutMs = 180000;
// A committed config that holds a good link/station for this long is marked "proven" and the
// recovery arm is cleared, so an ordinary later Wi-Fi hiccup never triggers a rollback.
constexpr uint32_t kConfigProofHoldMs = 60000;

// ---- UDP ----
constexpr uint16_t kUDPPort = 3333;
// If no start/keepalive packet arrives from the registered client within this window, stop
// streaming server-side rather than sending audio into the void.
constexpr uint32_t kStreamingInactivityTimeoutMs = 10000;

// ---- Audio streaming ----
// 10ms per packet at 44.1kHz — no UDP fragmentation, ~100 packets/sec, ~706kbps.
constexpr int kAudioSamplesPerPacket = 441;
// Stereo (kStereoAudioFrame, kMicCount==4 only) interleaves 2 channels into the same 12-byte
// header, so this is deliberately smaller than kAudioSamplesPerPacket above -- at 441 samples/
// channel the interleaved payload would be 12 + 441*2*2 = 1776 bytes, over the ~1472-byte
// practical UDP-over-WiFi MTU (risking IP fragmentation, the mono path's whole reason for using
// 441 in the first place). 360 samples/channel keeps it at 12 + 360*2*2 = 1452 bytes, ~8.16ms/
// ~122 packets/sec -- fragmentation-free with the same headroom philosophy as kAudioSamplesPerPacket.
constexpr int kStereoAudioSamplesPerChannel = 360;

// ---- Automatic top/bottom-pair audio fallback (kMicCount==4 only) ----
// Real-hardware finding 2026-08-18/20: the top pair (TL/TR) was found completely silent (peak
// level exactly 0 for a full ~2h08m field session AND a 30s real-hardware clip capture) while the
// bottom pair's I2S reads succeeded the whole time -- with no fallback, this meant the streamed
// reference audio (and therefore Bird Sounds Detection entirely) went silent even though a
// perfectly good second pair of mics was sitting right there, unused, on the same node. See
// usingBottomPairForStream's declaration for how these two constants gate the switch.
// Below this peak amplitude, a pair is considered "silent" for fallback purposes -- matches this
// array's own documented healthy background-noise floor (~15-110 in earlier real-hardware onset
// tuning), comfortably above normal quiet-room electrical noise so a genuinely working pair never
// falsely trips this.
constexpr int16_t kAudioFallbackSilenceThreshold = 50;
// How many consecutive 2s status-report intervals (~10s total) a pair must stay below the
// threshold before triggering a fallback -- avoids switching on a single quiet moment between bird
// calls. Symmetric: the same streak length is required to switch back once a previously-silent
// pair recovers.
constexpr int kAudioFallbackSilenceIntervals = 5;

// ---- Onset gate ----
constexpr float kOnsetFastEnvelopeAlpha = 0.6f;   // ~5ms time constant at this loop rate
// Asymmetric floor tracking: adapts DOWN toward real quiet periods fast, but UP far more slowly,
// so a sustained (non-transient) loud condition can't drag the floor up to meet it and lock out
// detection entirely -- confirmed as a real failure mode on real hardware: a genuinely symmetric
// floor (same alpha both directions, an earlier version of this file) climbed in lockstep with a
// steady ~19000 baseline until the trigger threshold exceeded what any real 16-bit sample could
// produce, permanently disabling onset detection after about 20-25 seconds of runtime.
constexpr float kOnsetFloorDownAlpha = 0.01f;  // ~1.5s time constant -- catches real quiet periods
constexpr float kOnsetFloorUpAlpha = 0.0001f;  // ~150s time constant -- 100x slower to rise
constexpr float kOnsetTriggerRatio = 4.0f;         // fast envelope must exceed floor * this ratio
constexpr uint32_t kOnsetMinHoldMs = 5;
constexpr uint32_t kOnsetMinIntervalMs = 175;       // rate-limit DOA events

// ---- Outlier rejection (interim software mitigation, not a substitute for the real fix) ----
// Real hardware (bare INMP441 modules, no decoupling caps, daisy-chained GND) showed isolated
// single-block RMS spikes up to ~31000 out of a 32767 max, uncorrelated with acoustic events or
// WiFi state -- consistent with occasional corrupted/flipped bits on the I2S data line rather
// than real sound (a genuine acoustic transient's RMS rises and sustains over several consecutive
// blocks; a bit-flip on one block does not). This clamps a block's RMS back down to a short causal
// baseline if it spikes further above that baseline than any real onset plausibly would in one
// block. Once the array is rewired with a star ground and decoupling caps (see README), this
// should rarely if ever fire in practice -- `OnsetDetector::outlierRejectedCount()` is exposed so
// you can confirm that on real hardware rather than guessing.
constexpr float kOutlierRejectRatio = 6.0f; // reject if a block is >6x the last 2 accepted blocks

// ---- DOA analysis window ----
constexpr int kDOAWindowSamples = 1024; // ~23ms at 44.1kHz

// ---- GPS (ATGM336H, UART) -- added 2026-08-14, ported from ../PeregrineMicArrayCam/Config.h ----
// EDIT per physical node -- not every unit necessarily has the GPS module installed/wired. Gates
// GPS entirely when false -- no UART init, no position reporting, no NodeIdentityPacket.hasGPS
// claim. Unlike the camera board, this bare ESP32-S3 dev board has plenty of free general-purpose
// GPIO (no camera peripheral eating 14 pins, no octal PSRAM claim to work around) -- kGPSTXPin/
// kGPSRXPin/kPPSPin below are plain GPIO, not a native-USB-port tradeoff the way the camera node's
// are, and deliberately avoid GPIO43/44 (this firmware's own Serial0 console, and the exact net
// esptool uses to flash -- confirmed on the camera node's first physical build that wiring
// anything else there breaks flashing outright, same risk applies to any ESP32-S3 board).
constexpr bool kGPSEnabled = true; // EDIT to false if this particular unit has no GPS module
// Real hardware finding, 2026-08-17: confirmed against the actual wiring that GPIO7/GPIO8 are
// swapped from the original 7=TX/8=RX assumption above -- GPIO7 is wired to the GPS module's TX
// line (so it's this ESP32's RX), GPIO8 to the module's RX line (this ESP32's TX).
constexpr int kGPSTXPin = 8; // ESP32 -> GPS RX
constexpr int kGPSRXPin = 7; // ESP32 <- GPS TX
constexpr uint32_t kGPSBaud = 9600; // ATGM336H default
// Real-hardware finding 2026-08-18, from a live GPS-freeze investigation on a physically 2-mic
// Cam node ("C2", ../PeregrineMicArrayCam/Config.h) -- this node's GPS code is identical, so the
// same fix applies here even though the freeze itself wasn't observed on this node's hardware.
// The default ESP32 Arduino core UART RX ring buffer is only 256 bytes, well under a second of
// headroom at this module's observed near-saturated ~450-460 B/s sustained send rate. Any loop()
// stall longer than that -- WiFi scan/reconnect's documented blocking calls (UDPStreamer.cpp) --
// can silently drop bytes with zero visibility. Sized generously (~4.5s of headroom at the
// observed rate) -- ESP32-S3 RAM isn't tight here. Paired with GPSReader::maxPollGapMs() (new,
// same investigation) to directly measure whether loop() actually stalls that long in the field.
constexpr uint32_t kGPSUARTRxBufferBytes = 2048;
// How often to send a GPSPositionPacket once a fix exists — position doesn't change mid-session,
// no need to stream it at telemetry rates.
constexpr uint32_t kGPSReportIntervalMs = 3000;

// ---- GPS PPS (pulse-per-second precision time base) ----
// Same purpose as ../PeregrineMicArrayCam/Config.h's own copy -- captures GPS PPS edge timing as a
// prerequisite for a future clock-synchronized multi-node capture feature (not implemented yet,
// see MIC_ARRAY_MASTER_AP_PLAN.md-adjacent discussion). Only meaningful if kGPSEnabled is also
// true. Plain GPIO here too, no native-USB port sacrificed (see the GPS section's comment above).
constexpr bool kPPSEnabled = true; // EDIT to false if this unit's GPS module's PPS pin isn't wired
constexpr int kPPSPin = 9;

// ---- Onboard compass (BNO055, COMPASS_HEADING_HARDWARE_PLAN.md) ----
// Gives this node a live, automatic heading independent of GPS -- NOT a GPS replacement (no
// position, no disciplined UTC clock; see CompassReader.h's header comment). This board (a
// generic ESP32-S3 dev board, not a fixed-pin camera module) has plenty of free GPIO left after
// the mic buses + GPS + PPS above -- 47/48 are unclaimed by anything else in this file.
constexpr bool kCompassEnabled = false; // EDIT to true once the BNO055 module is wired
constexpr int kCompassSDAPin = 47;
constexpr int kCompassSCLPin = 48;
// A stationary node's heading changes slowly (if at all) -- no need for telemetry-rate updates,
// same reasoning as kGPSReportIntervalMs above.
constexpr uint32_t kCompassReportIntervalMs = 1000;

} // namespace Config
