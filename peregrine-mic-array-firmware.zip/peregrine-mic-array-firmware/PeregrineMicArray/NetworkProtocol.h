// NetworkProtocol.h — wire format shared by the firmware and the Swift app's
// `MicArrayProtocol.swift`. Keep both sides in sync if you change anything here. Also duplicated
// verbatim (Protocol namespace only) in ../PeregrineMicArrayRearSensor/NetworkProtocol.h, since
// Arduino sketches can't share headers across folders -- keep that copy in sync too.
//
// All multi-byte fields little-endian (native on both ESP32-S3 and arm64 iOS — zero byte-swap
// cost either side). Every packet starts with a version byte for forward compatibility.
#pragma once

#include <cstdint>

namespace Protocol {

constexpr uint8_t kVersion = 1;

enum PacketType : uint8_t {
    kAudioFrame          = 0x01, // device -> phone (front array only)
    kDOATelemetry        = 0x02, // device -> phone (front array only)
    kHandshakePing       = 0x03, // phone -> device
    kHandshakePong       = 0x04, // device -> phone
    kSessionStart        = 0x05, // phone -> device
    kSessionStop         = 0x06, // phone -> device
    kRearSensorTelemetry = 0x07, // device -> phone (rear sensor only, see PeregrineMicArrayRearSensor)
    kSetFrequencyBands   = 0x09, // phone -> device (front array only)
};

// Max simultaneous species bands the phone can ask the front array to filter+correlate per onset
// capture (see kSetFrequencyBands / UDPStreamer's activeBands_ on the firmware side). Each band
// costs one extra bandpass-filter+cross-correlate pass over the same captured window -- cheap per
// pass, and DOA capture is onset-gated (transient-triggered), not continuous, but this bounds the
// worst case rather than accepting an unbounded list from the phone. Lives here (not Config.h) so
// this header stays a single self-contained file, matching the verbatim copy in
// ../PeregrineMicArrayRearSensor/NetworkProtocol.h.
constexpr int kMaxDOABands = 5;

constexpr uint8_t kPongMagic0 = 'P';
constexpr uint8_t kPongMagic1 = 'B';

#pragma pack(push, 1)

// 12-byte header, followed by N little-endian int16 PCM samples (one reference channel, M0 only).
struct AudioFrameHeader {
    uint8_t version;
    uint8_t type; // kAudioFrame
    uint32_t seq;
    uint32_t sampleRate; // 44100
    uint8_t encoding;    // 0x10 = int16 PCM
    uint8_t reserved;
};
constexpr uint8_t kEncodingInt16 = 0x10;

// 23 bytes total. Sent only on gated onset events, not continuously -- once per populated
// frequency band per onset capture (see kSetFrequencyBands below), all against the SAME captured
// 4-channel window, so multiple simultaneous callers in different frequency ranges can each get
// their own azimuth from one onset event. `bandId` echoes back whichever id the phone assigned via
// kSetFrequencyBands (0 when no bands are set -- the default full-spectrum single-reading case,
// unchanged from the original single-band behavior).
struct DOATelemetryPacket {
    uint8_t version;
    uint8_t type; // kDOATelemetry
    uint32_t seq;
    uint32_t timestampMs;
    // [0, 360) — relative to the array's own front mark, never true north. With this firmware's
    // two independent (unsynchronized) I2S buses, only left-right position is measurable, not
    // front-back -- so in practice this only ever falls in the forward hemisphere (270..360..90),
    // never indicating "behind." See DOAEstimator.h for why. The field itself is unchanged from a
    // hypothetical full-2D version, so the wire format and the phone app need no changes -- only
    // the range of values actually produced differs.
    float azimuthDeg;
    float confidence;    // [0, 1]
    float relativeLevel; // raw onset-window amplitude figure; NOT a distance measurement
    uint8_t bandId;       // which kSetFrequencyBands slot produced this reading (0 = default/unfiltered)
};

// 14 bytes total. Streamed continuously (every ~100ms) while a session is active, not gated on
// this unit's own onset trigger -- the phone needs a recent rear-sensor level sample available
// whenever the FRONT array's own onset happens to fire, and the two run on independent,
// unsynchronized clocks with no way to guarantee both gates trip on the same block. See
// MIC_ARRAY_MULTI_UNIT_PLAN.md (repo root) for what the phone does with this: compares it against
// the front array's own relativeLevel for roughly-contemporaneous events to flag/correct that
// unit's known front-back blind spot, and as a coarse proximity cue -- not for triangulation.
struct RearSensorTelemetryPacket {
    uint8_t version;
    uint8_t type; // kRearSensorTelemetry
    uint32_t seq;
    uint32_t timestampMs;
    float relativeLevel; // same smoothed-envelope figure as DOATelemetryPacket's relativeLevel
};

// 2-byte control packets, phone -> device.
struct ControlPacket {
    uint8_t version;
    uint8_t type; // kHandshakePing / kSessionStart / kSessionStop
};

// One requested band within a kSetFrequencyBands packet. `bandId` is an opaque phone-assigned
// label (0..254) echoed back in DOATelemetryPacket.bandId -- the firmware attaches no species
// meaning to it, that mapping lives entirely on the phone. `bandId == 0xFF` marks a slot unused
// when a packet's `count` is padded with empty entries (not currently produced, but decoders
// should tolerate/ignore it).
struct FrequencyBandSlot {
    uint8_t bandId;
    float lowHz;
    float highHz;
};

// 3 + kMaxDOABands*9 bytes total (48 bytes at kMaxDOABands=5). phone -> device (front array only).
// Fully replaces the array's active band set every time -- `count` (0..kMaxDOABands) says how
// many of `slots` are valid; the rest are ignored. An empty packet (count=0) clears all bands,
// reverting to full-spectrum DOA (today's original behavior) -- the default when nothing is being
// tracked. See DOAEstimator.h's `estimate()` comment for what the filtering itself does.
struct SetFrequencyBandsPacket {
    uint8_t version;
    uint8_t type; // kSetFrequencyBands
    uint8_t count;
    FrequencyBandSlot slots[kMaxDOABands];
};

// 4-byte reply, device -> phone.
struct HandshakePongPacket {
    uint8_t version;
    uint8_t type; // kHandshakePong
    uint8_t magic0; // 'P'
    uint8_t magic1; // 'B'
};

#pragma pack(pop)

} // namespace Protocol
