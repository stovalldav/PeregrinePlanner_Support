// WiFiConfigStore.cpp — see WiFiConfigStore.h and CONFIGURABLE_FLEET_PLAN.md Part A.
// Kept byte-identical between firmware/PeregrineMicArray/ and firmware/PeregrineMicArrayCam/.
#include "WiFiConfigStore.h"
#include <cstring>

namespace {
constexpr size_t kSsidCap = 32;
constexpr size_t kPassCap = 63;

// Append one length-prefixed (u8) string, capped. Returns bytes written, or 0 on overflow.
size_t putLP(uint8_t *out, size_t cap, size_t &off, const char *s, size_t maxLen) {
    size_t n = strlen(s);
    if (n > maxLen) n = maxLen;
    if (off + 1 + n > cap) return 0;
    out[off++] = (uint8_t)n;
    memcpy(out + off, s, n);
    off += n;
    return 1 + n;
}

// Read one length-prefixed string into `dst`. Returns false on malformed/overrun.
bool getLP(const uint8_t *in, size_t len, size_t &off, String &dst) {
    if (off >= len) return false;
    uint8_t n = in[off++];
    if (off + n > len) return false;
    dst = "";
    dst.reserve(n);
    for (uint8_t i = 0; i < n; i++) dst += (char)in[off + i];
    off += n;
    return true;
}
} // namespace

void WiFiConfigStore::begin(const Defaults &defaults) {
    defaults_ = defaults;
    defaultApPassword_ = defaults.apPassword ? defaults.apPassword : "";

    prefs_.begin("wcfg", /*readOnly=*/false);
    awaitingProof_ = (prefs_.getUChar("applied", 0) == 1);

    size_t prevLen = prefs_.isKey("prev") ? prefs_.getBytesLength("prev") : 0;
    hasPrevious_ = (prevLen > 0 && prevLen <= kMaxBlobBytes);

    if (!loadLiveBlob()) {
        loadFromDefaults();
        customised_ = false;
    } else {
        customised_ = true;
    }
    apPasswordIsDefault_ = (apPassword_ == defaultApPassword_);
    loadFromCache(); // seed the staging fields so a partial stage*() still commits a complete config
}

void WiFiConfigStore::loadFromDefaults() {
    role_ = defaults_.role;
    apSsid_ = defaults_.apSsid ? defaults_.apSsid : "";
    apPassword_ = defaults_.apPassword ? defaults_.apPassword : "";
    apChannel_ = defaults_.apChannel;
    isRosterMaster_ = defaults_.isRosterMaster;
    candidateCount_ = 0;
    for (uint8_t i = 0; i < defaults_.candidateCount && i < kMaxCandidates; i++) {
        candidates_[candidateCount_++] = defaults_.candidates[i];
    }
}

void WiFiConfigStore::loadFromCache() {
    stagedRole_ = role_;
    stagedApSsid_ = apSsid_;
    stagedApPassword_ = apPassword_;
    stagedApChannel_ = apChannel_;
    stagedIsRosterMaster_ = isRosterMaster_;
    stagedCandidateCount_ = candidateCount_;
    for (uint8_t i = 0; i < candidateCount_; i++) stagedCandidates_[i] = candidates_[i];
}

bool WiFiConfigStore::loadLiveBlob() {
    if (!prefs_.isKey("live")) return false;
    size_t len = prefs_.getBytesLength("live");
    if (len == 0 || len > kMaxBlobBytes) return false;
    uint8_t buf[kMaxBlobBytes];
    size_t got = prefs_.getBytes("live", buf, sizeof(buf));
    if (got != len) return false;
    return deserializeInto(buf, len);
}

bool WiFiConfigStore::deserializeInto(const uint8_t *in, size_t len) {
    size_t off = 0;
    if (len < 4) return false;
    uint8_t ver = in[off++];
    if (ver != kSchemaVersion) return false;
    role_ = in[off++];
    isRosterMaster_ = in[off++] != 0;
    apChannel_ = in[off++];
    if (!getLP(in, len, off, apSsid_)) return false;
    if (!getLP(in, len, off, apPassword_)) return false;
    if (off >= len) return false;
    uint8_t n = in[off++];
    if (n > kMaxCandidates) return false;
    candidateCount_ = 0;
    for (uint8_t i = 0; i < n; i++) {
        String ssid, pass;
        if (!getLP(in, len, off, ssid)) return false;
        if (!getLP(in, len, off, pass)) return false;
        if (off >= len) return false;
        candidates_[candidateCount_].ssid = ssid;
        candidates_[candidateCount_].password = pass;
        candidates_[candidateCount_].enabled = in[off++] != 0; // schema v2
        candidateCount_++;
    }
    return true;
}

size_t WiFiConfigStore::serializeStaged(uint8_t *out, size_t cap) const {
    size_t off = 0;
    if (cap < 4) return 0;
    out[off++] = kSchemaVersion;
    out[off++] = stagedRole_;
    out[off++] = stagedIsRosterMaster_ ? 1 : 0;
    out[off++] = stagedApChannel_;
    if (!putLP(out, cap, off, stagedApSsid_.c_str(), kSsidCap)) return 0;
    if (!putLP(out, cap, off, stagedApPassword_.c_str(), kPassCap)) return 0;
    if (off >= cap) return 0;
    out[off++] = stagedCandidateCount_;
    for (uint8_t i = 0; i < stagedCandidateCount_; i++) {
        if (!putLP(out, cap, off, stagedCandidates_[i].ssid.c_str(), kSsidCap)) return 0;
        if (!putLP(out, cap, off, stagedCandidates_[i].password.c_str(), kPassCap)) return 0;
        if (off >= cap) return 0;
        out[off++] = stagedCandidates_[i].enabled ? 1 : 0; // schema v2
    }
    return off;
}

void WiFiConfigStore::stageRole(uint8_t role, bool isRosterMaster) {
    stagedRole_ = role;
    stagedIsRosterMaster_ = isRosterMaster;
}

void WiFiConfigStore::stageAp(const char *ssid, const char *password, uint8_t channel) {
    if (ssid) stagedApSsid_ = ssid;
    if (password) stagedApPassword_ = password;
    if (channel >= 1 && channel <= 13) stagedApChannel_ = channel;
}

void WiFiConfigStore::stageCandidatesBegin() {
    stagedCandidateCount_ = 0;
}

bool WiFiConfigStore::stageCandidateAdd(const char *ssid, const char *password, bool enabled) {
    if (!ssid || !*ssid) return false;
    if (stagedCandidateCount_ >= kMaxCandidates) return false;
    stagedCandidates_[stagedCandidateCount_].ssid = ssid;
    stagedCandidates_[stagedCandidateCount_].password = password ? password : "";
    stagedCandidates_[stagedCandidateCount_].enabled = enabled;
    stagedCandidateCount_++;
    return true;
}

bool WiFiConfigStore::commit() {
    // Move the current live blob (if any) into the "prev" recovery slot before overwriting it.
    if (prefs_.isKey("live")) {
        size_t len = prefs_.getBytesLength("live");
        if (len > 0 && len <= kMaxBlobBytes) {
            uint8_t buf[kMaxBlobBytes];
            size_t got = prefs_.getBytes("live", buf, sizeof(buf));
            if (got == len) {
                prefs_.putBytes("prev", buf, len);
                hasPrevious_ = true;
            }
        }
    } else {
        // No prior live config -> no meaningful "previous" to fall back to; recovery goes straight
        // to Config.h defaults (resetToDefaults) instead.
        prefs_.remove("prev");
        hasPrevious_ = false;
    }

    uint8_t buf[kMaxBlobBytes];
    size_t n = serializeStaged(buf, sizeof(buf));
    if (n == 0) return false;
    if (prefs_.putBytes("live", buf, n) != n) return false;
    prefs_.putUChar("applied", 1);
    awaitingProof_ = true;

    // Reload the effective cache from what we just wrote (the caller reboots right after, but keep
    // the in-RAM view consistent regardless).
    if (!loadLiveBlob()) return false;
    customised_ = true;
    apPasswordIsDefault_ = (apPassword_ == defaultApPassword_);
    loadFromCache();
    return true;
}

void WiFiConfigStore::resetToDefaults() {
    prefs_.clear();
    hasPrevious_ = false;
    awaitingProof_ = false;
    customised_ = false;
    loadFromDefaults();
    apPasswordIsDefault_ = (apPassword_ == defaultApPassword_);
    loadFromCache();
}

bool WiFiConfigStore::revertToPrevious() {
    if (!prefs_.isKey("prev")) return false;
    size_t len = prefs_.getBytesLength("prev");
    if (len == 0 || len > kMaxBlobBytes) return false;
    uint8_t buf[kMaxBlobBytes];
    size_t got = prefs_.getBytes("prev", buf, sizeof(buf));
    if (got != len) return false;
    if (prefs_.putBytes("live", buf, len) != len) return false;
    prefs_.remove("prev");            // one-shot: a second recovery falls through to defaults
    hasPrevious_ = false;
    prefs_.putUChar("applied", 1);    // re-arm proof for the reverted config too
    awaitingProof_ = true;
    if (!loadLiveBlob()) return false;
    customised_ = true;
    apPasswordIsDefault_ = (apPassword_ == defaultApPassword_);
    loadFromCache();
    return true;
}

void WiFiConfigStore::markProven() {
    prefs_.putUChar("applied", 0);
    awaitingProof_ = false;
}

void WiFiConfigStore::deviceIdFromEfuseMac(uint64_t efuseMac, uint8_t out[6]) {
    for (int i = 0; i < 6; i++) out[i] = (uint8_t)(efuseMac >> (8 * i));
}

void WiFiConfigStore::deriveDefaultApPassword(const uint8_t deviceId[6], char *out, size_t outCap) {
    // "pp-" + 8 uppercase hex of the first 4 deviceId bytes -> 11 chars + NUL. WPA2-legal (>=8).
    if (outCap < 12) { if (outCap) out[0] = 0; return; }
    static const char *hex = "0123456789ABCDEF";
    out[0] = 'p'; out[1] = 'p'; out[2] = '-';
    for (int i = 0; i < 4; i++) {
        out[3 + i * 2]     = hex[(deviceId[i] >> 4) & 0xF];
        out[3 + i * 2 + 1] = hex[deviceId[i] & 0xF];
    }
    out[11] = 0;
}
