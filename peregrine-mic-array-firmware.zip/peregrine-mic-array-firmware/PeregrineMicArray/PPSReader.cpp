#include "PPSReader.h"
#include <Arduino.h>

namespace {
    // File-local, not class-static -- see PPSReader.h's `begin()` doc comment for why (a real GCC
    // parse error hit applying IRAM_ATTR to a `static` class member function; a plain free function
    // sidesteps it entirely, and there's only ever one PPS signal/reader in practice anyway).
    volatile uint32_t lastEdgeMicros_ = 0;
    volatile uint32_t previousEdgeMicros_ = 0;
    volatile uint32_t edgeCount_ = 0;

    // Session interval stats, all 32-bit so each read is atomic on the ESP32 (no critical section
    // needed for a field diagnostic -- worst case a reader gets one sample's worth of skew between
    // sumAbsDev_ and intervalCount_). sumAbsDev_ can't realistically overflow: |dev| stays well
    // under ~1ms even for a bad signal, so even a multi-day session sums to far under UINT32_MAX.
    volatile uint32_t minIntervalMicros_ = 0; // 0 = not set yet
    volatile uint32_t maxIntervalMicros_ = 0;
    volatile uint32_t intervalCount_ = 0;
    volatile uint32_t sumAbsDevMicros_ = 0;   // sum of |interval - 1,000,000| over all intervals

    // Disciplined-clock state. sanePpsIntervalMicros_ is the last interval within 1e6 +/- 5000 --
    // the crystal-rate estimate utcForLocalMicros() divides by. anchor* is set by bindUtcSecond().
    volatile uint32_t sanePpsIntervalMicros_ = 1000000; // safe default until a real interval lands
    volatile uint32_t anchorEdgeMicros_ = 0;
    volatile uint32_t anchorUtcSecond_ = 0;
    volatile bool anchorValid_ = false;

    void IRAM_ATTR handlePPSEdge() {
        // Minimal work in ISR context, per standard interrupt-handling practice -- just integer
        // math, no Serial output. Unsigned wraparound at micros()'s own ~71-minute rollover is fine
        // for a ~1s interval, same reasoning used elsewhere in this codebase.
        uint32_t now = micros();
        uint32_t prev = lastEdgeMicros_;
        previousEdgeMicros_ = prev;
        lastEdgeMicros_ = now;
        edgeCount_++;

        if (prev != 0) { // a real previous edge -> this is a valid interval (skips the bogus first)
            uint32_t interval = now - prev;
            if (minIntervalMicros_ == 0 || interval < minIntervalMicros_) minIntervalMicros_ = interval;
            if (interval > maxIntervalMicros_) maxIntervalMicros_ = interval;
            uint32_t absDev = (interval > 1000000u) ? (interval - 1000000u) : (1000000u - interval);
            sumAbsDevMicros_ += absDev;
            intervalCount_++;
            if (absDev <= 5000u) sanePpsIntervalMicros_ = interval; // a plausible 1Hz interval
        }
    }
}

void PPSReader::begin(int pin) {
    // INPUT_PULLDOWN, not plain INPUT. A GPS PPS output is push-pull, so a real signal drives
    // straight through the ESP32's weak (~45k) internal pulldown unaffected -- but if the pin is
    // NOT actually connected to a live PPS line (wrong pad, loose wire, or the module simply not
    // pulsing because it has no fix yet), plain INPUT floats and the RISING interrupt fires on
    // every bit of EMI. Real-hardware finding 2026-09-01: an unconnected GPIO19 on the camera node
    // logged ~60-110 spurious "edges"/second with sub-ms intervals. The pulldown makes an
    // unconnected pin sit at a stable LOW (zero edges), which also makes "wired but never pulsing"
    // cleanly distinguishable from "picking up noise".
    pinMode(pin, INPUT_PULLDOWN);
    attachInterrupt(digitalPinToInterrupt(pin), handlePPSEdge, RISING);
}

uint32_t PPSReader::lastEdgeMicros() const { return lastEdgeMicros_; }
uint32_t PPSReader::edgeCount() const { return edgeCount_; }
uint32_t PPSReader::lastIntervalMicros() const { return lastEdgeMicros_ - previousEdgeMicros_; }
uint32_t PPSReader::minIntervalMicros() const { return minIntervalMicros_; }
uint32_t PPSReader::maxIntervalMicros() const { return maxIntervalMicros_; }
uint32_t PPSReader::intervalSampleCount() const { return intervalCount_; }
uint32_t PPSReader::meanAbsDevMicros() const {
    uint32_t n = intervalCount_;
    return n ? (sumAbsDevMicros_ / n) : 0;
}

void PPSReader::bindUtcSecond(uint32_t utcSecondOfDay) {
    uint32_t edge = lastEdgeMicros_;
    if (edge == 0) return;                                  // no PPS edge seen yet
    if ((uint32_t)(micros() - edge) > 900000u) return;      // edge too old -- probably missed one
    anchorEdgeMicros_ = edge;
    anchorUtcSecond_ = utcSecondOfDay;
    anchorValid_ = true;
}

PPSReader::UtcMicros PPSReader::utcForLocalMicros(uint32_t localMicros) const {
    if (!anchorValid_) return {false, 0, 0};
    // Signed delta so a timestamp captured slightly before the anchor edge still works; uint32
    // subtraction wraps correctly for the sub-second magnitudes this is used with.
    int32_t elapsed = (int32_t)(localMicros - anchorEdgeMicros_);
    uint32_t rate = sanePpsIntervalMicros_ ? sanePpsIntervalMicros_ : 1000000u;
    int64_t corrected = (int64_t)elapsed * 1000000 / (int64_t)rate;
    int64_t total = (int64_t)anchorUtcSecond_ * 1000000 + corrected;
    const int64_t dayMicros = 86400LL * 1000000LL;
    total %= dayMicros;
    if (total < 0) total += dayMicros;
    return {true, (uint32_t)(total / 1000000), (uint32_t)(total % 1000000)};
}

bool PPSReader::utcAnchorValid() const { return anchorValid_; }

uint32_t PPSReader::anchorAgeMillis() const {
    if (!anchorValid_) return 0;
    return (uint32_t)(micros() - anchorEdgeMicros_) / 1000u;
}
