#include "PPSReader.h"
#include <Arduino.h>

namespace {
    // File-local, not class-static -- see PPSReader.h's `begin()` doc comment for why (a real GCC
    // parse error hit applying IRAM_ATTR to a `static` class member function; a plain free function
    // sidesteps it entirely, and there's only ever one PPS signal/reader in practice anyway).
    volatile uint32_t lastEdgeMicros_ = 0;
    volatile uint32_t previousEdgeMicros_ = 0;
    volatile uint32_t edgeCount_ = 0;

    void IRAM_ATTR handlePPSEdge() {
        // Minimal work in ISR context, per standard interrupt-handling practice -- just record the
        // timestamp and count, no Serial output, no complex logic. Unsigned wraparound at micros()'s
        // own ~71-minute rollover is fine here without special handling, same reasoning already used
        // elsewhere in this codebase for now-lastXMs style comparisons.
        uint32_t now = micros();
        previousEdgeMicros_ = lastEdgeMicros_;
        lastEdgeMicros_ = now;
        edgeCount_++;
    }
}

void PPSReader::begin(int pin) {
    // Plain INPUT, no pull resistor -- GPS PPS outputs are actively driven push-pull (both high
    // and low), unlike an open-drain signal that would need a pullup.
    pinMode(pin, INPUT);
    attachInterrupt(digitalPinToInterrupt(pin), handlePPSEdge, RISING);
}

uint32_t PPSReader::lastEdgeMicros() const { return lastEdgeMicros_; }
uint32_t PPSReader::edgeCount() const { return edgeCount_; }
uint32_t PPSReader::lastIntervalMicros() const { return lastEdgeMicros_ - previousEdgeMicros_; }
