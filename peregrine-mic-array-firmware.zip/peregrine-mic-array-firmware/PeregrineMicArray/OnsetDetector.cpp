#include "OnsetDetector.h"
#include <cmath>

float OnsetDetector::filterOutlier(float rawBlockRMS) {
    if (acceptedBlockCount_ < 2) {
        // Not enough history yet to judge -- accept as-is so startup isn't spuriously flagged.
        prevAcceptedRMS2_ = prevAcceptedRMS1_;
        prevAcceptedRMS1_ = rawBlockRMS;
        acceptedBlockCount_++;
        return rawBlockRMS;
    }

    float baseline = (prevAcceptedRMS1_ + prevAcceptedRMS2_) * 0.5f;
    bool isOutlier = (baseline > 1.0f) && (rawBlockRMS > baseline * Config::kOutlierRejectRatio);
    float accepted = isOutlier ? baseline : rawBlockRMS;
    if (isOutlier) {
        outlierRejectedCount_++;
    }

    prevAcceptedRMS2_ = prevAcceptedRMS1_;
    prevAcceptedRMS1_ = accepted;
    return accepted;
}

bool OnsetDetector::processBlock(const int16_t *samples, int count, uint32_t nowMs, uint32_t nowMicros) {
    // Block RMS.
    float sumSquares = 0;
    for (int i = 0; i < count; i++) {
        float s = samples[i];
        sumSquares += s * s;
    }
    float blockRMS = sqrtf(sumSquares / count);
    blockRMS = filterOutlier(blockRMS);

    float prevFastEnvelope = fastEnvelope_; // end-of-previous-block value, for sub-block crossing interp
    fastEnvelope_ = Config::kOnsetFastEnvelopeAlpha * blockRMS + (1 - Config::kOnsetFastEnvelopeAlpha) * fastEnvelope_;
    // Genuinely asymmetric now (an earlier version's comment claimed this but the code used the
    // same alpha both directions -- confirmed on real hardware to let the floor climb in lockstep
    // with a sustained loud baseline until the trigger threshold became unreachable). Tracks down
    // fast (real quiet periods update the floor quickly) but up 100x more slowly (a sustained loud
    // condition takes minutes, not seconds, to redefine "normal").
    float floorAlpha = (blockRMS < slowFloor_) ? Config::kOnsetFloorDownAlpha : Config::kOnsetFloorUpAlpha;
    slowFloor_ = floorAlpha * blockRMS + (1 - floorAlpha) * slowFloor_;
    lastFastEnvelope_ = fastEnvelope_;

    bool aboveThreshold = fastEnvelope_ > slowFloor_ * Config::kOnsetTriggerRatio;

    if (aboveThreshold && !currentlyAboveThreshold_) {
        currentlyAboveThreshold_ = true;
        aboveThresholdSinceMs_ = nowMs;
        // Sub-block crossing time for TDOA (MULTI_NODE_TDOA_PLAN.md Phase 3). nowMicros marks the
        // END of this block; threshold T sits somewhere between prevFastEnvelope (end of previous
        // block) and fastEnvelope_ (end of this one). Linear-interpolate the fraction of the block
        // at which the fast envelope crossed T, then back-date from nowMicros. Clamped to [0,1];
        // falls back to block end if the envelope didn't actually rise across the block (a real
        // crossing always does, this is just guarding the divide).
        float threshold = slowFloor_ * Config::kOnsetTriggerRatio;
        float rise = fastEnvelope_ - prevFastEnvelope;
        float frac = (rise > 1e-3f) ? (threshold - prevFastEnvelope) / rise : 1.0f;
        if (frac < 0.0f) frac = 0.0f;
        if (frac > 1.0f) frac = 1.0f;
        float blockMicros = (float)count * 1000000.0f / (float)Config::kSampleRateHz;
        lastCrossingMicros_ = nowMicros - (uint32_t)((1.0f - frac) * blockMicros);
    } else if (!aboveThreshold) {
        currentlyAboveThreshold_ = false;
    }

    if (currentlyAboveThreshold_ && (nowMs - aboveThresholdSinceMs_) >= Config::kOnsetMinHoldMs) {
        bool intervalOK = !everTriggered_ || (nowMs - lastTriggerMs_) >= Config::kOnsetMinIntervalMs;
        if (intervalOK) {
            lastTriggerMs_ = nowMs;
            everTriggered_ = true;
            return true;
        }
    }
    return false;
}
