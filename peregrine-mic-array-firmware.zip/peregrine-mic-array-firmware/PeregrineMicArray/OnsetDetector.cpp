#include "OnsetDetector.h"
#include <cmath>

float OnsetDetector::filterOutlier(float rawBlockRMS) {
    if (acceptedBlockCount_ < 2) {
        // Not enough history yet to judge -- accept as-is so startup isn't spuriously flagged.
        prevAcceptedRMS2_ = prevAcceptedRMS1_;
        prevAcceptedRMS1_ = rawBlockRMS;
        acceptedBlockCount_++;
        return rawBlockRMS;
    }

    float baseline = (prevAcceptedRMS1_ + prevAcceptedRMS2_) * 0.5f;
    bool isOutlier = (baseline > 1.0f) && (rawBlockRMS > baseline * Config::kOutlierRejectRatio);
    float accepted = isOutlier ? baseline : rawBlockRMS;
    if (isOutlier) {
        outlierRejectedCount_++;
    }

    prevAcceptedRMS2_ = prevAcceptedRMS1_;
    prevAcceptedRMS1_ = accepted;
    return accepted;
}

bool OnsetDetector::processBlock(const int16_t *samples, int count, uint32_t nowMs) {
    // Block RMS.
    float sumSquares = 0;
    for (int i = 0; i < count; i++) {
        float s = samples[i];
        sumSquares += s * s;
    }
    float blockRMS = sqrtf(sumSquares / count);
    blockRMS = filterOutlier(blockRMS);

    fastEnvelope_ = Config::kOnsetFastEnvelopeAlpha * blockRMS + (1 - Config::kOnsetFastEnvelopeAlpha) * fastEnvelope_;
    // Genuinely asymmetric now (an earlier version's comment claimed this but the code used the
    // same alpha both directions -- confirmed on real hardware to let the floor climb in lockstep
    // with a sustained loud baseline until the trigger threshold became unreachable). Tracks down
    // fast (real quiet periods update the floor quickly) but up 100x more slowly (a sustained loud
    // condition takes minutes, not seconds, to redefine "normal").
    float floorAlpha = (blockRMS < slowFloor_) ? Config::kOnsetFloorDownAlpha : Config::kOnsetFloorUpAlpha;
    slowFloor_ = floorAlpha * blockRMS + (1 - floorAlpha) * slowFloor_;
    lastFastEnvelope_ = fastEnvelope_;

    bool aboveThreshold = fastEnvelope_ > slowFloor_ * Config::kOnsetTriggerRatio;

    if (aboveThreshold && !currentlyAboveThreshold_) {
        currentlyAboveThreshold_ = true;
        aboveThresholdSinceMs_ = nowMs;
    } else if (!aboveThreshold) {
        currentlyAboveThreshold_ = false;
    }

    if (currentlyAboveThreshold_ && (nowMs - aboveThresholdSinceMs_) >= Config::kOnsetMinHoldMs) {
        bool intervalOK = !everTriggered_ || (nowMs - lastTriggerMs_) >= Config::kOnsetMinIntervalMs;
        if (intervalOK) {
            lastTriggerMs_ = nowMs;
            everTriggered_ = true;
            return true;
        }
    }
    return false;
}
