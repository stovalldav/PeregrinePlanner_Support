# Peregrine Mic Array Firmware

ESP32-S3 + 4x INMP441 direction-finding array for Peregrine Planner's Bird Sounds Detection and
AR Bird Identification screens. Streams a reference audio channel (for the app's existing
species-ID model) plus periodic azimuth/confidence readings over WiFi.

## What this can and can't do

- **Azimuth**: yes, but **left-right only** — roughly a ±90° bearing from center, not a full 360°
  compass. This ±90° "forward hemisphere" limit is inherent to cross-correlating a single 2-mic
  pair: one pair alone can't distinguish a source in front of its own axis from one mirrored
  behind it, since both produce the same time delay — no amount of clock sync fixes that
  specifically, it needs a mic with genuine front-back offset from the main pair (see
  `../PeregrineMicArrayRearSensor/`, which is exactly that). This firmware went through extensive
  real-device debugging trying to get true sample-synchronized 4-channel capture working (one I2S
  bus as master, the other as slave reading the same clock). Every documented configuration
  approach for that was tried and none worked reliably on this hardware, so the two mic pairs now
  run as fully independent, unsynchronized I2S buses instead — a much simpler, standard, reliable
  pattern, at the cost described under "Elevation" below. The reported azimuth is always
  constrained to the forward hemisphere (never claims a "behind" reading) as an honest reflection
  of what's actually measurable — see `DOAEstimator.h`. Relative to this device's own physical
  "front" mark, **not** true magnetic north — there's no compass on this board.
- **Elevation**: no, but not for a lack of physical mic geometry — **the two pairs are genuinely
  stacked vertically** (TL/TR physically higher, BL/BR physically lower, TL directly above BL and
  TR directly above BR, confirmed against the real build with no front-back offset between them).
  Comparing the TOP pair's timing against the BOTTOM pair's would measure exactly that height
  difference — real elevation, not a fundamental ambiguity. What's actually missing is the same
  synchronized clock the azimuth limitation above needed and never got: TL/TR live on I2S bus 0,
  BL/BR on I2S bus 1, two independent unsynchronized peripherals, so there's no shared time
  reference to measure a cross-bus delay against. The hardware baseline for elevation already
  exists in every array built to this design; only the clock-sync problem stands between here and
  using it.
- **Distance**: no real metric distance. The app only shows a qualitative "getting closer/
  farther" trend from relative signal level, not a number in meters — no amount of firmware
  cleverness can turn "how loud is this" into "how far away" without knowing the bird's true call
  loudness in advance, which varies hugely by species and individual.

## Hardware

- ESP32-S3 dev board (Arduino IDE, "ESP32S3 Dev Module" or your board's specific entry).
- 4x INMP441 I2S MEMS microphone breakout boards, mounted as two L-R pairs stacked vertically (TL/TR
  physically higher, BL/BR physically lower, directly beneath the top pair — no front-back/depth
  offset between the two pairs, only height differs).

### Wiring

Top pair (TL/TR) on I2S bus 0, bottom pair (BL/BR) on I2S bus 1 — **each bus has its own separate,
independent BCLK/WS clock, not shared between them**. Front-elevation view (looking at the array
from the direction it's facing — see "FRONT" below), TL/TR mounted above BL/BR:

```
              TL ------- TR      <- bus 0 (I2S0), own BCLK/WS, TL L-select LOW, TR L-select HIGH
              |           |            (physically HIGHER)
              |           |
              BL ------- BR      <- bus 1 (I2S1), own BCLK/WS, BL L-select LOW, BR L-select HIGH
                                       (physically LOWER, directly below the top pair)
```

**Mark the direction the mics are physically facing/pointing as "FRONT."** This is unrelated to
which pair is mounted higher/lower — it's simply which way the array listens. Every azimuth
reading — and the app's on-screen arrow — is relative to this mark. When using the AR screen's
turn-guidance feature, hold/mount the array so this direction points the same way as your phone's
camera.

| Signal | Pin |
|---|---|
| Bus 0 WS (TL/TR only) | GPIO4 |
| Bus 0 BCLK (TL/TR only) | GPIO5 |
| Bus 0 SD | GPIO6 |
| Bus 1 WS (BL/BR only) | GPIO1 |
| Bus 1 BCLK (BL/BR only) | GPIO2 |
| Bus 1 SD | GPIO42 |

Unlike earlier drafts of this firmware, **the two buses' clock pins are not the same and not
wired together** — TL/TR wire to GPIO4/GPIO5, BL/BR wire to GPIO1/GPIO2, and that's it, no
bridging. All 4 INMP441s: `VDD`→3.3V, `GND`→GND. `L/R` pin: tie LOW for TL/BL (left-select), HIGH
for TR/BR (right-select).

GPIO1/GPIO2/GPIO42 are safe to use here: none are ESP32-S3 strapping pins, none are used for
flash/PSRAM, none are the native-USB pair (GPIO19/20). GPIO1's only other role on the chip is
`ADC1_CH0`, GPIO2 is a plain GPIO, and GPIO42 doubles as `MTMS` (JTAG) but that's inert unless
JTAG debugging is enabled.

If any of these are unavailable or already used on your board, edit the pin numbers at the top of
`Config.h` — any 6 free GPIOs work, avoiding the ESP32-S3 strapping pins (0, 3, 45, 46) and your
board's native-USB pins (often 19/20).

Mic spacing: **edit `Config::kMicSpacingMeters` in `Config.h` to your array's actual measured
edge length** (TL-to-TR distance) — the search window firmware uses for cross-correlation
(`kMaxLagSamples`) is derived from this at compile time, so it automatically adapts to whatever
you actually built rather than assuming a specific spacing.

### GPS (ATGM336H) + PPS — optional, ported 2026-08-14 from `../PeregrineMicArrayCam/`

Not every unit needs this — `Config::kGPSEnabled`/`kPPSEnabled` (default `true`) gate it entirely;
set either to `false` if this particular unit has no GPS module wired.

| Signal | GPIO |
|---|---|
| GPS TX (ESP32 → GPS RX) | GPIO7 |
| GPS RX (ESP32 ← GPS TX) | GPIO8 |
| PPS (GPS → ESP32) | GPIO9 |
| VCC | 3.3–5V (module has its own regulator) |
| GND | GND |

Unlike the camera node, this board has no camera peripheral or octal PSRAM eating into the pin
budget, so GPS/PPS here are plain general-purpose GPIO — no native-USB-port tradeoff needed.
**Never wire anything to GPIO43/44** regardless of what's free elsewhere — that's this firmware's
own `Serial0` debug console, and the exact net esptool uses to flash the chip; putting a GPS
module's TX there broke flashing outright on the camera node's first physical build.

`gps.hasFix()`/`gps.latitude()`/`gps.longitude()` feed a periodic `GPSPositionPacket` to the phone
(see `Config::kGPSReportIntervalMs`) the same way the camera node's does — the app's existing GPS
diagnostics (Settings → Mic Array, or this node's row under "Manage Additional Nodes" if declared
as one) work unchanged, since they were never actually camera-specific to begin with. PPS only
captures and reports edge timing for now (`[pps] edges/interval` in the Serial log) — see
`PPSReader.h`'s header comment; nothing in either firmware consumes it for synchronized capture yet.

### Why not true 2D sync? (for anyone adapting this design)

This firmware's git history is a real record of what was tried, in case it saves you time on
similar hardware: same-pin sharing (slave configured with the master's own GPIO numbers, relying
on the ESP32 IO/GPIO matrix to fan the signal out internally — the standard, commonly-documented
technique for this pattern), separate slave GPIO numbers bridged with external loopback wires,
adding an MCLK loopback (both same-pin and separate-pin variants), explicit `bclk_div` tuning for
the slave's clock config, and enabling the slave channel before the master. All of these were
tried in various combinations on real hardware; none produced a single successful read on the
slave bus — it consistently reported `ESP_ERR_TIMEOUT` on every attempt, independent of sample
rate (tested down to 8kHz, ruling out signal integrity as the cause). If you have more insight
into why real cross-bus I2S sync didn't work here, the independent-masters fallback in this
firmware is functional either way.

## Arduino IDE setup

1. Install the **esp32 by Espressif Systems** board package (latest stable, ESP-IDF 5.x based) via
   Boards Manager.
2. Board: your specific ESP32-S3 dev board entry (or "ESP32S3 Dev Module").
3. Library: `TinyGPSPlus` (install via Library Manager or `arduino-cli lib install TinyGPSPlus`) --
   only needed if `Config::kGPSEnabled` is `true` (the default as of 2026-08-14), but the sketch
   won't compile without it regardless, same as the camera node's own setup.
4. Open `PeregrineMicArray.ino` — the other files in this folder (`Config.h`, `NetworkProtocol.h`,
   etc.) will show as additional tabs; that's normal, Arduino compiles them together.
5. Flash. Open the Serial Monitor at 115200 baud — you should see boot checkpoint lines ending
   with `WiFi AP up, IP 192.168.4.1` (default `kRolePrimary`; `WiFi joined, IP <dhcp-assigned>` if
   you set `kRoleClient` instead), then periodic `[status] top: N ok / N fail   bottom: N ok / N
   fail` lines with `ok` counts climbing on both buses.

**If you see the ROM bootloader banner (`ESP-ROM:esp32s3-...`) and then nothing at all**: this is
a confirmed real-hardware quirk on boards using the S3's native USB, not a firmware hang. The
app's own `Serial.begin()` call re-initializes the USB peripheral, which briefly disconnects and
re-enumerates from the host's point of view — if the Serial Monitor was attached to the transient
bootloader-phase connection, it can get stuck watching a dead session and never reconnect to the
app's real one. This firmware uses `Serial0` (UART) specifically to avoid this, but if you still
hit it: close the monitor, reset the board, wait a few seconds for USB to settle, then reopen the
monitor fresh.

## First-time setup / calibration

1. **Per-bus sanity check**: clap your hands symmetrically between TL and TR (equal distance from
   both) and confirm bus 0's `ok` count climbs with no meaningful azimuth shift; repeat for BL/BR
   on bus 1. Each bus's own two mics ARE sample-synchronized with each other (same I2S peripheral),
   so this should work reliably.
2. **Angle check**: clap to the left and right of the array's front edge and confirm the reported
   azimuth shifts accordingly (roughly 90° = full right, 270° = full left, 0°/center = either
   straight ahead or straight behind — genuinely indistinguishable with this hardware, see "What
   this can and can't do" above).
3. In the Peregrine Planner app: Settings → Mic Array → join this array's WiFi network when
   prompted (`PeregrineMicArray`/`birding123` by default, or whatever you set if you configured
   `Config::kNetworkRole = kRoleClient` to join an existing fleet instead — see "Network role"
   above), enable the feature, and use the live self-test readout there (claps should move the
   number) before heading into the field.

## Network protocol

See `NetworkProtocol.h` — kept in sync with the app's `MicArrayProtocol.swift`. UDP, port 3333,
little-endian. Summary: the phone pings (`0x03`) to detect the device, sends a session-start
(`0x05`) to begin receiving audio (`0x01`) and DOA telemetry (`0x02`) packets, and a session-stop
(`0x06`) when done. The device stops streaming on its own if it doesn't hear from the phone for
10 seconds.

## Resolved: electrical noise on bare INMP441 modules

Earlier builds on perfboard/breadboard prototypes showed wildly swinging `level` readings in
`[doa]`/`[onset]` output that didn't track real sound (occasional huge spikes uncorrelated with
claps, present even with WiFi fully disabled) — a known issue with bare INMP441 modules, not a
firmware bug, caused by two things:

1. **No decoupling capacitor.** Bare INMP441 modules need a 0.1µF ceramic capacitor across
   VDD/GND, as close to the module's pins as possible — without it, the mic's own switching
   current noise rides back onto the shared power rail.
2. **Daisy-chained GND.** Each mic's ground should return independently to one common point (a
   "star" topology), not chain mic-to-mic — a shared/daisy-chained ground return lets one mic's
   switching current induce noise on the others sharing that path.

**Fixed** by rewiring the power and ground rails: decoupling caps added at each mic, GND redone as
a star topology, I2S clock wires (BCLK/WS) kept physically separated from the data wires (SD)
rather than bundled together. Confirmed on real hardware — detections are accurate in the field
now. If you're building this from scratch, do the same: 0.1µF ceramic caps across VDD/GND per mic,
a proper star ground, and (if using salvaged cable) keep each SD line paired with its own dedicated
GND return rather than sharing one with the clock lines.

The onset detector's outlier rejection (`OnsetDetector::filterOutlier`,
`Config::kOutlierRejectRatio`) — originally added as an interim mitigation for this issue — is
kept as a general safety net against any single corrupted block, not because the electrical issue
is still open. Watch `[onset] ... outliers_rejected: N` in the Serial output; it should sit near
zero on a properly wired build. A high, climbing count on a new build points back at the wiring
above, not a firmware regression.

## Known v1 limitations (by design, not oversights)

- **Left-right azimuth only, not full 360°** — see "What this can and can't do" above for why.
- Time-domain cross-correlation, not GCC-PHAT — simpler and sufficient for this array's small
  baseline; documented as a v2 escalation path if real-world testing shows it too noisy indoors
  or in echo-heavy terrain.
- No true compass heading — azimuth is array-relative only.
- Up to `Config::kMaxAPStations` associated WiFi stations when hosting (default 5, as of the
  network-role system below) — one phone plus, optionally, the `PeregrineMicArrayRearSensor`
  companion unit and/or other fleet nodes; still not meant to serve multiple simultaneous phones.

## Network role — hosting your own fleet, or joining someone else's

Added 2026-08-12, see `FLEET_NETWORK_PARTICIPATION_PLAN.md` (repo root) for the full design.
**Default behavior is completely unchanged** — this array still hosts its own fixed
`PeregrineMicArray`/`birding123` WiFi network exactly as it always has, unless you deliberately
edit `Config::kNetworkRole`. Existing builds need no reflash to keep working.

- `Config::kRolePrimary` (the default): unchanged, hosts its own AP.
- `Config::kRoleClient`: joins a network as a station instead — set `kWiFiSSID`/`kWiFiPassword` to
  match whichever node is your fleet's current Primary (typically a `PeregrineMicArrayCam` camera
  node hosting its own fleet AP) so this array becomes one more discoverable node in that fleet
  instead of an isolated, unreachable-from-the-app-at-the-same-time network of its own. This is
  the fix for "Auto-Discover Nodes finds nothing" when your only currently-connected device was
  this array — it never used to speak the multi-node discovery protocol at all before this.

Same real limitation either way: your phone can only be joined to one WiFi network at a time, so a
front array in `kRolePrimary` mode and a camera-node fleet are still mutually exclusive from the
app's point of view unless you set this array to `kRoleClient` and point it at that fleet.

## Optional companion: rear sensor

`../PeregrineMicArrayRearSensor/` is a single-INMP441 accessory that mounts facing the opposite
direction from this array's own FRONT mark, to help flag/correct the front-back blind spot noted
above. See that folder's README and `MIC_ARRAY_MULTI_UNIT_PLAN.md` (repo root) for the design —
it's a separate optional build, not required for this array to work on its own.
