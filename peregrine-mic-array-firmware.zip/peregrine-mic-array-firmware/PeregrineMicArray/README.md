# Peregrine Mic Array Firmware

ESP32-S3 + 4x INMP441 direction-finding array for Peregrine Planner's Bird Sounds Detection and
AR Bird Identification screens. Streams a reference audio channel (for the app's existing
species-ID model) plus periodic azimuth/confidence readings over WiFi.

## What this can and can't do

- **Azimuth**: yes, but **left-right only** — roughly a ±90° bearing from center, not a full 360°
  compass. This firmware went through extensive real-device debugging trying to get true
  sample-synchronized 4-channel capture working (one I2S bus as master, the other as slave reading
  the same clock), which would have given full 2D azimuth. Every documented configuration
  approach for that was tried and none worked reliably on this hardware, so the two mic pairs now
  run as fully independent, unsynchronized I2S buses instead — a much simpler, standard, reliable
  pattern, at the cost of not being able to measure front-back position at all (that requires
  comparing timing across the two buses, which needs a shared clock). The reported azimuth is
  always constrained to the forward hemisphere (never claims a "behind" reading) as an honest
  reflection of what's actually measurable — see `DOAEstimator.h`. Relative to this device's own
  physical "front" mark, **not** true magnetic north — there's no compass on this board.
- **Elevation**: no. The 4 mics are mounted flat/planar, which has a fundamental ambiguity
  (a sound directly above and directly below produces identical timing) — not attempted here.
- **Distance**: no real metric distance. The app only shows a qualitative "getting closer/
  farther" trend from relative signal level, not a number in meters — no amount of firmware
  cleverness can turn "how loud is this" into "how far away" without knowing the bird's true call
  loudness in advance, which varies hugely by species and individual.

## Hardware

- ESP32-S3 dev board (Arduino IDE, "ESP32S3 Dev Module" or your board's specific entry).
- 4x INMP441 I2S MEMS microphone breakout boards, mounted in a square.

### Wiring

Square layout, top pair (TL/TR) on I2S bus 0, bottom pair (BL/BR) on I2S bus 1 — **each bus has
its own separate, independent BCLK/WS clock, not shared between them**:

```
              TL ------- TR      <- bus 0 (I2S0), own BCLK/WS, TL L-select LOW, TR L-select HIGH
              |           |
              |           |
              BL ------- BR      <- bus 1 (I2S1), own BCLK/WS, BL L-select LOW, BR L-select HIGH
```

**Mark the TOP edge of your enclosure "FRONT."** Every azimuth reading — and the app's on-screen
arrow — is relative to this mark. When using the AR screen's turn-guidance feature, hold/mount
the array so this edge points the same direction as your phone's camera.

| Signal | Pin |
|---|---|
| Bus 0 WS (TL/TR only) | GPIO4 |
| Bus 0 BCLK (TL/TR only) | GPIO5 |
| Bus 0 SD | GPIO6 |
| Bus 1 WS (BL/BR only) | GPIO1 |
| Bus 1 BCLK (BL/BR only) | GPIO2 |
| Bus 1 SD | GPIO42 |

Unlike earlier drafts of this firmware, **the two buses' clock pins are not the same and not
wired together** — TL/TR wire to GPIO4/GPIO5, BL/BR wire to GPIO1/GPIO2, and that's it, no
bridging. All 4 INMP441s: `VDD`→3.3V, `GND`→GND. `L/R` pin: tie LOW for TL/BL (left-select), HIGH
for TR/BR (right-select).

GPIO1/GPIO2/GPIO42 are safe to use here: none are ESP32-S3 strapping pins, none are used for
flash/PSRAM, none are the native-USB pair (GPIO19/20). GPIO1's only other role on the chip is
`ADC1_CH0`, GPIO2 is a plain GPIO, and GPIO42 doubles as `MTMS` (JTAG) but that's inert unless
JTAG debugging is enabled.

If any of these are unavailable or already used on your board, edit the pin numbers at the top of
`Config.h` — any 6 free GPIOs work, avoiding the ESP32-S3 strapping pins (0, 3, 45, 46) and your
board's native-USB pins (often 19/20).

Mic spacing: **edit `Config::kMicSpacingMeters` in `Config.h` to your array's actual measured
edge length** (TL-to-TR distance) — the search window firmware uses for cross-correlation
(`kMaxLagSamples`) is derived from this at compile time, so it automatically adapts to whatever
you actually built rather than assuming a specific spacing.

### Why not true 2D sync? (for anyone adapting this design)

This firmware's git history is a real record of what was tried, in case it saves you time on
similar hardware: same-pin sharing (slave configured with the master's own GPIO numbers, relying
on the ESP32 IO/GPIO matrix to fan the signal out internally — the standard, commonly-documented
technique for this pattern), separate slave GPIO numbers bridged with external loopback wires,
adding an MCLK loopback (both same-pin and separate-pin variants), explicit `bclk_div` tuning for
the slave's clock config, and enabling the slave channel before the master. All of these were
tried in various combinations on real hardware; none produced a single successful read on the
slave bus — it consistently reported `ESP_ERR_TIMEOUT` on every attempt, independent of sample
rate (tested down to 8kHz, ruling out signal integrity as the cause). If you have more insight
into why real cross-bus I2S sync didn't work here, the independent-masters fallback in this
firmware is functional either way.

## Arduino IDE setup

1. Install the **esp32 by Espressif Systems** board package (latest stable, ESP-IDF 5.x based) via
   Boards Manager.
2. Board: your specific ESP32-S3 dev board entry (or "ESP32S3 Dev Module").
3. Open `PeregrineMicArray.ino` — the other files in this folder (`Config.h`, `NetworkProtocol.h`,
   etc.) will show as additional tabs; that's normal, Arduino compiles them together.
4. Flash. Open the Serial Monitor at 115200 baud — you should see boot checkpoint lines ending
   with `AP 'PeregrineMicArray' up, gateway 192.168.4.1`, then periodic `[status] top: N ok / N
   fail   bottom: N ok / N fail` lines with `ok` counts climbing on both buses.

**If you see the ROM bootloader banner (`ESP-ROM:esp32s3-...`) and then nothing at all**: this is
a confirmed real-hardware quirk on boards using the S3's native USB, not a firmware hang. The
app's own `Serial.begin()` call re-initializes the USB peripheral, which briefly disconnects and
re-enumerates from the host's point of view — if the Serial Monitor was attached to the transient
bootloader-phase connection, it can get stuck watching a dead session and never reconnect to the
app's real one. This firmware uses `Serial0` (UART) specifically to avoid this, but if you still
hit it: close the monitor, reset the board, wait a few seconds for USB to settle, then reopen the
monitor fresh.

## First-time setup / calibration

1. **Per-bus sanity check**: clap your hands symmetrically between TL and TR (equal distance from
   both) and confirm bus 0's `ok` count climbs with no meaningful azimuth shift; repeat for BL/BR
   on bus 1. Each bus's own two mics ARE sample-synchronized with each other (same I2S peripheral),
   so this should work reliably.
2. **Angle check**: clap to the left and right of the array's front edge and confirm the reported
   azimuth shifts accordingly (roughly 90° = full right, 270° = full left, 0°/center = either
   straight ahead or straight behind — genuinely indistinguishable with this hardware, see "What
   this can and can't do" above).
3. In the Peregrine Planner app: Settings → Mic Array → join the `PeregrineMicArray` WiFi network
   when prompted, enable the feature, and use the live self-test readout there (claps should move
   the number) before heading into the field.

## Network protocol

See `NetworkProtocol.h` — kept in sync with the app's `MicArrayProtocol.swift`. UDP, port 3333,
little-endian. Summary: the phone pings (`0x03`) to detect the device, sends a session-start
(`0x05`) to begin receiving audio (`0x01`) and DOA telemetry (`0x02`) packets, and a session-stop
(`0x06`) when done. The device stops streaming on its own if it doesn't hear from the phone for
10 seconds.

## Known hardware issue: electrical noise on bare INMP441 modules

If you're seeing wildly swinging `level` readings in `[doa]`/`[onset]` output that don't track
real sound (occasional huge spikes uncorrelated with claps, present even with WiFi fully
disabled), this is a known issue with bare INMP441 modules on perfboard/breadboard prototypes, not
a firmware bug. Two likely causes, both real on the reference build this firmware was developed
against:

1. **No decoupling capacitor.** Bare INMP441 modules need a 0.1µF ceramic capacitor across
   VDD/GND, as close to the module's pins as possible — without it, the mic's own switching
   current noise rides back onto the shared power rail.
2. **Daisy-chained GND.** Each mic's ground should return independently to one common point (a
   "star" topology), not chain mic-to-mic — a shared/daisy-chained ground return lets one mic's
   switching current induce noise on the others sharing that path.

Fix: add the decoupling caps, rewire GND to a star topology, and keep the I2S clock wires
(BCLK/WS) physically separated from the data wires (SD) rather than bundled together — twisted-pair
wire (e.g. salvaged from a Cat5e/Cat6 cable) with each SD line paired with its own dedicated GND
return works well here.

**Interim software mitigation** (`OnsetDetector::filterOutlier`, `Config::kOutlierRejectRatio`):
until the rewire is done, the onset detector clamps any single block whose RMS spikes more than
6x above the last 2 accepted blocks, since a real acoustic transient stays elevated for several
consecutive blocks while electrical corruption typically hits one block in isolation. This helps
clap-testable onset detection but does **not** fix DOA accuracy — if individual samples inside an
otherwise-normal block are corrupted, the cross-correlation in `DOAEstimator` can still be thrown
off even when the block's overall RMS looks fine. Watch `[onset] ... outliers_rejected: N` in the
Serial output — this should climb quickly if the electrical issue is present, and should sit near
zero once the hardware fix above is done. Treat a high, climbing count as confirmation this is
still an open hardware issue, not a "fixed" state.

## Known v1 limitations (by design, not oversights)

- **Left-right azimuth only, not full 360°** — see "What this can and can't do" above for why.
- Time-domain cross-correlation, not GCC-PHAT — simpler and sufficient for this array's small
  baseline; documented as a v2 escalation path if real-world testing shows it too noisy indoors
  or in echo-heavy terrain.
- No true compass heading — azimuth is array-relative only.
- Up to 2 associated WiFi stations (`max_connection=2`) — one phone plus, optionally, the
  `PeregrineMicArrayRearSensor` companion unit (see below); still not meant to serve multiple
  simultaneous phones.

## Optional companion: rear sensor

`../PeregrineMicArrayRearSensor/` is a single-INMP441 accessory that mounts facing the opposite
direction from this array's own FRONT mark, to help flag/correct the front-back blind spot noted
above. See that folder's README and `MIC_ARRAY_MULTI_UNIT_PLAN.md` (repo root) for the design —
it's a separate optional build, not required for this array to work on its own.
