// GPSReader.h — thin wrapper around TinyGPSPlus + the remapped UART1 for the ATGM336H module.
// See Config.h's header comment for why GPS gets its own UART instead of sharing Serial0.
#pragma once

#include <cstdint>
#include <HardwareSerial.h>
#include <TinyGPSPlus.h>

class GPSReader {
public:
    // rxBufferSize sizes the UART driver's own RX ring buffer (must be set before serial.begin() --
    // the ESP32 Arduino core only honors setRxBufferSize() pre-begin()). See Config::
    // kGPSUARTRxBufferBytes's comment for why this isn't left at the core's 256-byte default.
    void begin(HardwareSerial &serial, int rxPin, int txPin, uint32_t baud, uint32_t rxBufferSize);

    // Call every loop() iteration: drains whatever bytes are waiting and feeds them to the NMEA
    // parser. Non-blocking — TinyGPSPlus is a streaming parser, no buffering of full sentences
    // needed on this side.
    void poll();

    bool hasFix() const { return hasFix_; }
    double latitude() const { return latitude_; }
    double longitude() const { return longitude_; }
    // 0 if the module doesn't report HDOP-derived accuracy, which is common/acceptable — the wire
    // packet's horizontalAccuracyMeters field already documents 0 as "unknown."
    float horizontalAccuracyMeters() const { return horizontalAccuracyMeters_; }

    // Raw link diagnostics, added 2026-08-12 -- "no fix yet" alone can't distinguish a module
    // that's genuinely still cold-starting/under bad sky view from one that's never received a
    // single valid byte at all (wrong TX/RX wiring, wrong baud, dead module). All three are
    // TinyGPSPlus's own running counters, exposed here rather than recomputed:
    //   charsProcessed() == 0 (or never climbing) -- no bytes arriving on the UART at all. Check
    //     wiring (GPS TX -> ESP32 RX/kGPSRXPin, not swapped) and baud (kGPSBaud) before anything
    //     else -- this is a link problem, not a fix problem.
    //   charsProcessed() climbing but passedChecksum() staying near 0 -- bytes ARE arriving but
    //     aren't valid NMEA (garbled) -- classic wrong-baud-rate symptom, or a noisy/marginal
    //     connection.
    //   passedChecksum() climbing normally, hasFix() still false -- the link is fine, this is a
    //     genuine "no fix yet" situation (cold start can take 30s-several minutes; needs open sky,
    //     doesn't work well indoors/under heavy canopy).
    uint32_t charsProcessed() const;
    uint32_t sentencesWithValidChecksum() const;
    uint32_t sentencesWithInvalidChecksum() const;
    // 0 until at least one GSV/GSA sentence with satellite-count info has been parsed -- not
    // every module/firmware reports this on every sentence type. Not `const`: TinyGPSInteger's
    // own value() clears an internal "updated" flag as a side effect, same pattern TinyGPSPlus
    // uses throughout its own API.
    int satellitesInView();

    // Real-hardware diagnostic added 2026-08-18, from a live GPS-freeze investigation on a 2-mic
    // Cam node: distinguishes "loop() itself stalled long enough to starve GPS polling" from other
    // causes of a wedged/frozen NMEA parser (sentencesWithValidChecksum()/WithInvalidChecksum()
    // both frozen forever while charsProcessed() keeps climbing normally -- see
    // Config::kGPSUARTRxBufferBytes's comment for the full theory this came out of). Longest gap
    // between two consecutive poll() calls, in ms, since boot -- a large number here confirms
    // loop() really did stop running for that long; a small number rules that theory out and points
    // back at the parser/module itself instead.
    uint32_t maxPollGapMs() const { return maxPollGapMs_; }

private:
    HardwareSerial *serial_ = nullptr;
    TinyGPSPlus parser_;
    bool hasFix_ = false;
    double latitude_ = 0;
    double longitude_ = 0;
    float horizontalAccuracyMeters_ = 0;
    uint32_t lastPollMs_ = 0;
    uint32_t maxPollGapMs_ = 0;
};
