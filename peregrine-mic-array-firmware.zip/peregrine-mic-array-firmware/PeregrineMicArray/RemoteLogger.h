// RemoteLogger.h — transparently mirrors everything already printed to Serial0 over UDP to the
// phone (FIELD_DEBUG_PLAN.md, repo root, added 2026-08-18), so a debugging session's log can be
// captured to a file on the phone instead of requiring the node to stay physically tethered to a
// laptop. Real motivating case: collecting GPS PPS interval jitter over an extended field session
// to inform the still-unbuilt elevation-sync design (see the "GPS PPS elevation / multi-node TDOA
// sync" design doc) -- exactly the kind of long-running, away-from-a-desk data collection a USB
// tether can't support.
//
// **Deliberately does NOT touch any of the ~100 existing Serial0.printf/println call sites** across
// this project's firmware -- see the plan doc's "key decision" for the full rationale. Instead this
// class is a Print subclass that the node's .ino shadows the name `Serial0` with via a preprocessor
// macro (see the bottom of this file's own .ino wiring), so every existing call transparently
// starts flowing through here with zero call-site changes. Verified against this exact Arduino core
// (3.3.11) with a standalone prototype before committing to this approach, including both
// `begin()` call-site shapes used across this project's firmware (single-arg and full 4-arg) and
// `printf`'s variadic form -- both compile and work cleanly (`Print::printf`/`println` are non-
// virtual, implemented once in the Print base class in terms of the virtual `write()` this class
// overrides, so nothing about printf/println itself needs reimplementing here).
//
// Opt-in, default OFF -- this is a debugging aid, not part of normal operation. When disabled,
// every write() still forwards to the real UART completely unchanged (the existing tethered
// workflow is untouched, byte-for-byte identical) but does none of the line-buffering/queuing work
// below, so there's genuinely zero added cost for anyone who never turns this on.
//
// Single-client model, same as every other part of this wire protocol -- log lines go to whichever
// phone is currently the registered UDP client, not broadcast to a fleet of listeners.
#pragma once

#include <Print.h>
#include <HardwareSerial.h>

class UDPStreamer;

class RemoteLogger : public Print {
public:
    // Captures the real UART to forward every write to, and to actually perform begin() against
    // (see that method's own comment for why `Serial0.begin(...)` still has to work correctly here).
    void attach(HardwareSerial &realSerial) { realSerial_ = &realSerial; }

    // Matches HardwareSerial::begin's own signature (default params cover both call shapes this
    // project's two active firmwares actually use: begin(baud) and begin(baud, config, rxPin,
    // txPin)) -- forwarded straight through to the real UART, unchanged.
    void begin(
        unsigned long baud, uint32_t config = SERIAL_8N1, int8_t rxPin = -1, int8_t txPin = -1,
        bool invert = false, unsigned long timeout_ms = 20000UL, uint8_t rxfifo_full_thrhd = 120
    );

    // Print interface -- this is the entire surface that makes the `#define Serial0 gRemoteLogger`
    // trick work transparently for every existing print/println/printf call site.
    size_t write(uint8_t byte) override;
    size_t write(const uint8_t *buffer, size_t size) override;

    // Wired to kSetRemoteLogging. Off by default -- see this file's header for why.
    void setEnabled(bool enabled) { enabled_ = enabled; }
    bool isEnabled() const { return enabled_; }

    // Call once per loop() iteration, same place UDPStreamer::poll() already runs. Draining here
    // rather than sending inline inside write() bounds how much network work happens per call and
    // keeps this off the hot byte-by-byte write path -- write() only ever does fast, fixed-size
    // buffer work.
    void poll(UDPStreamer &network);

private:
    void bufferByte(uint8_t byte);

    HardwareSerial *realSerial_ = nullptr;
    bool enabled_ = false;

    static constexpr size_t kLineBufferSize = 224;
    char lineBuffer_[kLineBufferSize];
    size_t lineLength_ = 0;
    // Set once lineBuffer_ has filled without a newline -- the current line gets a
    // "...[truncated]" marker appended when it does eventually complete (or the buffer would
    // otherwise overflow), rather than silently wrapping/corrupting it. Real hardware note: every
    // Serial0 line in this codebase is a short printf one-liner well under this size -- this guard
    // is defensive, not expected to trigger in practice.
    bool lineOverflowed_ = false;

    // Small fixed queue of complete lines waiting for the next poll() to actually send -- a fixed
    // array of fixed-size buffers, not String, to avoid heap churn on what can be a fairly hot
    // path (e.g. camera-node video capture already logs a line per frame at 6fps).  If a burst
    // fills the queue faster than poll() drains it, the OLDEST queued line is dropped to make room
    // for the newest -- same "losing an occasional line is fine" tolerance this whole protocol
    // already has for every other fire-and-forget UDP packet type.
    static constexpr int kMaxQueuedLines = 8;
    char queuedLines_[kMaxQueuedLines][kLineBufferSize];
    int queueHead_ = 0;
    int queueCount_ = 0;
    void enqueueLine(const char *line);
};
