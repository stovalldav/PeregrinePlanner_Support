// RingBuffer.h — a small mutex-guarded circular buffer of int16 samples, used two ways:
//   1. As a FIFO: capture tasks push new blocks, the network task drains sequentially-new
//      samples for outgoing audio packets (`popAvailable`).
//   2. As a lookback window: `snapshotRecent` copies the most recent N samples without
//      disturbing the FIFO read position — used to grab the DOA analysis window at the moment
//      an onset is detected.
#pragma once

#include <cstdint>
#include <cstring>
#include <cstdlib>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "esp32-hal-psram.h"

class RingBuffer {
public:
    explicit RingBuffer(int capacity) : capacity_(capacity) {
        // PSRAM-backed, not internal SRAM -- real finding, 2026-08-26: the streaming-audio FIFOs
        // (audioRing/etc., PeregrineMicArrayCam's Config::kAudioRingCapacitySamples) needed a real
        // capacity increase to survive camera-grab stalls during video recording, and this board's
        // internal SRAM budget is tight (~250KB free after WiFi/BLE/task stacks) -- too tight to
        // safely absorb that increase across 4 rings without real OOM risk. `ps_malloc` falls back
        // to the regular (internal) heap if PSRAM genuinely isn't available on a given board
        // (shouldn't happen on either firmware's target hardware, both PSRAM-equipped -- defensive
        // only, not expected to ever actually take this path).
        buffer_ = (int16_t *)ps_malloc(capacity_ * sizeof(int16_t));
        if (!buffer_) {
            buffer_ = (int16_t *)malloc(capacity_ * sizeof(int16_t));
        }
        memset(buffer_, 0, capacity_ * sizeof(int16_t));
        mutex_ = xSemaphoreCreateMutex();
    }

    ~RingBuffer() {
        free(buffer_);
        vSemaphoreDelete(mutex_);
    }

    // Producer side: append `count` new samples, overwriting the oldest data if the buffer wraps.
    void pushBlock(const int16_t *samples, int count) {
        xSemaphoreTake(mutex_, portMAX_DELAY);
        for (int i = 0; i < count; i++) {
            buffer_[writeIndex_] = samples[i];
            writeIndex_ = (writeIndex_ + 1) % capacity_;
            totalWritten_++;
        }
        xSemaphoreGive(mutex_);
    }

    // Consumer side (FIFO): copies up to `maxCount` samples that haven't been popped yet, in
    // order, into `out`. Returns the actual count copied. Safe to call from a different task
    // than the producer.
    int popAvailable(int16_t *out, int maxCount) {
        xSemaphoreTake(mutex_, portMAX_DELAY);
        uint32_t available = totalWritten_ - totalRead_;
        if (available > (uint32_t)capacity_) {
            // Consumer fell too far behind and the buffer wrapped past unread data -- skip ahead
            // rather than replaying garbage/stale positions. This is real, silent data loss (a
            // discontinuity spliced into whatever's being streamed) -- skippedSamples_ exists so
            // that loss is actually visible instead of an invisible root cause for anything
            // downstream that looks corrupted/degraded (see loop()'s "audio-ring" status print).
            skippedSamples_ += available - (uint32_t)capacity_;
            totalRead_ = totalWritten_ - capacity_;
            available = capacity_;
        }
        int count = (available < (uint32_t)maxCount) ? (int)available : maxCount;
        int readIndex = (writeIndex_ - (int)available + capacity_) % capacity_;
        for (int i = 0; i < count; i++) {
            out[i] = buffer_[readIndex];
            readIndex = (readIndex + 1) % capacity_;
        }
        totalRead_ += count;
        xSemaphoreGive(mutex_);
        return count;
    }

    // Lookback: copies the most recent `count` samples (oldest-first within the returned window)
    // into `out` without touching the FIFO read position. If fewer than `count` samples have
    // ever been written, the unwritten leading portion of `out` is left as zero (silence).
    // Total samples ever silently skipped in popAvailable() due to the consumer (loop(), for the
    // continuously-streamed classification audio) falling more than a full buffer behind the
    // producer (the capture task). Non-zero/climbing means real audio gaps are reaching the
    // phone's classifier -- worth watching specifically on `audioRing` when comparing Radar Mode
    // on vs. off, since more active bands means more per-onset work in loop() that could delay
    // draining this ring.
    uint32_t skippedSamples() const { return skippedSamples_; }

    void snapshotRecent(int16_t *out, int count) {
        xSemaphoreTake(mutex_, portMAX_DELAY);
        int available = (totalWritten_ < (uint32_t)count) ? (int)totalWritten_ : count;
        int missing = count - available;
        if (missing > 0) {
            memset(out, 0, missing * sizeof(int16_t));
        }
        int readIndex = (writeIndex_ - available + capacity_) % capacity_;
        for (int i = 0; i < available; i++) {
            out[missing + i] = buffer_[readIndex];
            readIndex = (readIndex + 1) % capacity_;
        }
        xSemaphoreGive(mutex_);
    }

private:
    int16_t *buffer_;
    int capacity_;
    int writeIndex_ = 0;
    uint32_t totalWritten_ = 0;
    uint32_t totalRead_ = 0;
    uint32_t skippedSamples_ = 0;
    SemaphoreHandle_t mutex_;
};
