// PPSReader.h — captures GPS PPS (pulse-per-second) rising-edge timestamps, the time-base
// prerequisite for a future clock-synchronized multi-node capture feature (cross-bus elevation /
// multi-node TDOA -- see MIC_ARRAY_MASTER_AP_PLAN.md-adjacent discussion). NOT that feature itself
// -- nothing in this firmware consumes the edge timing yet, this class only captures and reports
// it, so real-hardware bring-up can confirm the signal arrives correctly before anything is built
// on top of it.
//
// Each PPS pulse marks a GPS-precise UTC second boundary (accurate to tens of nanoseconds on
// consumer modules) -- capturing this node's own micros() at that exact instant gives a
// local-time-to-UTC mapping, refreshed every second, far more precise than anything a WiFi/UDP
// round-trip could offer for aligning independently-clocked nodes.
//
// Repurposes this board's SECOND USB-C port for the pin -- see Config::kPPSEnabled/kPPSPin's own
// comment for the real tradeoff this accepts (that port's native-USB function is given up
// permanently once its D-/D+ pin is wired to something else).
#pragma once

#include <cstdint>

class PPSReader {
public:
    // Configures `pin` as input and attaches the rising-edge interrupt -- call once from setup(),
    // only if Config::kPPSEnabled. The interrupt handler itself is a plain free function (not a
    // class member) -- attachInterrupt()'s C API takes a bare `void (*)()` function pointer, no
    // room for a `this` capture, and there's only ever one PPS signal/reader in practice, so
    // file-local shared state (see PPSReader.cpp) is the natural fit -- also sidesteps a real
    // GCC quirk hit while developing this: applying IRAM_ATTR to a `static` class member function
    // declaration split across header/cpp produced a bogus "int"-returning-function parse error,
    // not present with a plain free function.
    void begin(int pin);

    // Local micros() timestamp of the most recent PPS edge, or 0 if none seen yet.
    uint32_t lastEdgeMicros() const;
    // Total edges seen since begin() -- a steadily-incrementing count confirms the signal is
    // actually arriving, distinct from "wired but never pulsing."
    uint32_t edgeCount() const;
    // Microseconds between the two most recent edges -- should read very close to 1,000,000 on a
    // working GPS PPS signal; consistently and significantly off suggests a wiring/signal-
    // integrity problem, not normal jitter (real consumer-GPS PPS jitter is nanosecond-scale, well
    // below what a micros()-resolution reading here could even show). Meaningless (0) before the
    // second edge arrives.
    uint32_t lastIntervalMicros() const;
};
