// PPSReader.h — captures GPS PPS (pulse-per-second) rising-edge timestamps AND turns them into a
// disciplined local->UTC clock, the time base for multi-node TDOA source localization
// (MULTI_NODE_TDOA_PLAN.md). `bindUtcSecond()` (from loop(), on a fresh GPS time) anchors a UTC
// second to the most recent edge; `utcForLocalMicros()` then maps any local micros() reading to
// UTC microseconds, rate-corrected for the ESP32 crystal's ppm error using the measured PPS
// interval. The onset-timestamping path in the .ino feeds captured onset times through this.
//
// Each PPS pulse marks a GPS-precise UTC second boundary (accurate to tens of nanoseconds on
// consumer modules) -- capturing this node's own micros() at that exact instant gives a
// local-time-to-UTC mapping, refreshed every second, far more precise than anything a WiFi/UDP
// round-trip could offer for aligning independently-clocked nodes.
//
// Repurposes this board's SECOND USB-C port for the pin -- see Config::kPPSEnabled/kPPSPin's own
// comment for the real tradeoff this accepts (that port's native-USB function is given up
// permanently once its D-/D+ pin is wired to something else).
#pragma once

#include <cstdint>

class PPSReader {
public:
    // Configures `pin` as input and attaches the rising-edge interrupt -- call once from setup(),
    // only if Config::kPPSEnabled. The interrupt handler itself is a plain free function (not a
    // class member) -- attachInterrupt()'s C API takes a bare `void (*)()` function pointer, no
    // room for a `this` capture, and there's only ever one PPS signal/reader in practice, so
    // file-local shared state (see PPSReader.cpp) is the natural fit -- also sidesteps a real
    // GCC quirk hit while developing this: applying IRAM_ATTR to a `static` class member function
    // declaration split across header/cpp produced a bogus "int"-returning-function parse error,
    // not present with a plain free function.
    void begin(int pin);

    // Local micros() timestamp of the most recent PPS edge, or 0 if none seen yet.
    uint32_t lastEdgeMicros() const;
    // Total edges seen since begin() -- a steadily-incrementing count confirms the signal is
    // actually arriving, distinct from "wired but never pulsing."
    uint32_t edgeCount() const;
    // Microseconds between the two most recent edges -- should read very close to 1,000,000 on a
    // working GPS PPS signal; consistently and significantly off suggests a wiring/signal-
    // integrity problem, not normal jitter (real consumer-GPS PPS jitter is nanosecond-scale, well
    // below what a micros()-resolution reading here could even show). Meaningless (0) before the
    // second edge arrives.
    uint32_t lastIntervalMicros() const;

    // Session-wide interval statistics, accumulated in the ISR so every pulse is counted even when
    // loop() stalls (unlike lastIntervalMicros(), which is only whatever the last poll happened to
    // catch). Added 2026-09-01 to turn the 2s-cadence [pps] log into a real stability picture over
    // a long field session -- the input to the elevation-sync time-base plan.
    //
    // IMPORTANT: this is still ISR-latency + micros()-quantization limited (a few us), NOT the
    // actual GPS PPS jitter, which is nanosecond-scale. A tight PPS reads a few us of spread here;
    // tens of us or a growing max means a real signal-integrity / wiring problem, not GPS jitter.
    uint32_t minIntervalMicros() const;   // smallest interval seen (0 before the 2nd edge)
    uint32_t maxIntervalMicros() const;   // largest interval seen
    uint32_t intervalSampleCount() const; // number of intervals measured (~edgeCount - 1)
    // Mean absolute deviation of the interval from the nominal 1,000,000 us, over the whole session.
    uint32_t meanAbsDevMicros() const;

    // ---- Disciplined local->UTC clock (MULTI_NODE_TDOA_PLAN.md Phase 1/2) ----

    struct UtcMicros {
        bool valid;       // false until an edge + a bound UTC second both exist
        uint32_t second;  // seconds-of-day, 0..86399
        uint32_t micros;  // 0..999999
    };

    // Call from loop() when GPSReader::timeFresh() -- anchors `utcSecondOfDay` to the most recent
    // PPS edge. No-op if no edge yet, or if the last edge is >900ms old (we probably missed one,
    // don't anchor to a stale edge). The edge marks the START of the second the GPS just reported,
    // so anchorUtcSecond == utcSecondOfDay directly. (A whole-second offset, if the module times
    // its sentence differently, is harmless for RELATIVE TDOA between nodes -- both would be off by
    // the same second -- and would show as an obvious constant error in the [clock] debug line if
    // absolute time ever matters; adjust here then.)
    void bindUtcSecond(uint32_t utcSecondOfDay);

    // Map a local micros() reading to UTC, rate-corrected for the crystal's ppm error using the
    // measured PPS interval. `{false,...}` until bindUtcSecond() has succeeded at least once.
    UtcMicros utcForLocalMicros(uint32_t localMicros) const;

    bool utcAnchorValid() const;
    // Milliseconds since the anchored edge -- for the [clock] debug line; 0 if no anchor.
    uint32_t anchorAgeMillis() const;
};
