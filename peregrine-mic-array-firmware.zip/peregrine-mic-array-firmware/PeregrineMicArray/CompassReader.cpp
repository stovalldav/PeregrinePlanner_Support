#include "CompassReader.h"
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include "Config.h"

CompassReader::~CompassReader() {
    delete bno_;
}

bool CompassReader::begin(int sda, int scl) {
    Wire.begin(sda, scl);
    // 0x28 is the BNO055's default (ADR low); 0x29 is ADR high -- and some breakouts (e.g. the
    // GY-BNO055) ship with ADR pulled high. Real finding 2026-09-30: a GY-BNO055 on the security
    // node wasn't found at 0x28 alone. So try both, and if neither answers, scan the bus and log
    // what IS there, so the next step is evidence (wrong address vs. wiring vs. nothing connected).
    for (uint8_t address : {(uint8_t)0x28, (uint8_t)0x29}) {
        bno_ = new Adafruit_BNO055(/*sensorID=*/55, address, &Wire);
        if (bno_->begin()) {
            Serial0.printf("[compass] BNO055 found at 0x%02X\n", address);
            break;
        }
        delete bno_;
        bno_ = nullptr;
    }
    if (!bno_) {
        Serial0.println("[compass] BNO055 not found at 0x28 or 0x29 -- scanning the I2C bus:");
        int found = 0;
        for (uint8_t a = 0x08; a < 0x78; a++) {
            Wire.beginTransmission(a);
            if (Wire.endTransmission() == 0) {
                Serial0.printf("[compass]   device answered at 0x%02X\n", a);
                found++;
            }
        }
        if (found == 0) {
            Serial0.printf("[compass]   nothing on the bus (SDA %d, SCL %d) -- check power, GND, SDA/SCL not swapped, and pull-ups\n", sda, scl);
        }
        return false;
    }
    // Most BNO055 breakouts carry a 32.768kHz crystal; using it (rather than the chip's internal
    // oscillator) measurably improves fusion stability per Adafruit's own driver documentation.
    // Harmless no-op if the specific breakout doesn't actually have one populated.
    delay(1000);
    bno_->setExtCrystalUse(true);
    initialized_ = true;
    Serial0.println("[compass] BNO055 initialized");
    return true;
}

bool CompassReader::poll(uint32_t nowMs) {
    if (!initialized_) return false;
    if (nowMs - lastReportMs_ < Config::kCompassReportIntervalMs) return false;
    lastReportMs_ = nowMs;

    sensors_event_t event;
    bno_->getEvent(&event, Adafruit_BNO055::VECTOR_EULER);
    // Adafruit's BNO055 driver reports Euler heading (yaw) in orientation.x, already in the
    // [0, 360) clockwise-from-magnetic-north convention NetworkProtocol.h's CompassHeadingPacket
    // was designed to -- no conversion needed.
    headingDeg_ = event.orientation.x;

    uint8_t sys, gyro, accel, mag;
    bno_->getCalibration(&sys, &gyro, &accel, &mag);
    magCalibration_ = mag;
    packedCalibration_ = (uint8_t)(((sys & 3) << 6) | ((gyro & 3) << 4) | ((accel & 3) << 2) | (mag & 3));

    // NODE_ORIENTATION_3D_PLAN.md -- raw vectors for the app's own tilt-compensated orientation.
    imu::Vector<3> gravityVec = bno_->getVector(Adafruit_BNO055::VECTOR_GRAVITY);
    imu::Vector<3> magVec = bno_->getVector(Adafruit_BNO055::VECTOR_MAGNETOMETER);
    gravity_[0] = gravityVec.x(); gravity_[1] = gravityVec.y(); gravity_[2] = gravityVec.z();
    magnetic_[0] = magVec.x(); magnetic_[1] = magVec.y(); magnetic_[2] = magVec.z();

    Serial0.printf("[compass] heading: %.1f  mag calibration: %u/3 (sys %u gyro %u accel %u)\n",
        headingDeg_, mag, sys, gyro, accel);
    return true;
}
