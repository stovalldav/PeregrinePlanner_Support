#include "NodeRoster.h"
#include "Config.h"

void NodeRoster::addOrRefresh(IPAddress ip, const Protocol::NodeIdentityPacket &identity, uint32_t nowMs) {
    for (int i = 0; i < count_; i++) {
        if (entries_[i].ip == ip) {
            entries_[i].identity = identity;
            entries_[i].lastSeenMs = nowMs;
            return;
        }
    }
    if (count_ >= Protocol::kMaxRosterEntries) return; // full -- drop silently, same as kMaxDOABands
    entries_[count_].ip = ip;
    entries_[count_].identity = identity;
    entries_[count_].lastSeenMs = nowMs;
    count_++;
}

void NodeRoster::pruneStale(uint32_t nowMs) {
    for (int i = 0; i < count_; ) {
        if (nowMs - entries_[i].lastSeenMs > Config::kRosterStaleTimeoutMs) {
            entries_[i] = entries_[count_ - 1]; // swap-remove: order doesn't matter for a roster
            count_--;
        } else {
            i++;
        }
    }
}
