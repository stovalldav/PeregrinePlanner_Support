#include "I2SCapture.h"
#include <cstdlib>
#include "freertos/FreeRTOS.h" // pdMS_TO_TICKS

bool I2SBus::begin(i2s_port_t port, int bclk, int ws, int din, uint32_t sampleRateHz) {
    i2s_chan_config_t chanCfg = I2S_CHANNEL_DEFAULT_CONFIG(port, I2S_ROLE_MASTER);
    if (i2s_new_channel(&chanCfg, NULL, &rxHandle_) != ESP_OK) {
        return false;
    }

    i2s_std_config_t stdCfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(sampleRateHz),
        // INMP441 uses the standard I2S (Philips) format, 24-bit data left-justified in a 32-bit
        // slot -- I2S_DATA_BIT_WIDTH_32BIT is the correct slot width for this mic, not the actual
        // sample resolution (see readFrames' decode comment).
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED, // INMP441 doesn't need MCLK; each bus is its own master
            .bclk = (gpio_num_t)bclk,
            .ws = (gpio_num_t)ws,
            .dout = I2S_GPIO_UNUSED,
            .din = (gpio_num_t)din,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };

    if (i2s_channel_init_std_mode(rxHandle_, &stdCfg) != ESP_OK) {
        return false;
    }
    if (i2s_channel_enable(rxHandle_) != ESP_OK) {
        return false;
    }
    return true;
}

bool I2SBus::readFrames(int16_t *left, int16_t *right, int frameCount, uint32_t timeoutMs) {
    if (rawBufferCapacityFrames_ < frameCount) {
        free(rawBuffer_);
        rawBuffer_ = (int32_t *)malloc(sizeof(int32_t) * 2 * frameCount);
        rawBufferCapacityFrames_ = frameCount;
    }
    if (!rawBuffer_) return false;

    size_t bytesToRead = sizeof(int32_t) * 2 * frameCount;
    size_t bytesRead = 0;
    esp_err_t err = i2s_channel_read(rxHandle_, rawBuffer_, bytesToRead, &bytesRead, pdMS_TO_TICKS(timeoutMs));
    if (err != ESP_OK) return false;

    int framesRead = bytesRead / (sizeof(int32_t) * 2);
    for (int i = 0; i < framesRead; i++) {
        int32_t rawLeft = rawBuffer_[i * 2];
        int32_t rawRight = rawBuffer_[i * 2 + 1];
        // >>16: 8 bits strips the I2S padding (24-bit sample left-justified in a 32-bit word),
        // 8 more brings 24-bit range down to a 16-bit int16 -- see header comment.
        left[i] = (int16_t)(rawLeft >> 16);
        right[i] = (int16_t)(rawRight >> 16);
    }
    for (int i = framesRead; i < frameCount; i++) {
        left[i] = 0;
        right[i] = 0;
    }
    return framesRead == frameCount;
}
