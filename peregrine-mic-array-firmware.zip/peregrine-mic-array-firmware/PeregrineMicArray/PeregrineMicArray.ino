// PeregrineMicArray — ESP32-S3 4x INMP441 direction-finding firmware for Peregrine Planner.
// See README.md for wiring, board settings, and calibration steps. See ../../PHASE 7 plan doc
// (repo root, MIC_ARRAY plan) for the full architecture writeup this implements.
//
// Square array (TL, TR, BL, BR): bus 0 (top pair) and bus 1 (bottom pair) are two INDEPENDENT
// I2S masters, each with their own separate BCLK/WS pins -- not sample-synchronized with each
// other. See Config.h's header comment for why: true cross-bus sync (one master, one slave
// reading the same clock) was tried via several different strategies and never worked reliably
// on this hardware despite exhausting the documented ESP-IDF configuration space. The real,
// accepted cost of this simpler design is that azimuth is left-right only, not full 360 degrees -- see
// DOAEstimator.h.
//
// TL's channel doubles as the continuously-streamed mono reference for the phone's species-ID
// pipeline (like before, just renamed from the earlier "M0" naming). The onset/energy gate also
// runs on TL by default; when it fires, the most recent analysis window from all 4 channels is
// snapshotted and run through DOAEstimator to produce one azimuth+confidence reading. **Real-
// hardware finding 2026-08-20**: a completely dead top pair (confirmed on real hardware -- see
// project_mic_array_hardware memory) meant onset never fired at all, so nothing downstream
// (streaming audio, DOA, Radar Mode) ever worked regardless of the bottom pair being fine. Fixed
// with an automatic top/bottom-pair fallback (see usingBottomPair below) -- once the top pair is
// confirmed silent for ~10s straight, BOTH the streamed reference audio and the onset/DOA gate
// switch to the bottom pair instead (DOAEstimator::estimateSingleBus(), not the normal two-pair
// estimate() -- a known-dead pair can't just be blended into that average, see its own comment).
//
// Uses Serial0 (UART), not Serial (native USB CDC) -- confirmed on real hardware that this
// board's native-USB Serial object silently produces no output after the app's own Serial.begin()
// re-initializes the USB peripheral (a host-side reconnection issue), while Serial0 works reliably.

#include <WiFi.h>
#include "Config.h"
#include "NetworkProtocol.h"
#include "RingBuffer.h"
#include "I2SCapture.h"
#include "OnsetDetector.h"
#include "DOAEstimator.h"
#include "UDPStreamer.h"
#include "WiFiConfigStore.h"
#include "GPSReader.h"
#include "PPSReader.h"
#include "CompassReader.h"
#include "BLEAdvertiser.h"
#include "RemoteLogger.h"

// Block size for each I2S read -- small enough to keep the onset gate responsive (~5.8ms at
// 44.1kHz), large enough to not thrash the I2S DMA with tiny reads.
static const int kReadBlockFrames = 256;

I2SBus busTop;    // I2S_NUM_0, independent master -- TL (left-select) / TR (right-select)
I2SBus busBottom; // I2S_NUM_1, independent master -- BL (left-select) / BR (right-select)
UDPStreamer network;
// Runtime Wi-Fi / AP / role config, NVS-backed (CONFIGURABLE_FLEET_PLAN.md Part A). Seeded from
// the Config.h defaults in setup(); NVS overrides win where the app has set them.
WiFiConfigStore gWiFiConfig;

// Rolls a freshly-committed (and not-yet-proven) Wi-Fi config back if the node can't reach a
// network within Config::kConfigRecoveryTimeoutMs of boot -- see CONFIGURABLE_FLEET_PLAN.md Part A.
// millis()-since-boot is the clock: the node always reboots on commit, so "since boot" == "since
// the config change". Mirrors the camera firmware's copy.
static void pollConfigRecovery() {
    if (!gWiFiConfig.awaitingProof()) return;

    const uint8_t role = gWiFiConfig.role();
    const bool reachable = (role == Config::kRolePrimary)
        ? (WiFi.softAPgetStationNum() > 0)   // a typo'd AP password otherwise never "fails"
        : (WiFi.status() == WL_CONNECTED);

    static uint32_t proofStartMs = 0;
    const uint32_t now = millis();

    if (reachable) {
        if (proofStartMs == 0) proofStartMs = now;
        if (now - proofStartMs >= Config::kConfigProofHoldMs) {
            gWiFiConfig.markProven();
            Serial0.println("[wcfg] committed config proven good -- recovery arm cleared");
        }
        return;
    }
    proofStartMs = 0;
    if (now < Config::kConfigRecoveryTimeoutMs) return; // still inside the grace window since boot

    if (gWiFiConfig.hasPrevious()) {
        Serial0.printf("[wcfg] recovery: no network %lus after a config change -- reverting to previous\n",
                       (unsigned long)(Config::kConfigRecoveryTimeoutMs / 1000));
        gWiFiConfig.revertToPrevious();
    } else {
        Serial0.println("[wcfg] recovery: no network and no previous config -- resetting to Config.h defaults");
        gWiFiConfig.resetToDefaults();
    }
    delay(200);
    ESP.restart();
}
BLEAdvertiser bleAdvertiser; // BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17
OnsetDetector onset;
GPSReader gps;   // ported 2026-08-14 from ../PeregrineMicArrayCam -- see Config.h's GPS section
PPSReader pps;
CompassReader compass; // COMPASS_HEADING_HARDWARE_PLAN.md

// FIELD_DEBUG_PLAN.md, added 2026-08-18 -- see RemoteLogger.h for the full rationale. `RealSerial0`
// MUST be captured here, before the #define below -- that macro is a pure textual substitution, so
// any later occurrence of the literal token `Serial0` (including trying to reference the real
// global by name) would also get replaced, making the original object unreachable by name at all.
// Verified via a standalone prototype against this exact Arduino core before relying on it here.
HardwareSerial &RealSerial0 = Serial0;
RemoteLogger gRemoteLogger;
#define Serial0 gRemoteLogger

// Real diagnostic gap found 2026-08-18: user reported two failover symptoms -- (1) the
// "PeregrineMicArray" fallback AP is visible with the correct password entered, but the phone
// still can't join, and (2) when joining the phone's Personal Hotspot instead (kRoleSecondary's
// STA path), the array doesn't actually seem to join it at all. Nothing anywhere logged whether an
// association attempt even reached this node in AP mode, why it was rejected, or why an STA join
// attempt failed -- pollFailover()/promoteToFailedOver()/joinBestCandidate() only ever logged
// their own high-level intent ("promoting", "trying candidate X"), never the WiFi driver's own
// connect/disconnect events, which carry ESP-IDF's numeric reason code (wifi_err_reason_t --
// common ones: 2 = AUTH_EXPIRE, 15 = 4WAY_HANDSHAKE_TIMEOUT, 201 = NO_AP_FOUND, 202 = AUTH_FAIL,
// 203 = ASSOC_FAIL -- look the exact number up in esp_wifi_types_generic.h once we have a real one
// to check). Registered once in setup(), before the very first network.begin() call, so it also
// catches a cold-boot AP-hosting promotion, not just a later runtime failover.
void onWiFiEvent(WiFiEvent_t event, WiFiEventInfo_t info) {
    switch (event) {
        case ARDUINO_EVENT_WIFI_AP_STACONNECTED:
            Serial0.printf("[wifi-ap] station associated -- mac %02x:%02x:%02x:%02x:%02x:%02x aid %u\n",
                info.wifi_ap_staconnected.mac[0], info.wifi_ap_staconnected.mac[1], info.wifi_ap_staconnected.mac[2],
                info.wifi_ap_staconnected.mac[3], info.wifi_ap_staconnected.mac[4], info.wifi_ap_staconnected.mac[5],
                info.wifi_ap_staconnected.aid);
            break;
        case ARDUINO_EVENT_WIFI_AP_STADISCONNECTED:
            Serial0.printf("[wifi-ap] station disassociated -- mac %02x:%02x:%02x:%02x:%02x:%02x aid %u reason %u\n",
                info.wifi_ap_stadisconnected.mac[0], info.wifi_ap_stadisconnected.mac[1], info.wifi_ap_stadisconnected.mac[2],
                info.wifi_ap_stadisconnected.mac[3], info.wifi_ap_stadisconnected.mac[4], info.wifi_ap_stadisconnected.mac[5],
                info.wifi_ap_stadisconnected.aid, info.wifi_ap_stadisconnected.reason);
            break;
        case ARDUINO_EVENT_WIFI_AP_STAIPASSIGNED: {
            IPAddress ip(info.wifi_ap_staipassigned.ip.addr);
            Serial0.printf("[wifi-ap] DHCP lease handed out -- mac %02x:%02x:%02x:%02x:%02x:%02x ip %s\n",
                info.wifi_ap_staipassigned.mac[0], info.wifi_ap_staipassigned.mac[1], info.wifi_ap_staipassigned.mac[2],
                info.wifi_ap_staipassigned.mac[3], info.wifi_ap_staipassigned.mac[4], info.wifi_ap_staipassigned.mac[5],
                ip.toString().c_str());
            break;
        }
        case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:
            // Fires for every failed/dropped STA join attempt, including each of
            // joinBestCandidate()'s per-candidate tries that time out -- `reason` is the same
            // wifi_err_reason_t numbering as the AP-side event above.
            Serial0.printf("[wifi-sta] disconnected from '%.*s' -- reason %u, rssi %d\n",
                info.wifi_sta_disconnected.ssid_len, info.wifi_sta_disconnected.ssid,
                info.wifi_sta_disconnected.reason, info.wifi_sta_disconnected.rssi);
            break;
        default:
            break;
    }
}

// FIFO ring for the continuously-streamed mono reference channel (TL). ~200ms of headroom so a
// brief stall in the network task doesn't drop samples outright.
RingBuffer audioRing(Config::kSampleRateHz / 5);
// TR's matching FIFO, added 2026-08-18 for kStereoAudioFrame (Config::kMicCount==4 only) -- always
// fed alongside audioRing (see captureTopTask below), same size, so the two never desync in how
// much backlog each can hold. Harmless/unused overhead on a node not actually sending stereo.
RingBuffer audioRingRight(Config::kSampleRateHz / 5);
// Bottom pair's own matching FIFOs, added 2026-08-20 for automatic top/bottom-pair fallback (see
// usingBottomPair below) -- fed unconditionally by captureBottomTask, same as
// audioRing/audioRingRight are by captureTopTask, so a fallback has ~200ms of already-buffered
// bottom-pair audio ready the instant it triggers, no cold-start gap. Harmless/unused overhead
// when the top pair is healthy and this never gets drained (RingBuffer::pushBlock just silently
// overwrites the oldest unread data on overflow, same as any other unread-but-fed ring).
RingBuffer audioRingBottomLeft(Config::kSampleRateHz / 5);
RingBuffer audioRingBottomRight(Config::kSampleRateHz / 5);

// Lookback rings for DOA windowing -- only need to hold slightly more than one analysis window
// plus scheduling jitter.
RingBuffer topLeftRing(Config::kDOAWindowSamples * 4);
RingBuffer topRightRing(Config::kDOAWindowSamples * 4);
RingBuffer bottomLeftRing(Config::kDOAWindowSamples * 4);
RingBuffer bottomRightRing(Config::kDOAWindowSamples * 4);

// Producer (captureTopTask) writes these before giving the semaphore; consumer (loop()) reads
// after taking it -- the semaphore itself is the synchronization, no extra mutex needed for
// this specific handoff (see header comment).
static int16_t capturedTopLeft[Config::kDOAWindowSamples];
static int16_t capturedTopRight[Config::kDOAWindowSamples];
static int16_t capturedBottomLeft[Config::kDOAWindowSamples];
static int16_t capturedBottomRight[Config::kDOAWindowSamples];
SemaphoreHandle_t doaCaptureRequested;

uint32_t audioSeq = 0;
uint32_t doaSeq = 0;
uint32_t timedOnsetSeq = 0;

// Onset -> loop() handoff for the GPS-PPS-disciplined TDOA timestamp (MULTI_NODE_TDOA_PLAN.md
// Phase 3). The capture task latches the sub-block crossing micros() here and raises the flag;
// loop() converts it through pps.utcForLocalMicros() and sends a kTimedOnset packet. Plain 32-bit
// volatiles, atomic on the ESP32 -- the doaCaptureRequested semaphore already orders this same
// producer/consumer handoff for the captured audio windows, and a rare torn read here would only
// cost one onset's TDOA timestamp, never corrupt anything.
volatile uint32_t gOnsetCrossingMicros = 0;
volatile bool gOnsetPending = false;

// Which pair is currently authoritative -- feeds the streamed stereo reference audio AND (as of
// 2026-08-20) the onset/DOA gate + azimuth math (see captureTopTask/captureBottomTask below).
// See Config::kAudioFallbackSilenceThreshold/kAudioFallbackSilenceIntervals for the decision
// logic, evaluated once per status interval in loop(). Volatile: written only by loop(), but now
// READ by both capture tasks too (to decide which one drives onset/DOA this iteration) -- a plain
// bool read is atomic on this architecture, same accepted single-writer/multi-reader risk profile
// as topLeftPeak/etc. below.
volatile bool usingBottomPair = false;

// Snapshot of the most recent onset event's per-band DOA results, printed once in the periodic
// 2-second status block instead of via a Serial0.printf() on every single onset event. That
// per-event-per-band printing was real-device-measured to be the dominant cost behind a severe
// audio-ring skip regression under Radar Mode (2+ simultaneous bands): Serial0.printf() blocks on
// UART backpressure, and with N bands active every onset event was blocking loop() N times in a
// row -- directly starving the classification audio ring buffer's drain rate. See
// RingBuffer::skippedSamples()'s doc comment for how that loss gets surfaced.
struct LastDOAResult {
    uint8_t bandId;
    float lowHz;
    float highHz;
    float azimuthDeg;
    float confidence;
};
static LastDOAResult lastDOAResults[Protocol::kMaxDOABands];
static int lastDOAResultCount = 0;

// Read success/failure counters, surfaced periodically in loop() -- captureTopTask/
// captureBottomTask previously swallowed readFrames() failures silently (just `continue`),
// unlike the standalone sync-test sketch that explicitly printed each timeout. Volatile: written
// from the capture tasks, read from loop()/the Arduino main task.
volatile uint32_t topReadOk = 0;
volatile uint32_t topReadFail = 0;
volatile uint32_t bottomReadOk = 0;
volatile uint32_t bottomReadFail = 0;

// Real-hardware finding 2026-08-18/20: onset (above) only ever processes TL (top-left) -- there
// was previously NO visibility at all into whether TR/BL/BR actually carry real audio, only
// whether their I2S reads succeed structurally (topReadOk/bottomReadOk, which say nothing about
// signal content -- a dead mic on an otherwise-fine bus reads back clean zeros forever, same as a
// healthy read of true silence). Added specifically to root-cause a real report: the recorded
// debug clip (TL-only) was silent, wiring "appeared fine" on inspection, and TL's own onset
// envelope had independently already been confirmed flat (0.0) for a full field session -- this
// closes the remaining "what about TR/BL/BR" gap without needing a second field capture.
// Peak-since-last-report per channel (not a running max since boot -- reset after each print, see
// loop() below, so a one-time transient doesn't make a since-dead channel look permanently alive).
// Not mutex-guarded, same accepted risk profile as topReadOk/etc. above (a torn read of a single
// volatile int16_t is not a real concern on this architecture, and this is a coarse diagnostic
// display, not correctness-critical state).
volatile int16_t topLeftPeak = 0;
volatile int16_t topRightPeak = 0;
volatile int16_t bottomLeftPeak = 0;
volatile int16_t bottomRightPeak = 0;

static void updatePeak(volatile int16_t &peak, const int16_t *block, int count) {
    for (int i = 0; i < count; i++) {
        // int32_t, not int16_t: abs(INT16_MIN) is 32768, one past int16_t's own positive range --
        // computing the magnitude in a wider type avoids signed-overflow UB on that specific value.
        int32_t magnitude = abs((int32_t)block[i]);
        if (magnitude > peak) peak = (int16_t)(magnitude > INT16_MAX ? INT16_MAX : magnitude);
    }
}

void captureTopTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!busTop.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            topReadFail++;
            continue;
        }
        topReadOk++;
        updatePeak(topLeftPeak, blockLeft, kReadBlockFrames);
        updatePeak(topRightPeak, blockRight, kReadBlockFrames);

        topLeftRing.pushBlock(blockLeft, kReadBlockFrames);
        topRightRing.pushBlock(blockRight, kReadBlockFrames);
        audioRing.pushBlock(blockLeft, kReadBlockFrames); // TL is the streamed reference channel
        audioRingRight.pushBlock(blockRight, kReadBlockFrames); // TR, for kStereoAudioFrame (see its declaration)

        // Real-hardware fix 2026-08-20: only the currently-authoritative pair drives onset/DOA --
        // `onset` is a single shared detector instance, so letting both capture tasks call
        // processBlock() concurrently would race its internal envelope/floor state. When the top
        // pair is known-dead (usingBottomPair), captureBottomTask below does this instead, and its
        // own results are computed via DOAEstimator::estimateSingleBus() (loop()), not this task's
        // capturedTopLeft/Right snapshot -- see that call site's comment for why a dead pair can't
        // just be included in the normal two-pair average.
        if (!usingBottomPair) {
            bool triggered = onset.processBlock(blockLeft, kReadBlockFrames, millis(), micros());
            if (triggered) {
                topLeftRing.snapshotRecent(capturedTopLeft, Config::kDOAWindowSamples);
                topRightRing.snapshotRecent(capturedTopRight, Config::kDOAWindowSamples);
                gOnsetCrossingMicros = onset.lastCrossingMicros();
                gOnsetPending = true;
                xSemaphoreGive(doaCaptureRequested);
            }
        }
    }
}

void captureBottomTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!busBottom.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            bottomReadFail++;
            continue;
        }
        bottomReadOk++;
        updatePeak(bottomLeftPeak, blockLeft, kReadBlockFrames);
        updatePeak(bottomRightPeak, blockRight, kReadBlockFrames);
        audioRingBottomLeft.pushBlock(blockLeft, kReadBlockFrames);
        audioRingBottomRight.pushBlock(blockRight, kReadBlockFrames);
        bottomLeftRing.pushBlock(blockLeft, kReadBlockFrames);
        bottomRightRing.pushBlock(blockRight, kReadBlockFrames);

        // Mirrors captureTopTask's own onset/DOA gating above, flipped -- see its comment. Only
        // runs once the top pair has been confirmed dead and usingBottomPair has switched.
        if (usingBottomPair) {
            bool triggered = onset.processBlock(blockLeft, kReadBlockFrames, millis(), micros());
            if (triggered) {
                bottomLeftRing.snapshotRecent(capturedBottomLeft, Config::kDOAWindowSamples);
                bottomRightRing.snapshotRecent(capturedBottomRight, Config::kDOAWindowSamples);
                gOnsetCrossingMicros = onset.lastCrossingMicros();
                gOnsetPending = true;
                xSemaphoreGive(doaCaptureRequested);
            }
        }
    }
}

void setup() {
    gRemoteLogger.attach(RealSerial0);
    Serial0.begin(115200);
    delay(1500); // let the host's terminal attach before the first print
    Serial0.println("[boot] checkpoint 1: Serial0 ready");

    if (Config::kBottomBusClockSlave) {
        // CONFIGURABLE_FLEET_PLAN.md Part C -- board reworked so bus 1's BCLK/WS are jumpered from
        // bus 0 (this firmware always wires both buses). Init both deferred, then enable the SLAVE
        // (bus 1) before the MASTER (bus 0) so it's armed when bus 0's first WS edge arrives.
        Serial0.println("[boot] checkpoint 2-5: 4-mic SYNCHRONOUS -- busBottom slaved to busTop's clock");
        bool okInitB = busBottom.begin(I2S_NUM_1, Config::kBottomBCLK, Config::kBottomWS, Config::kBottomBusDIN,
                                       Config::kSampleRateHz, I2S_ROLE_SLAVE, /*deferEnable=*/true);
        bool okInitT = busTop.begin(I2S_NUM_0, Config::kTopBCLK, Config::kTopWS, Config::kTopBusDIN,
                                    Config::kSampleRateHz, I2S_ROLE_MASTER, /*deferEnable=*/true);
        bool okEnB = busBottom.enable(); // slave first
        bool okEnT = busTop.enable();
        Serial0.printf("[boot] sync I2S: initB=%d initT=%d enB=%d enT=%d (offset const %ld)\n",
            okInitB, okInitT, okEnB, okEnT, (long)Config::kInterBusSampleOffset);
    } else {
        // Both buses are independent masters -- configure order doesn't matter, neither depends on
        // the other's clock.
        Serial0.println("[boot] checkpoint 2: starting busTop (I2S master)");
        if (!busTop.begin(I2S_NUM_0, Config::kTopBCLK, Config::kTopWS, Config::kTopBusDIN, Config::kSampleRateHz)) {
            Serial0.println("[boot] Top bus init failed");
        } else {
            Serial0.println("[boot] checkpoint 3: busTop ready");
        }

        Serial0.println("[boot] checkpoint 4: starting busBottom (I2S master, independent clock)");
        if (!busBottom.begin(I2S_NUM_1, Config::kBottomBCLK, Config::kBottomWS, Config::kBottomBusDIN, Config::kSampleRateHz)) {
            Serial0.println("[boot] Bottom bus init failed");
        } else {
            Serial0.println("[boot] checkpoint 5: busBottom ready");
        }
    }

    // Load the runtime Wi-Fi/AP/role config (NVS over Config.h defaults) BEFORE any Wi-Fi bring-up.
    {
        WiFiConfigStore::Defaults d;
        d.role = Config::kNetworkRole;
        d.apSsid = Config::kWiFiSSID;
        // Per-chip default AP password unless disabled -- see Config::kUseDerivedApPassword.
        static char derivedApPw[16];
        {
            uint8_t did[6];
            WiFiConfigStore::deviceIdFromEfuseMac(ESP.getEfuseMac(), did);
            WiFiConfigStore::deriveDefaultApPassword(did, derivedApPw, sizeof(derivedApPw));
        }
        d.apPassword = Config::kUseDerivedApPassword ? derivedApPw : Config::kWiFiPassword;
        d.apChannel = (uint8_t)Config::kWiFiChannel;
        d.isRosterMaster = Config::kIsRosterMaster;
        static WiFiConfigStore::Credential defCands[WiFiConfigStore::kMaxCandidates];
        const int defCount = sizeof(Config::kWiFiCandidates) / sizeof(Config::kWiFiCandidates[0]);
        uint8_t n = 0;
        for (int i = 0; i < defCount && n < WiFiConfigStore::kMaxCandidates; i++) {
            defCands[n].ssid = Config::kWiFiCandidates[i].ssid;
            defCands[n].password = Config::kWiFiCandidates[i].password;
            n++;
        }
        d.candidates = defCands;
        d.candidateCount = n;
        gWiFiConfig.begin(d);
        Serial0.printf("[boot] wifi config %s (role=%u, %u candidate(s))%s\n",
            gWiFiConfig.isCustomised() ? "loaded from NVS" : "using Config.h defaults",
            (unsigned)gWiFiConfig.role(), (unsigned)gWiFiConfig.candidateCount(),
            gWiFiConfig.awaitingProof() ? " [recovery arm SET -- unproven]" : "");
        if (!gWiFiConfig.isCustomised() && gWiFiConfig.role() != Config::kRoleClient) {
            Serial0.printf("[boot] AP password (per-chip default): %s  -- change it from the app\n", gWiFiConfig.apPassword());
        }
    }

    if (Config::kDiagnosticDisableWiFi) {
        Serial0.println("[boot] checkpoint 6: kDiagnosticDisableWiFi=true -- skipping WiFi/network entirely");
        Serial0.println("[boot] checkpoint 7: (no AP, no UDP -- audio/DOA telemetry only visible via [doa]/[onset] prints)");
    } else {
        // See Config::kNetworkRole / FLEET_NETWORK_PARTICIPATION_PLAN.md (repo root) -- Primary
        // (the default, unchanged from before this role system existed) hosts its own AP, Client
        // joins a network as a station instead (typically a camera node's own fleet AP).
        bool isPrimary = (gWiFiConfig.role() == Config::kRolePrimary);
        Serial0.printf("[boot] checkpoint 6: %s WiFi (%s)...\n", isPrimary ? "hosting" : "joining", isPrimary ? "AP" : "STA");
        WiFi.onEvent(onWiFiEvent); // see onWiFiEvent's own doc comment -- registered before the
                                    // first network.begin() so it catches a cold-boot AP promotion too
        if (!network.begin(gWiFiConfig)) {
            Serial0.println(isPrimary
                ? "[boot] AP hosting failed -- check the AP SSID/password (>=8 chars) and kMaxAPStations"
                : "[boot] WiFi join failed/timed out -- check the configured candidate list");
        } else {
            // Real bug found 2026-08-18: this was `isPrimary ? softAPIP() : localIP()` -- correct
            // for kRolePrimary/kRoleClient, but wrong for a kRoleSecondary that had no candidate to
            // join at cold boot and immediately fell back to hosting its own AP (begin()'s
            // "promoting immediately" path): `isPrimary` is false there too, so this printed
            // localIP() -- 0.0.0.0, since it was never actually a STA client of anything -- instead
            // of the AP address a user would actually need to manually enter. `isCurrentlyHosting()`
            // covers both real "am I hosting" cases; `isPrimary` alone only covered one of them.
            bool isHosting = network.isCurrentlyHosting();
            IPAddress myIP = isHosting ? WiFi.softAPIP() : WiFi.localIP();
            Serial0.printf("[boot] checkpoint 7: WiFi %s, IP %s -- enter this in the app's node Network Address field\n", isHosting ? "AP up" : "joined", myIP.toString().c_str());
            if (isHosting) {
                // For any Secondary node's Config::kPrimaryBSSID (MIC_ARRAY_MASTER_AP_PLAN.md §4)
                // -- read this and hardcode it into the Secondary's own Config.h before relying on
                // failover in the field.
                Serial0.printf("[boot] AP BSSID (for a Secondary's kPrimaryBSSID): %s\n", WiFi.softAPmacAddress().c_str());
            }
        }
        // BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17 -- skipped alongside WiFi under
        // kDiagnosticDisableWiFi since the whole point of that flag is testing for zero radio
        // activity at all (see its own comment); BLE is a second, separate radio that would
        // reintroduce exactly the kind of interference that diagnostic mode exists to rule out.
        bleAdvertiser.begin();
        if (Config::kBleProvisioningEnabled) {
            bleAdvertiser.enableProvisioning(gWiFiConfig); // CONFIGURABLE_FLEET_PLAN.md -- BLE-GATT Wi-Fi provisioning
        }
        Serial0.println("[boot] checkpoint 7a: BLE advertising ready (event-gated -- silent while a client is registered)");
    }

    // Ported 2026-08-14 from ../PeregrineMicArrayCam -- see Config.h's GPS section.
    if (Config::kGPSEnabled) {
        Serial0.println("[boot] checkpoint 8: starting GPS UART");
        gps.begin(Serial1, Config::kGPSRXPin, Config::kGPSTXPin, Config::kGPSBaud, Config::kGPSUARTRxBufferBytes);
    } else {
        Serial0.println("[boot] checkpoint 8: kGPSEnabled=false -- skipping GPS entirely");
    }

    if (Config::kPPSEnabled) {
        Serial0.println("[boot] checkpoint 8a: attaching GPS PPS interrupt");
        pps.begin(Config::kPPSPin);
    }

    if (Config::kCompassEnabled) {
        Serial0.println("[boot] checkpoint 8b: starting BNO055 compass over I2C");
        if (!compass.begin(Config::kCompassSDAPin, Config::kCompassSCLPin)) {
            Serial0.println("[boot] BNO055 init failed -- heading will be unavailable this boot");
        }
    } else {
        Serial0.println("[boot] checkpoint 8b: kCompassEnabled=false -- skipping compass entirely");
    }

    doaCaptureRequested = xSemaphoreCreateBinary();

    xTaskCreatePinnedToCore(captureTopTask, "captureTop", 4096, NULL, 2, NULL, 0);
    xTaskCreatePinnedToCore(captureBottomTask, "captureBottom", 4096, NULL, 2, NULL, 1);
    Serial0.println("[boot] checkpoint 9: capture tasks started, entering loop()");
}

void loop() {
    uint32_t now = millis();

    if (!Config::kDiagnosticDisableWiFi) {
        network.poll();
        network.pollFailover(); // no-op unless effective role == kRoleSecondary
        network.pollReconnect(); // no-op unless effective role == kRoleClient -- WIFI_MULTI_SSID_FALLBACK_PLAN.md Phase 2
        pollConfigRecovery();   // rolls back an unproven committed Wi-Fi config -- CONFIGURABLE_FLEET_PLAN.md Part A

        // FIELD_DEBUG_PLAN.md, added 2026-08-18 -- drains whatever Serial0 lines accumulated since
        // the last poll() into kLogLine packets (no-op if remote logging isn't enabled, see
        // RemoteLogger's own gating), and applies the phone's kSetRemoteLogging toggle if one
        // arrived.
        gRemoteLogger.poll(network);
        bool remoteLoggingEnabled;
        if (network.consumeSetRemoteLoggingRequest(remoteLoggingEnabled)) {
            gRemoteLogger.setEnabled(remoteLoggingEnabled);
        }

        // BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17 -- event-gated: only ever advertising while
        // network.isStreaming() is false (no registered phone client), so BLE is silent for the
        // entire duration of an established session. WiFi.softAPIP() vs WiFi.localIP() mirrors the
        // exact same isCurrentlyHosting() branch setup() already uses for its own boot-log IP print.
        IPAddress currentIP = network.isCurrentlyHosting() ? WiFi.softAPIP() : WiFi.localIP();
        bleAdvertiser.poll(network.isStreaming(), currentIP);
        bleAdvertiser.pollProvisioning(); // applies any Wi-Fi config the phone wrote over BLE-GATT; reboots on commit
    }

    if (!Config::kDiagnosticDisableWiFi) {
        // Added 2026-08-12, see FLEET_NETWORK_PARTICIPATION_PLAN.md -- mirrors
        // ../PeregrineMicArrayCam/PeregrineMicArrayCam.ino's identical placement/reasoning.
        static uint32_t lastIdentityMs = 0;
        if (now - lastIdentityMs >= Config::kNodeIdentityIntervalMs) {
            lastIdentityMs = now;
            network.sendNodeIdentity();
        }

        // Peer-to-peer roster discovery -- unlike sendNodeIdentity() above, not gated on a phone
        // session existing (it's a LAN broadcast to sibling nodes). Skipped whenever THIS node is
        // CURRENTLY acting as roster master (isActingAsRosterMaster() -- hosting the AP, always
        // true for Primary/a failed-over Secondary, OR explicitly designated via
        // Config::kIsRosterMaster as of 2026-08-16 for an all-kRoleClient shared-network setup) --
        // a master node already knows its own identity without needing to hear its own broadcast,
        // and sendNodeAnnounce()'s broadcast-address computation is only meaningful while
        // genuinely STA-joined to something anyway.
        static uint32_t lastAnnounceMs = 0;
        if (!network.isActingAsRosterMaster() && now - lastAnnounceMs >= Config::kNodeAnnounceIntervalMs) {
            lastAnnounceMs = now;
            network.sendNodeAnnounce();
        }

        // Ported 2026-08-14 from ../PeregrineMicArrayCam -- independent of WiFi role/mode, so
        // inside this kDiagnosticDisableWiFi guard only because sendGPSPosition() needs a
        // registered phone client the same way every other send* call here does.
        if (Config::kGPSEnabled) {
            static uint32_t lastGPSReportMs = 0;
            if (now - lastGPSReportMs >= Config::kGPSReportIntervalMs) {
                lastGPSReportMs = now;
                network.sendGPSPosition(
                    now, gps.latitude(), gps.longitude(), gps.horizontalAccuracyMeters(), gps.hasFix(),
                    (uint8_t)gps.satellitesInView(), gps.charsProcessed(), gps.sentencesWithValidChecksum(),
                    gps.sentencesWithInvalidChecksum(), pps.edgeCount(), pps.lastIntervalMicros()
                );
            }
        }

        // COMPASS_HEADING_HARDWARE_PLAN.md -- same "needs a registered phone client" reasoning as
        // sendGPSPosition() above. compass.poll() is internally rate-limited to
        // Config::kCompassReportIntervalMs and only returns true on a fresh reading.
        if (Config::kCompassEnabled && compass.poll(now)) {
            network.sendCompassHeading(now, compass.headingDeg());
        network.sendOrientation(now, compass.gravity(), compass.magnetic(), compass.packedCalibration());
        }
    }

    if (Config::kGPSEnabled) {
        gps.poll();
        // MULTI_NODE_TDOA_PLAN.md Phase 1: anchor a UTC second to the most recent PPS edge whenever
        // a fresh GPS time has been parsed. utcSecondOfDay() clears the "fresh" flag.
        if (Config::kPPSEnabled && gps.timeFresh() && gps.timeValid()) {
            pps.bindUtcSecond(gps.utcSecondOfDay());
        }
    }

    // Drain the mono audio ring, accumulating partial reads ACROSS loop() iterations until a full
    // packet's worth is ready -- NOT assuming a single popAvailable() call will happen to return
    // exactly kAudioSamplesPerPacket. Real-device testing showed that assumption failing badly:
    // popAvailable() drains whatever's ready right now, not "waits for a full chunk," so once
    // loop() iterates fast relative to the ~10ms it takes to produce one packet's worth of real
    // audio (441 samples @ 44.1kHz), most individual calls return a small partial count and the
    // old strict `available == kAudioSamplesPerPacket` check almost never fired -- audio packets
    // were only sent on the rare iteration that happened to catch a large-enough backlog in one
    // call (~3.6/sec measured on real hardware, not the intended ~100/sec), even though the ring
    // itself never overflowed (draining in tiny dribbles is still draining, from the ring's own
    // point of view).
    // Stereo (Config::kMicCount==4) and mono (kMicCount==2) are mutually exclusive -- a node sends
    // one or the other, never both (see NetworkProtocol.h's AudioFrameHeader comment). Both drain
    // the exact same audioRing (TL) the mono path always has; stereo additionally drains
    // audioRingRight (TR), fed in lockstep by captureTopTask every block.
    if (Config::kMicCount == 4) {
        static int16_t stereoLeftAccum[Config::kStereoAudioSamplesPerChannel];
        static int16_t stereoRightAccum[Config::kStereoAudioSamplesPerChannel];
        static int stereoAccumCount = 0;
        // Real-hardware finding 2026-08-18/20 -- top pair confirmed completely silent (see
        // Config::kAudioFallbackSilenceThreshold's comment). usingBottomPair (updated once
        // per status interval below) picks which pair's already-buffered rings to drain here --
        // a torn packet mixing both pairs' samples is possible on the exact iteration a fallback
        // triggers mid-accumulation, a rare (once per ~10s streak minimum) and harmless cosmetic
        // glitch, not worth adding cross-iteration state to prevent.
        RingBuffer &leftSource = usingBottomPair ? audioRingBottomLeft : audioRing;
        RingBuffer &rightSource = usingBottomPair ? audioRingBottomRight : audioRingRight;
        int remaining = Config::kStereoAudioSamplesPerChannel - stereoAccumCount;
        int gotLeft = leftSource.popAvailable(stereoLeftAccum + stereoAccumCount, remaining);
        int gotRight = rightSource.popAvailable(stereoRightAccum + stereoAccumCount, remaining);
        // The selected pair's two rings are pushed together every single block (same call site,
        // same count), so gotLeft should always equal gotRight -- min() is a defensive guard, not
        // an expected path, against the two ever silently drifting apart rather than corrupting
        // the L/R interleave with mismatched channel data.
        int got = (gotLeft < gotRight) ? gotLeft : gotRight;
        stereoAccumCount += got;
        if (stereoAccumCount == Config::kStereoAudioSamplesPerChannel) {
            network.sendStereoAudioFrame(audioSeq++, stereoLeftAccum, stereoRightAccum, stereoAccumCount);
            stereoAccumCount = 0;
        }
    } else {
        static int16_t audioAccumulator[Config::kAudioSamplesPerPacket];
        static int audioAccumulatedCount = 0;
        audioAccumulatedCount += audioRing.popAvailable(
            audioAccumulator + audioAccumulatedCount, Config::kAudioSamplesPerPacket - audioAccumulatedCount
        );
        if (audioAccumulatedCount == Config::kAudioSamplesPerPacket) {
            network.sendAudioFrame(audioSeq++, audioAccumulator, audioAccumulatedCount);
            audioAccumulatedCount = 0;
        }
    }

    // Non-blocking check for a completed DOA capture handoff from whichever capture task is
    // currently authoritative (captureTopTask normally, captureBottomTask once usingBottomPair
    // has switched -- see both tasks' own onset-gating comments). Runs DOAEstimator::estimate()
    // once per phone-requested frequency band (see UDPStreamer's activeBands_) against the SAME
    // captured window(s), so multiple simultaneous callers in different frequency ranges can each
    // get their own azimuth from one onset event. With no bands set (the default), falls back to a
    // single full-spectrum estimate at bandId 0 -- exactly the original single-reading behavior.
    // Results are stashed into lastDOAResults and printed once per periodic status interval below,
    // NOT here -- see that array's doc comment for why printing per onset event per band was a
    // real, measured problem.
    if (xSemaphoreTake(doaCaptureRequested, 0) == pdTRUE) {
        // Real-hardware finding 2026-08-18/20: DOAEstimator::estimate()'s cross-pair average is
        // NOT graceful about a known-dead pair -- a silent channel's cross-correlation is exactly
        // 0 at every lag, so pairDelay() always picks the same (bogus, extreme) lag for it, and
        // blending that into the average systematically biases every azimuth reading, not just
        // lowering confidence. estimateSingleBus() (already built for Cam's 2-mic single-bus mode,
        // ported here) uses ONLY the bottom pair's own math instead, with no averaging against a
        // pair we already know is silent. Top's captured window isn't even needed in that case.
        if (!usingBottomPair) {
            bottomLeftRing.snapshotRecent(capturedBottomLeft, Config::kDOAWindowSamples);
            bottomRightRing.snapshotRecent(capturedBottomRight, Config::kDOAWindowSamples);
        }

        int bandCount = network.activeBandCount();
        if (bandCount == 0) {
            DOAResult result = usingBottomPair
                ? DOAEstimator::estimateSingleBus(capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples, 0, 0)
                : DOAEstimator::estimate(capturedTopLeft, capturedTopRight, capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples, 0, 0);
            network.sendDOATelemetry(doaSeq++, millis(), result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), 0);
            lastDOAResults[0] = {0, 0, 0, result.azimuthDeg, result.confidence};
            lastDOAResultCount = 1;
        } else {
            lastDOAResultCount = bandCount;
            for (int i = 0; i < bandCount; i++) {
                const Protocol::FrequencyBandSlot &band = network.activeBand(i);
                DOAResult result = usingBottomPair
                    ? DOAEstimator::estimateSingleBus(capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples, band.lowHz, band.highHz)
                    : DOAEstimator::estimate(capturedTopLeft, capturedTopRight, capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples, band.lowHz, band.highHz);
                network.sendDOATelemetry(doaSeq++, millis(), result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), band.bandId);
                lastDOAResults[i] = {band.bandId, band.lowHz, band.highHz, result.azimuthDeg, result.confidence};
            }
        }

        // GPS-PPS-disciplined onset timestamp for multi-node TDOA (MULTI_NODE_TDOA_PLAN.md
        // Phase 3). Sent alongside the DOA telemetry above, for the same event -- the capture task
        // latched the sub-block crossing micros() in gOnsetCrossingMicros. Skipped silently when
        // the clock isn't anchored (no PPS edge + parsed GPS time yet): this node just doesn't
        // participate in TDOA this session, bearing-only still works.
        if (gOnsetPending) {
            gOnsetPending = false;
            PPSReader::UtcMicros t = pps.utcForLocalMicros(gOnsetCrossingMicros);
            if (t.valid) {
                float conf = (lastDOAResultCount > 0) ? lastDOAResults[0].confidence : 0.0f;
                network.sendTimedOnset(timedOnsetSeq++, t.second, t.micros, 0, onset.lastRelativeLevel(), conf);
            }
        }
    }

    // Periodic read-health summary -- captureTopTask/captureBottomTask no longer swallow
    // readFrames() failures silently. Both buses are independent masters now, so a failing bus
    // usually just means a wiring/pin problem on that specific bus (check its own BCLK/WS/SD
    // connections), not a cross-bus sync issue.
    // `now` reused from loop()'s top -- no longer re-fetched here (was `uint32_t now = millis();`
    // before the identity/announce block above was added 2026-08-12, which would have made this a
    // duplicate declaration in the same scope).
    static uint32_t lastStatusMs = 0;
    if (now - lastStatusMs >= 2000) {
        lastStatusMs = now;
        Serial0.printf(
            "[status] top: %lu ok / %lu fail   bottom: %lu ok / %lu fail\n",
            (unsigned long)topReadOk, (unsigned long)topReadFail,
            (unsigned long)bottomReadOk, (unsigned long)bottomReadFail
        );
        // Real-hardware diagnostic added 2026-08-20 -- see topLeftPeak's own declaration comment
        // for the full "why" (onset only ever reflects TL; this is the first visibility into
        // whether TR/BL/BR carry real audio at all). Peak absolute sample value seen since the
        // last report, per channel -- make noise near the array and watch which numbers actually
        // move; a channel that stays near 0 despite real noise nearby is the dead one. Reset after
        // each print so this always reflects "since the last ~2s," not "ever since boot."
        Serial0.printf(
            "[levels] TL: %d  TR: %d  BL: %d  BR: %d\n",
            topLeftPeak, topRightPeak, bottomLeftPeak, bottomRightPeak
        );

        // Automatic top/bottom-pair fallback + phone-visible level telemetry, kMicCount==4 only --
        // see Config::kAudioFallbackSilenceThreshold's comment for the real-hardware finding this
        // exists for. A 2-mic node has only one pair to begin with, nothing to fall back to.
        if (Config::kMicCount == 4) {
            int16_t topPairPeak = (topLeftPeak > topRightPeak) ? topLeftPeak : topRightPeak;
            int16_t bottomPairPeak = (bottomLeftPeak > bottomRightPeak) ? bottomLeftPeak : bottomRightPeak;

            static int topSilentStreak = 0;
            static int bottomSilentStreak = 0;
            topSilentStreak = (topPairPeak < Config::kAudioFallbackSilenceThreshold) ? topSilentStreak + 1 : 0;
            bottomSilentStreak = (bottomPairPeak < Config::kAudioFallbackSilenceThreshold) ? bottomSilentStreak + 1 : 0;

            if (!usingBottomPair
                && topSilentStreak >= Config::kAudioFallbackSilenceIntervals
                && bottomSilentStreak < Config::kAudioFallbackSilenceIntervals) {
                usingBottomPair = true;
                Serial0.println("[audio-fallback] top pair silent, bottom pair alive -- streaming reference audio + onset/DOA now from bottom pair instead");
            } else if (usingBottomPair
                && bottomSilentStreak >= Config::kAudioFallbackSilenceIntervals
                && topSilentStreak < Config::kAudioFallbackSilenceIntervals) {
                usingBottomPair = false;
                Serial0.println("[audio-fallback] bottom pair silent, top pair alive -- streaming reference audio + onset/DOA back on top pair");
            }

            network.sendAudioLevels(now, topLeftPeak, topRightPeak, bottomLeftPeak, bottomRightPeak, usingBottomPair);
        }

        topLeftPeak = 0;
        topRightPeak = 0;
        bottomLeftPeak = 0;
        bottomRightPeak = 0;
        // Direct measurement of whether loop() is keeping up with draining the continuously-
        // streamed classification audio -- topReadOk/bottomReadFail above only cover whether the
        // I2S DMA read itself succeeded, which says nothing about whether this ring's consumer
        // (this same loop()) is being serviced often enough. A climbing count here means real
        // audio discontinuities are reaching the phone's classifier; compare this specifically
        // with Radar Mode on vs. off (see RingBuffer::skippedSamples()'s doc comment).
        Serial0.printf("[audio-ring] skipped: %lu samples\n", (unsigned long)audioRing.skippedSamples());
        // Snapshot of the most recent onset event's DOA result(s) -- see lastDOAResults' doc
        // comment for why this is printed here (once per status interval) instead of once per
        // onset event per band, as it was originally.
        for (int i = 0; i < lastDOAResultCount; i++) {
            const LastDOAResult &r = lastDOAResults[i];
            if (r.bandId == 0 && r.lowHz == 0 && r.highHz == 0) {
                Serial0.printf("[doa] band 0 (full spectrum)  azimuth: %.1f  confidence: %.2f  level: %.1f\n", r.azimuthDeg, r.confidence, onset.lastRelativeLevel());
            } else {
                Serial0.printf("[doa] band %u (%.0f-%.0f Hz)  azimuth: %.1f  confidence: %.2f  level: %.1f\n",
                    r.bandId, r.lowHz, r.highHz, r.azimuthDeg, r.confidence, onset.lastRelativeLevel());
            }
        }
        // Direct visibility into the onset gate's internal state -- a real-device report showed
        // DOA events firing right after boot and then apparently never again, even for a clap
        // that should be an obvious transient. This shows exactly why: is the fast envelope
        // (current block loudness) actually reaching `threshold` (floor * kOnsetTriggerRatio), or
        // is the adaptive floor itself sitting implausibly high?
        Serial0.printf(
            "[onset] fast: %.1f  floor: %.1f  threshold: %.1f  outliers_rejected: %lu\n",
            onset.currentFastEnvelope(), onset.currentSlowFloor(), onset.currentThreshold(),
            (unsigned long)onset.outlierRejectedCount()
        );
        // Visibility into the phone-controlled DOA frequency bands (see UDPStreamer's
        // kSetFrequencyBands handling / DOAEstimator::estimate()) -- lets you confirm on the
        // Serial Monitor that tracking/radar mode in the app actually narrowed these, without
        // needing to instrument the app side to check.
        if (network.activeBandCount() == 0) {
            Serial0.println("[doa-band] full spectrum (no bands set)");
        } else {
            for (int i = 0; i < network.activeBandCount(); i++) {
                const Protocol::FrequencyBandSlot &band = network.activeBand(i);
                Serial0.printf("[doa-band] id %u: %.0f - %.0f Hz\n", band.bandId, band.lowHz, band.highHz);
            }
        }
        // Ported 2026-08-14 from ../PeregrineMicArrayCam -- see GPSReader.h's doc comment on how
        // to read charsProcessed/validChecksum/invalidChecksum together to tell a wiring/baud
        // problem apart from a genuine still-acquiring-fix state.
        if (Config::kGPSEnabled) {
            Serial0.printf("[gps] fix: %s  lat: %.6f  lon: %.6f\n", gps.hasFix() ? "yes" : "no", gps.latitude(), gps.longitude());
            Serial0.printf("[gps-link] chars: %lu  valid sentences: %lu  invalid: %lu  satellites: %d  max poll gap: %lu ms\n",
                (unsigned long)gps.charsProcessed(), (unsigned long)gps.sentencesWithValidChecksum(),
                (unsigned long)gps.sentencesWithInvalidChecksum(), gps.satellitesInView(),
                (unsigned long)gps.maxPollGapMs());
        }
        if (Config::kPPSEnabled) {
            Serial0.printf("[pps] edges: %lu  interval us: last %lu  min %lu  max %lu  meanAbsDev %lu  (n=%lu)\n",
                (unsigned long)pps.edgeCount(), (unsigned long)pps.lastIntervalMicros(),
                (unsigned long)pps.minIntervalMicros(), (unsigned long)pps.maxIntervalMicros(),
                (unsigned long)pps.meanAbsDevMicros(), (unsigned long)pps.intervalSampleCount());
            // MULTI_NODE_TDOA_PLAN.md Phase 1: the disciplined local->UTC clock. Once anchored,
            // `utc` should track real wall-clock time; a constant whole-second offset is harmless
            // for relative TDOA (see PPSReader::bindUtcSecond's comment).
            PPSReader::UtcMicros nowUtc = pps.utcForLocalMicros(micros());
            if (nowUtc.valid) {
                Serial0.printf("[clock] utc: %lu.%06lu  anchorAge: %lu ms\n",
                    (unsigned long)nowUtc.second, (unsigned long)nowUtc.micros,
                    (unsigned long)pps.anchorAgeMillis());
            } else {
                Serial0.println("[clock] utc: not anchored (need a PPS edge + a parsed GPS time)");
            }
        }
    }
}
