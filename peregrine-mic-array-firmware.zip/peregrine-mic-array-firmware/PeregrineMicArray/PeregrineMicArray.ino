#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>

// PeregrineMicArray — ESP32-S3 4x INMP441 direction-finding firmware for Peregrine Planner.
// See README.md for wiring, board settings, and calibration steps. See ../../PHASE 7 plan doc
// (repo root, MIC_ARRAY plan) for the full architecture writeup this implements.
//
// Square array (TL, TR, BL, BR): bus 0 (top pair) and bus 1 (bottom pair) are two INDEPENDENT
// I2S masters, each with their own separate BCLK/WS pins -- not sample-synchronized with each
// other. See Config.h's header comment for why: true cross-bus sync (one master, one slave
// reading the same clock) was tried via several different strategies and never worked reliably
// on this hardware despite exhausting the documented ESP-IDF configuration space. The real,
// accepted cost of this simpler design is that azimuth is left-right only, not full 360 degrees -- see
// DOAEstimator.h.
//
// TL's channel doubles as the continuously-streamed mono reference for the phone's species-ID
// pipeline (like before, just renamed from the earlier "M0" naming). The onset/energy gate also
// runs on TL; when it fires, the most recent analysis window from all 4 channels is snapshotted
// and run through DOAEstimator to produce one azimuth+confidence reading.
//
// Uses Serial0 (UART), not Serial (native USB CDC) -- confirmed on real hardware that this
// board's native-USB Serial object silently produces no output after the app's own Serial.begin()
// re-initializes the USB peripheral (a host-side reconnection issue), while Serial0 works reliably.

#include <WiFi.h>
#include "Config.h"
#include "NetworkProtocol.h"
#include "RingBuffer.h"
#include "I2SCapture.h"
#include "OnsetDetector.h"
#include "DOAEstimator.h"
#include "UDPStreamer.h"

// Block size for each I2S read -- small enough to keep the onset gate responsive (~5.8ms at
// 44.1kHz), large enough to not thrash the I2S DMA with tiny reads.
static const int kReadBlockFrames = 256;

I2SBus busTop;    // I2S_NUM_0, independent master -- TL (left-select) / TR (right-select)
I2SBus busBottom; // I2S_NUM_1, independent master -- BL (left-select) / BR (right-select)
UDPStreamer network;
OnsetDetector onset;

// FIFO ring for the continuously-streamed mono reference channel (TL). ~200ms of headroom so a
// brief stall in the network task doesn't drop samples outright.
RingBuffer audioRing(Config::kSampleRateHz / 5);

// Lookback rings for DOA windowing -- only need to hold slightly more than one analysis window
// plus scheduling jitter.
RingBuffer topLeftRing(Config::kDOAWindowSamples * 4);
RingBuffer topRightRing(Config::kDOAWindowSamples * 4);
RingBuffer bottomLeftRing(Config::kDOAWindowSamples * 4);
RingBuffer bottomRightRing(Config::kDOAWindowSamples * 4);

// Producer (captureTopTask) writes these before giving the semaphore; consumer (loop()) reads
// after taking it -- the semaphore itself is the synchronization, no extra mutex needed for
// this specific handoff (see header comment).
static int16_t capturedTopLeft[Config::kDOAWindowSamples];
static int16_t capturedTopRight[Config::kDOAWindowSamples];
static int16_t capturedBottomLeft[Config::kDOAWindowSamples];
static int16_t capturedBottomRight[Config::kDOAWindowSamples];
SemaphoreHandle_t doaCaptureRequested;

uint32_t audioSeq = 0;
uint32_t doaSeq = 0;

// Snapshot of the most recent onset event's per-band DOA results, printed once in the periodic
// 2-second status block instead of via a Serial0.printf() on every single onset event. That
// per-event-per-band printing was real-device-measured to be the dominant cost behind a severe
// audio-ring skip regression under Radar Mode (2+ simultaneous bands): Serial0.printf() blocks on
// UART backpressure, and with N bands active every onset event was blocking loop() N times in a
// row -- directly starving the classification audio ring buffer's drain rate. See
// RingBuffer::skippedSamples()'s doc comment for how that loss gets surfaced.
struct LastDOAResult {
    uint8_t bandId;
    float lowHz;
    float highHz;
    float azimuthDeg;
    float confidence;
};
static LastDOAResult lastDOAResults[Protocol::kMaxDOABands];
static int lastDOAResultCount = 0;

// Read success/failure counters, surfaced periodically in loop() -- captureTopTask/
// captureBottomTask previously swallowed readFrames() failures silently (just `continue`),
// unlike the standalone sync-test sketch that explicitly printed each timeout. Volatile: written
// from the capture tasks, read from loop()/the Arduino main task.
volatile uint32_t topReadOk = 0;
volatile uint32_t topReadFail = 0;
volatile uint32_t bottomReadOk = 0;
volatile uint32_t bottomReadFail = 0;

void captureTopTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!busTop.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            topReadFail++;
            continue;
        }
        topReadOk++;

        topLeftRing.pushBlock(blockLeft, kReadBlockFrames);
        topRightRing.pushBlock(blockRight, kReadBlockFrames);
        audioRing.pushBlock(blockLeft, kReadBlockFrames); // TL is the streamed reference channel

        bool triggered = onset.processBlock(blockLeft, kReadBlockFrames, millis());
        if (triggered) {
            topLeftRing.snapshotRecent(capturedTopLeft, Config::kDOAWindowSamples);
            topRightRing.snapshotRecent(capturedTopRight, Config::kDOAWindowSamples);
            xSemaphoreGive(doaCaptureRequested);
        }
    }
}

void captureBottomTask(void *parameter) {
    int16_t blockLeft[kReadBlockFrames];
    int16_t blockRight[kReadBlockFrames];

    for (;;) {
        if (!busBottom.readFrames(blockLeft, blockRight, kReadBlockFrames)) {
            bottomReadFail++;
            continue;
        }
        bottomReadOk++;
        bottomLeftRing.pushBlock(blockLeft, kReadBlockFrames);
        bottomRightRing.pushBlock(blockRight, kReadBlockFrames);
    }
}

void setup() {
    Serial0.begin(115200);
    delay(1500); // let the host's terminal attach before the first print
    Serial0.println("[boot] checkpoint 1: Serial0 ready");

    // Both buses are independent masters now -- configure order doesn't matter, neither depends
    // on the other's clock.
    Serial0.println("[boot] checkpoint 2: starting busTop (I2S master)");
    if (!busTop.begin(I2S_NUM_0, Config::kTopBCLK, Config::kTopWS, Config::kTopBusDIN, Config::kSampleRateHz)) {
        Serial0.println("[boot] Top bus init failed");
    } else {
        Serial0.println("[boot] checkpoint 3: busTop ready");
    }

    Serial0.println("[boot] checkpoint 4: starting busBottom (I2S master, independent clock)");
    if (!busBottom.begin(I2S_NUM_1, Config::kBottomBCLK, Config::kBottomWS, Config::kBottomBusDIN, Config::kSampleRateHz)) {
        Serial0.println("[boot] Bottom bus init failed");
    } else {
        Serial0.println("[boot] checkpoint 5: busBottom ready");
    }

    if (Config::kDiagnosticDisableWiFi) {
        Serial0.println("[boot] checkpoint 6: kDiagnosticDisableWiFi=true -- skipping WiFi/network entirely");
        Serial0.println("[boot] checkpoint 7: (no AP, no UDP -- audio/DOA telemetry only visible via [doa]/[onset] prints)");
    } else {
        Serial0.println("[boot] checkpoint 6: starting network.begin() (WiFi SoftAP + UDP)");
        network.begin();
        Serial0.printf("[boot] checkpoint 7: AP '%s' up, gateway %s\n", Config::kWiFiSSID, WiFi.softAPIP().toString().c_str());
    }

    doaCaptureRequested = xSemaphoreCreateBinary();

    xTaskCreatePinnedToCore(captureTopTask, "captureTop", 4096, NULL, 2, NULL, 0);
    xTaskCreatePinnedToCore(captureBottomTask, "captureBottom", 4096, NULL, 2, NULL, 1);
    Serial0.println("[boot] checkpoint 8: capture tasks started, entering loop()");
}

void loop() {
    if (!Config::kDiagnosticDisableWiFi) network.poll();

    // Drain the mono audio ring, accumulating partial reads ACROSS loop() iterations until a full
    // packet's worth is ready -- NOT assuming a single popAvailable() call will happen to return
    // exactly kAudioSamplesPerPacket. Real-device testing showed that assumption failing badly:
    // popAvailable() drains whatever's ready right now, not "waits for a full chunk," so once
    // loop() iterates fast relative to the ~10ms it takes to produce one packet's worth of real
    // audio (441 samples @ 44.1kHz), most individual calls return a small partial count and the
    // old strict `available == kAudioSamplesPerPacket` check almost never fired -- audio packets
    // were only sent on the rare iteration that happened to catch a large-enough backlog in one
    // call (~3.6/sec measured on real hardware, not the intended ~100/sec), even though the ring
    // itself never overflowed (draining in tiny dribbles is still draining, from the ring's own
    // point of view).
    static int16_t audioAccumulator[Config::kAudioSamplesPerPacket];
    static int audioAccumulatedCount = 0;
    audioAccumulatedCount += audioRing.popAvailable(
        audioAccumulator + audioAccumulatedCount, Config::kAudioSamplesPerPacket - audioAccumulatedCount
    );
    if (audioAccumulatedCount == Config::kAudioSamplesPerPacket) {
        network.sendAudioFrame(audioSeq++, audioAccumulator, audioAccumulatedCount);
        audioAccumulatedCount = 0;
    }

    // Non-blocking check for a completed DOA capture handoff from captureTopTask. Runs
    // DOAEstimator::estimate() once per phone-requested frequency band (see UDPStreamer's
    // activeBands_) against the SAME captured 4-channel window, so multiple simultaneous callers
    // in different frequency ranges can each get their own azimuth from one onset event. With no
    // bands set (the default), falls back to a single full-spectrum estimate at bandId 0 --
    // exactly the original single-reading behavior. Results are stashed into lastDOAResults and
    // printed once per periodic status interval below, NOT here -- see that array's doc comment
    // for why printing per onset event per band was a real, measured problem.
    if (xSemaphoreTake(doaCaptureRequested, 0) == pdTRUE) {
        bottomLeftRing.snapshotRecent(capturedBottomLeft, Config::kDOAWindowSamples);
        bottomRightRing.snapshotRecent(capturedBottomRight, Config::kDOAWindowSamples);

        int bandCount = network.activeBandCount();
        if (bandCount == 0) {
            DOAResult result = DOAEstimator::estimate(
                capturedTopLeft, capturedTopRight, capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples,
                0, 0
            );
            network.sendDOATelemetry(doaSeq++, millis(), result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), 0);
            lastDOAResults[0] = {0, 0, 0, result.azimuthDeg, result.confidence};
            lastDOAResultCount = 1;
        } else {
            lastDOAResultCount = bandCount;
            for (int i = 0; i < bandCount; i++) {
                const Protocol::FrequencyBandSlot &band = network.activeBand(i);
                DOAResult result = DOAEstimator::estimate(
                    capturedTopLeft, capturedTopRight, capturedBottomLeft, capturedBottomRight, Config::kDOAWindowSamples,
                    band.lowHz, band.highHz
                );
                network.sendDOATelemetry(doaSeq++, millis(), result.azimuthDeg, result.confidence, onset.lastRelativeLevel(), band.bandId);
                lastDOAResults[i] = {band.bandId, band.lowHz, band.highHz, result.azimuthDeg, result.confidence};
            }
        }
    }

    // Periodic read-health summary -- captureTopTask/captureBottomTask no longer swallow
    // readFrames() failures silently. Both buses are independent masters now, so a failing bus
    // usually just means a wiring/pin problem on that specific bus (check its own BCLK/WS/SD
    // connections), not a cross-bus sync issue.
    static uint32_t lastStatusMs = 0;
    uint32_t now = millis();
    if (now - lastStatusMs >= 2000) {
        lastStatusMs = now;
        Serial0.printf(
            "[status] top: %lu ok / %lu fail   bottom: %lu ok / %lu fail\n",
            (unsigned long)topReadOk, (unsigned long)topReadFail,
            (unsigned long)bottomReadOk, (unsigned long)bottomReadFail
        );
        // Direct measurement of whether loop() is keeping up with draining the continuously-
        // streamed classification audio -- topReadOk/bottomReadFail above only cover whether the
        // I2S DMA read itself succeeded, which says nothing about whether this ring's consumer
        // (this same loop()) is being serviced often enough. A climbing count here means real
        // audio discontinuities are reaching the phone's classifier; compare this specifically
        // with Radar Mode on vs. off (see RingBuffer::skippedSamples()'s doc comment).
        Serial0.printf("[audio-ring] skipped: %lu samples\n", (unsigned long)audioRing.skippedSamples());
        // Snapshot of the most recent onset event's DOA result(s) -- see lastDOAResults' doc
        // comment for why this is printed here (once per status interval) instead of once per
        // onset event per band, as it was originally.
        for (int i = 0; i < lastDOAResultCount; i++) {
            const LastDOAResult &r = lastDOAResults[i];
            if (r.bandId == 0 && r.lowHz == 0 && r.highHz == 0) {
                Serial0.printf("[doa] band 0 (full spectrum)  azimuth: %.1f  confidence: %.2f  level: %.1f\n", r.azimuthDeg, r.confidence, onset.lastRelativeLevel());
            } else {
                Serial0.printf("[doa] band %u (%.0f-%.0f Hz)  azimuth: %.1f  confidence: %.2f  level: %.1f\n",
                    r.bandId, r.lowHz, r.highHz, r.azimuthDeg, r.confidence, onset.lastRelativeLevel());
            }
        }
        // Direct visibility into the onset gate's internal state -- a real-device report showed
        // DOA events firing right after boot and then apparently never again, even for a clap
        // that should be an obvious transient. This shows exactly why: is the fast envelope
        // (current block loudness) actually reaching `threshold` (floor * kOnsetTriggerRatio), or
        // is the adaptive floor itself sitting implausibly high?
        Serial0.printf(
            "[onset] fast: %.1f  floor: %.1f  threshold: %.1f  outliers_rejected: %lu\n",
            onset.currentFastEnvelope(), onset.currentSlowFloor(), onset.currentThreshold(),
            (unsigned long)onset.outlierRejectedCount()
        );
        // Visibility into the phone-controlled DOA frequency bands (see UDPStreamer's
        // kSetFrequencyBands handling / DOAEstimator::estimate()) -- lets you confirm on the
        // Serial Monitor that tracking/radar mode in the app actually narrowed these, without
        // needing to instrument the app side to check.
        if (network.activeBandCount() == 0) {
            Serial0.println("[doa-band] full spectrum (no bands set)");
        } else {
            for (int i = 0; i < network.activeBandCount(); i++) {
                const Protocol::FrequencyBandSlot &band = network.activeBand(i);
                Serial0.printf("[doa-band] id %u: %.0f - %.0f Hz\n", band.bandId, band.lowHz, band.highHz);
            }
        }
    }
}
