// NodeRoster.h — the master node's table of siblings heard via kNodeAnnounce broadcasts (see
// MULTI_NODE_APP_ENHANCEMENTS_PLAN.md #1 / NetworkProtocol.h's kNodeAnnounce/kRosterRequest/
// kRosterResponse). Only meaningful on whichever node is currently the Primary (see
// MIC_ARRAY_MASTER_AP_PLAN.md, Config::kNetworkRole == kRolePrimary) -- every other node still owns
// an (always-empty) instance of this class, kept simple by not special-casing "am I the master" at
// the call site, only at UDPStreamer's kNodeAnnounce handler itself.
//
// entries_[0..count_-1] are always the valid, contiguous set -- no `inUse` flags to check, no
// gaps to skip. addOrRefresh appends at the end (or updates in place on an IP match);
// pruneStale swap-removes a stale entry with the last valid one, which reorders the roster but
// keeps it compact in O(1) per removal -- order was never meaningful here anyway.
#pragma once

#include <IPAddress.h>
#include "NetworkProtocol.h"

class NodeRoster {
public:
    // Adds a newly-heard sibling, or refreshes an existing one's lastSeenMs/identity if this IP is
    // already known -- an IP reused by a different physical node (DHCP lease churn) is treated as
    // the same slot rather than a duplicate, which is the right call for "how do I discover you,"
    // not "how do I tell every node apart forever" (the latter is the phone's own declared
    // MicArrayNodeConfiguration's job, not this table's). Silently drops the announce if the
    // roster is already full and this is a genuinely new IP -- bounded, like kMaxDOABands.
    void addOrRefresh(IPAddress ip, const Protocol::NodeIdentityPacket &identity, uint32_t nowMs);

    // Drops entries not refreshed within Config::kRosterStaleTimeoutMs -- called lazily whenever
    // the roster is actually read (see UDPStreamer's kRosterRequest handler), not on a separate
    // timer, matching this firmware's existing "check on access" economy elsewhere.
    void pruneStale(uint32_t nowMs);

    int count() const { return count_; }
    IPAddress ip(int index) const { return entries_[index].ip; }
    const Protocol::NodeIdentityPacket &identity(int index) const { return entries_[index].identity; }

private:
    struct Entry {
        IPAddress ip;
        Protocol::NodeIdentityPacket identity;
        uint32_t lastSeenMs;
    };
    Entry entries_[Protocol::kMaxRosterEntries] = {};
    int count_ = 0;
};
