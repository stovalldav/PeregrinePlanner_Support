// WiFiConfigStore.h — NVS-backed runtime Wi-Fi / AP / network-role config, replacing the
// compile-time Config::kWiFi* / kNetworkRole / kIsRosterMaster constants as the *source of truth*.
// See CONFIGURABLE_FLEET_PLAN.md Part A.
//
// The compile-time Config.h values become the fallback: anything not present in NVS resolves to
// the matching field in the Defaults the .ino passes to begin() (so this module never has to
// #include a per-tree Config.h, and a fresh flash with an empty NVS behaves exactly as before).
//
// Kept byte-identical between firmware/PeregrineMicArray/ and firmware/PeregrineMicArrayCam/.
#pragma once

#include <cstdint>
#include <cstddef>
#include <Preferences.h>
#include <WString.h>

class WiFiConfigStore {
public:
    static constexpr uint8_t kMaxCandidates = 6;
    static constexpr uint8_t kSchemaVersion = 2;                          // v2 adds a per-candidate `enabled` byte
    static constexpr size_t kMaxBlobBytes = 1 + 1 + 1 + 1                 // ver, role, rmaster, apChannel
        + 1 + 33 + 1 + 64                                                 // apSsid, apPass (len-prefixed, capped)
        + 1 + kMaxCandidates * (1 + 33 + 1 + 64 + 1);                     // candidates (ssid, pass, enabled)

    struct Credential {
        String ssid;
        String password;
        // false = keep this network in the list but never try to join it. The user can toggle
        // individual candidates off without losing the SSID/password (CONFIGURABLE_FLEET_PLAN.md).
        bool enabled = true;
    };

    // Compile-time fallbacks from Config.h -- passed in once at boot.
    struct Defaults {
        uint8_t role = 0;                       // Config::kNetworkRole
        const char *apSsid = "";                // Config::kWiFiSSID
        const char *apPassword = "";            // Config::kWiFiPassword
        uint8_t apChannel = 6;                  // Config::kWiFiChannel
        bool isRosterMaster = false;            // Config::kIsRosterMaster
        const Credential *candidates = nullptr; // Config::kWiFiCandidates, converted by the .ino
        uint8_t candidateCount = 0;
    };

    // Opens NVS ("wcfg" namespace), loads the effective config into the in-RAM cache. Call once,
    // before any Wi-Fi bring-up.
    void begin(const Defaults &defaults);

    // ---- effective (resolved) view -- what UDPStreamer::begin() and joinBestCandidate() read ----
    uint8_t role() const { return role_; }
    const char *apSsid() const { return apSsid_.c_str(); }
    const char *apPassword() const { return apPassword_.c_str(); }
    uint8_t apChannel() const { return apChannel_; }
    bool isRosterMaster() const { return isRosterMaster_; }
    uint8_t candidateCount() const { return candidateCount_; }
    const Credential &candidate(uint8_t i) const { return candidates_[i]; }
    bool isCustomised() const { return customised_; }        // any NVS override present
    bool apPasswordIsDefault() const { return apPasswordIsDefault_; }

    // ---- staged mutation -- does NOT touch the running radio; commit() persists + the caller reboots ----
    void stageRole(uint8_t role, bool isRosterMaster);
    void stageAp(const char *ssid, const char *password, uint8_t channel);
    void stageCandidatesBegin();                              // clears the staging candidate list
    bool stageCandidateAdd(const char *ssid, const char *password, bool enabled = true);
    bool commit();                                            // prev <- live; live <- staged; arm proof
    void resetToDefaults();                                   // wipe NVS namespace, cache <- Defaults
    bool revertToPrevious();                                  // live <- prev, then delete prev

    // ---- recovery bookkeeping (driven by the .ino's loop) ----
    bool awaitingProof() const { return awaitingProof_; }     // a commit/revert not yet proven good
    void markProven();                                        // a committed config held good long enough
    bool hasPrevious() const { return hasPrevious_; }

    // ---- per-chip default AP password (CONFIGURABLE_FLEET_PLAN.md A5) ----
    // Instead of shipping one shared literal ("birding123") on every node, the .ino derives an
    // 11-char password unique to this chip from its 6-byte deviceId and passes it as the Default
    // apPassword. The app knows the same deviceId (BLE advert bytes 2-7 / kNodeIdentity) so it can
    // reproduce this string to show the user / pre-fill a join. Format: "pp-" + 8 uppercase hex of
    // deviceId[0..3]. deviceId bytes are ESP.getEfuseMac() little-endian, same as BLEAdvertiser's
    // fillDeviceId() / UDPStreamer::fillDeviceId().
    static void deviceIdFromEfuseMac(uint64_t efuseMac, uint8_t out[6]);
    static void deriveDefaultApPassword(const uint8_t deviceId[6], char *out, size_t outCap);

private:
    Preferences prefs_;
    Defaults defaults_{};
    String defaultApPassword_;

    // effective cache
    uint8_t role_ = 0;
    String apSsid_;
    String apPassword_;
    uint8_t apChannel_ = 6;
    bool isRosterMaster_ = false;
    Credential candidates_[kMaxCandidates];
    uint8_t candidateCount_ = 0;
    bool customised_ = false;
    bool apPasswordIsDefault_ = true;
    bool awaitingProof_ = false;
    bool hasPrevious_ = false;

    // staging (mirrors the effective fields until commit)
    uint8_t stagedRole_ = 0;
    String stagedApSsid_;
    String stagedApPassword_;
    uint8_t stagedApChannel_ = 6;
    bool stagedIsRosterMaster_ = false;
    Credential stagedCandidates_[kMaxCandidates];
    uint8_t stagedCandidateCount_ = 0;

    void loadFromDefaults();
    void loadFromCache();                                     // copy effective -> staging
    bool loadLiveBlob();                                      // NVS "live" -> effective cache; false if absent/bad
    size_t serializeStaged(uint8_t *out, size_t cap) const;
    bool deserializeInto(const uint8_t *in, size_t len);      // blob -> effective cache
};
