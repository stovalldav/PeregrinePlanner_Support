#include "RemoteLogger.h"
#include <cstring>
#include "UDPStreamer.h"

void RemoteLogger::begin(
    unsigned long baud, uint32_t config, int8_t rxPin, int8_t txPin,
    bool invert, unsigned long timeout_ms, uint8_t rxfifo_full_thrhd
) {
    if (!realSerial_) return;
    realSerial_->begin(baud, config, rxPin, txPin, invert, timeout_ms, rxfifo_full_thrhd);
}

size_t RemoteLogger::write(uint8_t byte) {
    size_t sent = realSerial_ ? realSerial_->write(byte) : 0;
    if (enabled_) bufferByte(byte);
    return sent;
}

size_t RemoteLogger::write(const uint8_t *buffer, size_t size) {
    size_t sent = realSerial_ ? realSerial_->write(buffer, size) : 0;
    if (enabled_) {
        for (size_t i = 0; i < size; i++) bufferByte(buffer[i]);
    }
    return sent;
}

// Splits whatever's been written into complete lines on '\n', enqueuing each finished line for
// poll() to actually send. Only ever called while enabled_ is true (see write()'s own gating) --
// disabling mid-line just means whatever was partially buffered is silently dropped rather than
// sent as a truncated fragment later, which is fine: this is a debugging aid, not a guaranteed
// delivery channel, and the same line will be complete again the very next time it's logged.
void RemoteLogger::bufferByte(uint8_t byte) {
    if (byte == '\n') {
        if (lineLength_ > 0 || lineOverflowed_) {
            lineBuffer_[lineLength_] = '\0';
            enqueueLine(lineBuffer_);
        }
        lineLength_ = 0;
        lineOverflowed_ = false;
        return;
    }
    if (byte == '\r') return; // CRLF line endings anywhere upstream shouldn't produce empty lines

    if (lineLength_ + 1 >= kLineBufferSize - 16) { // leave room for the truncation marker below
        if (!lineOverflowed_) {
            lineOverflowed_ = true;
            const char *marker = "...[truncated]";
            size_t markerLen = strlen(marker);
            memcpy(lineBuffer_ + lineLength_, marker, markerLen);
            lineLength_ += markerLen;
        }
        return; // keep discarding bytes until the eventual '\n' closes this line out
    }
    lineBuffer_[lineLength_++] = (char)byte;
}

void RemoteLogger::enqueueLine(const char *line) {
    if (queueCount_ >= kMaxQueuedLines) {
        // Drop the oldest to make room -- same "losing an occasional line is fine" tolerance this
        // whole fire-and-forget UDP protocol already has everywhere else.
        queueHead_ = (queueHead_ + 1) % kMaxQueuedLines;
        queueCount_--;
    }
    int tail = (queueHead_ + queueCount_) % kMaxQueuedLines;
    // strncpy, not strcpy -- `line` (lineBuffer_) is already guaranteed < kLineBufferSize by
    // bufferByte()'s own overflow guard, but this stays defensive rather than assuming.
    strncpy(queuedLines_[tail], line, kLineBufferSize - 1);
    queuedLines_[tail][kLineBufferSize - 1] = '\0';
    queueCount_++;
}

void RemoteLogger::poll(UDPStreamer &network) {
    while (queueCount_ > 0) {
        network.sendLogLine(queuedLines_[queueHead_]);
        queueHead_ = (queueHead_ + 1) % kMaxQueuedLines;
        queueCount_--;
    }
}
