// UDPStreamer.h — WiFi (SoftAP or station, see Config::kNetworkRole) + the UDP control/data
// socket. Owns the single registered UDP client (the phone) this device streams audio/DOA
// telemetry to. When hosting its own AP (kRolePrimary, the default), allows up to
// Config::kMaxAPStations associated WiFi stations (see .cpp) -- the phone, an optional
// PeregrineMicArrayRearSensor companion unit, and (since 2026-08-12, see
// FLEET_NETWORK_PARTICIPATION_PLAN.md) any other node joining as a Client -- that's a link-layer
// change only, it doesn't affect this class's single-client application-layer tracking.
//
// Role/roster system added 2026-08-12, mirroring ../PeregrineMicArrayCam/UDPStreamer.h's own copy
// directly rather than reinventing it -- see that file's comments and
// FLEET_NETWORK_PARTICIPATION_PLAN.md for the full rationale.
#pragma once

#include <cstdint>
#include <WiFiUdp.h>
#include "NetworkProtocol.h"
#include "NodeRoster.h"

class UDPStreamer {
public:
    // Hosts an AP or joins a network as a station depending on Config::kNetworkRole -- see that
    // constant's comment. Returns false on AP-hosting failure or STA join timeout (see
    // Config::kWiFiConnectTimeoutMs), so the caller can decide whether to retry/reboot rather than
    // silently running with no network -- same as ../PeregrineMicArrayCam/UDPStreamer::begin().
    bool begin();

    // Call every loop() iteration: processes any incoming control packets (ping/start/stop) and
    // checks the streaming-inactivity timeout.
    void poll();

    // Call every loop() iteration alongside poll() -- only meaningful when Config::kNetworkRole ==
    // kRoleSecondary, a no-op otherwise. See MIC_ARRAY_MASTER_AP_PLAN.md §4's failover state
    // machine, implemented here 2026-08-14, mirroring ../PeregrineMicArrayCam/UDPStreamer's own
    // copy verbatim.
    void pollFailover();

    // Call every loop() iteration alongside poll() -- only meaningful when Config::kNetworkRole ==
    // kRoleClient, a no-op otherwise. See WIFI_MULTI_SSID_FALLBACK_PLAN.md's Phase 2 (added
    // 2026-08-16): re-attempts the Config::kWiFiCandidates join loop if the STA link has been down
    // for Config::kWiFiReconnectGraceMs, covering runtime drops that begin()'s one-time join can't.
    void pollReconnect();

    // True if this node is CURRENTLY acting as the fleet's AP host -- always true for
    // kRolePrimary, true for kRoleSecondary only while failed-over, false otherwise. See
    // ../PeregrineMicArrayCam/UDPStreamer.h's identical method for the full rationale.
    bool isCurrentlyHosting() const;

    // Added 2026-08-16 -- broader than isCurrentlyHosting(): true whenever this node should act as
    // the fleet's roster master, whether that's because it's hosting the AP OR because
    // Config::kIsRosterMaster was set true on it for an all-kRoleClient shared-external-network
    // deployment (see that constant's own doc comment in Config.h for the full rationale). The two
    // roster-related call sites (kNodeAnnounce acceptance, self-announce skip) use this instead of
    // the bare isCurrentlyHosting() now; every other use of "am I hosting" stays on that original
    // method unchanged. Defined in the .cpp, not inline here, like isCurrentlyHosting() itself --
    // this header doesn't #include "Config.h" (only UDPStreamer.cpp does, and only after this
    // header), so a Config:: reference in an inline body here wouldn't resolve.
    bool isActingAsRosterMaster() const;

    bool isStreaming() const { return streaming_; }

    void sendAudioFrame(uint32_t seq, const int16_t *samples, int count);
    // 4-mic nodes only (Config::kMicCount==4) -- interleaves left/right into one kStereoAudioFrame
    // packet, mutually exclusive with sendAudioFrame (a node sends one or the other, never both --
    // see .ino's loop()). `countPerChannel` matches Config::kStereoAudioSamplesPerChannel.
    void sendStereoAudioFrame(uint32_t seq, const int16_t *left, const int16_t *right, int countPerChannel);
    // 4-mic nodes only -- see NetworkProtocol.h's AudioLevelsPacket for the real-hardware finding
    // this exists for. usingBottomPair mirrors the .ino's own usingBottomPairForStream state.
    void sendAudioLevels(uint32_t timestampMs, int16_t topLeftPeak, int16_t topRightPeak, int16_t bottomLeftPeak, int16_t bottomRightPeak, bool usingBottomPair);
    void sendDOATelemetry(uint32_t seq, uint32_t timestampMs, float azimuthDeg, float confidence, float relativeLevel, uint8_t bandId);
    // GPS-PPS-disciplined onset timestamp for multi-node TDOA (MULTI_NODE_TDOA_PLAN.md). Caller
    // only invokes this once its PPSReader clock is anchored; utcSecond/utcMicros come from
    // PPSReader::utcForLocalMicros().
    void sendTimedOnset(uint32_t seq, uint32_t utcSecond, uint32_t utcMicros, uint16_t bandId, float peakLevel, float confidence);

    // New 2026-08-12 -- see NetworkProtocol.h's "Multi-node network additions" and
    // ../PeregrineMicArrayCam/UDPStreamer.h's identical methods for the full rationale.
    void sendNodeIdentity();
    // Peer-to-peer LAN broadcast, not gated on `streaming_` -- only called from .ino when this
    // node is NOT the current Primary (see Config::kNetworkRole).
    void sendNodeAnnounce();

    // Added 2026-08-14, mirrors ../PeregrineMicArrayCam/UDPStreamer's identical method -- see
    // NetworkProtocol.h's GPSPositionPacket comment. Only meaningful when Config::kGPSEnabled.
    // Diagnostic params (satellitesInView through ppsLastIntervalMicros) added the same day, for
    // in-field GPS troubleshooting -- straight passthrough of GPSReader's/PPSReader's own counters.
    void sendGPSPosition(
        uint32_t timestampMs, double latitude, double longitude, float horizontalAccuracyMeters, bool hasFix,
        uint8_t satellitesInView, uint32_t charsProcessed, uint32_t sentencesValid, uint32_t sentencesInvalid,
        uint32_t ppsEdgeCount, uint32_t ppsLastIntervalMicros
    );

    // Added 2026-08-18, FIELD_DEBUG_PLAN.md -- see RemoteLogger.h for the full rationale. Only
    // needs a registered client at all (not a live `streaming_` session) -- same "requires
    // kSessionStart to have happened at least once" gating as sendVideoReady, deliberately not
    // gated on isStreaming() since a debugging session shouldn't need the audio/DOA stream itself
    // to be active for its logs to be worth capturing.
    void sendLogLine(const char *line);

    // Set via the phone's kSetRemoteLogging control packet -- .ino's loop() checks this the same
    // way it already checks consumeSetPhotoMode() on the camera-node firmware, calling
    // RemoteLogger::setEnabled() (this class doesn't own a RemoteLogger instance itself).
    bool consumeSetRemoteLoggingRequest(bool &enabled);

    // Set via the phone's kSetFrequencyBands control packet (see .cpp's handlePacket) -- read by
    // PeregrineMicArray.ino's loop(), which calls DOAEstimator::estimate() once per active band
    // against the same captured window and tags each resulting DOATelemetryPacket with that band's
    // id. Empty (count 0) until the phone sends one -- loop() falls back to a single full-spectrum
    // estimate at bandId 0 in that case, exactly the original single-band behavior.
    int activeBandCount() const { return activeBandCount_; }
    const Protocol::FrequencyBandSlot &activeBand(int index) const { return activeBands_[index]; }

private:
    void handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort);
    IPAddress broadcastAddress() const;
    // Shared by begin()'s cold-boot-with-no-Primary path and pollFailover()'s runtime-loss path --
    // both converge to the same "start hosting our own AP" transition.
    void promoteToFailedOver();
    // Shared by begin()'s STA branch and pollReconnect() -- see the .cpp's own doc comment.
    // WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16.
    bool joinBestCandidate();
    // Fills a 6-byte NodeIdentityPacket::deviceId/RosterEntryPacket::deviceId field from
    // ESP.getEfuseMac() -- see NodeIdentityPacket's own doc comment in NetworkProtocol.h for why
    // this specific source, not WiFi.macAddress()/softAPmacAddress(). Shared by sendNodeIdentity()
    // and sendNodeAnnounce(), the two call sites that build a NodeIdentityPacket.
    static void fillDeviceId(uint8_t *out);

    WiFiUDP udp_;
    bool streaming_ = false;
    IPAddress clientIP_;
    uint16_t clientPort_ = 0;
    uint32_t lastClientActivityMs_ = 0;
    Protocol::FrequencyBandSlot activeBands_[Protocol::kMaxDOABands] = {};
    int activeBandCount_ = 0;
    // Only ever populated if this node is the current roster master (Config::kNetworkRole ==
    // kRolePrimary) -- see NodeRoster.h's header for why every node still safely owns one of
    // these either way.
    NodeRoster roster_;
    // Secondary/failover state (MIC_ARRAY_MASTER_AP_PLAN.md §4) -- unused/inert unless
    // Config::kNetworkRole == kRoleSecondary.
    bool failedOver_ = false;
    uint32_t lastConnectedMs_ = 0;
    uint32_t lastPrimaryScanMs_ = 0;
    // kSetRemoteLogging request state -- see consumeSetRemoteLoggingRequest()'s own comment.
    bool remoteLoggingRequested_ = false;
    bool remoteLoggingRequestedValue_ = false;
    // Sequence counters are owned by the caller (PeregrineMicArray.ino), passed into each send
    // call -- kept out of this class since audio and DOA packets are produced by different tasks.
};
