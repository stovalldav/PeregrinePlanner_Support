// UDPStreamer.h — WiFi SoftAP + the UDP control/data socket. Owns the single registered UDP
// client (the phone) this device streams audio/DOA telemetry to. The AP itself now allows up to
// 2 associated WiFi stations (see .cpp) so the optional PeregrineMicArrayRearSensor companion
// unit can join the same network to reach the phone -- that's a link-layer change only, it
// doesn't affect this class's single-client application-layer tracking.
#pragma once

#include <cstdint>
#include <WiFiUdp.h>
#include "NetworkProtocol.h"

class UDPStreamer {
public:
    void begin();

    // Call every loop() iteration: processes any incoming control packets (ping/start/stop) and
    // checks the streaming-inactivity timeout.
    void poll();

    bool isStreaming() const { return streaming_; }

    void sendAudioFrame(uint32_t seq, const int16_t *samples, int count);
    void sendDOATelemetry(uint32_t seq, uint32_t timestampMs, float azimuthDeg, float confidence, float relativeLevel, uint8_t bandId);

    // Set via the phone's kSetFrequencyBands control packet (see .cpp's handlePacket) -- read by
    // PeregrineMicArray.ino's loop(), which calls DOAEstimator::estimate() once per active band
    // against the same captured window and tags each resulting DOATelemetryPacket with that band's
    // id. Empty (count 0) until the phone sends one -- loop() falls back to a single full-spectrum
    // estimate at bandId 0 in that case, exactly the original single-band behavior.
    int activeBandCount() const { return activeBandCount_; }
    const Protocol::FrequencyBandSlot &activeBand(int index) const { return activeBands_[index]; }

private:
    void handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort);

    WiFiUDP udp_;
    bool streaming_ = false;
    IPAddress clientIP_;
    uint16_t clientPort_ = 0;
    uint32_t lastClientActivityMs_ = 0;
    Protocol::FrequencyBandSlot activeBands_[Protocol::kMaxDOABands] = {};
    int activeBandCount_ = 0;
    // Sequence counters are owned by the caller (PeregrineMicArray.ino), passed into each send
    // call -- kept out of this class since audio and DOA packets are produced by different tasks.
};
