#include "UDPStreamer.h"
#include <WiFi.h>
#include <cstring>
#include "Config.h"

bool UDPStreamer::begin() {
    if (Config::kNetworkRole == Config::kRolePrimary) {
        // Host our own AP -- unchanged default behavior from before this role system existed
        // (2026-08-12), just now gated on kNetworkRole instead of unconditional. max_connection
        // now Config::kMaxAPStations (was a hardcoded 2) -- see that constant's comment for why.
        WiFi.mode(WIFI_AP);
        if (!WiFi.softAP(Config::kWiFiSSID, Config::kWiFiPassword, Config::kWiFiChannel, /*hidden=*/0, Config::kMaxAPStations)) {
            return false;
        }
    } else {
        // kRoleClient or kRoleSecondary -- both start by trying each Config::kWiFiCandidates entry
        // in priority order (see WIFI_MULTI_SSID_FALLBACK_PLAN.md, added 2026-08-16). Mirrors
        // ../PeregrineMicArrayCam/UDPStreamer::begin()'s STA path exactly.
        WiFi.mode(WIFI_STA);
        if (!joinBestCandidate()) {
            if (Config::kNetworkRole == Config::kRoleSecondary) {
                // Cold boot with no Primary reachable yet -- don't hard-fail the way
                // kRoleClient does below. See ../PeregrineMicArrayCam/UDPStreamer::begin()'s
                // identical branch for the full rationale.
                Serial0.println("[failover] no Primary reachable at boot -- promoting immediately");
                promoteToFailedOver();
                udp_.begin(Config::kUDPPort);
                return true;
            }
            return false; // kRoleClient has no fallback -- unchanged behavior
        }
        lastConnectedMs_ = millis();
    }

    udp_.begin(Config::kUDPPort);
    return true;
}

// Real bug found 2026-08-18: a WiFi candidate SSID typed by hand into Config.h will very commonly
// carry a plain ASCII apostrophe (0x27), but iOS auto-generates possessive device/hotspot names
// (e.g. "Someone's iPhone") using the typographic right single quote (U+2019, UTF-8 bytes
// E2 80 99) instead -- confirmed on real hardware: this silently made a correctly-spelled,
// in-range, correctly-passworded hotspot completely unfindable (WIFI_REASON_NO_AP_FOUND) until the
// exact byte was hand-corrected. Not something every future user setting up their own phone's
// hotspot as a candidate can reasonably be expected to know to watch for -- normalizing this one
// specific, well-understood substitution when matching a scanned SSID against a candidate closes
// the whole class of bug rather than relying on each person typing it exactly right.
static String normalizeApostrophes(const String &s) {
    String out;
    out.reserve(s.length());
    for (size_t i = 0; i < s.length(); ) {
        if (i + 2 < s.length()
            && (uint8_t)s[i] == 0xE2 && (uint8_t)s[i + 1] == 0x80 && (uint8_t)s[i + 2] == 0x99) {
            out += '\''; // U+2019 -> plain ASCII apostrophe, for comparison purposes only
            i += 3;
        } else {
            out += s[i];
            i += 1;
        }
    }
    return out;
}

// Shared by begin()'s STA branch and pollReconnect() (WIFI_MULTI_SSID_FALLBACK_PLAN.md Phase 1/2,
// added 2026-08-16) -- tries each Config::kWiFiCandidates entry in order, each given up to
// Config::kWiFiPerCandidateTimeoutMs, stopping at the first that reaches WL_CONNECTED. Assumes
// WiFi.mode() has already been set to WIFI_STA (or WIFI_AP_STA) by the caller -- this only drives
// the join attempts themselves, not the radio mode.
bool UDPStreamer::joinBestCandidate() {
    constexpr int candidateCount = sizeof(Config::kWiFiCandidates) / sizeof(Config::kWiFiCandidates[0]);

    // One scan up front, reused for every candidate below -- see normalizeApostrophes()'s doc
    // comment. Real, accepted added cost: this blocks for the scan's own duration (several
    // seconds) on every join pass, on top of what was already here -- same "acceptable, this path
    // already blocks" reasoning as pollReconnect()'s own doc comment. `scanDelete()` at the end
    // frees the scan result memory regardless of which candidate (if any) ultimately connects.
    int scanCount = WiFi.scanNetworks();

    for (int i = 0; i < candidateCount; i++) {
        const Config::WiFiCredential &candidate = Config::kWiFiCandidates[i];

        // Default: the literal candidate string, unchanged -- covers a hidden network (never
        // appears in a scan) and any candidate that was already byte-correct. Overridden below
        // only if a scanned network matches once apostrophe-style differences are normalized away
        // -- in that case we join using the SCANNED network's own real bytes, not our possibly-
        // mistyped copy, so this exact mismatch can't recur regardless of what's in Config.h.
        String joinSSID = candidate.ssid;
        String normalizedCandidate = normalizeApostrophes(joinSSID);
        for (int s = 0; s < scanCount; s++) {
            if (normalizeApostrophes(WiFi.SSID(s)) == normalizedCandidate) {
                joinSSID = WiFi.SSID(s);
                break;
            }
        }

        Serial0.printf("[wifi] trying candidate %d/%d: %s\n", i + 1, candidateCount, joinSSID.c_str());
        // Real hardware finding, 2026-08-17: calling WiFi.begin() again for the next candidate
        // right after our own per-candidate timeout gives up is NOT enough -- the ESP-IDF driver's
        // previous connection attempt can still be active internally even once WiFi.status() stops
        // being useful to us, and esp_wifi_set_config() then rejects the new credentials outright
        // ("E wifi:sta is connecting, cannot set config"), silently failing every remaining
        // candidate for the rest of this pass. WiFi.disconnect() explicitly aborts any in-flight
        // attempt and returns the driver to idle before the next WiFi.begin() -- harmless to call
        // on the very first candidate too (nothing in-flight yet). Delay is an unmeasured starting
        // point, just long enough for the driver to settle before the next begin().
        WiFi.disconnect(true);
        delay(100);
        WiFi.begin(joinSSID.c_str(), candidate.password);
        uint32_t startMs = millis();
        while (WiFi.status() != WL_CONNECTED && millis() - startMs <= Config::kWiFiPerCandidateTimeoutMs) {
            delay(250);
        }
        if (WiFi.status() == WL_CONNECTED) {
            Serial0.printf("[wifi] joined %s\n", joinSSID.c_str());
            // Real hardware finding, 2026-08-17 (see
            // ../PeregrineMicArrayRearSensor/UDPStreamer.cpp's identical fix for the full
            // rationale): ESP32 WiFi modem sleep (default-enabled in STA mode) can intermittently
            // miss incoming UDP packets while dozing between beacon intervals -- observed on the
            // rear sensor as a session that worked for a while then permanently stopped receiving.
            // Disabled defensively here too. MUST live here, not in begin() -- pollReconnect()
            // calls this method directly, bypassing begin() entirely; a first real-hardware test
            // with this placed in begin() instead never actually ran it for exactly that reason.
            WiFi.setSleep(false);
            WiFi.scanDelete();
            return true;
        }
    }
    WiFi.scanDelete();
    Serial0.println("[wifi] exhausted every kWiFiCandidates entry -- none reachable");
    return false;
}

// Phase 2 of WIFI_MULTI_SSID_FALLBACK_PLAN.md -- only meaningful for kNetworkRole == kRoleClient
// (kRoleSecondary has its own, more specialized runtime recovery via pollFailover()'s
// promote-to-AP path; kRolePrimary/a failed-over Secondary hosts, nothing to reconnect to). If the
// STA link has been down for Config::kWiFiReconnectGraceMs, re-runs joinBestCandidate() from the
// top -- covers the gap Phase 1 alone left open: a node that joined some candidate at begin() but
// later dropped off it entirely had no runtime recovery path beyond the ESP32 core's own default
// auto-reconnect. Known, accepted cost: this blocks loop() for up to
// candidateCount * kWiFiPerCandidateTimeoutMs while it runs -- see Config::kWiFiReconnectGraceMs's
// comment for why that's fine here (capture tasks are pinned separately, and no UDP traffic is
// possible without a live link anyway).
void UDPStreamer::pollReconnect() {
    if (Config::kNetworkRole != Config::kRoleClient) return;
    if (WiFi.status() == WL_CONNECTED) {
        lastConnectedMs_ = millis();
        return;
    }
    if (millis() - lastConnectedMs_ < Config::kWiFiReconnectGraceMs) return;
    Serial0.println("[wifi] STA link down past the grace period -- retrying the candidate list");
    joinBestCandidate();
    // Reset the grace clock regardless of outcome (success or another exhausted pass) -- avoids a
    // tight retry loop hammering every single loop() iteration if nothing is currently reachable,
    // same throttling lesson as MicArrayNodeConnection's own reconnect cooldown (app side).
    lastConnectedMs_ = millis();
}

void UDPStreamer::promoteToFailedOver() {
    Serial0.println("[failover] promoting to WIFI_AP_STA -- hosting our own AP while watching for the real Primary");
    WiFi.mode(WIFI_AP_STA);
    // Real diagnostic gap found 2026-08-18: this return value was silently discarded -- if softAP()
    // itself failed outright (bad channel, band/regulatory issue, whatever), everything downstream
    // would look identical to "hosting fine, but no station can join" with zero indication the AP
    // never actually came up in the first place.
    bool apOk = WiFi.softAP(Config::kWiFiSSID, Config::kWiFiPassword, Config::kWiFiChannel, /*hidden=*/0, Config::kMaxAPStations);
    Serial0.printf("[failover] softAP() %s -- ssid '%s' channel %d, ip %s\n",
        apOk ? "ok" : "FAILED", Config::kWiFiSSID, Config::kWiFiChannel, WiFi.softAPIP().toString().c_str());
    failedOver_ = true;
    lastPrimaryScanMs_ = millis();
}

void UDPStreamer::pollFailover() {
    if (Config::kNetworkRole != Config::kRoleSecondary) return;

    if (!failedOver_) {
        if (WiFi.status() == WL_CONNECTED) {
            lastConnectedMs_ = millis();
            return;
        }
        if (millis() - lastConnectedMs_ > Config::kFailoverTimeoutMs) {
            Serial0.println("[failover] lost the Primary's connection -- promoting");
            promoteToFailedOver();
        }
        return;
    }

    // Currently failed-over -- periodically re-scan for the real Primary specifically (BSSID, not
    // just SSID -- see Config::kPrimaryBSSID's comment). WiFi.scanNetworks() blocks, so this is
    // deliberately infrequent (Config::kPrimaryRescanIntervalMs).
    if (millis() - lastPrimaryScanMs_ < Config::kPrimaryRescanIntervalMs) return;
    lastPrimaryScanMs_ = millis();

    // Real diagnostic gap found 2026-08-18: user reported the AP is visible with a correct
    // password but won't let a phone join -- this scan is the prime suspect (ESP32 has one radio;
    // scanNetworks() has to hop channels 1-13, which necessarily means briefly leaving the AP's own
    // channel (Config::kWiFiChannel) for the whole scan's duration -- a station's association
    // attempt landing during that window can fail even though the AP looks fine before and after).
    // Logged with a start/end timestamp specifically so a failed-join report can be checked against
    // whether it landed inside one of these windows.
    uint32_t scanStartMs = millis();
    Serial0.println("[failover] starting periodic Primary re-scan -- AP briefly leaves its own channel for this");
    int found = WiFi.scanNetworks();
    bool primaryReachable = false;
    for (int i = 0; i < found; i++) {
        uint8_t *bssid = WiFi.BSSID(i);
        if (bssid != nullptr && memcmp(bssid, Config::kPrimaryBSSID, 6) == 0) {
            primaryReachable = true;
            break;
        }
    }
    WiFi.scanDelete();
    Serial0.printf("[failover] re-scan done -- %dms, %d networks found, Primary %s\n",
        (int)(millis() - scanStartMs), found, primaryReachable ? "reachable" : "not found");

    if (primaryReachable) {
        Serial0.println("[failover] real Primary reachable again -- stepping down");
        WiFi.softAPdisconnect(true);
        WiFi.mode(WIFI_STA);
        WiFi.begin(Config::kWiFiSSID, Config::kWiFiPassword);
        failedOver_ = false;
        lastConnectedMs_ = millis();
    }
}

bool UDPStreamer::isCurrentlyHosting() const {
    return Config::kNetworkRole == Config::kRolePrimary
        || (Config::kNetworkRole == Config::kRoleSecondary && failedOver_);
}

bool UDPStreamer::isActingAsRosterMaster() const {
    return isCurrentlyHosting() || Config::kIsRosterMaster;
}

void UDPStreamer::poll() {
    int packetSize = udp_.parsePacket();
    if (packetSize > 0) {
        // Sized for the largest incoming packet, SetFrequencyBandsPacket (3 + kMaxDOABands*9 = 48
        // bytes at kMaxDOABands=5) -- every other control packet this device accepts is far smaller.
        uint8_t buf[64];
        int len = udp_.read(buf, sizeof(buf));
        if (len > 0) {
            handlePacket(buf, len, udp_.remoteIP(), udp_.remotePort());
        }
    }

    if (streaming_ && (millis() - lastClientActivityMs_) > Config::kStreamingInactivityTimeoutMs) {
        streaming_ = false;
    }
}

void UDPStreamer::handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort) {
    if (len < 2) return;
    uint8_t type = data[1];

    switch (type) {
        case Protocol::kHandshakePing: {
            Protocol::HandshakePongPacket pong;
            pong.version = Protocol::kVersion;
            pong.type = Protocol::kHandshakePong;
            pong.magic0 = Protocol::kPongMagic0;
            pong.magic1 = Protocol::kPongMagic1;
            udp_.beginPacket(remoteIP, remotePort);
            udp_.write((const uint8_t *)&pong, sizeof(pong));
            udp_.endPacket();
            break;
        }
        case Protocol::kSessionStart: {
            clientIP_ = remoteIP;
            clientPort_ = remotePort;
            streaming_ = true;
            lastClientActivityMs_ = millis();
            break;
        }
        case Protocol::kSessionStop: {
            if (remoteIP == clientIP_ && remotePort == clientPort_) {
                streaming_ = false;
            }
            break;
        }
        case Protocol::kSetRemoteLogging: {
            // FIELD_DEBUG_PLAN.md, added 2026-08-18.
            if (len < 3) break;
            remoteLoggingRequested_ = true;
            remoteLoggingRequestedValue_ = (data[2] != 0);
            break;
        }
        case Protocol::kSetFrequencyBands: {
            // Header (version, type, count) must be present; the `slots` array can be shorter than
            // the full fixed-size struct since the phone only sends `count` populated entries, not
            // padding out to kMaxDOABands -- so check against the header + count*slot size actually
            // needed, not sizeof(SetFrequencyBandsPacket).
            if (len < 3) break;
            uint8_t count = data[2];
            if (count > Protocol::kMaxDOABands) count = Protocol::kMaxDOABands;
            if (len < 3 + (int)(count * sizeof(Protocol::FrequencyBandSlot))) break;

            for (uint8_t i = 0; i < count; i++) {
                // memcpy rather than a raw pointer cast: `data` isn't guaranteed aligned for a
                // struct containing floats, and this is the safe, portable way to read a packed
                // wire struct out of an arbitrary byte buffer.
                memcpy(&activeBands_[i], data + 3 + i * sizeof(Protocol::FrequencyBandSlot), sizeof(Protocol::FrequencyBandSlot));
            }
            activeBandCount_ = count;
            break;
        }
        case Protocol::kNodeAnnounce: {
            // Broadcast from a sibling node, not the phone -- only meaningful if THIS node is
            // CURRENTLY the roster master, i.e. isActingAsRosterMaster() -- either hosting the AP
            // (isCurrentlyHosting(), always true for Primary, true for a failed-over Secondary too
            // as of MIC_ARRAY_MASTER_AP_PLAN.md §4/§5, implemented 2026-08-14) OR explicitly
            // designated as roster master via Config::kIsRosterMaster (added 2026-08-16, for an
            // all-kRoleClient shared-external-network deployment where nothing hosts at all --
            // see that constant's own doc comment). Mirrors
            // ../PeregrineMicArrayCam/UDPStreamer.cpp's identical handler.
            //
            // Real Serial logging added 2026-08-12 -- this whole path was completely silent
            // before, on both accept and every reject reason, making "is discovery even working"
            // undiagnosable from the Serial Monitor alone (same class of gap already hit and
            // fixed for GPS-link and photo-capture elsewhere in this project). Rare event (once
            // per Config::kNodeAnnounceIntervalMs per remote node, not a hot per-loop() path), so
            // an unconditional Serial0.printf() here is safe -- not the per-onset-event
            // UART-backpressure problem already documented elsewhere in this codebase.
            if (!isActingAsRosterMaster()) {
                Serial0.printf("[roster] kNodeAnnounce from %s ignored -- this node is not currently acting as roster master\n", remoteIP.toString().c_str());
                break;
            }
            if (len < (int)sizeof(Protocol::NodeIdentityPacket)) {
                Serial0.printf("[roster] kNodeAnnounce from %s ignored -- packet too short (%d bytes, need %u)\n", remoteIP.toString().c_str(), len, (unsigned)sizeof(Protocol::NodeIdentityPacket));
                break;
            }
            Protocol::NodeIdentityPacket identity;
            memcpy(&identity, data, sizeof(identity));
            // A different user's node sharing this WiFi network would otherwise get silently
            // aggregated into this roster too -- see NodeIdentityPacket's fleetId comment.
            if (identity.fleetId != Config::kFleetId) {
                Serial0.printf("[roster] kNodeAnnounce from %s ignored -- fleetId mismatch (got 0x%08lX, this fleet is 0x%08lX)\n",
                    remoteIP.toString().c_str(), (unsigned long)identity.fleetId, (unsigned long)Config::kFleetId);
                break;
            }
            roster_.addOrRefresh(remoteIP, identity, millis());
            Serial0.printf("[roster] kNodeAnnounce from %s accepted -- nodeType %u, roster now has %d entries\n",
                remoteIP.toString().c_str(), identity.nodeType, roster_.count());
            break;
        }
        case Protocol::kRosterRequest: {
            // Always answered, even on a non-master node (which just has nothing to report) --
            // the phone doesn't need to know in advance which connected node is master. Mirrors
            // ../PeregrineMicArrayCam/UDPStreamer.cpp's identical handler.
            roster_.pruneStale(millis());
            Serial0.printf("[roster] kRosterRequest from %s -- replying with %d entries\n", remoteIP.toString().c_str(), roster_.count());
            Protocol::RosterResponsePacket response;
            response.version = Protocol::kVersion;
            response.type = Protocol::kRosterResponse;
            response.count = (uint8_t)roster_.count();
            for (int i = 0; i < roster_.count(); i++) {
                IPAddress ip = roster_.ip(i);
                const Protocol::NodeIdentityPacket &identity = roster_.identity(i);
                response.entries[i].ipOctet0 = ip[0];
                response.entries[i].ipOctet1 = ip[1];
                response.entries[i].ipOctet2 = ip[2];
                response.entries[i].ipOctet3 = ip[3];
                response.entries[i].nodeType = identity.nodeType;
                response.entries[i].hasGPS = identity.hasGPS;
                response.entries[i].hasCompass = identity.hasCompass;
                response.entries[i].hasMotionSensor = identity.hasMotionSensor;
                response.entries[i].micCount = identity.micCount;
                memcpy(response.entries[i].deviceId, identity.deviceId, 6);
            }
            size_t responseSize = sizeof(Protocol::RosterResponsePacket) - sizeof(Protocol::RosterEntryPacket) * (Protocol::kMaxRosterEntries - roster_.count());
            udp_.beginPacket(remoteIP, remotePort);
            udp_.write((const uint8_t *)&response, responseSize);
            udp_.endPacket();
            break;
        }
        default:
            break;
    }
}

IPAddress UDPStreamer::broadcastAddress() const {
    IPAddress local = WiFi.localIP();
    IPAddress mask = WiFi.subnetMask();
    return IPAddress(
        local[0] | (~mask[0] & 0xFF),
        local[1] | (~mask[1] & 0xFF),
        local[2] | (~mask[2] & 0xFF),
        local[3] | (~mask[3] & 0xFF)
    );
}

void UDPStreamer::fillDeviceId(uint8_t *out) {
    uint64_t mac = ESP.getEfuseMac();
    for (int i = 0; i < 6; i++) {
        out[i] = (uint8_t)(mac >> (8 * i));
    }
}

void UDPStreamer::sendNodeIdentity() {
    if (!streaming_) return;

    Protocol::NodeIdentityPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kNodeIdentity;
    packet.nodeType = Config::kNodeType;
    packet.hasGPS = Config::kGPSEnabled ? 1 : 0; // ported 2026-08-14, see Config.h's GPS section
    packet.hasCompass = 0;
    packet.hasMotionSensor = 0;
    packet.micCount = Config::kMicCount;
    packet.fleetId = Config::kFleetId; // not used by the phone, just keeping the shared struct fully populated
    fillDeviceId(packet.deviceId);

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendNodeAnnounce() {
    // Peer-to-peer, not to the registered phone client -- deliberately not gated on `streaming_`
    // (see .h's doc comment on this method).
    Protocol::NodeIdentityPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kNodeAnnounce;
    packet.nodeType = Config::kNodeType;
    packet.hasGPS = Config::kGPSEnabled ? 1 : 0; // ported 2026-08-14, see Config.h's GPS section
    packet.hasCompass = 0;
    packet.hasMotionSensor = 0;
    packet.micCount = Config::kMicCount;
    packet.fleetId = Config::kFleetId;
    fillDeviceId(packet.deviceId);

    IPAddress dest = broadcastAddress();
    udp_.beginPacket(dest, Config::kUDPPort);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
    // Real Serial logging added 2026-08-12, same reasoning as kNodeAnnounce's receive-side
    // logging above -- confirms from the SENDING node's own Serial output that announces are
    // actually going out (and to what computed broadcast address), rather than only being able
    // to infer it indirectly from whether the Primary's roster ever grows.
    Serial0.printf("[roster] sent kNodeAnnounce to %s (nodeType %u, fleetId 0x%08lX)\n",
        dest.toString().c_str(), Config::kNodeType, (unsigned long)Config::kFleetId);
}

void UDPStreamer::sendGPSPosition(
    uint32_t timestampMs, double latitude, double longitude, float horizontalAccuracyMeters, bool hasFix,
    uint8_t satellitesInView, uint32_t charsProcessed, uint32_t sentencesValid, uint32_t sentencesInvalid,
    uint32_t ppsEdgeCount, uint32_t ppsLastIntervalMicros
) {
    if (!streaming_) return;

    Protocol::GPSPositionPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kGPSPosition;
    packet.timestampMs = timestampMs;
    packet.latitude = latitude;
    packet.longitude = longitude;
    packet.horizontalAccuracyMeters = horizontalAccuracyMeters;
    packet.hasFix = hasFix ? 1 : 0;
    packet.satellitesInView = satellitesInView;
    packet.charsProcessed = charsProcessed;
    packet.sentencesValid = sentencesValid;
    packet.sentencesInvalid = sentencesInvalid;
    packet.ppsEdgeCount = ppsEdgeCount;
    packet.ppsLastIntervalMicros = ppsLastIntervalMicros;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

// FIELD_DEBUG_PLAN.md, added 2026-08-18 -- see RemoteLogger.h for the full rationale. Only needs a
// registered client at all, not a live streaming_ session -- see this method's own header comment.
void UDPStreamer::sendLogLine(const char *line) {
    if (clientPort_ == 0) return;

    size_t length = strlen(line);
    if (length > Protocol::kMaxLogLineLength) length = Protocol::kMaxLogLineLength; // defensive, RemoteLogger's own buffer already caps this

    Protocol::LogLineHeader header;
    header.version = Protocol::kVersion;
    header.type = Protocol::kLogLine;
    header.length = (uint8_t)length;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&header, sizeof(header));
    udp_.write((const uint8_t *)line, length);
    udp_.endPacket();
}

// FIELD_DEBUG_PLAN.md, added 2026-08-18 -- see UDPStreamer.h's own comment for why this class
// doesn't own a RemoteLogger instance itself (the .ino's loop() bridges the two, same pattern as
// every other consumeXRequest()/apply-to-some-other-object call site).
bool UDPStreamer::consumeSetRemoteLoggingRequest(bool &enabled) {
    if (!remoteLoggingRequested_) return false;
    remoteLoggingRequested_ = false;
    enabled = remoteLoggingRequestedValue_;
    return true;
}

void UDPStreamer::sendAudioFrame(uint32_t seq, const int16_t *samples, int count) {
    if (!streaming_) return;

    Protocol::AudioFrameHeader header;
    header.version = Protocol::kVersion;
    header.type = Protocol::kAudioFrame;
    header.seq = seq;
    header.sampleRate = Config::kSampleRateHz;
    header.encoding = Protocol::kEncodingInt16;
    header.reserved = 0;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&header, sizeof(header));
    udp_.write((const uint8_t *)samples, count * sizeof(int16_t));
    udp_.endPacket();
}

void UDPStreamer::sendStereoAudioFrame(uint32_t seq, const int16_t *left, const int16_t *right, int countPerChannel) {
    if (!streaming_) return;

    Protocol::AudioFrameHeader header;
    header.version = Protocol::kVersion;
    header.type = Protocol::kStereoAudioFrame;
    header.seq = seq;
    header.sampleRate = Config::kSampleRateHz;
    header.encoding = Protocol::kEncodingInt16;
    header.reserved = 2; // channel count, informational -- see NetworkProtocol.h's AudioFrameHeader comment

    // Interleave L/R into one small stack buffer before the single UDP write -- matches
    // sendAudioFrame's one-write-per-packet shape rather than two separate writes per sample,
    // which would double the syscall/framing overhead for no benefit (the interleave itself is
    // cheap, countPerChannel is bounded by Config::kStereoAudioSamplesPerChannel).
    int16_t interleaved[Config::kStereoAudioSamplesPerChannel * 2];
    for (int i = 0; i < countPerChannel; i++) {
        interleaved[i * 2] = left[i];
        interleaved[i * 2 + 1] = right[i];
    }

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&header, sizeof(header));
    udp_.write((const uint8_t *)interleaved, countPerChannel * 2 * sizeof(int16_t));
    udp_.endPacket();
}

void UDPStreamer::sendAudioLevels(uint32_t timestampMs, int16_t topLeftPeak, int16_t topRightPeak, int16_t bottomLeftPeak, int16_t bottomRightPeak, bool usingBottomPair) {
    if (!streaming_) return;

    Protocol::AudioLevelsPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kAudioLevels;
    packet.timestampMs = timestampMs;
    packet.topLeftPeak = topLeftPeak;
    packet.topRightPeak = topRightPeak;
    packet.bottomLeftPeak = bottomLeftPeak;
    packet.bottomRightPeak = bottomRightPeak;
    packet.activePair = usingBottomPair ? 1 : 0;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}

void UDPStreamer::sendDOATelemetry(uint32_t seq, uint32_t timestampMs, float azimuthDeg, float confidence, float relativeLevel, uint8_t bandId) {
    if (!streaming_) return;

    Protocol::DOATelemetryPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kDOATelemetry;
    packet.seq = seq;
    packet.timestampMs = timestampMs;
    packet.azimuthDeg = azimuthDeg;
    packet.confidence = confidence;
    packet.relativeLevel = relativeLevel;
    packet.bandId = bandId;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}
