#include "UDPStreamer.h"
#include <WiFi.h>
#include <cstring>
#include "Config.h"

void UDPStreamer::begin() {
    WiFi.mode(WIFI_AP);
    // max_connection=2: the phone plus, optionally, the PeregrineMicArrayRearSensor companion
    // unit (see ../PeregrineMicArrayRearSensor/) joining as a second WiFi station to reach the
    // phone over the same LAN. This class's own registered-client tracking below is unaffected --
    // it still only ever talks UDP to one client (the phone); the rear sensor addresses the phone
    // directly, not through this device's application logic.
    WiFi.softAP(Config::kWiFiSSID, Config::kWiFiPassword, Config::kWiFiChannel, /*hidden=*/0, /*max_connection=*/2);
    udp_.begin(Config::kUDPPort);
}

void UDPStreamer::poll() {
    int packetSize = udp_.parsePacket();
    if (packetSize > 0) {
        // Sized for the largest incoming packet, SetFrequencyBandsPacket (3 + kMaxDOABands*9 = 48
        // bytes at kMaxDOABands=5) -- every other control packet this device accepts is far smaller.
        uint8_t buf[64];
        int len = udp_.read(buf, sizeof(buf));
        if (len > 0) {
            handlePacket(buf, len, udp_.remoteIP(), udp_.remotePort());
        }
    }

    if (streaming_ && (millis() - lastClientActivityMs_) > Config::kStreamingInactivityTimeoutMs) {
        streaming_ = false;
    }
}

void UDPStreamer::handlePacket(const uint8_t *data, int len, IPAddress remoteIP, uint16_t remotePort) {
    if (len < 2) return;
    uint8_t type = data[1];

    switch (type) {
        case Protocol::kHandshakePing: {
            Protocol::HandshakePongPacket pong;
            pong.version = Protocol::kVersion;
            pong.type = Protocol::kHandshakePong;
            pong.magic0 = Protocol::kPongMagic0;
            pong.magic1 = Protocol::kPongMagic1;
            udp_.beginPacket(remoteIP, remotePort);
            udp_.write((const uint8_t *)&pong, sizeof(pong));
            udp_.endPacket();
            break;
        }
        case Protocol::kSessionStart: {
            clientIP_ = remoteIP;
            clientPort_ = remotePort;
            streaming_ = true;
            lastClientActivityMs_ = millis();
            break;
        }
        case Protocol::kSessionStop: {
            if (remoteIP == clientIP_ && remotePort == clientPort_) {
                streaming_ = false;
            }
            break;
        }
        case Protocol::kSetFrequencyBands: {
            // Header (version, type, count) must be present; the `slots` array can be shorter than
            // the full fixed-size struct since the phone only sends `count` populated entries, not
            // padding out to kMaxDOABands -- so check against the header + count*slot size actually
            // needed, not sizeof(SetFrequencyBandsPacket).
            if (len < 3) break;
            uint8_t count = data[2];
            if (count > Protocol::kMaxDOABands) count = Protocol::kMaxDOABands;
            if (len < 3 + (int)(count * sizeof(Protocol::FrequencyBandSlot))) break;

            for (uint8_t i = 0; i < count; i++) {
                // memcpy rather than a raw pointer cast: `data` isn't guaranteed aligned for a
                // struct containing floats, and this is the safe, portable way to read a packed
                // wire struct out of an arbitrary byte buffer.
                memcpy(&activeBands_[i], data + 3 + i * sizeof(Protocol::FrequencyBandSlot), sizeof(Protocol::FrequencyBandSlot));
            }
            activeBandCount_ = count;
            break;
        }
        default:
            break;
    }
}

void UDPStreamer::sendAudioFrame(uint32_t seq, const int16_t *samples, int count) {
    if (!streaming_) return;

    Protocol::AudioFrameHeader header;
    header.version = Protocol::kVersion;
    header.type = Protocol::kAudioFrame;
    header.seq = seq;
    header.sampleRate = Config::kSampleRateHz;
    header.encoding = Protocol::kEncodingInt16;
    header.reserved = 0;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&header, sizeof(header));
    udp_.write((const uint8_t *)samples, count * sizeof(int16_t));
    udp_.endPacket();
}

void UDPStreamer::sendDOATelemetry(uint32_t seq, uint32_t timestampMs, float azimuthDeg, float confidence, float relativeLevel, uint8_t bandId) {
    if (!streaming_) return;

    Protocol::DOATelemetryPacket packet;
    packet.version = Protocol::kVersion;
    packet.type = Protocol::kDOATelemetry;
    packet.seq = seq;
    packet.timestampMs = timestampMs;
    packet.azimuthDeg = azimuthDeg;
    packet.confidence = confidence;
    packet.relativeLevel = relativeLevel;
    packet.bandId = bandId;

    udp_.beginPacket(clientIP_, clientPort_);
    udp_.write((const uint8_t *)&packet, sizeof(packet));
    udp_.endPacket();
}
