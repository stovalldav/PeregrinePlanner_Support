// DOAEstimator.h — left-right-only direction-of-arrival from two independent I2S masters (top
// pair, bottom pair). See Config.h's header comment for why this is 1D, not full 2D: true
// front-back measurement needs a cross-bus comparison, which needs the two buses on a
// synchronized clock -- a design that was tried and didn't work reliably on this hardware.
//
// Each bus's own left-right delay is measured independently (top pair, bottom pair) and
// averaged for better noise robustness than a single measurement. The result is reported as an
// azimuth constrained to the forward hemisphere (-90..+90 degrees from center, wrapped into
// [0,360) the same way a full 2D azimuth would be) -- never fabricates a "behind" reading, since
// that's genuinely not measurable with this hardware. This keeps the wire protocol and the phone
// app completely unchanged (both already expect a plain [0,360) azimuthDeg); only what value
// range actually gets produced is different.
#pragma once

#include <cstdint>

struct DOAResult {
    float azimuthDeg;  // [0, 360), but only ever in the forward hemisphere: 270..360..90
    float confidence;  // [0, 1]
};

class DOAEstimator {
public:
    // `topLeft`/`topRight` (bus 0) and `bottomLeft`/`bottomRight` (bus 1) are NOT
    // sample-synchronized with each other -- each pair is only ever compared against its own
    // bus-mate, never cross-bus. All four windows must be `windowSamples` long
    // (Config::kDOAWindowSamples).
    //
    // `lowHz`/`highHz`: when both describe a valid band (lowHz > 0 and highHz > lowHz), all four
    // windows are bandpass-filtered to that range before cross-correlation -- set by the phone
    // (see UDPStreamer's kSetFrequencyBand handling) to the typical call-frequency range of
    // whichever species is currently being tracked, so a busy multi-bird soundscape is more
    // likely to isolate that species' onset rather than whichever transient is loudest overall
    // across the full spectrum. When the band is degenerate/unset (the default when no species is
    // tracked), no filtering is applied -- exactly the original full-spectrum behavior. This is a
    // coarse heuristic, not true source separation -- see MIC_ARRAY_MULTI_UNIT_PLAN.md (repo
    // root) and the app's SpeciesFrequencyEstimator.swift for the honest caveats on how
    // approximate the frequency ranges themselves are.
    static DOAResult estimate(
        const int16_t *topLeft, const int16_t *topRight,
        const int16_t *bottomLeft, const int16_t *bottomRight,
        int windowSamples, float lowHz, float highHz
    );

private:
    // Normalized cross-correlation over +/-Config::kMaxLagSamples, with parabolic sub-sample
    // interpolation around the integer peak. Returns the estimated delay in samples (positive
    // means `right` lags `left`, i.e. the sound arrived at `left` first) and the peak
    // correlation coefficient (a rough per-pair confidence signal).
    static void pairDelay(const int16_t *left, const int16_t *right, int windowSamples, float &delaySamplesOut, float &peakCorrelationOut);

    // Writes a bandpass-filtered copy of `input` into `output` (both `windowSamples` long) using
    // a standard constant-0dB-peak-gain RBJ ("Audio EQ Cookbook") biquad bandpass, reset fresh for
    // each call -- these are independent captured windows, not a continuous stream, so there's no
    // persistent filter state to carry across calls. Plain copy (no-op) if lowHz/highHz don't
    // describe a valid band.
    static void applyBandpass(const int16_t *input, int16_t *output, int windowSamples, float lowHz, float highHz);
};
