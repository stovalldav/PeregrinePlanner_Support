#include "DOAEstimator.h"
#include "Config.h"
#include <cmath>

void DOAEstimator::applyBandpass(const int16_t *input, int16_t *output, int windowSamples, float lowHz, float highHz) {
    // Degenerate/unset band: pass through unchanged -- this is the default (full-spectrum,
    // exactly the original behavior) whenever no species is actively being tracked.
    float nyquist = (float)Config::kSampleRateHz * 0.5f;
    if (lowHz <= 0.0f || highHz <= lowHz || highHz >= nyquist) {
        for (int i = 0; i < windowSamples; i++) output[i] = input[i];
        return;
    }

    // Standard RBJ "Audio EQ Cookbook" bandpass biquad, constant 0dB peak gain (doesn't boost the
    // passband, just attenuates outside it) -- center frequency as the geometric mean of the
    // band edges, Q derived from the bandwidth in Hz.
    float f0 = sqrtf(lowHz * highHz);
    float bwHz = highHz - lowHz;
    float q = f0 / bwHz;

    float w0 = 2.0f * (float)M_PI * f0 / (float)Config::kSampleRateHz;
    float cosW0 = cosf(w0);
    float sinW0 = sinf(w0);
    float alpha = sinW0 / (2.0f * q);

    float b0 = alpha;
    float b1 = 0.0f;
    float b2 = -alpha;
    float a0 = 1.0f + alpha;
    float a1 = -2.0f * cosW0;
    float a2 = 1.0f - alpha;
    b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;

    float x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (int i = 0; i < windowSamples; i++) {
        float x0 = (float)input[i];
        float y0 = b0 * x0 + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
        x2 = x1; x1 = x0;
        y2 = y1; y1 = y0;
        if (y0 > 32767.0f) y0 = 32767.0f;
        if (y0 < -32768.0f) y0 = -32768.0f;
        output[i] = (int16_t)y0;
    }
}

float DOAEstimator::energyRetentionRatio(const int16_t *raw, const int16_t *filtered, int windowSamples) {
    float rawEnergy = 0, filteredEnergy = 0;
    for (int i = 0; i < windowSamples; i++) {
        float r = raw[i];
        float f = filtered[i];
        rawEnergy += r * r;
        filteredEnergy += f * f;
    }
    // Near-silent window (well below any real signal, let alone noise floor) -- nothing meaningful
    // to penalize; returning 1.0 (no penalty) avoids dividing by ~0 and matches this function's
    // purpose (distinguish narrowband-vs-broadband CONTENT, not flag silence -- silence is already
    // handled by pairDelay's own near-zero-correlation result).
    if (rawEnergy < 1.0f) return 1.0f;
    float ratio = filteredEnergy / rawEnergy;
    if (ratio > 1.0f) ratio = 1.0f; // shouldn't exceed 1 mathematically; clamped defensively
    if (ratio < 0.0f) ratio = 0.0f;
    return ratio;
}

void DOAEstimator::pairDelay(const int16_t *left, const int16_t *right, int windowSamples, float &delaySamplesOut, float &peakCorrelationOut) {
    int maxLag = Config::kMaxLagSamples;
    float bestCorr = -1e9f;
    int bestLag = 0;

    // `float` throughout, not `double` -- the ESP32-S3 only has a single-precision hardware FPU,
    // so `double` arithmetic here silently falls back to software-emulated floating point, which
    // real-device testing showed to be catastrophically slow in this hot loop (called up to
    // 2*kMaxLagSamples+1 times per pairDelay() call, each iterating the full analysis window) --
    // slow enough with 2-3 simultaneous Radar Mode bands to stall loop() long enough to starve the
    // classification audio ring buffer (see RingBuffer::skippedSamples()). `float` is standard and
    // sufficient for a peak-picking correlation search like this (relative comparison, not
    // absolute precision), matching every other DSP calculation in this codebase.
    auto correlationAtLag = [&](int lag) -> float {
        int start = (lag < 0) ? -lag : 0;
        int end = (lag < 0) ? windowSamples : windowSamples - lag;
        if (end <= start) return 0.0f;
        float sumLR = 0, sumLL = 0, sumRR = 0;
        for (int n = start; n < end; n++) {
            float l = left[n];
            float r = right[n + lag];
            sumLR += l * r;
            sumLL += l * l;
            sumRR += r * r;
        }
        float denom = sqrtf(sumLL * sumRR);
        return (denom > 1e-6f) ? (sumLR / denom) : 0.0f;
    };

    for (int lag = -maxLag; lag <= maxLag; lag++) {
        float corr = correlationAtLag(lag);
        if (corr > bestCorr) {
            bestCorr = corr;
            bestLag = lag;
        }
    }

    // Parabolic sub-sample interpolation around the true integer peak.
    float corrAtBest = correlationAtLag(bestLag);
    float corrBeforeBest = (bestLag > -maxLag) ? correlationAtLag(bestLag - 1) : corrAtBest;
    float corrAfterBest = (bestLag < maxLag) ? correlationAtLag(bestLag + 1) : corrAtBest;

    float denom = (corrBeforeBest - 2 * corrAtBest + corrAfterBest);
    float subSampleOffset = 0.0f;
    if (fabsf(denom) > 1e-6f) {
        subSampleOffset = 0.5f * (corrBeforeBest - corrAfterBest) / denom;
        if (subSampleOffset > 1.0f) subSampleOffset = 1.0f;
        if (subSampleOffset < -1.0f) subSampleOffset = -1.0f;
    }

    delaySamplesOut = (float)bestLag + subSampleOffset;
    peakCorrelationOut = bestCorr;
}

DOAResult DOAEstimator::estimate(
    const int16_t *topLeft, const int16_t *topRight,
    const int16_t *bottomLeft, const int16_t *bottomRight,
    int windowSamples, float lowHz, float highHz
) {
    // Static, not stack-allocated: these windows are Config::kDOAWindowSamples (1024) int16s
    // each, and estimate() is only ever called from the single-threaded main loop() (see
    // PeregrineMicArray.ino), so there's no re-entrancy concern -- matches this codebase's
    // existing preference for avoiding heap/dynamic allocation in this path.
    static int16_t filteredTopLeft[Config::kDOAWindowSamples];
    static int16_t filteredTopRight[Config::kDOAWindowSamples];
    static int16_t filteredBottomLeft[Config::kDOAWindowSamples];
    static int16_t filteredBottomRight[Config::kDOAWindowSamples];

    applyBandpass(topLeft, filteredTopLeft, windowSamples, lowHz, highHz);
    applyBandpass(topRight, filteredTopRight, windowSamples, lowHz, highHz);
    applyBandpass(bottomLeft, filteredBottomLeft, windowSamples, lowHz, highHz);
    applyBandpass(bottomRight, filteredBottomRight, windowSamples, lowHz, highHz);

    // Left-right (X) delay, measured independently on each bus (no cross-bus comparison -- see
    // header) and averaged for noise robustness.
    float delayTop, corrTop, delayBottom, corrBottom;
    pairDelay(filteredTopLeft, filteredTopRight, windowSamples, delayTop, corrTop);
    pairDelay(filteredBottomLeft, filteredBottomRight, windowSamples, delayBottom, corrBottom);
    float delayX = (delayTop + delayBottom) / 2.0f;

    // pairDelay's positive-delay means "right lags left" i.e. sound arrived at the LEFT mic
    // first, meaning the source is on the LEFT -- the negative of "rightward" component, hence
    // the sign flip below.
    float normX = -delayX / (float)Config::kMaxLagSamples; // rightward-positive
    if (normX > 1.0f) normX = 1.0f; else if (normX < -1.0f) normX = -1.0f;

    // For a linear 2-mic pair under the standard far-field DOA model, normalized delay IS sin(theta)
    // (theta measured from broadside/straight-ahead) -- delay = (spacing/c)*sin(theta), and normX
    // divides by the theta=90 case (max possible delay), so normX == sin(theta) directly. Recovering
    // theta is therefore asin(normX), not atan2(normX, 1) -- an earlier version of this file used
    // atan2 here, reasoning it would "constrain to the forward hemisphere," but that reasoning was
    // wrong: atan2(x, 1) for x in [-1,1] only spans -45..+45 degrees, not -90..+90, confirmed on real
    // hardware by every reading clustering near exactly +-45 (the clamped extreme) instead of using
    // the full range. asin(normX) correctly spans the full -90..+90 forward hemisphere.
    float azimuthRad = asinf(normX);
    float azimuthDeg = azimuthRad * 180.0f / (float)M_PI;
    if (azimuthDeg < 0) azimuthDeg += 360.0f;

    float confidence = (corrTop + corrBottom) / 2.0f;
    if (confidence < 0) confidence = 0;
    if (confidence > 1) confidence = 1;

    // Spectral pre-filter, see energyRetentionRatio's own doc comment -- only meaningful when a
    // real band was actually requested (a degenerate/unset band means applyBandpass() already
    // passed the signal through unchanged, so retention would trivially be ~1.0 anyway, but
    // there's no real "expected frequency" to have verified against in that case).
    if (lowHz > 0.0f && highHz > lowHz) {
        float topRetention = energyRetentionRatio(topLeft, filteredTopLeft, windowSamples);
        float bottomRetention = energyRetentionRatio(bottomLeft, filteredBottomLeft, windowSamples);
        confidence *= (topRetention + bottomRetention) / 2.0f;
    }

    return DOAResult{azimuthDeg, confidence};
}

DOAResult DOAEstimator::estimateSingleBus(
    const int16_t *left, const int16_t *right, int windowSamples, float lowHz, float highHz
) {
    // Static, not stack-allocated -- same reasoning as estimate() above (single-threaded loop()
    // caller, no re-entrancy concern).
    static int16_t filteredLeft[Config::kDOAWindowSamples];
    static int16_t filteredRight[Config::kDOAWindowSamples];

    applyBandpass(left, filteredLeft, windowSamples, lowHz, highHz);
    applyBandpass(right, filteredRight, windowSamples, lowHz, highHz);

    float delay, corr;
    pairDelay(filteredLeft, filteredRight, windowSamples, delay, corr);

    // Same sign convention and asin-based recovery as estimate() -- see its comment for why
    // asin(normX), not atan2. No cross-pair averaging here: there's only the one pair.
    float normX = -delay / (float)Config::kMaxLagSamples;
    if (normX > 1.0f) normX = 1.0f; else if (normX < -1.0f) normX = -1.0f;

    float azimuthRad = asinf(normX);
    float azimuthDeg = azimuthRad * 180.0f / (float)M_PI;
    if (azimuthDeg < 0) azimuthDeg += 360.0f;

    float confidence = corr;
    if (confidence < 0) confidence = 0;
    if (confidence > 1) confidence = 1;

    // Spectral pre-filter, see energyRetentionRatio's own doc comment / estimate()'s matching
    // comment for the full reasoning.
    if (lowHz > 0.0f && highHz > lowHz) {
        confidence *= energyRetentionRatio(left, filteredLeft, windowSamples);
    }

    return DOAResult{azimuthDeg, confidence};
}
