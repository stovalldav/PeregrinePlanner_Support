// I2SCapture.h — wraps one ESP32-S3 I2S peripheral in standard stereo RX mode, reading two
// INMP441s that share a bus (one L-select, one R-select).
//
// By default both buses are independent I2S masters with their own separate BCLK/WS pins. A board
// physically reworked per CONFIGURABLE_FLEET_PLAN.md Part C (bottom-bus BCLK/WS jumpered from the
// top bus) can instead run bus 1 as a clock SLAVE -- pass `role = I2S_ROLE_SLAVE` and
// `deferEnable = true` for both buses, enable the MASTER first so a real BCLK/WS is already
// running, then enable() the slave against it and relock() the slave once so its WS-edge detector
// locks from a clean READY state (a slave enabled before any clock exists can latch a half-frame
// off -- observed as one stereo slot reading a permanent zero). Gated on
// Config::kBottomBusClockSlave.
#pragma once

#include <cstdint>
#include "driver/i2s_std.h"

class I2SBus {
public:
    // `port` is I2S_NUM_0 or I2S_NUM_1. `bclk`/`ws` are the clock GPIOs -- outputs for a master,
    // inputs (driven externally) for a slave. `din` is this bus's data GPIO. When `deferEnable` is
    // true, begin() inits the channel but does NOT start it -- the caller must call enable() (used
    // to control master/slave start order).
    bool begin(i2s_port_t port, int bclk, int ws, int din, uint32_t sampleRateHz,
               i2s_role_t role = I2S_ROLE_MASTER, bool deferEnable = false);

    // Starts a channel init'd with deferEnable = true. Safe to call once; no-op if already enabled
    // or not init'd.
    bool enable();

    // Stop + immediately restart an already-enabled channel (RUNNING -> READY -> RUNNING) so a
    // slave RX re-locks its WS-edge detector to an external clock that is now genuinely running.
    // Returns false (no-op) if the channel was never enabled.
    bool relock();

    // Blocking read of `frameCount` stereo frames (frameCount samples per channel), bounded to
    // `timeoutMs` -- not portMAX_DELAY, so a stalled bus reports failure and lets the caller's
    // task loop retry rather than blocking forever. Decodes each INMP441's 24-bit-in-32-bit I2S
    // word down to int16 (right-shift by 16: 8 bits to strip the padding, 8 more to reduce
    // 24-bit range to 16-bit — acceptable precision loss for wireless streaming and
    // cross-correlation, both of which only need relative timing/amplitude, not full 24-bit
    // dynamic range). `left`/`right` must each have room for `frameCount` samples.
    bool readFrames(int16_t *left, int16_t *right, int frameCount, uint32_t timeoutMs = 1000);

    // Last undecoded 32-bit I2S word seen for each slot on the most recent readFrames() call --
    // a bring-up/troubleshooting aid. A slot stuck at exactly 0x00000000 means nothing is driving
    // the data line during that half-frame (mic unpowered, data pad open, or L/R-select floating);
    // a nonzero-but-unchanging value means the mic is powered but producing no audio. Decoded
    // int16 min/max/peak can't tell those two apart because a sub-2^16 DC level rounds to 0.
    int32_t lastRawLeft() const { return lastRawLeft_; }
    int32_t lastRawRight() const { return lastRawRight_; }

private:
    i2s_chan_handle_t rxHandle_ = nullptr;
    bool enabled_ = false;
    int32_t *rawBuffer_ = nullptr;
    int rawBufferCapacityFrames_ = 0;
    int32_t lastRawLeft_ = 0;
    int32_t lastRawRight_ = 0;
};
