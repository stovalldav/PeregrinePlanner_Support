// I2SCapture.h — wraps one ESP32-S3 I2S peripheral in standard stereo RX mode, reading two
// INMP441s that share a bus (one L-select, one R-select). Both buses are independent I2S masters
// with their own separate BCLK/WS pins -- see Config.h's header comment for why (an earlier,
// more ambitious true-sample-synchronized design via I2S master/slave was tried and abandoned
// after exhausting the documented configuration space without it working reliably).
#pragma once

#include <cstdint>
#include "driver/i2s_std.h"

class I2SBus {
public:
    // `port` is I2S_NUM_0 or I2S_NUM_1. `bclk`/`ws` are this bus's own dedicated clock GPIOs
    // (each bus generates its own, independent of the other). `din` is this bus's data GPIO.
    bool begin(i2s_port_t port, int bclk, int ws, int din, uint32_t sampleRateHz);

    // Blocking read of `frameCount` stereo frames (frameCount samples per channel), bounded to
    // `timeoutMs` -- not portMAX_DELAY, so a stalled bus reports failure and lets the caller's
    // task loop retry rather than blocking forever. Decodes each INMP441's 24-bit-in-32-bit I2S
    // word down to int16 (right-shift by 16: 8 bits to strip the padding, 8 more to reduce
    // 24-bit range to 16-bit — acceptable precision loss for wireless streaming and
    // cross-correlation, both of which only need relative timing/amplitude, not full 24-bit
    // dynamic range). `left`/`right` must each have room for `frameCount` samples.
    bool readFrames(int16_t *left, int16_t *right, int frameCount, uint32_t timeoutMs = 1000);

private:
    i2s_chan_handle_t rxHandle_ = nullptr;
    int32_t *rawBuffer_ = nullptr;
    int rawBufferCapacityFrames_ = 0;
};
