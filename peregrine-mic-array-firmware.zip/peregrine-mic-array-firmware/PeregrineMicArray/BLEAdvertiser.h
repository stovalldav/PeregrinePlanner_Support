// BLEAdvertiser.h — event-gated BLE advertising for zero-config node discovery
// (BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17). Broadcasts this node's deviceId/nodeType/
// current-IP/capability-flags as a small custom manufacturer-data payload so the phone can
// discover and auto-connect without any prior configuration or WiFi-side bootstrap -- see that
// plan doc for the full design rationale (why BLE, not a WiFi-only fix; why event-gated, not
// continuous).
//
// Non-connectable advertising only -- no GATT server, no BLE connection is ever established.
// Purely a broadcast discovery/bootstrap layer; actual audio/telemetry stays on WiFi UDP exactly
// as before.
//
// Event-gated to bound WiFi/BLE coexistence risk (user request, 2026-08-17): only ever active
// while this node has no live registered UDP client (see UDPStreamer::isStreaming()) -- silent
// for the entire duration of an established session, which is exactly when real-time audio is
// flowing and coexistence would matter most. Advertises at boot (covers first connection) and
// resumes whenever the registered client goes stale (covers reconnect) -- caller (the .ino) drives
// this by passing `!network.isStreaming()` into poll() every loop() iteration, mirroring how
// pollFailover()/pollReconnect() are already driven from the same loop().
#pragma once

#include <cstdint>
#include <WiFiUdp.h> // pulls in IPAddress -- matches UDPStreamer.h's own include, not a UDP dependency here

class BLEAdvertiser {
public:
    // Starts the BLE stack (BLEDevice::init()) -- call once from setup(). Does not start
    // advertising yet; the first poll() call does that once WiFi has an IP.
    void begin();

    // Call every loop() iteration. `hasClient` should be the UDPStreamer's own isStreaming() --
    // starts/stops advertising to track it, and refreshes the advertised IP if it changes while
    // already advertising (DHCP renewal). `currentIP` is passed in rather than read internally via
    // WiFi.localIP() because that call is only valid in STA mode -- a node currently hosting its
    // own AP (kRolePrimary, or a failed-over Secondary) needs WiFi.softAPIP() instead, and only the
    // caller (the .ino, via UDPStreamer::isCurrentlyHosting()) knows which applies.
    void poll(bool hasClient, IPAddress currentIP);

private:
    void startAdvertising(IPAddress ip);
    void stopAdvertising();

    bool advertising_ = false;
    IPAddress lastAdvertisedIP_;
    uint8_t deviceId_[6] = {};
};
