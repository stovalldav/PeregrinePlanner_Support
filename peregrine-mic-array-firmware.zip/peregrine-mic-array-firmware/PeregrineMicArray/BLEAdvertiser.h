// BLEAdvertiser.h — event-gated BLE advertising for zero-config node discovery
// (BLE_NODE_DISCOVERY_PLAN.md, added 2026-08-17). Broadcasts this node's deviceId/nodeType/
// current-IP/capability-flags as a small custom manufacturer-data payload so the phone can
// discover and auto-connect without any prior configuration or WiFi-side bootstrap -- see that
// plan doc for the full design rationale (why BLE, not a WiFi-only fix; why event-gated, not
// continuous). Mirrors ../PeregrineMicArray/BLEAdvertiser.h directly.
//
// **BLE-GATT Wi-Fi provisioning (CONFIGURABLE_FLEET_PLAN.md follow-up, 2026-09-07):** optionally
// (Config::kBleProvisioningEnabled) this also stands up a small connectable GATT server so the
// phone can read the current Wi-Fi/AP/role config and stage/commit changes *over BLE* -- the
// password never crosses Wi-Fi (see the security note in that plan's Part A5). Proximity is the
// gate (BLE is ~10 m); Config::kBleProvisioningEncrypted additionally requires an encrypted link
// for writes. The GATT ops mirror the UDP kSetWiFiConfig / kWiFiConfigReport exactly, so
// WiFiConfigStore and the app's decoder are reused unchanged.
//
// Discovery advertising stays event-gated to bound WiFi/BLE coexistence risk: only ever active
// while this node has no live registered UDP client (see UDPStreamer::isStreaming()). The GATT
// server, once created, persists (an in-progress provisioning connection isn't torn down just
// because a Wi-Fi session started), but no NEW BLE connection can be made while advertising is
// suppressed.
#pragma once

#include <cstdint>
#include <WiFiUdp.h> // pulls in IPAddress -- matches UDPStreamer.h's own include, not a UDP dependency here
#include "WiFiConfigStore.h"

class BLECharacteristic;
class BLEServer;

class BLEAdvertiser {
public:
    // Starts the BLE stack (BLEDevice::init()) -- call once from setup(). Does not start
    // advertising yet; the first poll() call does that once WiFi has an IP.
    void begin();

    // Optional -- call once from setup() right after begin() when Config::kBleProvisioningEnabled.
    // Stands up the GATT server (config-write + config-report characteristics) and makes the
    // advertisement carry the provisioning service UUID in its scan response so the app can filter.
    void enableProvisioning(WiFiConfigStore &cfg);

    // Call every loop() iteration. `hasClient` should be the UDPStreamer's own isStreaming() --
    // starts/stops advertising to track it, and refreshes the advertised IP if it changes while
    // already advertising (DHCP renewal). `currentIP` is passed in rather than read internally via
    // WiFi.localIP() because that call is only valid in STA mode -- a node currently hosting its
    // own AP (kRolePrimary, or a failed-over Secondary) needs WiFi.softAPIP() instead, and only the
    // caller (the .ino, via UDPStreamer::isCurrentlyHosting()) knows which applies.
    void poll(bool hasClient, IPAddress currentIP);

    // Call every loop() iteration when enableProvisioning() was used -- applies any config op the
    // phone wrote over the GATT characteristic (mirrors UDPStreamer's kSetWiFiConfig handler) and
    // reboots on commit / reset. No-op if provisioning isn't enabled or nothing is pending.
    void pollProvisioning();

private:
    void startAdvertising(IPAddress ip);
    void stopAdvertising();
    void refreshReportCharacteristic();

    bool advertising_ = false;
    IPAddress lastAdvertisedIP_;
    uint8_t deviceId_[6] = {};

    // --- GATT provisioning ---
    WiFiConfigStore *cfg_ = nullptr;
    BLEServer *server_ = nullptr;
    BLECharacteristic *writeChar_ = nullptr;
    BLECharacteristic *reportChar_ = nullptr;
    bool provisioning_ = false;

    // The BLE write callback runs in the BLE task; it just copies the op bytes here and sets the
    // flag, and pollProvisioning() on the main loop does the actual WiFiConfigStore work + any
    // ESP.restart() -- same "callback stashes, loop() acts" pattern as UDPStreamer's *Requested_.
    volatile bool opPending_ = false;
    uint8_t opBuf_[600] = {};
    volatile int opLen_ = 0;

    friend class BLEProvWriteCallback;
};
