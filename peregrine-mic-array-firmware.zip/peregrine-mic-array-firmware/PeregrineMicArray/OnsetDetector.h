// OnsetDetector.h — a fast/slow envelope-follower energy gate. Feeds successive audio blocks
// in; reports whether a transient (a bird call onset, ideally) is currently active, so the
// (cheap but non-zero) DOA cross-correlation only runs on real events, not continuously on
// background noise. Runs on bus X's reference channel (M0) only — one gate decides when both
// buses' analysis windows get captured.
#pragma once

#include <cstdint>
#include "Config.h"

class OnsetDetector {
public:
    // Feed one block of samples; returns true if this block completes a new onset trigger
    // (rate-limited per Config::kOnsetMinIntervalMs -- won't return true again for the same
    // sustained call until that interval has passed).
    //
    // `nowMicros` is micros() sampled right after this block was read -- it timestamps the block's
    // END. Used to latch the threshold-crossing instant to sub-block precision for multi-node TDOA
    // (MULTI_NODE_TDOA_PLAN.md Phase 3). The crossing that opens an onset generally happens in an
    // EARLIER block than the one that finally returns true (there's a kOnsetMinHoldMs debounce),
    // so its micros() is latched at the crossing and read back via lastCrossingMicros().
    bool processBlock(const int16_t *samples, int count, uint32_t nowMs, uint32_t nowMicros);

    float lastRelativeLevel() const { return lastFastEnvelope_; }
    // micros() of the fast-envelope threshold crossing that opened the most recent onset, linearly
    // interpolated to sub-block resolution between the previous block's ending envelope and this
    // block's. Re-latched each time the envelope goes from below to above threshold; meaningful
    // once processBlock() has returned true at least once.
    uint32_t lastCrossingMicros() const { return lastCrossingMicros_; }
    // Diagnostic accessors -- so a caller can print the actual envelope/floor/threshold state
    // directly, rather than only being able to observe whether a trigger happened. Needed
    // because a real-device report showed onset events firing early after boot and then
    // apparently never again -- these numbers directly answer whether the fast envelope simply
    // isn't reaching the trigger threshold (and by how much), rather than requiring more guessing.
    float currentFastEnvelope() const { return fastEnvelope_; }
    float currentSlowFloor() const { return slowFloor_; }
    float currentThreshold() const { return slowFloor_ * Config::kOnsetTriggerRatio; }
    // How many blocks have been clamped as likely electrical-noise spikes rather than real audio
    // -- see Config::kOutlierRejectRatio. Should be near-zero after the hardware rewire.
    uint32_t outlierRejectedCount() const { return outlierRejectedCount_; }

private:
    // Clamps an isolated single-block RMS spike back to a short causal baseline (average of the
    // last 2 accepted blocks) if it exceeds that baseline by more than kOutlierRejectRatio. A real
    // acoustic onset stays elevated for several consecutive blocks, so at most the very first
    // block of a genuine loud sound gets clamped -- the second block raises the baseline and
    // rejection stops applying. Skipped during the first 2 blocks (no baseline yet).
    float filterOutlier(float rawBlockRMS);

    float fastEnvelope_ = 0;
    float slowFloor_ = 1.0f; // starts nonzero so an initial ratio check isn't divide-by-near-zero
    float lastFastEnvelope_ = 0;
    uint32_t lastCrossingMicros_ = 0;
    uint32_t aboveThresholdSinceMs_ = 0;
    bool currentlyAboveThreshold_ = false;
    uint32_t lastTriggerMs_ = 0;
    bool everTriggered_ = false;

    float prevAcceptedRMS1_ = 0;
    float prevAcceptedRMS2_ = 0;
    int acceptedBlockCount_ = 0;
    uint32_t outlierRejectedCount_ = 0;
};
